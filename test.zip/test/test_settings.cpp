/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <filesystem>
#include <gtest/gtest.h>

/* Unit Under Test */
#include "settings.h"

/* === Fixtures === */

/* === Tests === */
/**
 * @brief Test the technology factors of the settings.
 */
TEST(Settings, TechnologyFactors)
{
    /* Create default settings */
    Settings settings{};

    /* Check the default technology factors */
    ASSERT_EQ(settings.technology_factor("engine_mass"), 1.0);
    ASSERT_EQ(settings.technology_factor("nacelle_mass"), 1.0);
    ASSERT_EQ(settings.technology_factor("pylon_mass"), 1.0);
    ASSERT_EQ(settings.technology_factor("engine_efficiency"), 1.0);

    /* Check accessing invalid factors */
    ASSERT_THROW(settings.technology_factor("invalid_factor"), std::out_of_range);
}
