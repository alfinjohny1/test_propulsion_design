/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <filesystem>
#include <gtest/gtest.h>

/* Unit Under Test */
#include "mass/default/default_mass.h"
#include "mass/default/turbofan.cpp"

/* === Types ===*/
using Point_2 = geom2::Point_2;
using Polygon_2 = geom2::Polygon_2;
using PolygonSection = geom2::PolygonSection;
using AirfoilSection = geom2::AirfoilSection;

/* === Fixtures === */
class MassNacelle : public ::testing::Test
{
protected:
    void SetUp() override
    {
        /* Create the shape */
        Polygon_2 shape{};
        shape.push_back(Point_2(-1, -1));
        shape.push_back(Point_2(1, -1));
        shape.push_back(Point_2(1, 1));
        shape.push_back(Point_2(-1, 1));

        // Initialize nacelle_surface here
        nacelle_surface.sections.emplace_back(shape);
        nacelle_surface.sections.emplace_back(shape);
        nacelle_surface.sections.emplace_back(shape);
        nacelle_surface.sections[0].origin = {0, 0, 0};
        nacelle_surface.sections[0].set_width(1.0);
        nacelle_surface.sections[1].origin = {0, 1, 2};
        nacelle_surface.sections[1].set_width(1.0);
        nacelle_surface.sections[2].origin = {0, 2, 4};
        nacelle_surface.sections[2].set_width(1.0);
    }

    geom2::MultisectionSurface<PolygonSection> nacelle_surface;
};


class MassPylon : public ::testing::Test
{
protected:
    void SetUp() override
    {
        /* Create the shape */
        Polygon_2 shape{};
        shape.push_back(Point_2(0, 0));
        shape.push_back(Point_2(0.5, 0.2));
        shape.push_back(Point_2(1.0, 0.0));
        shape.push_back(Point_2(0.5, 0.0));

        /* Create the airfoil */
        AirfoilSection airfoil{shape};

        /* Create a simple pylon surface with 2 sections */
        pylon_surface.sections.emplace_back(airfoil);
        pylon_surface.sections.emplace_back(airfoil);
        pylon_surface.sections.emplace_back(airfoil);
        pylon_surface.sections[0].origin = geom2::Point_3(0, 0, 0);
        pylon_surface.sections[0].set_chord_length(3.0);
        pylon_surface.sections[1].origin = geom2::Point_3(0, 0, -2);
        pylon_surface.sections[1].set_chord_length(1.0);
        pylon_surface.sections[2].origin = geom2::Point_3(0, 0, -4);
        pylon_surface.sections[2].set_chord_length(1.0);
    }

    geom2::MultisectionSurface<AirfoilSection> pylon_surface{};
};
/* === Tests === */
/**
 * @brief Test analysing the mass a kerosene turbofan engine.
 */

TEST(TurbofanKeroseneDefaultMass, AnalyseEngineMass)
{
    const double thrust = 100;
    const double technology_factor = 1;
    const double engine_mass = mass::calculate_engine_mass(technology_factor, thrust);
    EXPECT_DOUBLE_EQ(engine_mass, 308.16);
}

TEST(TurbofanKeroseneDefaultMass, AnalyseEngineCG)
{
    double engine_length = 4;
    Eigen::Vector3d engine_cg = mass::calculate_engine_CG(engine_length);
    EXPECT_EQ(engine_cg, Eigen::Vector3d(2, 0, 0));
}

TEST(TurbofanKeroseneDefaultMass, AnalyseEngineInertia)
{
    double height = 10.0;
    double width = 10.0;
    double length = 10.0;
    double mass = 5.0;

    Eigen::Matrix3d inertia_tensor = mass::calculate_engine_inertia(height, width, length, mass);
    Eigen::Matrix3d inertia_tensor_expected;
    inertia_tensor_expected <<  62.5, 0.0   , 0.0,
                                0.0  , 72.91, 0.0,
                                0.0  , 0.0   , 72.91;
    EXPECT_TRUE(inertia_tensor.isApprox(inertia_tensor_expected, 1e-1));
}

TEST(TurbofanKeroseneDefaultMass, AnalyseNacelleMass)
{
    const double thrust = 100;
    const double technology_factor = 1;
    double nacelle_mass = mass::calculate_nacelle_mass(technology_factor, thrust);
    EXPECT_DOUBLE_EQ(nacelle_mass, 595.81);
}

TEST_F(MassNacelle, AnalyseNacelleCG)
{
    /* Analyse the default */
    Eigen::Vector3d nacelle_cg = mass::calculate_nacelle_CG(nacelle_surface);
    EXPECT_EQ(nacelle_cg, Eigen::Vector3d(0.0, 1.0, 2.0));

    /* Change the normal of the nacelle */
    nacelle_surface.normal = {1, 0, 0};
    nacelle_surface.rotation_z = -1.5708; // Rotate 90 degrees
    nacelle_cg = mass::calculate_nacelle_CG(nacelle_surface);
    EXPECT_TRUE(nacelle_cg.isApprox(Eigen::Vector3d(2.0, 1.0, 0.0), 1e-4));
}

TEST_F(MassNacelle, AnalyseNacelleInertia)
{
    /* Analyse the default */
    Eigen::Matrix3d inertia_tensor = mass::calculate_nacelle_inertia(nacelle_surface);
    // TODO needs to be also checked by hand
    Eigen::Matrix3d inertia_tensor_expected;
    inertia_tensor_expected <<  52.9562, 0.0       , 0.0,
                                0.0    , 36.3062   , 16.0671,
                                0.0    , 16.0671   , 25.291;
    EXPECT_TRUE(inertia_tensor.isApprox(inertia_tensor_expected, 1e-1));
}

TEST(TurbofanKeroseneDefaultMass, AnalysePylonMass)
{
    const double thrust = 100;
    const double technology_factor = 1;
    double pylon_mass = mass::calculate_pylon_mass(technology_factor, thrust);
    EXPECT_DOUBLE_EQ(pylon_mass, 233.53);
}

TEST_F(MassPylon, AnalysePylonCG)
{
    /* Analyse the default */
    Eigen::Vector3d centroid_pylon = mass::calculate_pylon_CG(pylon_surface);
    EXPECT_EQ(centroid_pylon, Eigen::Vector3d(0.75, 0, -2));

    /* Change the normal direction of the pylon */
    pylon_surface.normal = {0, 0, -1};
    centroid_pylon = mass::calculate_pylon_CG(pylon_surface);
    EXPECT_TRUE(centroid_pylon.isApprox(Eigen::Vector3d(0.75, 0, +2)));
}

TEST_F(MassPylon, AnalysePylonInertia)
{
    Eigen::Matrix3d inertia_tensor = mass::calculate_pylon_inertia(pylon_surface);
    // TODO needs to be also checked by hand
    Eigen::Matrix3d inertia_tensor_expected;
    inertia_tensor_expected <<  17.56  , 0.0,  5.17811,
                                0.0,  22.1972,  0.0,
                                5.17811, 0.0,    5.021;
    // EXPECT_EQ(inertia_tensor, inertia_tensor_expected);
    EXPECT_TRUE(inertia_tensor.isApprox(inertia_tensor_expected, 1e-1));
}
