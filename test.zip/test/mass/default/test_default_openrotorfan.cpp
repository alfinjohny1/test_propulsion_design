/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 *
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/*
 * Unit tests for the open-rotor mass analysis (FR-8.1 - FR-8.4).
 *
 * Expected values are calculated by hand from the formulas:
 *   engine  m = f_m (0.0159 T + 306.57) * 1.2
 *   nacelle m = f_n (0.0039 T + 595.42)
 *   pylon   m = f_p (0.0024 T + 233.29) * 1.5
 *   engine CG = (L/2, 0, 0)
 *   engine inertia (solid cylinder, r = (h + w) / 4):
 *     Ixx = m r^2 / 2,  Iyy = Izz = m (3 r^2 + L^2) / 12
 */

/* === Includes === */
#include <filesystem>
#include <gtest/gtest.h>

/* Unit Under Test (the helper functions are only defined in the source file) */
#include "mass/default/default_mass.h"
#include "mass/default/openrotorfan.cpp"

/* === Types ===*/
using Point_2 = geom2::Point_2;
using Polygon_2 = geom2::Polygon_2;
using PolygonSection = geom2::PolygonSection;
using AirfoilSection = geom2::AirfoilSection;

/* === Helpers === */
namespace
{
    constexpr double TOLERANCE = 1e-9;

    /* Nacelle surface of the turbofan mass tests: centroid at (0, 1, 2) */
    auto make_nacelle() -> geom2::MultisectionSurface<PolygonSection>
    {
        Polygon_2 shape{};
        shape.push_back(Point_2(-1, -1));
        shape.push_back(Point_2(1, -1));
        shape.push_back(Point_2(1, 1));
        shape.push_back(Point_2(-1, 1));

        geom2::MultisectionSurface<PolygonSection> nacelle;
        nacelle.sections.emplace_back(shape);
        nacelle.sections.emplace_back(shape);
        nacelle.sections.emplace_back(shape);
        nacelle.sections[0].origin = {0, 0, 0};
        nacelle.sections[0].set_width(1.0);
        nacelle.sections[1].origin = {0, 1, 2};
        nacelle.sections[1].set_width(1.0);
        nacelle.sections[2].origin = {0, 2, 4};
        nacelle.sections[2].set_width(1.0);
        return nacelle;
    }

    /* Pylon surface of the turbofan mass tests: centroid at (0.75, 0, -2) */
    auto make_pylon() -> geom2::MultisectionSurface<AirfoilSection>
    {
        Polygon_2 shape{};
        shape.push_back(Point_2(0, 0));
        shape.push_back(Point_2(0.5, 0.2));
        shape.push_back(Point_2(1.0, 0.0));
        shape.push_back(Point_2(0.5, 0.0));
        AirfoilSection airfoil{shape};

        geom2::MultisectionSurface<AirfoilSection> pylon;
        pylon.sections.emplace_back(airfoil);
        pylon.sections.emplace_back(airfoil);
        pylon.sections.emplace_back(airfoil);
        pylon.sections[0].origin = geom2::Point_3(0, 0, 0);
        pylon.sections[0].set_chord_length(3.0);
        pylon.sections[1].origin = geom2::Point_3(0, 0, -2);
        pylon.sections[1].set_chord_length(1.0);
        pylon.sections[2].origin = geom2::Point_3(0, 0, -4);
        pylon.sections[2].set_chord_length(1.0);
        return pylon;
    }

    /* Hand calculation of the solid-cylinder inertia */
    auto cylinder_inertia(const double height, const double width, const double length, const double mass) -> Eigen::Matrix3d
    {
        const double r = (height + width) / 4.0;
        Eigen::Matrix3d inertia = Eigen::Matrix3d::Zero();
        inertia(0, 0) = mass * r * r / 2.0;
        inertia(1, 1) = mass * (3.0 * r * r + length * length) / 12.0;
        inertia(2, 2) = inertia(1, 1);
        return inertia;
    }
} // namespace

/* === Layer 1: formulas with hand-calculated values === */
/**
 * @brief FR-8.1 engine mass: (0.0159 * 1000 + 306.57) * 1.2 = 386.964 kg.
 */
TEST(OpenrotorfanDefaultMass, EngineMass)
{
    EXPECT_NEAR(mass::calculate_engine_mass_openrotor(1.0, 1000.0), 386.964, TOLERANCE);
}

/**
 * @brief FR-8.1 the technology factor scales the engine mass: 0.8 * 386.964 = 309.5712 kg.
 */
TEST(OpenrotorfanDefaultMass, EngineMassTechnologyFactor)
{
    EXPECT_NEAR(mass::calculate_engine_mass_openrotor(0.8, 1000.0), 309.5712, TOLERANCE);
}

/**
 * @brief FR-8.1 the open-rotor engine mass is 1.2 times the turbofan regression line.
 */
TEST(OpenrotorfanDefaultMass, EngineMassZeroThrust)
{
    EXPECT_NEAR(mass::calculate_engine_mass_openrotor(1.0, 0.0), 306.57 * 1.2, TOLERANCE);
}

/**
 * @brief FR-8.2 engine CG at half the engine length on the engine axis.
 */
TEST(OpenrotorfanDefaultMass, EngineCG)
{
    EXPECT_EQ(mass::calculate_engine_CG_openrotor(4.0), Eigen::Vector3d(2.0, 0.0, 0.0));
    EXPECT_EQ(mass::calculate_engine_CG_openrotor(3.0), Eigen::Vector3d(1.5, 0.0, 0.0));
}

/**
 * @brief FR-8.2 solid-cylinder inertia: h = w = 2 m, L = 4 m, m = 12 kg -> diag(6, 19, 19), no products of inertia.
 */
TEST(OpenrotorfanDefaultMass, EngineInertia)
{
    const Eigen::Matrix3d inertia = mass::calculate_engine_inertia_openrotor(2.0, 2.0, 4.0, 12.0);

    Eigen::Matrix3d expected = Eigen::Matrix3d::Zero();
    expected(0, 0) = 6.0;
    expected(1, 1) = 19.0;
    expected(2, 2) = 19.0;
    EXPECT_TRUE(inertia.isApprox(expected, TOLERANCE)) << inertia;
}

/**
 * @brief FR-8.2 non-circular cross-section: the radius is the mean of height and width divided by 2.
 * h = 2 m, w = 4 m -> r = 1.5 m; L = 3 m, m = 8 kg -> Ixx = 9, Iyy = Izz = 0.6667 * (6.75 + 9) = 10.5.
 */
TEST(OpenrotorfanDefaultMass, EngineInertiaNonCircular)
{
    const Eigen::Matrix3d inertia = mass::calculate_engine_inertia_openrotor(2.0, 4.0, 3.0, 8.0);

    EXPECT_NEAR(inertia(0, 0), 9.0, TOLERANCE);
    EXPECT_NEAR(inertia(1, 1), 10.5, TOLERANCE);
    EXPECT_NEAR(inertia(2, 2), 10.5, TOLERANCE);
    EXPECT_NEAR(inertia(0, 1), 0.0, TOLERANCE);
    EXPECT_NEAR(inertia(0, 2), 0.0, TOLERANCE);
    EXPECT_NEAR(inertia(1, 2), 0.0, TOLERANCE);
}

/**
 * @brief FR-8.3 nacelle mass: 0.0039 * 1000 + 595.42 = 599.32 kg; with factor 0.8: 479.456 kg.
 */
TEST(OpenrotorfanDefaultMass, NacelleMass)
{
    EXPECT_NEAR(mass::calculate_nacelle_mass_openrotor(1.0, 1000.0), 599.32, TOLERANCE);
    EXPECT_NEAR(mass::calculate_nacelle_mass_openrotor(0.8, 1000.0), 479.456, TOLERANCE);
}

/**
 * @brief FR-8.4 pylon mass: (0.0024 * 1000 + 233.29) * 1.5 = 353.535 kg; with factor 0.8: 282.828 kg.
 */
TEST(OpenrotorfanDefaultMass, PylonMass)
{
    EXPECT_NEAR(mass::calculate_pylon_mass_openrotor(1.0, 1000.0), 353.535, TOLERANCE);
    EXPECT_NEAR(mass::calculate_pylon_mass_openrotor(0.8, 1000.0), 282.828, TOLERANCE);
}

/* === Layer 2: geometry-derived CG === */
/**
 * @brief FR-8.3 nacelle CG is the centroid of the surface, and it moves with the surface origin.
 */
TEST(OpenrotorfanDefaultMass, NacelleCGFollowsSurface)
{
    auto nacelle = make_nacelle();
    const Eigen::Vector3d cg = mass::calculate_nacelle_CG_openrotor(nacelle);
    EXPECT_TRUE(cg.isApprox(Eigen::Vector3d(0.0, 1.0, 2.0), 1e-9)) << cg.transpose();

    nacelle.origin = geom2::Point_3(1.0, 2.0, 3.0);
    const Eigen::Vector3d moved = mass::calculate_nacelle_CG_openrotor(nacelle);
    EXPECT_TRUE(moved.isApprox(cg + Eigen::Vector3d(1.0, 2.0, 3.0), 1e-9)) << moved.transpose();
}

/**
 * @brief FR-8.3 nacelle CG of a rotated surface: normal (1, 0, 0) and a rotation of -90 degrees
 * about z turn the centroid (0, 1, 2) into (2, 1, 0), as in the turbofan nacelle test.
 */
TEST(OpenrotorfanDefaultMass, NacelleCGFollowsRotation)
{
    auto nacelle = make_nacelle();
    nacelle.normal = {1, 0, 0};
    nacelle.rotation_z = -1.5708;

    const Eigen::Vector3d cg = mass::calculate_nacelle_CG_openrotor(nacelle);

    EXPECT_TRUE(cg.isApprox(Eigen::Vector3d(2.0, 1.0, 0.0), 1e-4)) << cg.transpose();
}

/**
 * @brief FR-8.4 pylon CG is the centroid of the surface, and it moves with the surface origin.
 */
TEST(OpenrotorfanDefaultMass, PylonCGFollowsSurface)
{
    auto pylon = make_pylon();
    const Eigen::Vector3d cg = mass::calculate_pylon_CG_openrotor(pylon);
    EXPECT_TRUE(cg.isApprox(Eigen::Vector3d(0.75, 0.0, -2.0), 1e-9)) << cg.transpose();

    pylon.origin = geom2::Point_3(1.0, 2.0, 3.0);
    const Eigen::Vector3d moved = mass::calculate_pylon_CG_openrotor(pylon);
    EXPECT_TRUE(moved.isApprox(cg + Eigen::Vector3d(1.0, 2.0, 3.0), 1e-9)) << moved.transpose();
}

/* === Layer 3: mass::Default::operator()(Openrotorfan<Kerosene>&) === */
/**
 * @brief Open-rotor engine with thrust 1000 N, dimensions h = w = 2 m, L = 4 m and the test nacelle.
 * Technology factors come from the configuration (set explicitly in each test).
 */
class OpenrotorfanMassAnalyzer : public ::testing::Test
{
  protected:
    void SetUp() override
    {
        engine.set_required_thrust(THRUST);
        engine.set_dimension({HEIGHT, WIDTH, LENGTH});
        engine.set_nacelle(make_nacelle());

        config = aixml::openDocument(std::filesystem::path{CMAKE_TEST_CONFIG_FILE});
        set_technology_factors(1.0, 1.0, 1.0);
    }

    void set_technology_factors(const double engine_mass, const double nacelle_mass, const double pylon_mass)
    {
        const std::string base = "module_configuration_file/program_settings/technology_factors/";
        config->at(base + "engine_mass/value") = engine_mass;
        config->at(base + "nacelle_mass/value") = nacelle_mass;
        config->at(base + "pylon_mass/value") = pylon_mass;
    }

    /* Create and initialize the analyzer with the current configuration, then analyze the engine */
    void analyze()
    {
        mass::Default analyzer{config};
        analyzer.initialize();
        analyzer(engine);
    }

    static constexpr double THRUST = 1000.0;
    static constexpr double HEIGHT = 2.0;
    static constexpr double WIDTH = 2.0;
    static constexpr double LENGTH = 4.0;
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{};
    std::shared_ptr<node> config;
};

/**
 * @brief Without a pre-set engine mass and without a pylon: engine and nacelle follow the formulas,
 * the pylon point mass stays zero.
 */
TEST_F(OpenrotorfanMassAnalyzer, WithoutPylon)
{
    analyze();

    const PointMass engine_mass = engine.pointmass(Component::Engine);
    EXPECT_NEAR(engine_mass.mass, 386.964, TOLERANCE);
    EXPECT_TRUE(engine_mass.CG.isApprox(Eigen::Vector3d(2.0, 0.0, 0.0)));
    EXPECT_TRUE(engine_mass.inertia.isApprox(cylinder_inertia(HEIGHT, WIDTH, LENGTH, 386.964), 1e-12));

    const PointMass nacelle_mass = engine.pointmass(Component::Nacelle);
    EXPECT_NEAR(nacelle_mass.mass, 599.32, TOLERANCE);
    EXPECT_TRUE(nacelle_mass.CG.isApprox(Eigen::Vector3d(0.0, 1.0, 2.0), 1e-9)) << nacelle_mass.CG.transpose();

    const PointMass pylon_mass = engine.pointmass(Component::Pylon);
    EXPECT_EQ(pylon_mass.mass, 0.0);
    EXPECT_EQ(pylon_mass.CG, Eigen::Vector3d::Zero());
    EXPECT_EQ(pylon_mass.inertia, Eigen::Matrix3d::Zero());
}

/**
 * @brief With a pylon surface the pylon mass follows the formula and its CG is the pylon centroid.
 */
TEST_F(OpenrotorfanMassAnalyzer, WithPylon)
{
    engine.set_pylon(make_pylon());

    analyze();

    const PointMass pylon_mass = engine.pointmass(Component::Pylon);
    EXPECT_NEAR(pylon_mass.mass, 353.535, TOLERANCE);
    EXPECT_TRUE(pylon_mass.CG.isApprox(Eigen::Vector3d(0.75, 0.0, -2.0), 1e-9)) << pylon_mass.CG.transpose();
}

/**
 * @brief The technology factors from the configuration are applied to all three masses.
 */
TEST_F(OpenrotorfanMassAnalyzer, TechnologyFactorsFromConfiguration)
{
    engine.set_pylon(make_pylon());
    set_technology_factors(0.8, 0.9, 1.1);

    analyze();

    EXPECT_NEAR(engine.pointmass(Component::Engine).mass, 0.8 * 386.964, TOLERANCE);
    EXPECT_NEAR(engine.pointmass(Component::Nacelle).mass, 0.9 * 599.32, TOLERANCE);
    EXPECT_NEAR(engine.pointmass(Component::Pylon).mass, 1.1 * 353.535, TOLERANCE);
}

/**
 * @brief FR-8.6 total mass after the analysis: the sum of engine, nacelle and pylon masses at the
 * mass-weighted CG of the three components (hand calculation from their masses and CGs).
 */
TEST_F(OpenrotorfanMassAnalyzer, TotalMassCombinesComponents)
{
    engine.set_pylon(make_pylon());

    analyze();

    const double m_engine = 386.964;
    const double m_nacelle = 599.32;
    const double m_pylon = 353.535;
    const double m_total = m_engine + m_nacelle + m_pylon; // 1339.819 kg
    const Eigen::Vector3d cg_expected = (m_engine * Eigen::Vector3d(2.0, 0.0, 0.0) +
                                         m_nacelle * Eigen::Vector3d(0.0, 1.0, 2.0) +
                                         m_pylon * Eigen::Vector3d(0.75, 0.0, -2.0)) / m_total;

    const PointMass total = engine.total_mass();
    EXPECT_NEAR(total.mass, 1339.819, 1e-9);
    EXPECT_TRUE(total.CG.isApprox(cg_expected, 1e-9)) << total.CG.transpose();
}

/**
 * @brief A pre-set, nonzero engine mass (from the engine design) is kept; the regression is only a fallback.
 * CG and inertia are still recalculated, the inertia with the kept mass.
 */
TEST_F(OpenrotorfanMassAnalyzer, PresetEngineMassIsKept)
{
    engine.set_pointmass(Component::Engine, {Eigen::Vector3d(9.0, 9.0, 9.0), Eigen::Matrix3d::Identity(), 2000.0});

    analyze();

    const PointMass engine_mass = engine.pointmass(Component::Engine);
    EXPECT_EQ(engine_mass.mass, 2000.0);
    EXPECT_TRUE(engine_mass.CG.isApprox(Eigen::Vector3d(2.0, 0.0, 0.0)));
    EXPECT_TRUE(engine_mass.inertia.isApprox(cylinder_inertia(HEIGHT, WIDTH, LENGTH, 2000.0), 1e-12));
}

/**
 * @brief Current behaviour: nacelle and pylon inertia are the geometry library's surface inertia
 * and are not scaled by the component mass, so a different technology factor changes the mass
 * but not the inertia.
 */
TEST_F(OpenrotorfanMassAnalyzer, NacelleAndPylonInertiaNotScaledByMass)
{
    engine.set_pylon(make_pylon());
    analyze();
    const Eigen::Matrix3d nacelle_inertia = engine.pointmass(Component::Nacelle).inertia;
    const Eigen::Matrix3d pylon_inertia = engine.pointmass(Component::Pylon).inertia;

    set_technology_factors(1.0, 0.5, 0.5);
    analyze();

    EXPECT_NEAR(engine.pointmass(Component::Nacelle).mass, 0.5 * 599.32, TOLERANCE);
    EXPECT_TRUE(engine.pointmass(Component::Nacelle).inertia.isApprox(nacelle_inertia));
    EXPECT_TRUE(engine.pointmass(Component::Pylon).inertia.isApprox(pylon_inertia));
    EXPECT_FALSE(nacelle_inertia.isZero());
}
