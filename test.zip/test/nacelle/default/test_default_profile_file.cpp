/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 *
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/*
 * Unit tests for FR-5.2: a nacelle profile file (*.dat) that does not exist in the geometry
 * directory is created with the default circular profile and then used.
 *
 * The generated profile has the same points as test/stubs/nacelle.dat (the stub only repeats
 * the first point at the end), so a nacelle designed from a generated file must match one
 * designed from the stub.
 */

/* === Includes === */
#include <cmath>
#include <filesystem>
#include <fstream>
#include <gtest/gtest.h>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "../../temp_directory.h"

/* Unit Under Test */
#include "nacelle/default/default_nacelle.h"

/* === Fixtures === */
/**
 * @brief Nacelle designer on an empty temporary geometry directory.
 * The engine is the one of NacelleDefaultTurbofanKerosene.LargeFanShortDuct.
 */
class NacelleProfileFile : public ::testing::Test
{
  protected:
    void SetUp() override
    {
        config = aixml::openDocument(std::filesystem::path{CMAKE_TEST_CONFIG_FILE});
    }

    void set_profile(const std::string &profile)
    {
        config->at("module_configuration_file/program_settings/propulsion@Default/nacelle/profile/value") = profile;
    }

    /* Design the nacelle with the given geometry directory and return the engine */
    auto design(const std::filesystem::path &geometry_directory) -> Turbofan<EnergyCarrierFamily::Kerosene>
    {
        geometry::nacelle::Default designer{config, geometry_directory};
        designer.initialize();
        Turbofan<EnergyCarrierFamily::Kerosene> engine{};
        engine.set_dimension({1.0, 2.0, 3.0});
        engine.set_fan({2.5});
        designer(engine);
        return engine;
    }

    static auto read_text(const std::filesystem::path &file) -> std::string
    {
        std::ifstream stream(file);
        std::stringstream content;
        content << stream.rdbuf();
        return content.str();
    }

    std::shared_ptr<node> config;
    const UniqueTempDirectory geometry{"test_nacelle_profile"};
};

/* === Tests === */
/**
 * @brief A missing nacelle.dat is created with 40 points on a circle of diameter 1, every 9 degrees,
 * counter-clockwise from (0.5, 0): point k = (0.5 cos(9 k deg), 0.5 sin(9 k deg)).
 * The file is read as plain text, independent of the geometry library's reader.
 */
TEST_F(NacelleProfileFile, CreatesMissingProfileFile)
{
    const std::filesystem::path profile_file = geometry.path() / "nacelle.dat";
    ASSERT_FALSE(std::filesystem::exists(profile_file));

    const auto engine = design(geometry.path());

    ASSERT_TRUE(std::filesystem::exists(profile_file));
    std::ifstream file(profile_file);
    std::vector<std::pair<double, double>> points;
    std::string line;
    while (std::getline(file, line))
    {
        std::istringstream row(line);
        double x = 0.0;
        double y = 0.0;
        if (row >> x >> y)
        {
            points.emplace_back(x, y);
        }
    }
    ASSERT_EQ(points.size(), 40U);
    const double pi = std::acos(-1.0);
    for (std::size_t k = 0; k < points.size(); ++k)
    {
        const double angle = pi * 9.0 * static_cast<double>(k) / 180.0;
        /* The file holds 5 decimals */
        EXPECT_NEAR(points[k].first, 0.5 * std::cos(angle), 1e-5) << "point " << k;
        EXPECT_NEAR(points[k].second, 0.5 * std::sin(angle), 1e-5) << "point " << k;
    }
    EXPECT_FALSE(engine.nacelle().sections.empty());
}

/**
 * @brief The nacelle designed from the created file equals the nacelle designed from the stub nacelle.dat.
 */
TEST_F(NacelleProfileFile, CreatedProfileGivesSameNacelleAsStub)
{
    const auto from_created = design(geometry.path());
    const auto from_stub = design(std::filesystem::path{CMAKE_TEST_STUBS_DIR});

    const auto &created = from_created.nacelle();
    const auto &stub = from_stub.nacelle();
    ASSERT_EQ(created.sections.size(), 4U);
    ASSERT_EQ(created.sections.size(), stub.sections.size());
    EXPECT_EQ(created.name, stub.name);
    EXPECT_EQ(created.origin, stub.origin);
    EXPECT_EQ(created.normal, stub.normal);
    for (std::size_t i = 0; i < stub.sections.size(); ++i)
    {
        EXPECT_EQ(created.sections[i].name, "nacelle") << "section " << i;
        EXPECT_EQ(created.sections[i].origin, stub.sections[i].origin) << "section " << i;
        const auto created_box = created.sections[i].get_contour(true).bbox();
        const auto stub_box = stub.sections[i].get_contour(true).bbox();
        EXPECT_NEAR(created_box.x_span(), stub_box.x_span(), 1e-9) << "section " << i;
        EXPECT_NEAR(created_box.y_span(), stub_box.y_span(), 1e-9) << "section " << i;
    }
    /* The inlet section has the fan diameter */
    EXPECT_NEAR(created.sections[0].get_contour(true).bbox().x_span(), 2.5, 1e-3);
    EXPECT_NEAR(created.sections[0].get_contour(true).bbox().y_span(), 2.5, 1e-3);
}

/**
 * @brief Once the file exists it is read, not created again. After the first run the created
 * circle is replaced by a distinct valid profile (a square). The second run must use the square
 * and leave the file unchanged. A larger circle would not do: the designer rescales every profile
 * to the required width and height, so only the shape can show which file was used.
 * Shape check: a square fills its bounding box (area ratio 1), the 40-point circle only about pi/4.
 */
TEST_F(NacelleProfileFile, SecondRunReadsExistingFile)
{
    const std::filesystem::path profile_file = geometry.path() / "nacelle.dat";
    const auto first = design(geometry.path());
    ASSERT_FALSE(first.nacelle().sections.empty());
    ASSERT_EQ(first.nacelle().sections[0].get_contour(false).size(), 40U);

    {
        std::ofstream square(profile_file, std::ios::trunc);
        square << "# square\n0.5 0.5\n-0.5 0.5\n-0.5 -0.5\n0.5 -0.5\n";
    }
    const std::string square_content = read_text(profile_file);

    const auto second = design(geometry.path());

    EXPECT_EQ(read_text(profile_file), square_content) << "the existing profile file was overwritten";
    ASSERT_EQ(second.nacelle().sections.size(), first.nacelle().sections.size());
    for (std::size_t i = 0; i < second.nacelle().sections.size(); ++i)
    {
        const auto contour = second.nacelle().sections[i].get_contour(true);
        EXPECT_EQ(contour.size(), 4U) << "section " << i;
        const auto box = contour.bbox();
        EXPECT_NEAR(std::abs(CGAL::to_double(contour.area())) / (box.x_span() * box.y_span()), 1.0, 1e-9) << "section " << i;
    }
}

/**
 * @brief A profile path that cannot be created (its folder is an existing regular file) gives a clear error.
 */
TEST_F(NacelleProfileFile, UncreatableProfilePathThrows)
{
    std::ofstream(geometry.path() / "blocker") << "not a directory";
    set_profile("blocker/nacelle.dat");

    try
    {
        design(geometry.path());
        FAIL() << "Expected std::runtime_error for an uncreatable profile path";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("Error while creating the file for nacelle."), std::string::npos) << error.what();
    }
}

/**
 * @brief FR-5.1: a profile that is neither circle, ellipse nor a *.dat file is rejected.
 */
TEST_F(NacelleProfileFile, UnsupportedProfileThrows)
{
    set_profile("Triangle");

    try
    {
        design(geometry.path());
        FAIL() << "Expected std::invalid_argument for an unsupported nacelle profile";
    }
    catch (const std::invalid_argument &error)
    {
        /* The name is converted to lower case when the configuration is read */
        EXPECT_NE(std::string{error.what()}.find("The nacelle shape 'triangle' is not supported."), std::string::npos) << error.what();
    }
}

/**
 * @brief A profile in a missing subdirectory is created together with the subdirectory.
 */
TEST_F(NacelleProfileFile, CreatesMissingSubdirectory)
{
    set_profile("profiles/nacelle.dat");

    const auto engine = design(geometry.path());

    EXPECT_TRUE(std::filesystem::exists(geometry.path() / "profiles" / "nacelle.dat"));
    EXPECT_EQ(engine.nacelle().sections.size(), 4U);
}
