/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <filesystem>
#include <gtest/gtest.h>

/* Unit Under Test */
#include "nacelle/default/default_nacelle.h"

/* === Fixtures === */

/* === Tests === */
/**
 * @brief Test designing the nacelle of a kerosene turbofan engine.
 */
TEST(NacelleDefaultTurbofanKerosene, LargeFanShortDuct)
{
    /* Create the engine designer and engine */
    std::filesystem::path config{CMAKE_TEST_CONFIG_FILE};
    geometry::nacelle::Default designer{aixml::openDocument(config), {CMAKE_TEST_STUBS_DIR}};
    Turbofan<EnergyCarrierFamily::Kerosene> engine{};

    /* Design the nacelle when the fan diameter
     * is larger than the engine width and height */
    engine.set_dimension({1.0, 2.0, 3.0});
    engine.set_fan({2.5});
    designer.initialize();
    designer(engine);

    /* Check the result */
    ASSERT_EQ(engine.nacelle().sections.size(), 4);
    EXPECT_EQ(engine.nacelle().origin, geom2::Point_3(0.0, 0.0, 0.0));
    EXPECT_EQ(engine.nacelle().normal, geom2::Direction_3(1.0, 0.0, 0.0));
    EXPECT_EQ(engine.nacelle().name, "nacelle_0");

    /* Section 0 */
    EXPECT_EQ(engine.nacelle().sections[0].origin, geom2::Point_3(0.0, 0.0, 0.0));
    EXPECT_EQ(engine.nacelle().sections[0].name, "nacelle");
    EXPECT_NEAR(engine.nacelle().sections[0].get_contour(true).bbox().x_span(), 2.50, 1e-3);
    EXPECT_NEAR(engine.nacelle().sections[0].get_contour(true).bbox().y_span(), 2.50, 1e-3);

    /* Section 1 */
    EXPECT_EQ(engine.nacelle().sections[1].origin, geom2::Point_3(0.0, 0.0, 0.75));
    EXPECT_NEAR(engine.nacelle().sections[1].get_contour(true).bbox().x_span(), 3.125, 1e-3);
    EXPECT_NEAR(engine.nacelle().sections[1].get_contour(true).bbox().y_span(), 3.125, 1e-3);

    /* Section 2 */
    EXPECT_EQ(engine.nacelle().sections[2].origin, geom2::Point_3(0.0, 0.0, 2.25));
    EXPECT_NEAR(engine.nacelle().sections[2].get_contour(true).bbox().x_span(), 3.125, 1e-3);
    EXPECT_NEAR(engine.nacelle().sections[2].get_contour(true).bbox().y_span(), 3.125, 1e-3);

    /* Section 3 */
    EXPECT_EQ(engine.nacelle().sections[3].origin, geom2::Point_3(0.0, 0.0, 3.00));
    EXPECT_NEAR(engine.nacelle().sections[3].get_contour(true).bbox().x_span(), 2.50, 1e-3);
    EXPECT_NEAR(engine.nacelle().sections[3].get_contour(true).bbox().y_span(), 2.50, 1e-3);
}