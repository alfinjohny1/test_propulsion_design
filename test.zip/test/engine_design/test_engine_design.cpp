/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 *
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/*
 * Unit tests for the engine-efficiency technology factor (FR-4.8):
 * design::EngineDesigner::scale_deck_data_values() / write_deck_value() and the adjustment done
 * by design::Rubber::initialize() and design::Rubber::save().
 *
 * Every deck value except the placeholder -9999 is multiplied by 1 + (1 - efficiency_factor).
 */

/* === Includes === */
#include <aixml/node.h>
#include <algorithm>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <gtest/gtest.h>
#include <iomanip>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include "../temp_directory.h"

/* Unit Under Test */
#include "engine_design/engine_design.h"
#include "engine_design/rubber/rubber_design.h"

/* === Fixtures === */
/**
 * @brief Provides an engine designer and a small 2 x 2 x 2 deck.
 * The designer only stores its constructor arguments, so no configuration or files are needed.
 */
class ScaleDeckDataValues : public ::testing::Test
{
  protected:
    void SetUp() override
    {
        deck.name = "test_deck";
        deck.N = {0.8, 1.0};
        deck.FL = {0.0, 10000.0};
        deck.Mach = {0.0, 0.8};
        deck.values.resize(boost::extents[2][2][2]);
        for (std::size_t i = 0; i < 2; ++i)
            for (std::size_t j = 0; j < 2; ++j)
                for (std::size_t k = 0; k < 2; ++k)
                    deck.values[i][j][k] = INPUT[i][j][k];
    }

    /* Expect every value to be the input value times the factor, except the -9999 placeholders */
    static void expect_scaled(const DeckData &result, const double factor)
    {
        for (std::size_t i = 0; i < 2; ++i)
            for (std::size_t j = 0; j < 2; ++j)
                for (std::size_t k = 0; k < 2; ++k)
                {
                    const double original = INPUT[i][j][k];
                    const double expected = original == -9999.0 ? -9999.0 : original * factor;
                    EXPECT_NEAR(result.values[i][j][k], expected, 1e-9) << "index [" << i << "][" << j << "][" << k << "]";
                }
    }

    /* The only definition of the deck values; the tests also check some results as literals */
    static constexpr double INPUT[2][2][2] = {{{100.0, 200.0}, {-9999.0, 50.0}}, {{0.0, -9999.0}, {1.5, 400.0}}};
    design::EngineDesigner designer{nullptr, {}, {}};
    DeckData deck;
};

/* === Tests === */
/**
 * @brief Efficiency factor 1.1 scales the values by 0.9 and keeps the -9999 placeholders.
 */
TEST_F(ScaleDeckDataValues, FactorAboveOneReducesValues)
{
    const DeckData result = designer.scale_deck_data_values(deck, 1.1);

    EXPECT_NEAR(result.values[0][0][0], 90.0, 1e-9);
    EXPECT_NEAR(result.values[0][0][1], 180.0, 1e-9);
    EXPECT_EQ(result.values[0][1][0], -9999.0);
    expect_scaled(result, 0.9);
}

/**
 * @brief Efficiency factor 1.0 leaves the deck unchanged.
 */
TEST_F(ScaleDeckDataValues, FactorOneLeavesValuesUnchanged)
{
    const DeckData result = designer.scale_deck_data_values(deck, 1.0);

    expect_scaled(result, 1.0);
}

/**
 * @brief Efficiency factor 0.9 scales the values by 1.1.
 */
TEST_F(ScaleDeckDataValues, FactorBelowOneIncreasesValues)
{
    const DeckData result = designer.scale_deck_data_values(deck, 0.9);

    EXPECT_NEAR(result.values[1][1][1], 440.0, 1e-9);
    expect_scaled(result, 1.1);
}

/**
 * @brief The -9999 placeholders stay exactly -9999 for any factor.
 */
TEST_F(ScaleDeckDataValues, PlaceholderNeverScaled)
{
    for (const double efficiency_factor : {0.5, 0.9, 1.0, 1.1, 1.5})
    {
        DeckData copy = deck;
        const DeckData result = designer.scale_deck_data_values(copy, efficiency_factor);
        EXPECT_EQ(result.values[0][1][0], -9999.0) << "efficiency factor " << efficiency_factor;
        EXPECT_EQ(result.values[1][0][1], -9999.0) << "efficiency factor " << efficiency_factor;
    }
}

/**
 * @brief The deck passed in is modified in place, and the returned copy holds the same values.
 */
TEST_F(ScaleDeckDataValues, ModifiesInputInPlace)
{
    const DeckData result = designer.scale_deck_data_values(deck, 1.1);

    expect_scaled(deck, 0.9);
    EXPECT_TRUE(deck.values == result.values);
}

/**
 * @brief Name and breakpoints (N, FL, Mach) are not changed.
 */
TEST_F(ScaleDeckDataValues, MetadataUnchanged)
{
    const DeckData result = designer.scale_deck_data_values(deck, 1.1);

    EXPECT_EQ(result.name, "test_deck");
    EXPECT_EQ(result.N, (std::vector<double>{0.8, 1.0}));
    EXPECT_EQ(result.FL, (std::vector<double>{0.0, 10000.0}));
    EXPECT_EQ(result.Mach, (std::vector<double>{0.0, 0.8}));
    ASSERT_EQ(result.values.shape()[0], 2U);
    ASSERT_EQ(result.values.shape()[1], 2U);
    ASSERT_EQ(result.values.shape()[2], 2U);
}

/**
 * @brief An empty deck is returned unchanged without error.
 */
TEST_F(ScaleDeckDataValues, EmptyDeck)
{
    DeckData empty{};

    const DeckData result = designer.scale_deck_data_values(empty, 1.1);

    EXPECT_EQ(result.values.num_elements(), 0U);
}

/* === Tests with a deck file === */
namespace
{
    /* Fuel-flow deck of the test-engine stub, in the CSV format of the engine database */
    const std::filesystem::path DECK_FILE = std::filesystem::path{CMAKE_TEST_STUBS_DIR} / "engines" / "test-engine" / "test-engine_WF.csv";
} // namespace

/**
 * @brief Scaling a deck read from a deck CSV file: every value is scaled, every -9999 placeholder is kept.
 */
TEST(ScaleDeckDataValuesDeckFile, ScalesEveryValueOfDeckFile)
{
    const DeckData original = DeckData::from_csv(DECK_FILE);
    DeckData deck = DeckData::from_csv(DECK_FILE);
    design::EngineDesigner designer{nullptr, {}, {}};

    const DeckData result = designer.scale_deck_data_values(deck, 1.1);

    ASSERT_GT(original.values.num_elements(), 0U);
    std::size_t placeholders = 0;
    std::size_t scaled = 0;
    const auto *in = original.values.data();
    const auto *out = result.values.data();
    for (std::size_t i = 0; i < original.values.num_elements(); ++i)
    {
        if (in[i] == -9999.0)
        {
            EXPECT_EQ(out[i], -9999.0) << "element " << i;
            ++placeholders;
        }
        else
        {
            EXPECT_NEAR(out[i], 0.9 * in[i], 1e-12 * std::max(1.0, std::abs(in[i]))) << "element " << i;
            ++scaled;
        }
    }
    /* The file contains both real values and placeholders, so both branches were exercised */
    EXPECT_GT(placeholders, 0U);
    EXPECT_GT(scaled, 0U);
}

/**
 * @brief Scaled deck written with write_deck_value() and read back with DeckData::from_csv(),
 * as Rubber does when it adjusts an engine in the project directory.
 */
TEST(ScaleDeckDataValuesDeckFile, WriteAndReadBackScaledDeck)
{
    const UniqueTempDirectory temp{"test_scale_deck_round_trip"};
    const std::filesystem::path &engine_directory = temp.path();
    std::filesystem::create_directories(engine_directory / "test-engine");

    DeckData deck = DeckData::from_csv(DECK_FILE);
    design::EngineDesigner designer{nullptr, engine_directory, {}};
    const DeckData scaled = designer.scale_deck_data_values(deck, 1.1);
    designer.write_deck_value(scaled, "test-engine");

    /* The deck keeps the name of the file it was read from, so the original WF file is overwritten */
    EXPECT_EQ(scaled.name, "test-engine_WF");
    const std::filesystem::path written = engine_directory / "test-engine" / "test-engine_WF.csv";
    ASSERT_TRUE(std::filesystem::exists(written)) << written;
    const DeckData read_back = DeckData::from_csv(written);

    EXPECT_EQ(read_back.N, scaled.N);
    EXPECT_EQ(read_back.FL, scaled.FL);
    EXPECT_EQ(read_back.Mach, scaled.Mach);
    ASSERT_EQ(read_back.values.num_elements(), scaled.values.num_elements());
    const auto *expected = scaled.values.data();
    const auto *actual = read_back.values.data();
    for (std::size_t i = 0; i < scaled.values.num_elements(); ++i)
    {
        /* The file is written with the default stream precision (6 significant digits) */
        EXPECT_NEAR(actual[i], expected[i], 1e-5 * std::max(1.0, std::abs(expected[i]))) << "element " << i;
    }
}

/* === Tests of the Rubber adjustment path === */
/**
 * @brief Temporary project engine directory and engine database with consistent copies of the test engine.
 *
 * Every engine copy is a "previously adjusted" dataset: its XML stores a factor f_old and its
 * WF deck is the base deck of the stub engine times (2 - f_old). For a configured factor f the
 * requirement is that the adjusted deck equals base * (2 - f), whatever f_old was, and the
 * engine XML stores f.
 *
 * Rubber implements this as a ratio on the current deck (current * (2 - f) / (2 - f_old)) and,
 * in both initialize() and save(), takes the deck file name from the first engine_model entry
 * of the configuration (the Default one).
 */
class RubberEfficiencyFactor : public ::testing::Test
{
  protected:
    void SetUp() override
    {
        base_deck.emplace(DeckData::from_csv(STUB_ENGINE / "test-engine_WF.csv"));
        project = temp.path() / "project";
        database = temp.path() / "database";
        std::filesystem::create_directories(project);
        std::filesystem::create_directories(database);

        config = aixml::openDocument(std::filesystem::path{CMAKE_TEST_CONFIG_FILE});
        config->at("module_configuration_file/program_settings/propulsion@Default/Rubber/engine_model/value") = std::string{MODEL_A};
        config->at("module_configuration_file/program_settings/path_engine_database/value") = database.string();
    }

    /*
     * Create <directory>/<model> with the stub XML storing f_old and the deck base * (2 - f_old).
     * Contains fatal assertions: call it as ASSERT_NO_FATAL_FAILURE(make_engine(...)).
     */
    void make_engine(const std::filesystem::path &directory, const std::string &model, const double f_old) const
    {
        const std::filesystem::path engine_dir = directory / model;
        std::filesystem::create_directories(engine_dir);
        std::filesystem::copy_file(STUB_ENGINE / "test-engine.xml", engine_dir / (model + ".xml"));
        auto engine_xml = aixml::openDocument(engine_dir / (model + ".xml"));
        engine_xml->at("EngineDataFile").appendChild("EngineTechnologyFactor", true) = f_old;
        ASSERT_TRUE(aixml::saveDocument(*engine_xml));
        ASSERT_NO_FATAL_FAILURE(write_deck(engine_dir / (model + "_WF.csv"), 2.0 - f_old));
    }

    /* Add a marker node to the engine XML; it disappears if the engine is copied over again */
    static void add_marker(const std::filesystem::path &directory, const std::string &model)
    {
        auto engine_xml = aixml::openDocument(directory / model / (model + ".xml"));
        engine_xml->at("EngineDataFile").appendChild("TestMarker", true) = std::string{"project copy"};
        ASSERT_TRUE(aixml::saveDocument(*engine_xml));
    }

    [[nodiscard]] static auto has_marker(const std::filesystem::path &directory, const std::string &model) -> bool
    {
        auto engine_xml = aixml::openDocument(directory / model / (model + ".xml"));
        return engine_xml->find("EngineDataFile/TestMarker") != nullptr;
    }

    [[nodiscard]] static auto read_text(const std::filesystem::path &file) -> std::string
    {
        std::ifstream stream(file);
        std::stringstream content;
        content << stream.rdbuf();
        return content.str();
    }

    /* Write base deck * factor (-9999 kept) in the deck CSV format, with full precision */
    void write_deck(const std::filesystem::path &file_name, const double factor) const
    {
        std::ofstream file(file_name, std::ios::out | std::ios::trunc);
        ASSERT_TRUE(file.is_open()) << file_name;
        file << std::setprecision(17);
        const DeckData &deck = *base_deck;
        for (std::size_t n = 0; n < deck.N.size(); ++n)
        {
            file << deck.N[n] << ';';
            for (const double mach : deck.Mach)
                file << mach << ';';
            file << '\n';
            for (std::size_t fl = 0; fl < deck.FL.size(); ++fl)
            {
                file << deck.FL[fl] << ';';
                for (std::size_t m = 0; m < deck.Mach.size(); ++m)
                {
                    const double value = deck.values[n][fl][m];
                    file << (value == -9999.0 ? -9999.0 : factor * value) << ';';
                }
                file << '\n';
            }
        }
        file.close();
        ASSERT_FALSE(file.fail()) << "writing " << file_name << " failed";
    }

    void set_configured_factor(const double factor)
    {
        config->at("module_configuration_file/program_settings/technology_factors/engine_efficiency/value") = factor;
    }

    /* Add a propulsion entry with its own engine model for the given propulsor ID */
    void add_model_override(const std::string &id, const std::string &model)
    {
        node &propulsion = config->at("module_configuration_file/program_settings").appendChild("propulsion", true);
        propulsion.setAttrib("ID", id);
        propulsion.appendChild("engine", true).appendChild("Rubber", true).appendChild("engine_model", true).appendChild("value", true) = model;
    }

    [[nodiscard]] static auto stored_factor(const std::filesystem::path &directory, const std::string &model) -> double
    {
        auto engine_xml = aixml::openDocument(directory / model / (model + ".xml"));
        return engine_xml->at("EngineDataFile/EngineTechnologyFactor");
    }

    /*
     * Expect <directory>/<model>/<model>_WF.csv to be base deck * factor, -9999 unchanged.
     * Contains a fatal assertion: call it as ASSERT_NO_FATAL_FAILURE(expect_deck(...)).
     */
    void expect_deck(const std::filesystem::path &directory, const std::string &model, const double factor) const
    {
        const DeckData written = DeckData::from_csv(directory / model / (model + "_WF.csv"));
        const DeckData &base = *base_deck;
        ASSERT_EQ(written.values.num_elements(), base.values.num_elements()) << model;
        EXPECT_EQ(written.N, base.N);
        EXPECT_EQ(written.FL, base.FL);
        EXPECT_EQ(written.Mach, base.Mach);
        const auto *in = base.values.data();
        const auto *out = written.values.data();
        std::size_t mismatches = 0;
        for (std::size_t i = 0; i < base.values.num_elements(); ++i)
        {
            const double expected = in[i] == -9999.0 ? -9999.0 : factor * in[i];
            /* Rubber writes 6 significant digits and reads the configured factor as float */
            if (std::abs(out[i] - expected) > 1e-5 * std::max(1.0, std::abs(expected)))
            {
                if (mismatches < 3)
                {
                    ADD_FAILURE() << model << " element " << i << ": expected " << expected << " (base " << in[i]
                                  << " * " << factor << "), got " << out[i]
                                  << (in[i] != 0.0 && in[i] != -9999.0 ? " = base * " + std::to_string(out[i] / in[i]) : "");
                }
                ++mismatches;
            }
        }
        EXPECT_EQ(mismatches, 0U) << model << ": number of deck values not equal to base * " << factor;
    }

    static constexpr const char *MODEL_A = "test-engine";   /**< Default engine model of the configuration. */
    static constexpr const char *MODEL_B = "test-engine-b"; /**< Engine model of a per-engine override. */
    const std::filesystem::path STUB_ENGINE = std::filesystem::path{CMAKE_TEST_STUBS_DIR} / "engines" / "test-engine";
    const UniqueTempDirectory temp{"test_rubber_efficiency_factor"};
    std::filesystem::path project;
    std::filesystem::path database;
    std::optional<DeckData> base_deck; /* Constructed in place: multi_array copy-assignment requires equal shapes */
    std::shared_ptr<node> config;
};

/* --- initialize(): engine already in the project engine directory --- */
/**
 * @brief A previously adjusted engine (f_old = 1.05) is re-adjusted to the configured factor 1.1:
 * deck = base * 0.9, XML stores 1.1.
 */
TEST_F(RubberEfficiencyFactor, InitializeReadjustsPreviouslyAdjustedEngine)
{
    ASSERT_NO_FATAL_FAILURE(make_engine(project, MODEL_A, 1.05));
    set_configured_factor(1.1);
    design::Rubber designer{config, project, {}};

    designer.initialize();

    ASSERT_NO_FATAL_FAILURE(expect_deck(project, MODEL_A, 2.0 - 1.1));
    EXPECT_NEAR(stored_factor(project, MODEL_A), 1.1, 1e-6);
    /* The designer keeps the ratio factor 2 - (2 - f) / (2 - f_old) */
    EXPECT_NEAR(designer.technology_factor("engine_efficiency"), 2.0 - 0.9 / 0.95, 1e-6);
}

/**
 * @brief Configured factor equal to the stored one: deck and XML are unchanged.
 */
TEST_F(RubberEfficiencyFactor, InitializeSameFactorLeavesEngineUnchanged)
{
    ASSERT_NO_FATAL_FAILURE(make_engine(project, MODEL_A, 1.05));
    set_configured_factor(1.05);
    design::Rubber designer{config, project, {}};

    designer.initialize();

    ASSERT_NO_FATAL_FAILURE(expect_deck(project, MODEL_A, 2.0 - 1.05));
    EXPECT_NEAR(stored_factor(project, MODEL_A), 1.05, 1e-6);
}

/**
 * @brief A second initialization with the same configuration does not scale the deck again.
 */
TEST_F(RubberEfficiencyFactor, InitializeTwiceScalesOnce)
{
    ASSERT_NO_FATAL_FAILURE(make_engine(project, MODEL_A, 1.05));
    set_configured_factor(1.1);
    design::Rubber{config, project, {}}.initialize();

    design::Rubber{config, project, {}}.initialize();

    ASSERT_NO_FATAL_FAILURE(expect_deck(project, MODEL_A, 2.0 - 1.1));
    EXPECT_NEAR(stored_factor(project, MODEL_A), 1.1, 1e-6);
}

/**
 * @brief An engine that exists only in the database is not changed by initialize().
 */
TEST_F(RubberEfficiencyFactor, InitializeDoesNotTouchDatabase)
{
    ASSERT_NO_FATAL_FAILURE(make_engine(database, MODEL_A, 1.0));
    set_configured_factor(1.1);
    design::Rubber designer{config, project, {}};

    designer.initialize();

    ASSERT_NO_FATAL_FAILURE(expect_deck(database, MODEL_A, 1.0));
    EXPECT_NEAR(stored_factor(database, MODEL_A), 1.0, 1e-6);
    EXPECT_FALSE(std::filesystem::exists(project / MODEL_A));
}

/* --- save(): engine newly copied from the database --- */
/**
 * @brief save() copies a designed engine from the database into the project and adjusts the copy:
 * project deck = base * 0.9, project XML 1.1; the database stays unchanged.
 */
TEST_F(RubberEfficiencyFactor, SaveCopiesAndAdjustsNewEngine)
{
    ASSERT_NO_FATAL_FAILURE(make_engine(database, MODEL_A, 1.0));
    set_configured_factor(1.1);
    design::Rubber designer{config, project, {}};
    designer.initialize();
    designer.add_designed_engine(MODEL_A);

    designer.save();

    ASSERT_TRUE(std::filesystem::exists(project / MODEL_A / (std::string{MODEL_A} + ".xml")));
    ASSERT_NO_FATAL_FAILURE(expect_deck(project, MODEL_A, 2.0 - 1.1));
    EXPECT_NEAR(stored_factor(project, MODEL_A), 1.1, 1e-6);
    ASSERT_NO_FATAL_FAILURE(expect_deck(database, MODEL_A, 1.0));
    EXPECT_NEAR(stored_factor(database, MODEL_A), 1.0, 1e-6);
}

/**
 * @brief save() with the neutral factor 1.0 copies the engine unchanged.
 */
TEST_F(RubberEfficiencyFactor, SaveWithNeutralFactorCopiesUnchanged)
{
    ASSERT_NO_FATAL_FAILURE(make_engine(database, MODEL_A, 1.0));
    set_configured_factor(1.0);
    design::Rubber designer{config, project, {}};
    designer.initialize();
    designer.add_designed_engine(MODEL_A);

    designer.save();

    ASSERT_NO_FATAL_FAILURE(expect_deck(project, MODEL_A, 1.0));
    EXPECT_NEAR(stored_factor(project, MODEL_A), 1.0, 1e-6);
}

/**
 * @brief save() leaves an engine that is already in the project alone.
 * A re-copy from the database followed by a re-adjustment would give the same deck and factor,
 * so a marker node in the project XML is used to detect that the project copy was not replaced.
 */
TEST_F(RubberEfficiencyFactor, SaveSkipsEngineAlreadyInProject)
{
    ASSERT_NO_FATAL_FAILURE(make_engine(database, MODEL_A, 1.0));
    ASSERT_NO_FATAL_FAILURE(make_engine(project, MODEL_A, 1.1));
    ASSERT_NO_FATAL_FAILURE(add_marker(project, MODEL_A));
    set_configured_factor(1.1);
    design::Rubber designer{config, project, {}};
    designer.initialize();
    designer.add_designed_engine(MODEL_A);

    designer.save();

    EXPECT_TRUE(has_marker(project, MODEL_A)) << "the project engine was replaced by a copy from the database";
    ASSERT_NO_FATAL_FAILURE(expect_deck(project, MODEL_A, 2.0 - 1.1));
    EXPECT_NEAR(stored_factor(project, MODEL_A), 1.1, 1e-6);
}

/* --- Threshold of the factor comparison (|f_xml - f| > 1e-6, f read as float) --- */
/**
 * @brief A configured factor within the 1e-6 threshold of the stored one (1.05 + 4e-7, still
 * about 4e-7 apart after the float conversion) does not adjust the engine: deck file and XML unchanged.
 */
TEST_F(RubberEfficiencyFactor, InitializeFactorWithinThresholdNotAdjusted)
{
    ASSERT_NO_FATAL_FAILURE(make_engine(project, MODEL_A, 1.05));
    const std::filesystem::path deck_file = project / MODEL_A / (std::string{MODEL_A} + "_WF.csv");
    const std::string deck_before = read_text(deck_file);
    set_configured_factor(1.05 + 4e-7);
    design::Rubber designer{config, project, {}};

    designer.initialize();

    EXPECT_EQ(read_text(deck_file), deck_before) << "the deck was rewritten";
    EXPECT_EQ(stored_factor(project, MODEL_A), 1.05);
}

/**
 * @brief A configured factor just outside the threshold (1.05 + 4e-6) adjusts the engine:
 * the deck file is rewritten and the XML stores the new factor.
 */
TEST_F(RubberEfficiencyFactor, InitializeFactorOutsideThresholdAdjusted)
{
    ASSERT_NO_FATAL_FAILURE(make_engine(project, MODEL_A, 1.05));
    const std::filesystem::path deck_file = project / MODEL_A / (std::string{MODEL_A} + "_WF.csv");
    const std::string deck_before = read_text(deck_file);
    constexpr double f = 1.05 + 4e-6;
    set_configured_factor(f);
    design::Rubber designer{config, project, {}};

    designer.initialize();

    /* The deck values change by only 4e-6 relative, but Rubber rewrites the file in its own format */
    EXPECT_NE(read_text(deck_file), deck_before) << "the deck was not rewritten";
    ASSERT_NO_FATAL_FAILURE(expect_deck(project, MODEL_A, 2.0 - f));
    EXPECT_NEAR(stored_factor(project, MODEL_A), f, 2e-7); /* float resolution near 1.05 is 1.2e-7 */
    EXPECT_GT(std::abs(stored_factor(project, MODEL_A) - 1.05), 2e-6);
}

/* --- Per-engine model overrides --- */
/**
 * @brief Default model A and an override with model B, both previously adjusted (1.05) in the project.
 * Requirement: each engine is adjusted once to the configured factor (deck = base * 0.9, XML 1.1).
 */
TEST_F(RubberEfficiencyFactor, InitializeAdjustsEachOverriddenModelOnce)
{
    ASSERT_NO_FATAL_FAILURE(make_engine(project, MODEL_A, 1.05));
    ASSERT_NO_FATAL_FAILURE(make_engine(project, MODEL_B, 1.05));
    add_model_override("1", MODEL_B);
    set_configured_factor(1.1);
    design::Rubber designer{config, project, {}};

    designer.initialize();

    ASSERT_NO_FATAL_FAILURE(expect_deck(project, MODEL_A, 2.0 - 1.1));
    ASSERT_NO_FATAL_FAILURE(expect_deck(project, MODEL_B, 2.0 - 1.1));
    EXPECT_NEAR(stored_factor(project, MODEL_A), 1.1, 1e-6);
    EXPECT_NEAR(stored_factor(project, MODEL_B), 1.1, 1e-6);
}

/**
 * @brief Only the override model B was designed and is copied from the database.
 * Requirement: the copy of B is adjusted (deck = base * 0.9, XML 1.1).
 */
TEST_F(RubberEfficiencyFactor, SaveAdjustsCopiedOverrideModel)
{
    ASSERT_NO_FATAL_FAILURE(make_engine(database, MODEL_A, 1.0));
    ASSERT_NO_FATAL_FAILURE(make_engine(database, MODEL_B, 1.0));
    add_model_override("1", MODEL_B);
    set_configured_factor(1.1);
    design::Rubber designer{config, project, {}};
    designer.initialize();
    designer.add_designed_engine(MODEL_B);

    ASSERT_NO_THROW(designer.save());

    ASSERT_TRUE(std::filesystem::exists(project / MODEL_B / (std::string{MODEL_B} + ".xml")));
    ASSERT_NO_FATAL_FAILURE(expect_deck(project, MODEL_B, 2.0 - 1.1));
    EXPECT_NEAR(stored_factor(project, MODEL_B), 1.1, 1e-6);
}
