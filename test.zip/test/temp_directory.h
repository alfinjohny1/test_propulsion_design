/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 *
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

#ifndef TEST_TEMP_DIRECTORY_H_
#define TEST_TEMP_DIRECTORY_H_

/* === Includes === */
#include <chrono>
#include <cstdint>
#include <filesystem>
#include <random>
#include <string>

/**
 * @brief A new, empty directory with a unique name in the system temp folder,
 * removed again when the object goes out of scope.
 */
class UniqueTempDirectory
{
  public:
    explicit UniqueTempDirectory(const std::string &prefix)
    {
        std::mt19937_64 generator{std::random_device{}() ^
                                  static_cast<std::uint64_t>(std::chrono::steady_clock::now().time_since_epoch().count())};
        do
        {
            path_ = std::filesystem::temp_directory_path() / (prefix + "_" + std::to_string(generator()));
        } while (std::filesystem::exists(path_));
        std::filesystem::create_directories(path_);
    }
    ~UniqueTempDirectory()
    {
        std::error_code ec;
        std::filesystem::remove_all(path_, ec);
    }
    UniqueTempDirectory(const UniqueTempDirectory &) = delete;
    auto operator=(const UniqueTempDirectory &) -> UniqueTempDirectory & = delete;

    [[nodiscard]] auto path() const -> const std::filesystem::path & { return path_; }

  private:
    std::filesystem::path path_;
};

#endif // TEST_TEMP_DIRECTORY_H_
