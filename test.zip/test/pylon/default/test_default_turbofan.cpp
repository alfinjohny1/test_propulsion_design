/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <filesystem>
#include <gtest/gtest.h>

#include "pylon_test_geometry.h"

/* Unit Under Test */
#include "pylon/default/default_pylon.h"

/* === Fixtures === */
/* The aircraft geometry (nacelle, wing, aircraft) comes from pylon_test_geometry.h */
class PylonDefault : public ::testing::Test, protected PylonTestGeometry
{
  protected:
    std::shared_ptr<node> config = aixml::openDocument(std::filesystem::path{CMAKE_TEST_CONFIG_FILE});
};

/* === Tests === */
/**
 * @brief Test designing the pylon of a kerosene turbofan engine when the engine is under the wing.
 */
TEST_F(PylonDefault, DesignTurbofanKeroseneUnderWing)
{
    /* Create the pylon designer */
    geometry::pylon::Default designer{config, aircraft, {CMAKE_TEST_STUBS_DIR}};
    designer.initialize();

    /* Setup the engine */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({2.0, 3.0, -1.0});
    engine.set_nacelle(nacelle);

    /* Design the right engine */
    designer(engine);

    /* Check the result */
    auto result = engine.pylon();
    ASSERT_EQ(result.sections.size(), 2);
    EXPECT_EQ(result.normal, geom2::Direction_3(0, 0, -1));
    EXPECT_EQ(result.origin, geom2::Point_3(0, 0, 0));
    EXPECT_EQ(result.sections.at(0).name, "pylon");
    /*
     * origin == (0.375, 0.0, -0.584), not (0.0, 0.0, -0.5): the nacelle-side section sits at
     * attachment.first shifted by the fairing inset v_inset = (engine.length * 0.25, 0,
     * engine.height * 0.21 / 2) = (0.375, 0, 0.084) - see the offset_start comment below -
     * on top of the nacelle's own top-surface offset from the engine centerline (radius 0.5
     * for this fixture's unit-diameter test nacelle).
     */
    EXPECT_NEAR(result.sections.at(0).origin.x(), 0.375, 1e-3);
    EXPECT_NEAR(result.sections.at(0).origin.y(), 0.0, 1e-3);
    EXPECT_NEAR(result.sections.at(0).origin.z(), -0.584, 1e-3);
    /*
     * chord == 1.125, not the full engine length (1.5): capped so the nacelle-side section
     * never extends past the engine's own rear end. It starts 0.375 (= 0.25 * length) aft of
     * the engine's front/inlet reference (engine.position()), so only 1.125 (= 0.75 * length)
     * of runway remains before the engine's own casing ends.
     */
    EXPECT_NEAR(result.sections.at(0).get_chord_length(), 1.125, 1e-3);
    /*
     * origin.x() == 1.0, matching the wing's own local LEADING EDGE at this span station
     * (not the engine's own chordwise position of -1.0): for an under-wing pylon the wing-
     * side section anchors at the wing's LE, matching how a real pylon fairing's leading
     * edge blends into the wing's own leading edge. desired_chord (1.725) is bigger than
     * the local wing chord here (1.4, from this fixture's 2.0->1.0 taper interpolated at
     * z=-3), so the trailing-edge cap shrinks it down to the local wing chord exactly -
     * starting at the LE and running the full local chord lands precisely on the TE.
     */
    EXPECT_NEAR(result.sections.at(1).origin.x(), 1.0, 1e-3);
    EXPECT_NEAR(result.sections.at(1).origin.y(), 0.0, 1e-3);
    EXPECT_NEAR(result.sections.at(1).origin.z(), -3.0, 1e-3);
    EXPECT_NEAR(result.sections.at(1).get_chord_length(), 1.4, 1e-3);

    /* Design the left engine */
    engine.set_position({2.0, -3.0, -1.0});
    designer(engine);

    /* Check the result */
    result = engine.pylon();
    ASSERT_EQ(result.sections.size(), 2);
    EXPECT_EQ(result.normal, geom2::Direction_3(0, 0, -1));
    EXPECT_EQ(result.origin, geom2::Point_3(0, 0, 0));
    /*
     * origin == (0.375, 0.0, -0.584), not (0.0, 0.0, -0.5): the nacelle-side section sits at
     * attachment.first shifted by the fairing inset v_inset = (engine.length * 0.25, 0,
     * engine.height * 0.21 / 2) = (0.375, 0, 0.084) - see the offset_start comment below -
     * on top of the nacelle's own top-surface offset from the engine centerline (radius 0.5
     * for this fixture's unit-diameter test nacelle).
     */
    EXPECT_NEAR(result.sections.at(0).origin.x(), 0.375, 1e-3);
    EXPECT_NEAR(result.sections.at(0).origin.y(), 0.0, 1e-3);
    EXPECT_NEAR(result.sections.at(0).origin.z(), -0.584, 1e-3);
    /*
     * chord == 1.125, not the full engine length (1.5): capped so the nacelle-side section
     * never extends past the engine's own rear end. It starts 0.375 (= 0.25 * length) aft of
     * the engine's front/inlet reference (engine.position()), so only 1.125 (= 0.75 * length)
     * of runway remains before the engine's own casing ends.
     */
    EXPECT_NEAR(result.sections.at(0).get_chord_length(), 1.125, 1e-3);
    EXPECT_NEAR(result.sections.at(1).origin.x(), 1.0, 1e-3);
    EXPECT_NEAR(result.sections.at(1).origin.y(), 0.0, 1e-3);
    EXPECT_NEAR(result.sections.at(1).origin.z(), -3.0, 1e-3);
    EXPECT_NEAR(result.sections.at(1).get_chord_length(), 1.4, 1e-3);
}
/**
 * @brief Test designing the pylon of a kerosene turbofan engine when the engine is on the fuselage side.
 */
TEST_F(PylonDefault, DesignTurbofanKeroseneMidFuselage)
{
    /* Create the pylon designer */
    geometry::pylon::Default designer{config, aircraft, {CMAKE_TEST_STUBS_DIR}};
    designer.initialize();

    /* Setup the engine */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Mid}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({1.0, 2.0, 0.1});
    nacelle.sections.at(0).set_width(1.5);
    nacelle.sections.at(1).set_width(1.5);
    engine.set_nacelle(nacelle);

    /* Design the right engine */
    designer(engine);

    /*
     * NOTE: this test currently FAILS (section origins and chords). This is an unresolved
     * design/test question, not a confirmed source defect, and not simply a stale value:
     * the attachment points are parent-specific (get_fuselage_attachment_points() for this
     * engine), but pylon::Default::turbofan_method() takes the chord sizing and clearance from
     * the WING also for this fuselage-mounted engine (select_wing(), the wing's mean
     * aerodynamic chord, the wing trailing-edge cap, and "engine under the wing" is decided
     * relative to the wing). The expected values below (1.5 m chords) are not verified either.
     * A fuselage-pylon sizing rule has to be agreed before these expectations are changed.
     */

    /* Check the result */
    auto result = engine.pylon();
    ASSERT_EQ(result.sections.size(), 2);
    EXPECT_EQ(result.normal, geom2::Direction_3(0, 1, 0));
    EXPECT_EQ(result.origin, geom2::Point_3(0, 0, 0));
    EXPECT_EQ(result.name, "pylon_0");
    EXPECT_NEAR(result.sections.at(0).origin.x(), 0.0, 1e-3);
    EXPECT_NEAR(result.sections.at(0).origin.y(), 0.0, 1e-3);
    EXPECT_NEAR(result.sections.at(0).origin.z(), -0.75, 1e-3);
    EXPECT_NEAR(result.sections.at(0).get_chord_length(), 1.5, 1e-3);
    EXPECT_NEAR(result.sections.at(1).origin.x(), 0.0, 1e-3);
    EXPECT_NEAR(result.sections.at(1).origin.y(), 0.1, 1e-3);
    EXPECT_NEAR(result.sections.at(1).origin.z(), -1.5, 1e-3);
    EXPECT_NEAR(result.sections.at(1).get_chord_length(), 1.5, 1e-3);

    /* Design the left engine */
    engine.set_position({1.0, -2.0, 0.1});
    designer(engine);

    /* Check the result */
    result = engine.pylon();
    ASSERT_EQ(result.sections.size(), 2);
    EXPECT_EQ(result.normal, geom2::Direction_3(0, -1, 0));
    EXPECT_EQ(result.origin, geom2::Point_3(0, 0, 0));
    EXPECT_NEAR(result.sections.at(0).origin.x(), 0.0, 1e-3);
    EXPECT_NEAR(result.sections.at(0).origin.y(), 0.0, 1e-3);
    EXPECT_NEAR(result.sections.at(0).origin.z(), -0.75, 1e-3);
    EXPECT_NEAR(result.sections.at(0).get_chord_length(), 1.5, 1e-3);
    EXPECT_NEAR(result.sections.at(1).origin.x(), 0.0, 1e-3);
    EXPECT_NEAR(result.sections.at(1).origin.y(), -0.1, 1e-3);
    EXPECT_NEAR(result.sections.at(1).origin.z(), -1.5, 1e-3);
    EXPECT_NEAR(result.sections.at(1).get_chord_length(), 1.5, 1e-3);
}

/**
 * @brief When the parent location is Vertical::In no pylon is necessary.
 */
TEST_F(PylonDefault, DesignTurbofanKeroseneIn)
{
    /* Create the pylon designer */
    geometry::pylon::Default designer{config, aircraft, {CMAKE_TEST_STUBS_DIR}};
    designer.initialize();

    /* Setup the engine */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::In}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({1.0, 2.0, 0.1});
    nacelle.sections.at(0).set_width(1.5);
    nacelle.sections.at(1).set_width(1.5);
    engine.set_nacelle(nacelle);

    /* Design the right engine */
    designer(engine);

    /* Check the result */
    auto result = engine.pylon();
    ASSERT_TRUE(result.sections.empty());
}

/**
 * @brief Test designing unsupported pylons.
 */
TEST_F(PylonDefault, DesignTurbofanKeroseneUnsupported)
{
    /* Create the pylon designer */
    geometry::pylon::Default designer{config, aircraft, {CMAKE_TEST_STUBS_DIR}};
    designer.initialize();

    /* Setup the engine */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Fuselage, Lateral::Mid, Longitudinal::Rear, Vertical::Over}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({1.0, 2.0, 0.1});
    nacelle.sections.at(0).set_width(1.5);
    nacelle.sections.at(1).set_width(1.5);
    engine.set_nacelle(nacelle);

    /* Design the right engine */
    ASSERT_THROW(designer(engine), std::runtime_error);
}

/**
 * @brief Test designing a pylon when no aircraft geometry exists yet.
 */
TEST_F(PylonDefault, DesignTurbofanKeroseneNoGeometry)
{
    /* Create the pylon designer */
    geometry::pylon::Default designer{config, nullptr, {CMAKE_TEST_STUBS_DIR}};
    designer.initialize();

    /* Setup the engine */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Mid}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({1.0, 2.0, 0.1});
    nacelle.sections.at(0).set_width(1.5);
    nacelle.sections.at(1).set_width(1.5);
    engine.set_nacelle(nacelle);

    /* Design the right engine */
    ASSERT_NO_THROW(designer(engine));
    EXPECT_TRUE(engine.pylon().sections.empty());
}
