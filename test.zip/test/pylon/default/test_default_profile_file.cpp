/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 *
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/*
 * Unit tests for FR-7.3: a pylon profile file (*.dat) that does not exist in the geometry
 * directory is created with the default NACA 0012 profile and then used.
 *
 * The generated profile has exactly the points of test/stubs/pylon.dat, so a pylon designed
 * from a generated file must equal one designed from the stub.
 */

/* === Includes === */
#include <aircraftGeometry2/io/dat.h>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <gtest/gtest.h>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "../../temp_directory.h"
#include "pylon_test_geometry.h"

/* Unit Under Test */
#include "pylon/default/default_pylon.h"

/* === Fixtures === */
/**
 * @brief Aircraft geometry (pylon_test_geometry.h) and under-wing engine of
 * PylonDefault.DesignTurbofanKeroseneUnderWing, with the pylon designer on an empty temporary
 * geometry directory.
 */
class PylonProfileFile : public ::testing::Test, protected PylonTestGeometry
{
  protected:
    void set_profile(const std::string &profile)
    {
        config->at("module_configuration_file/program_settings/propulsion@Default/pylon/profile/value") = profile;
    }

    /* Design the pylon with the given geometry directory and return the engine */
    auto design(const std::filesystem::path &geometry_directory) -> Turbofan<EnergyCarrierFamily::Kerosene>
    {
        geometry::pylon::Default designer{config, aircraft, geometry_directory};
        designer.initialize();
        Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
        engine.set_dimension({0.8, 0.8, 1.5});
        engine.set_fan({0.9});
        engine.set_position({2.0, 3.0, -1.0});
        engine.set_nacelle(nacelle);
        designer(engine);
        return engine;
    }

    static auto read_text(const std::filesystem::path &file) -> std::string
    {
        std::ifstream stream(file);
        std::stringstream content;
        content << stream.rdbuf();
        return content.str();
    }

    std::shared_ptr<node> config = aixml::openDocument(std::filesystem::path{CMAKE_TEST_CONFIG_FILE});
    const UniqueTempDirectory geometry{"test_pylon_profile"};
};

/* === Tests === */
/**
 * @brief A missing pylon.dat is created with the NACA 0012 points (202 points from (0, 0) to (1, 0))
 * and a two-section pylon is designed from it.
 */
TEST_F(PylonProfileFile, CreatesMissingProfileFile)
{
    const std::filesystem::path profile_file = geometry.path() / "pylon.dat";
    ASSERT_FALSE(std::filesystem::exists(profile_file));

    const auto engine = design(geometry.path());

    ASSERT_TRUE(std::filesystem::exists(profile_file));
    const geom2::Polygon_2 contour = geom2::io::read_dat_file(profile_file);
    ASSERT_EQ(contour.size(), 202U);
    EXPECT_EQ(*contour.vertices_begin(), geom2::Point_2(0.0, 0.0));
    EXPECT_EQ(*std::prev(contour.vertices_end()), geom2::Point_2(1.0, 0.0));

    ASSERT_EQ(engine.pylon().sections.size(), 2U);
    EXPECT_EQ(engine.pylon().sections.at(0).name, "pylon");
}

/**
 * @brief Every coordinate of the created profile, checked independently against the NACA 4-digit
 * thickness distribution for t = 0.12 with closed trailing edge:
 *   x_i = (1 - cos(pi i / 100)) / 2,  i = 0 ... 100 (cosine spacing)
 *   |y| = 5 t (0.2969 sqrt(x) - 0.1281 x - 0.3516 x^2 + 0.2843 x^3 - 0.1015 x^4)
 * The coefficients sum to zero, so y(1) = 0. (The commonly published open-trailing-edge
 * set uses -0.1260 for the linear term.)
 * File layout: upper surface from (0, 0) to (1, 0), then lower surface from (0, 0) to (1, 0).
 * The file is read as plain text, independent of the geometry library's reader.
 */
TEST_F(PylonProfileFile, CreatedProfileMatchesNacaFormula)
{
    design(geometry.path());

    std::ifstream file(geometry.path() / "pylon.dat");
    std::string line;
    ASSERT_TRUE(std::getline(file, line));
    EXPECT_EQ(line, "#NACA0012");
    std::vector<std::pair<double, double>> points;
    while (std::getline(file, line))
    {
        std::istringstream row(line);
        double x = 0.0;
        double y = 0.0;
        if (row >> x >> y)
        {
            points.emplace_back(x, y);
        }
    }
    ASSERT_EQ(points.size(), 202U);

    constexpr double t = 0.12;
    const double pi = std::acos(-1.0);
    const auto thickness = [t](const double x)
    {
        return 5.0 * t * (0.2969 * std::sqrt(x) - 0.1281 * x - 0.3516 * x * x + 0.2843 * x * x * x - 0.1015 * x * x * x * x);
    };
    for (int surface = 0; surface < 2; ++surface)
    {
        const double sign = surface == 0 ? 1.0 : -1.0;
        for (int i = 0; i <= 100; ++i)
        {
            const double x = 0.5 * (1.0 - std::cos(pi * i / 100.0));
            const double y = sign * thickness(x);
            const auto &[actual_x, actual_y] = points[static_cast<std::size_t>(101 * surface + i)];
            /* The file holds 8 decimals */
            EXPECT_NEAR(actual_x, x, 1e-7) << (surface == 0 ? "upper" : "lower") << " point " << i;
            EXPECT_NEAR(actual_y, y, 1e-7) << (surface == 0 ? "upper" : "lower") << " point " << i;
        }
    }
}

/**
 * @brief The pylon designed from the created file equals the pylon designed from the stub pylon.dat.
 */
TEST_F(PylonProfileFile, CreatedProfileGivesSamePylonAsStub)
{
    const auto from_created = design(geometry.path());
    const auto from_stub = design(std::filesystem::path{CMAKE_TEST_STUBS_DIR});

    const auto &created = from_created.pylon();
    const auto &stub = from_stub.pylon();
    ASSERT_EQ(created.sections.size(), 2U);
    ASSERT_EQ(created.sections.size(), stub.sections.size());
    EXPECT_EQ(created.origin, stub.origin);
    EXPECT_EQ(created.normal, stub.normal);
    for (std::size_t i = 0; i < stub.sections.size(); ++i)
    {
        EXPECT_EQ(created.sections[i].name, stub.sections[i].name) << "section " << i;
        EXPECT_EQ(created.sections[i].origin, stub.sections[i].origin) << "section " << i;
        EXPECT_NEAR(created.sections[i].get_chord_length(), stub.sections[i].get_chord_length(), 1e-12) << "section " << i;
        const auto created_box = created.sections[i].get_contour(true).bbox();
        const auto stub_box = stub.sections[i].get_contour(true).bbox();
        EXPECT_NEAR(created_box.x_span(), stub_box.x_span(), 1e-12) << "section " << i;
        EXPECT_NEAR(created_box.y_span(), stub_box.y_span(), 1e-12) << "section " << i;
    }
}

/**
 * @brief Once the file exists it is read, not created again. After the first run the created
 * NACA 0012 file is replaced by a distinct valid profile (a 4-point diamond with thickness 0.4).
 * The second run must use the diamond and leave the file unchanged. Comparing the contour is
 * needed because the chord scaling would hide a profile that only differs in size.
 */
TEST_F(PylonProfileFile, SecondRunReadsExistingFile)
{
    const std::filesystem::path profile_file = geometry.path() / "pylon.dat";
    const auto first = design(geometry.path());
    ASSERT_EQ(first.pylon().sections.size(), 2U);
    ASSERT_EQ(first.pylon().sections.at(0).get_contour(false).size(), 202U);

    {
        std::ofstream diamond(profile_file, std::ios::trunc);
        diamond << "#diamond\n0 0\n0.5 0.2\n1 0\n0.5 -0.2\n";
    }
    const std::string diamond_content = read_text(profile_file);

    const auto second = design(geometry.path());

    EXPECT_EQ(read_text(profile_file), diamond_content) << "the existing profile file was overwritten";
    ASSERT_EQ(second.pylon().sections.size(), 2U);
    for (std::size_t i = 0; i < 2; ++i)
    {
        const auto &section = second.pylon().sections.at(i);
        EXPECT_EQ(section.get_contour(false).size(), 4U) << "section " << i;
        const auto box = section.get_contour(true).bbox();
        EXPECT_NEAR(box.y_span() / box.x_span(), 0.4, 1e-9) << "section " << i;
    }
}

/**
 * @brief A profile path that cannot be created (its folder is an existing regular file) gives a clear error.
 */
TEST_F(PylonProfileFile, UncreatableProfilePathThrows)
{
    std::ofstream(geometry.path() / "blocker") << "not a directory";
    set_profile("blocker/pylon.dat");

    try
    {
        design(geometry.path());
        FAIL() << "Expected std::runtime_error for an uncreatable profile path";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("Error while creating the file for pylon."), std::string::npos) << error.what();
    }
}

/**
 * @brief A profile in a missing subdirectory is created together with the subdirectory.
 */
TEST_F(PylonProfileFile, CreatesMissingSubdirectory)
{
    set_profile("profiles/pylon.dat");

    const auto engine = design(geometry.path());

    EXPECT_TRUE(std::filesystem::exists(geometry.path() / "profiles" / "pylon.dat"));
    EXPECT_EQ(engine.pylon().sections.size(), 2U);
}
