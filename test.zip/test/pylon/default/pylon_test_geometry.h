/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 *
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

#ifndef TEST_PYLON_DEFAULT_PYLON_TEST_GEOMETRY_H_
#define TEST_PYLON_DEFAULT_PYLON_TEST_GEOMETRY_H_

/* === Includes === */
#include <aircraftGeometry2/geometry/builder.h>
#include <memory>

#include "aircraft_geometry.h"

/**
 * @brief Aircraft geometry shared by the pylon tests: a unit-diameter nacelle (also used as the
 * fuselage) and a symmetric, tapered wing with chord 2.0 at the root and 1.0 at z = -5.
 */
struct PylonTestGeometry
{
    PylonTestGeometry()
    {
        geom2::Polygon_2 poly = geom2::build::ellipse(1.0, 1.0).get_contour(false);
        nacelle.sections.emplace_back(poly);
        nacelle.sections.emplace_back(poly);
        nacelle.sections.back().origin = geom2::Point_3(0, 0, 2.0);
        nacelle.normal = geom2::Direction_3(1, 0, 0);
        wing.sections.emplace_back(poly);
        wing.sections.emplace_back(poly);
        wing.sections.at(0).set_chord_length(2.0);
        wing.sections.at(1).set_chord_length(1.0);
        wing.sections.at(1).origin = geom2::Point_3(0, 0, -5.0);
        wing.origin = geom2::Point_3(3, 0, 2);
        wing.normal = geom2::Direction_3(0, -1, 0);
        wing.is_symmetric = true;
        aircraft->wings.emplace_back(wing);
        aircraft->fuselages.emplace_back(nacelle);
    }

    geom2::MultisectionSurface<geom2::PolygonSection> nacelle;
    geom2::MultisectionSurface<geom2::AirfoilSection> wing;
    std::shared_ptr<geometry::Aircraft> aircraft = std::make_shared<geometry::Aircraft>();
};

#endif // TEST_PYLON_DEFAULT_PYLON_TEST_GEOMETRY_H_
