/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 *
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/*
 * Unit tests for report::BucketCurve (FR-10.2 curve summation, FR-10.3 bucket point).
 */

/* === Includes === */
#include <gtest/gtest.h>
#include <valarray>

/* Unit Under Test */
#include "report/report_data.h"

/* === Helpers === */
namespace
{
    constexpr double TOLERANCE = 1e-12;

    void expect_array_near(const std::valarray<double> &actual, const std::valarray<double> &expected)
    {
        ASSERT_EQ(actual.size(), expected.size());
        for (std::size_t i = 0; i < expected.size(); ++i)
        {
            EXPECT_NEAR(actual[i], expected[i], TOLERANCE) << "index " << i;
        }
    }
} // namespace

/* === Tests === */
/**
 * @brief A default curve has report::bucket_points entries for thrust and fuel flow.
 */
TEST(BucketCurve, DefaultSize)
{
    const report::BucketCurve curve{};

    EXPECT_EQ(curve.thrust().size(), report::bucket_points);
    EXPECT_EQ(curve.fuel_flow().size(), report::bucket_points);
}

/**
 * @brief The constructor and the setters store the given arrays.
 */
TEST(BucketCurve, ConstructorAndSetters)
{
    report::BucketCurve curve{{100.0, 200.0}, {1.0, 3.0}};
    expect_array_near(curve.thrust(), {100.0, 200.0});
    expect_array_near(curve.fuel_flow(), {1.0, 3.0});

    curve.set_thrust({10.0, 20.0, 30.0});
    curve.set_fuel_flow({0.1, 0.2, 0.3});
    expect_array_near(curve.thrust(), {10.0, 20.0, 30.0});
    expect_array_near(curve.fuel_flow(), {0.1, 0.2, 0.3});
}

/**
 * @brief TSFC is the element-wise ratio fuel flow / thrust.
 */
TEST(BucketCurve, TsfcIsFuelFlowOverThrust)
{
    const report::BucketCurve curve{{100.0, 200.0, 400.0}, {1.0, 1.0, 2.0}};

    expect_array_near(curve.tsfc(), {0.01, 0.005, 0.005});
}

/**
 * @brief The bucket point is the thrust and TSFC at the minimum TSFC.
 */
TEST(BucketCurve, BucketPointAtMinimumTsfc)
{
    report::BucketCurve curve{{100.0, 200.0, 300.0}, {2.0, 1.0, 3.0}}; // TSFC: 0.02, 0.005, 0.01

    const BucketPoint point = curve.bucket_point();

    EXPECT_NEAR(point.thrust, 200.0, TOLERANCE);
    EXPECT_NEAR(point.tsfc, 0.005, TOLERANCE);
}

/**
 * @brief The minimum may lie at either end of the curve.
 */
TEST(BucketCurve, BucketPointAtCurveEnds)
{
    report::BucketCurve first{{100.0, 200.0, 300.0}, {0.5, 2.0, 3.0}}; // TSFC: 0.005, 0.01, 0.01
    EXPECT_NEAR(first.bucket_point().thrust, 100.0, TOLERANCE);

    report::BucketCurve last{{100.0, 200.0, 300.0}, {2.0, 3.0, 0.3}}; // TSFC: 0.02, 0.015, 0.001
    EXPECT_NEAR(last.bucket_point().thrust, 300.0, TOLERANCE);
}

/**
 * @brief With equal minima the first one (lowest index) is taken.
 */
TEST(BucketCurve, BucketPointTieTakesFirst)
{
    report::BucketCurve curve{{100.0, 200.0, 400.0}, {1.0, 1.0, 2.0}}; // TSFC: 0.01, 0.005, 0.005

    EXPECT_NEAR(curve.bucket_point().thrust, 200.0, TOLERANCE);
}

/**
 * @brief The const overload gives the same bucket point as the non-const one.
 */
TEST(BucketCurve, ConstBucketPointMatches)
{
    report::BucketCurve curve{{100.0, 200.0, 300.0}, {2.0, 1.0, 3.0}};
    const report::BucketCurve &const_curve = curve;

    const BucketPoint from_const = const_curve.bucket_point(); // not cached yet -> computed
    const BucketPoint from_non_const = curve.bucket_point();   // computes and caches
    const BucketPoint from_const_cached = const_curve.bucket_point();

    EXPECT_NEAR(from_const.thrust, from_non_const.thrust, TOLERANCE);
    EXPECT_NEAR(from_const.tsfc, from_non_const.tsfc, TOLERANCE);
    EXPECT_NEAR(from_const_cached.thrust, from_non_const.thrust, TOLERANCE);
    EXPECT_NEAR(from_const_cached.tsfc, from_non_const.tsfc, TOLERANCE);
}

/**
 * @brief update_bucket_point() makes the cached point available to the const overload.
 */
TEST(BucketCurve, UpdateBucketPoint)
{
    report::BucketCurve curve{{100.0, 200.0, 300.0}, {2.0, 1.0, 3.0}};
    curve.update_bucket_point();
    const report::BucketCurve &const_curve = curve;

    EXPECT_NEAR(const_curve.bucket_point().thrust, 200.0, TOLERANCE);
    EXPECT_NEAR(const_curve.bucket_point().tsfc, 0.005, TOLERANCE);
}

/**
 * @brief operator+ adds thrust and fuel flow element-wise and leaves the operands unchanged.
 */
TEST(BucketCurve, AdditionIsElementWise)
{
    const report::BucketCurve lhs{{100.0, 200.0, 300.0}, {2.0, 1.0, 3.0}};
    const report::BucketCurve rhs{{50.0, 100.0, 150.0}, {0.5, 1.5, 0.5}};

    const report::BucketCurve sum = lhs + rhs;

    expect_array_near(sum.thrust(), {150.0, 300.0, 450.0});
    expect_array_near(sum.fuel_flow(), {2.5, 2.5, 3.5});
    expect_array_near(lhs.thrust(), {100.0, 200.0, 300.0});
    expect_array_near(rhs.fuel_flow(), {0.5, 1.5, 0.5});
}

/**
 * @brief The bucket point of a sum is taken from the summed curve,
 * not from adding the bucket points of the operands.
 */
TEST(BucketCurve, BucketPointOfSumUsesSummedCurve)
{
    const report::BucketCurve lhs{{100.0, 200.0, 300.0}, {2.0, 1.0, 3.0}};  // bucket at index 1
    const report::BucketCurve rhs{{100.0, 100.0, 100.0}, {0.5, 2.0, 0.1}}; // bucket at index 2

    report::BucketCurve sum = lhs + rhs; // thrust 200, 300, 400; fuel flow 2.5, 3.0, 3.1
                                         // TSFC   0.0125, 0.01, 0.00775 -> index 2
    const BucketPoint point = sum.bucket_point();

    EXPECT_NEAR(point.thrust, 400.0, TOLERANCE);
    EXPECT_NEAR(point.tsfc, 3.1 / 400.0, TOLERANCE);
}

/**
 * @brief operator+= gives the same curve as operator+.
 */
TEST(BucketCurve, PlusAssignMatchesPlus)
{
    const report::BucketCurve lhs{{100.0, 200.0, 300.0}, {2.0, 1.0, 3.0}};
    const report::BucketCurve rhs{{50.0, 100.0, 150.0}, {0.5, 1.5, 0.5}};

    report::BucketCurve accumulated = lhs;
    accumulated += rhs;
    const report::BucketCurve sum = lhs + rhs;

    expect_array_near(accumulated.thrust(), sum.thrust());
    expect_array_near(accumulated.fuel_flow(), sum.fuel_flow());
}

/**
 * @brief operator+= invalidates a cached bucket point, so the next query sees the new data.
 */
TEST(BucketCurve, PlusAssignInvalidatesCachedBucketPoint)
{
    report::BucketCurve curve{{100.0, 200.0, 300.0}, {2.0, 1.0, 3.0}};
    ASSERT_NEAR(curve.bucket_point().thrust, 200.0, TOLERANCE); // cached at index 1

    curve += report::BucketCurve{{100.0, 100.0, 100.0}, {0.5, 2.0, 0.1}};

    EXPECT_NEAR(curve.bucket_point().thrust, 400.0, TOLERANCE); // now index 2
    const report::BucketCurve &const_curve = curve;
    EXPECT_NEAR(const_curve.bucket_point().thrust, 400.0, TOLERANCE);
}

/**
 * @brief Summing curves starting from a default (all-zero) curve gives the summed engine curves,
 * as done for the "with offtakes" / "without offtakes" totals in report::generate_data().
 */
TEST(BucketCurve, AccumulateFromDefaultCurve)
{
    report::BucketCurve total{};
    std::valarray<double> thrust(report::bucket_points);
    std::valarray<double> fuel_flow(report::bucket_points);
    for (std::size_t i = 0; i < report::bucket_points; ++i)
    {
        thrust[i] = 1000.0 + 10.0 * static_cast<double>(i);
        fuel_flow[i] = 0.02 + 0.0001 * static_cast<double>(i);
    }
    const report::BucketCurve engine{thrust, fuel_flow};

    total += engine;
    total += engine;

    expect_array_near(total.thrust(), 2.0 * thrust);
    expect_array_near(total.fuel_flow(), 2.0 * fuel_flow);
    expect_array_near(total.tsfc(), engine.tsfc());
}
