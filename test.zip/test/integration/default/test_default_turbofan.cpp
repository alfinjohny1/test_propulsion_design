/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <filesystem>
#include <gtest/gtest.h>
#include <aircraftGeometry2/geometry/builder.h>

/* Unit Under Test */
#include "integration/default/default_integration.h"

/* === Fixtures === */
class IntegrationDefault : public ::testing::Test
{
  protected:
    void SetUp() override
    {
        /* Setup the aircraft geometry */
        geom2::Polygon_2 poly = geom2::build::ellipse(1.0, 1.0).get_contour(false);
        geom2::Polygon_2 airfoil;
        airfoil.push_back({0, 0});
        airfoil.push_back({0.5, 0.2});
        airfoil.push_back({1.0, 0});
        airfoil.push_back({0.0, 0.0});

        /* Nacelle */
        nacelle.sections.emplace_back(poly);
        nacelle.sections.emplace_back(poly);
        nacelle.sections.back().origin = geom2::Point_3(0, 0, 2.0);
        nacelle.normal = geom2::Direction_3(1, 0, 0);

        /* Main Wing */
        wing.sections.emplace_back(airfoil);
        wing.sections.emplace_back(airfoil);
        wing.sections.at(0).set_chord_length(2.0);
        wing.sections.at(1).set_chord_length(1.0);
        wing.sections.at(1).origin = geom2::Point_3(0, 0, -5.0);
        wing.origin = geom2::Point_3(3, 0, 2);
        wing.normal = geom2::Direction_3(0, -1, 0);

        /* Vertical Tail */
        vtp.sections.emplace_back(airfoil);
        vtp.sections.emplace_back(airfoil);
        vtp.sections.at(0).set_chord_length(1.0);
        vtp.sections.at(1).set_chord_length(0.5);
        vtp.sections.at(1).origin = geom2::Point_3(1.0, 0, -3.0);
        vtp.origin = geom2::Point_3(1.0, 0, 0.5);
        vtp.normal = geom2::Direction_3(0, 0, -1);
        vtp.is_symmetric = false;

        /* Assemble the aircraft */
        aircraft->wings.emplace_back(wing);
        aircraft->fuselages.emplace_back(nacelle);
        aircraft->empennage.emplace_back(vtp);
    }

    /* A wing-mounted test engine (0.8 x 0.8 x 1.5 m, fan 0.9 m) with its own ID */
    auto make_wing_engine(const int id, const Lateral lateral, const Vertical vertical) const -> Turbofan<EnergyCarrierFamily::Kerosene>
    {
        Turbofan<EnergyCarrierFamily::Kerosene> engine{id, {Parent::Wing, lateral, Longitudinal::Front, vertical}};
        engine.set_dimension({0.8, 0.8, 1.5});
        engine.set_fan({0.9});
        engine.set_nacelle(nacelle);
        return engine;
    }

    std::shared_ptr<node> config = aixml::openDocument(std::filesystem::path{CMAKE_TEST_CONFIG_FILE});
    geom2::MultisectionSurface<geom2::PolygonSection> nacelle;
    geom2::MultisectionSurface<geom2::AirfoilSection> wing;
    geom2::MultisectionSurface<geom2::AirfoilSection> vtp;
    std::shared_ptr<geometry::Aircraft> aircraft = std::make_shared<geometry::Aircraft>();
};

/* === Tests === */
/*
 * Expected wing-mounted positions are derived by hand from the placement rules in
 * integrate_into_wing() / calculate_span_position() (Ata10) for this fixture:
 *   wing: straight, chord 2 m at the root and 1 m at local z = -5 (span 5 m), LE at local x = 0,
 *         origin (3, 0, 2); local (x, y, z) maps to global (3 + x, -z, 2 + y)
 *   fuselage width w = 1 m, nacelle height 1 m, engine length L = 1.5 m
 *   D_max = 1.21 * fan diameter = 1.21 * 0.9 = 1.089 m
 *   span position s: 2 engines        0.95 * (w/2 + 1.3 D_max + 0.5 D_max) = 2.33719 m
 *                    4 engines, inner (0.9/4) * (0.64 * span + w - D_max)   = 0.699975 m
 *                    4 engines, outer 0.64 * span / 2                       = 1.6 m
 *   local chord c(s) = 2 - s / 5
 *   under the wing: x = 0.10 c - 0.9 L,  y = -0.5 * nacelle height - 0.1 c
 *   over the wing:  x = 0.75 c,          y = +0.8 * nacelle height
 * Slots on a side are assigned from the number of wing engines already integrated
 * (engines_done.wing modulo the number of slots per side): inner first, then outer.
 */

/**
 * @brief Test integrating a turbofan engine into a wing with two engines under the wing.
 * s = 2.33719, c = 1.532562: x = 3 + 0.1532562 - 1.35 = 1.8032562, z = 2 - 0.5 - 0.1532562 = 1.3467438.
 */
TEST_F(IntegrationDefault, IntegrateTurbofanKeroseneTwoEnginesUnderWing)
{
    /* Create the engine designer */
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup right engine */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_right{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine_right.set_dimension({0.8, 0.8, 1.5});
    engine_right.set_fan({0.9});
    engine_right.set_nacelle(nacelle);

    /* Setup left engine */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_left{1, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}};
    engine_left.set_dimension({0.8, 0.8, 1.5});
    engine_left.set_fan({0.9});
    engine_left.set_nacelle(nacelle);

    /* Design the right engine */
    integrator(engine_right);
    EXPECT_NEAR(engine_right.position().x(), 1.8032562, 1e-6);
    EXPECT_NEAR(engine_right.position().y(), 2.33719, 1e-6);
    EXPECT_NEAR(engine_right.position().z(), 1.3467438, 1e-6);

    /* Design the left engine: mirrored in y */
    integrator(engine_left);
    EXPECT_NEAR(engine_left.position().x(), 1.8032562, 1e-6);
    EXPECT_NEAR(engine_left.position().y(), -2.33719, 1e-6);
    EXPECT_NEAR(engine_left.position().z(), 1.3467438, 1e-6);
}

/**
 * @brief Test integrating turbofan engines over the wing (supported mount {Wing, *, Front, Over}).
 * s = 2.33719, c = 1.532562: x = 3 + 0.75 c = 4.1494215, z = 2 + 0.8 = 2.8.
 */
TEST_F(IntegrationDefault, IntegrateTurbofanKeroseneTwoEnginesOverWing)
{
    /* Create the engine designer */
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the engines */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_right{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Over}};
    engine_right.set_dimension({0.8, 0.8, 1.5});
    engine_right.set_fan({0.9});
    engine_right.set_nacelle(nacelle);
    Turbofan<EnergyCarrierFamily::Kerosene> engine_left{1, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Over}};
    engine_left.set_dimension({0.8, 0.8, 1.5});
    engine_left.set_fan({0.9});
    engine_left.set_nacelle(nacelle);

    /* Design the engines */
    integrator(engine_right);
    EXPECT_NEAR(engine_right.position().x(), 4.1494215, 1e-6);
    EXPECT_NEAR(engine_right.position().y(), 2.33719, 1e-6);
    EXPECT_NEAR(engine_right.position().z(), 2.8, 1e-6);

    integrator(engine_left);
    EXPECT_NEAR(engine_left.position().x(), 4.1494215, 1e-6);
    EXPECT_NEAR(engine_left.position().y(), -2.33719, 1e-6);
    EXPECT_NEAR(engine_left.position().z(), 2.8, 1e-6);
}

/**
 * @brief Test integrating a turbofan engine into a wing with four engines under the wing.
 * Inner: s = 0.699975, c = 1.860005: x = 3 + 0.1860005 - 1.35 = 1.8360005, z = 2 - 0.5 - 0.1860005 = 1.3139995.
 * Outer: s = 1.6,      c = 1.68:     x = 3 + 0.168 - 1.35     = 1.818,     z = 2 - 0.5 - 0.168     = 1.332.
 */
TEST_F(IntegrationDefault, IntegrateTurbofanKeroseneFourEnginesUnderWing)
{
    /* Create the engine designer */
    design::integration::Default integrator{config, aircraft, {0, 4, 0}};

    /* Four distinct engines, integrated in the order right inner, right outer, left inner, left outer */
    auto engine_right_inner = make_wing_engine(0, Lateral::Right, Vertical::Under);
    auto engine_right_outer = make_wing_engine(1, Lateral::Right, Vertical::Under);
    auto engine_left_inner = make_wing_engine(2, Lateral::Left, Vertical::Under);
    auto engine_left_outer = make_wing_engine(3, Lateral::Left, Vertical::Under);

    /* Right side: the first engine takes the inner slot */
    integrator(engine_right_inner);
    EXPECT_NEAR(engine_right_inner.position().x(), 1.8360005, 1e-6);
    EXPECT_NEAR(engine_right_inner.position().y(), 0.699975, 1e-6);
    EXPECT_NEAR(engine_right_inner.position().z(), 1.3139995, 1e-6);

    /* Right side: the second engine takes the outer slot */
    integrator(engine_right_outer);
    EXPECT_NEAR(engine_right_outer.position().x(), 1.818, 1e-6);
    EXPECT_NEAR(engine_right_outer.position().y(), 1.6, 1e-6);
    EXPECT_NEAR(engine_right_outer.position().z(), 1.332, 1e-6);

    /* Left side: inner slot, mirrored in y */
    integrator(engine_left_inner);
    EXPECT_NEAR(engine_left_inner.position().x(), 1.8360005, 1e-6);
    EXPECT_NEAR(engine_left_inner.position().y(), -0.699975, 1e-6);
    EXPECT_NEAR(engine_left_inner.position().z(), 1.3139995, 1e-6);

    /* Left side: outer slot, mirrored in y */
    integrator(engine_left_outer);
    EXPECT_NEAR(engine_left_outer.position().x(), 1.818, 1e-6);
    EXPECT_NEAR(engine_left_outer.position().y(), -1.6, 1e-6);
    EXPECT_NEAR(engine_left_outer.position().z(), 1.332, 1e-6);

    /* The first two engines keep their positions */
    EXPECT_NEAR(engine_right_inner.position().y(), 0.699975, 1e-6);
    EXPECT_NEAR(engine_right_outer.position().y(), 1.6, 1e-6);
}

/**
 * @brief A wing configured for two engines must reject a third one (FR-6.7).
 * integrate_into_wing() contains the check "No space on the wing for the engine to be integrated",
 * but the slot index it tests is engines_done.wing modulo the number of slots per side, so it is
 * always below the limit and the check cannot trigger. This test is expected to FAIL until that
 * is fixed in the source; it is kept separate from the position tests on purpose.
 */
TEST_F(IntegrationDefault, IntegrateTurbofanKeroseneWingRejectsExtraEngine)
{
    /* Create the engine designer */
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    auto engine_right = make_wing_engine(0, Lateral::Right, Vertical::Under);
    auto engine_left = make_wing_engine(1, Lateral::Left, Vertical::Under);
    auto engine_extra = make_wing_engine(2, Lateral::Right, Vertical::Under);

    integrator(engine_right);
    integrator(engine_left);

    /* A distinct third engine on a wing configured for two */
    EXPECT_THROW(integrator(engine_extra), std::runtime_error);
}

/**
 * @brief Test integrating a turbofan into a fuselage with two engines in the rear.
 */
TEST_F(IntegrationDefault, IntegrateTurbofanKeroseneTwoEnginesMidFuselage)
{
    /* Create the engine designer */
    design::integration::Default integrator{config, aircraft, {2, 0, 0}};

    /* Setup right engine */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_right{0, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Mid}};
    engine_right.set_dimension({0.8, 0.8, 1.5});
    engine_right.set_fan({0.9});
    engine_right.set_nacelle(nacelle);

    /* Setup left engine */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_left{1, {Parent::Fuselage, Lateral::Left, Longitudinal::Rear, Vertical::Mid}};
    engine_left.set_dimension({0.8, 0.8, 1.5});
    engine_left.set_fan({0.9});
    engine_left.set_nacelle(nacelle);

    /* Test invalid engine setups */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_invalid{2, {Parent::Fuselage, Lateral::Left, Longitudinal::Front, Vertical::In}};
    EXPECT_THROW(integrator(engine_invalid), std::runtime_error);

    /* Design the first engine */
    integrator(engine_right);
    EXPECT_NEAR(engine_right.position().x(), 1.600, 1e-3);
    EXPECT_NEAR(engine_right.position().y(), 1.125, 1e-3);
    EXPECT_NEAR(engine_right.position().z(), 0.250, 1e-3);

    /* Integrating the first engine again should throw */
    EXPECT_THROW(integrator(engine_right), std::runtime_error);

    /*
     * Design the second engine: expected at the lateral mirror of the right engine.
     * NOTE: this currently FAILS because of a suspected source defect (O-28), not a stale
     * expectation. integrate_into_fuselage() works in the fuselage-local frame
     * (X width, Y height, Z length, see its own comment) but mirrors a left engine with
     * z -> -z, i.e. along the fuselage LENGTH, which puts it at (-1.6, 1.125, 0.25)
     * instead of mirroring the width coordinate. Do not change these values to the output.
     */
    integrator(engine_left);
    EXPECT_NEAR(engine_left.position().x(), 1.600, 1e-3);
    EXPECT_NEAR(engine_left.position().y(), -1.125, 1e-3);
    EXPECT_NEAR(engine_left.position().z(), 0.250, 1e-3);

    /* Integrating the second engine again should throw */
    EXPECT_THROW(integrator(engine_left), std::runtime_error);
}

/**
 * @brief Test integrating a turbofan into the bottom of a vertical tail.
 */
TEST_F(IntegrationDefault, IntegrateTurbofanKeroseneOneEngineInVerticalTail)
{
    /* Create the engine designer */
    design::integration::Default integrator{config, aircraft, {0, 0, 1}};

    /* Setup engine */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Empennage, Lateral::Mid, Longitudinal::Front, Vertical::In}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Design the engine */
    integrator(engine);
    EXPECT_NEAR(engine.position().x(), 1.264, 1e-3);
    EXPECT_NEAR(engine.position().y(), 0.0, 1e-3);
    EXPECT_NEAR(engine.position().z(), 1.0, 1e-3);

    /* Integrating the engine again should throw */
    EXPECT_THROW(integrator(engine), std::runtime_error);
}

/**
 * @brief Test integrating a turbofan into an unsupported parent component.
 */
TEST_F(IntegrationDefault, IntegrateTurbofanKeroseneUnsupported)
{
    /* Create the engine designer */
    design::integration::Default integrator{config, aircraft, {0, 0, 0}};

    /* Setup engine */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Fuselage, Lateral::Mid, Longitudinal::Rear, Vertical::Over}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Test the unsupported parent component */
    EXPECT_THROW(integrator(engine), std::runtime_error);
    engine = Turbofan<EnergyCarrierFamily::Kerosene>{0, {Parent::Fuselage, Lateral::Mid, Longitudinal::Rear, Vertical::Mid}};
    EXPECT_THROW(integrator(engine), std::runtime_error);
}

/**
 * @brief Test integrating engines when no aircraft geometry is provided.
 */
TEST_F(IntegrationDefault, IntegrateTurbofanKeroseneNoAircraftGeometry)
{
    /* Create the engine designer */
    design::integration::Default integrator{config, nullptr, {0, 0, 0}};

    /* Setup engine */
    Turbofan<EnergyCarrierFamily::Kerosene> engine0{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine0.set_dimension({0.8, 0.8, 1.5});
    engine0.set_fan({0.9});
    engine0.set_nacelle(nacelle);
    Turbofan<EnergyCarrierFamily::Kerosene> engine1{0, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}};
    engine1.set_dimension({0.8, 0.8, 1.5});
    engine1.set_fan({0.9});
    engine1.set_nacelle(nacelle);

    /* Test integrating the engine at default positions */
    EXPECT_NO_THROW(integrator(engine0));
    EXPECT_NEAR(engine0.position().x(), 0.0, 1e-3);
    EXPECT_NEAR(engine0.position().y(), 0.0, 1e-3);
    EXPECT_NEAR(engine0.position().z(), 0.0, 1e-3);

    /* Test integrating the engine at default positions */
    EXPECT_NO_THROW(integrator(engine1));
    EXPECT_NEAR(engine1.position().x(), 0.0, 1e-3);
    EXPECT_NEAR(engine1.position().y(), 0.0, 1e-3);
    EXPECT_NEAR(engine1.position().z(), 0.0, 1e-3);

}

/**
 * @brief Test integrating engines with invalid aircraft geometry.
 */
TEST_F(IntegrationDefault, IntegrateTurbofanKeroseneInvalidAircraftGeometry)
{
    /* Create the engine designer */
    design::integration::Default integrator{config, aircraft, {2, 2, 1}};

    /* Setup engine */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Empennage, Lateral::Mid, Longitudinal::Front, Vertical::In}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Test integrating when there is no vertical tail */
    aircraft->empennage.at(0).normal = geom2::Direction_3{0, 1, 0};
    EXPECT_THROW(integrator(engine), std::runtime_error);
    
    /* Test integrating when there are multiple wings */
    engine.set_parent({Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under});
    aircraft->wings.emplace_back(aircraft->wings.at(0));
    EXPECT_THROW(integrator(engine), std::runtime_error);
    
    /* Test integrating when there are multiple fuselages */
    engine.set_parent({Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Mid});
    aircraft->fuselages.emplace_back(aircraft->fuselages.at(0));
    EXPECT_THROW(integrator(engine), std::runtime_error);
}
