/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <filesystem>
#include <gtest/gtest.h>

/* Unit Under Test */
#include "propulsion.h"

/* === Fixtures === */

/* === Tests === */
/**
 * @brief Test getting the fuel type of the propulsion base type.
 */
TEST(Propulsion, GetEnergyCarrier)
{
    /* Create a kerosene based propulsion */
    Propulsion<EnergyCarrierFamily::Kerosene> engine;

    /* Check the fuel type */
    EXPECT_EQ(engine.energy_carrier, EnergyCarrierFamily::Kerosene);
}

/**
 * @brief Test the base properties of the propulsion base type.
 */
TEST(Propulsion, BaseProperties)
{
    /* Create a kerosene based propulsion */
    Propulsion<EnergyCarrierFamily::Kerosene> engine;

    /* Check the properties */
    EXPECT_TRUE(engine.model().empty());
    EXPECT_TRUE(engine.nacelle().sections.empty());
    EXPECT_TRUE(engine.pylon().sections.empty());
    EXPECT_TRUE(engine.bucket_point().thrust < 0);
    EXPECT_TRUE(engine.bucket_point().tsfc < 0);
    EXPECT_EQ(engine.id(), 0);
    EXPECT_EQ(engine.offtakes().bleed_air, 0.0);
    EXPECT_EQ(engine.offtakes().shaft_power, 0.0);
    EXPECT_EQ(engine.position(), geom2::Point_3(0, 0, 0));
    EXPECT_EQ(engine.required_thrust(), 0.0);
    EXPECT_DOUBLE_EQ(engine.dimension().width, 0.0);
    EXPECT_DOUBLE_EQ(engine.dimension().length, 0.0);
    EXPECT_DOUBLE_EQ(engine.dimension().height, 0.0);
    EXPECT_DOUBLE_EQ(engine.scale(), 1.0);

    /* Check mass properties */
    EXPECT_DOUBLE_EQ(engine.pointmass(Component::Engine).mass, 0.0);
    EXPECT_DOUBLE_EQ(engine.pointmass(Component::Engine).CG.x(), 0.0);
    EXPECT_DOUBLE_EQ(engine.pointmass(Component::Engine).CG.y(), 0.0);
    EXPECT_DOUBLE_EQ(engine.pointmass(Component::Engine).CG.z(), 0.0);
    EXPECT_DOUBLE_EQ(engine.pointmass(Component::Engine).inertia(0, 0), 0.0);
}

/**
 * @brief Test the needed constructors of the propulsion base type.
 */
TEST(Propulsion, Constructors)
{
    /* Create a container of the propulsion base type */
    std::vector<Propulsion<EnergyCarrierFamily::Kerosene>> engines;

    /* Test the move constructor */
    auto moved_engine = Propulsion<EnergyCarrierFamily::Kerosene>{};
    EXPECT_TRUE(moved_engine.model().empty());

    /* Test the move assignment operator */
    moved_engine = Propulsion<EnergyCarrierFamily::Kerosene>{};
    EXPECT_TRUE(moved_engine.model().empty());
}

/**
 * @brief Check the parent component of the propulsion base type.
 */
TEST(Propulsion, ParentComponent)
{
    /* Create a kerosene based propulsion */
    Propulsion<EnergyCarrierFamily::Kerosene> engine;

    /* Check the initial parent component */
    EXPECT_EQ(std::get<Parent>(engine.parent_component()), Parent::Fuselage);
    EXPECT_EQ(std::get<Lateral>(engine.parent_component()), Lateral::Left);
    EXPECT_EQ(std::get<Longitudinal>(engine.parent_component()), Longitudinal::Front);
    EXPECT_EQ(std::get<Vertical>(engine.parent_component()), Vertical::Over);

    /* Set the parent component */
    auto parent = std::make_tuple(Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under);
    engine.set_parent(parent);
    EXPECT_EQ(engine.parent_component(), parent);

    /* Test the constructor with a parent component */
    Propulsion<EnergyCarrierFamily::Kerosene> engine1{1, parent};
    EXPECT_EQ(engine1.parent_component(), parent);
}

/**
 * @brief Test setting the bucket point of a propulsion.
 */
TEST(Propulsion, SetBucketPoint)
{
    /* Create a kerosene based propulsion */
    Propulsion<EnergyCarrierFamily::Kerosene> engine;

    /* Set the bucket point */
    engine.set_bucket_point({100.0, 0.5});

    /* Check the properties */
    EXPECT_DOUBLE_EQ(engine.bucket_point().thrust, 100.0);
    EXPECT_DOUBLE_EQ(engine.bucket_point().tsfc, 0.5);
}

/**
 * @brief Test setting the dimensions of the propulsion base type.
 */
TEST(Propulsion, SetDimensions)
{
    /* Create a kerosene based propulsion */
    Propulsion<EnergyCarrierFamily::Kerosene> engine;

    /* Set the dimensions */
    engine.set_model("Test");
    engine.set_dimension({1.0, 2.0, 3.0});

    /* Check the properties */
    EXPECT_EQ(engine.model(), "Test");
    EXPECT_DOUBLE_EQ(engine.dimension().height, 1.0);
    EXPECT_DOUBLE_EQ(engine.dimension().width, 2.0);
    EXPECT_DOUBLE_EQ(engine.dimension().length, 3.0);
}

/**
 * @brief Test setting the dimensions of the propulsion base type.
 */
TEST(Propulsion, SetMasses)
{
    /* Create a kerosene based propulsion */
    Propulsion<EnergyCarrierFamily::Kerosene> engine;
    engine.set_model("Test");
    PointMass testMass;
    /* Modify the components of testMass as needed */
    testMass.CG = Eigen::Vector3d::Ones();
    testMass.inertia = Eigen::Matrix3d::Ones();
    testMass.mass = 300.0;
    engine.set_pointmass(Component::Engine, testMass);

    /* Check the properties */
    EXPECT_EQ(engine.model(), "Test");
    EXPECT_TRUE(engine.pointmass(Component::Engine).CG.isApprox(Eigen::Vector3d::Ones(), 1e-6));
    EXPECT_TRUE(engine.pointmass(Component::Engine).inertia.isApprox(Eigen::Matrix3d::Ones(), 1e-6));
    EXPECT_DOUBLE_EQ(engine.pointmass(Component::Engine).mass, 300.0);
}


/**
 * @brief Test setting the scale which should affect the dimensions.
 */
TEST(Propulsion, ScaleDimensions)
{
    /* Create a kerosene based propulsion */
    Propulsion<EnergyCarrierFamily::Kerosene> engine;

    /* Set the dimensions */
    engine.set_dimension({1.0, 2.0, 3.0});
    engine.set_scale(2.0);

    /* Check the properties */
    EXPECT_DOUBLE_EQ(engine.scale(), 2.0);

    /* Dimensions should not be affected by scale */
    EXPECT_DOUBLE_EQ(engine.dimension().height, 1.0);
    EXPECT_DOUBLE_EQ(engine.dimension().width, 2.0);
    EXPECT_DOUBLE_EQ(engine.dimension().length, 3.0);
}

/**
 * @brief Test inserting a nacelle into the propulsion base type.
 */
TEST(Propulsion, SetNacelle)
{
    /* Create a kerosene based propulsion */
    Propulsion<EnergyCarrierFamily::Kerosene> engine;

    /* Create and add nacelle */
    geom2::MultisectionSurface<geom2::PolygonSection> nacelle;
    nacelle.name = "Test";
    engine.set_nacelle(nacelle);

    /* Test the result */
    EXPECT_EQ(engine.nacelle().name, "Test");
}

/**
 * @brief Test setting the offtakes of the propulsion base type.
 */
TEST(Propulsion, SetOfftakes)
{
    /* Create a kerosene based propulsion */
    Propulsion<EnergyCarrierFamily::Kerosene> engine;

    /* Set the offtakes */
    engine.set_offtakes({1.0, 2.0});

    /* Check the properties */
    EXPECT_DOUBLE_EQ(engine.offtakes().bleed_air, 1.0);
    EXPECT_DOUBLE_EQ(engine.offtakes().shaft_power, 2.0);
}

/**
 * @brief Test inserting a pylon into the propulsion base type.
 */
TEST(Propulsion, SetPylon)
{
    /* Create a kerosene based propulsion */
    Propulsion<EnergyCarrierFamily::Kerosene> engine;

    /* Create and add pylon */
    geom2::MultisectionSurface<geom2::AirfoilSection> pylon;
    pylon.name = "Test";
    engine.set_pylon(pylon);

    /* Test the result */
    EXPECT_EQ(engine.pylon().name, "Test");
}

/**
 * @brief Test getting the total mass of a propulsion.
 */
TEST(Propulsion, TotalMass)
{
    /* Create a kerosene based propulsion */
    Propulsion<EnergyCarrierFamily::Kerosene> engine;

    /* Set the mass of the engine */
    PointMass testMass;
    testMass.CG = Eigen::Vector3d::Ones();
    testMass.inertia = Eigen::Matrix3d::Ones();
    testMass.mass = 300.0;
    engine.set_pointmass(Component::Engine, testMass);

    /* Check the total mass */
    EXPECT_DOUBLE_EQ(engine.total_mass().mass, 300.0);
}

/**
 * @brief Test changing the reference frame of a propulsion.
 */
TEST(Propulsion, ChangeReferenceFrame)
{
    /* Create a kerosene based propulsion */
    Propulsion<EnergyCarrierFamily::Kerosene> engine;

    /* Set the mass of the engine */
    PointMass testMass{};
    testMass.CG = Eigen::Vector3d::Ones();
    engine.set_pointmass(Component::Engine, testMass);
    engine.set_position({0.5, 2.5, 0.0});

    /* Change the reference frame */
    engine.change_to_global_reference_frame({1.0, -2.0, 3.0});

    /* Check the engine position coordinates */
    EXPECT_NEAR(engine.position().x(), -0.5, 1e-3);
    EXPECT_NEAR(engine.position().y(), +4.5, 1e-3);
    EXPECT_NEAR(engine.position().z(), -3.0, 1e-3);

    /* Check the engine mass properties */
    EXPECT_NEAR(engine.pointmass(Component::Engine).CG.x(), -0.5 + 1.0, 1e-3);
    EXPECT_NEAR(engine.pointmass(Component::Engine).CG.y(), +4.5 + 1.0, 1e-3);
    EXPECT_NEAR(engine.pointmass(Component::Engine).CG.z(), -3.0 + 1.0, 1e-3);

    /* Test reverting the reference frame back to local */
    engine.revert_to_local_reference_frame({1.0, -2.0, 3.0});
    EXPECT_NEAR(engine.position().x(), 0.5, 1e-3);
    EXPECT_NEAR(engine.position().y(), 2.5, 1e-3);
    EXPECT_NEAR(engine.position().z(), 0.0, 1e-3);
    EXPECT_NEAR(engine.pointmass(Component::Engine).CG.x(), 1.0, 1e-3);
    EXPECT_NEAR(engine.pointmass(Component::Engine).CG.y(), 1.0, 1e-3);
    EXPECT_NEAR(engine.pointmass(Component::Engine).CG.z(), 1.0, 1e-3);
}

/**
 * @brief Test getting the fuel type of a turbofan propulsion.
 */
TEST(Turbofan, GetEnergyCarrier)
{
    /* Create a turbofan */
    Turbofan<EnergyCarrierFamily::Liquid_Hydrogen> engine;

    /* Check the fuel type */
    EXPECT_EQ(engine.energy_carrier, EnergyCarrierFamily::Liquid_Hydrogen);
}

/**
 * @brief Test getting the turbofan specific properties.
 */
TEST(Turbofan, Properties)
{
    /* Create a Turbofan */
    Turbofan<EnergyCarrierFamily::Liquid_Hydrogen> engine;

    /* Check the properties */
    EXPECT_DOUBLE_EQ(engine.bypass_ratio(), 0.0);
    EXPECT_DOUBLE_EQ(engine.fan().diameter, 0.0);
}

/**
 * @brief Test getting the fuel type of a turboprop propulsion.
 */
TEST(Turboprop, GetEnergyCarrier)
{
    /* Create a turboprop */
    Turboprop<EnergyCarrierFamily::Kerosene> engine;

    /* Check the fuel type */
    EXPECT_EQ(engine.energy_carrier, EnergyCarrierFamily::Kerosene);
}
