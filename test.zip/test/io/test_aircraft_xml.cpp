/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <filesystem>
#include <gtest/gtest.h>

/* Unit Under Test */
#include "io/aircraft_xml.h"

/* === Fixtures === */

/* === Tests === */
/**
 * @brief Test inserting the reference position into the version 3 aircraft xml file.
 */
TEST(AircraftXMLv3, InsertReferencePosition)
{
    /* Create the engine and file interface */
    std::shared_ptr<node> aircraft = std::make_shared<node>("file.xml");

    /* Insert a reference position */
    io::AircraftXML{aircraft}.insert(geom2::Point_3{1.0, 2.0, 3.0});

    /* Check the result */
    ASSERT_TRUE(aircraft->find("aircraft_exchange_file/component_design/propulsion/position"));
    EXPECT_DOUBLE_EQ(aircraft->at("aircraft_exchange_file/component_design/propulsion/position/x/value"), 1.0);
    EXPECT_DOUBLE_EQ(aircraft->at("aircraft_exchange_file/component_design/propulsion/position/y/value"), 2.0);
    EXPECT_DOUBLE_EQ(aircraft->at("aircraft_exchange_file/component_design/propulsion/position/z/value"), 3.0);
}

/**
 * @brief Test inserting the mass properties of the propulsion assembly.
 */
TEST(AircraftXMLv3, InsertMassProperties)
{
    /* Create the engine and file interface */
    std::shared_ptr<node> aircraft = std::make_shared<node>("file.xml");

    /* Insert the mass properties */
    PointMass mass_properties;
    io::AircraftXML{aircraft}.insert(mass_properties);

    /* Check the result */
    ASSERT_TRUE(aircraft->find("aircraft_exchange_file/component_design/propulsion/mass_properties"));
    EXPECT_DOUBLE_EQ(aircraft->at("aircraft_exchange_file/component_design/propulsion/mass_properties/mass/value"), 0.0);
    EXPECT_DOUBLE_EQ(aircraft->at("aircraft_exchange_file/component_design/propulsion/mass_properties/inertia/j_xx/value"), 0.0);
    EXPECT_DOUBLE_EQ(aircraft->at("aircraft_exchange_file/component_design/propulsion/mass_properties/inertia/j_yy/value"), 0.0);
    EXPECT_DOUBLE_EQ(aircraft->at("aircraft_exchange_file/component_design/propulsion/mass_properties/inertia/j_zz/value"), 0.0);
    EXPECT_DOUBLE_EQ(aircraft->at("aircraft_exchange_file/component_design/propulsion/mass_properties/inertia/j_xy/value"), 0.0);
    EXPECT_DOUBLE_EQ(aircraft->at("aircraft_exchange_file/component_design/propulsion/mass_properties/inertia/j_xz/value"), 0.0);
    EXPECT_DOUBLE_EQ(aircraft->at("aircraft_exchange_file/component_design/propulsion/mass_properties/inertia/j_yx/value"), 0.0);
    EXPECT_DOUBLE_EQ(aircraft->at("aircraft_exchange_file/component_design/propulsion/mass_properties/inertia/j_yz/value"), 0.0);
    EXPECT_DOUBLE_EQ(aircraft->at("aircraft_exchange_file/component_design/propulsion/mass_properties/inertia/j_zx/value"), 0.0);
    EXPECT_DOUBLE_EQ(aircraft->at("aircraft_exchange_file/component_design/propulsion/mass_properties/inertia/j_zy/value"), 0.0);
    EXPECT_DOUBLE_EQ(aircraft->at("aircraft_exchange_file/component_design/propulsion/mass_properties/center_of_gravity/x/value"), 0.0);
    EXPECT_DOUBLE_EQ(aircraft->at("aircraft_exchange_file/component_design/propulsion/mass_properties/center_of_gravity/y/value"), 0.0);
    EXPECT_DOUBLE_EQ(aircraft->at("aircraft_exchange_file/component_design/propulsion/mass_properties/center_of_gravity/z/value"), 0.0);
}

/**
 * @brief Test inserting the nacelle of a kerosene turbofan engine
 * into the version 3 aircraft xml file.
 */
TEST(AircraftXMLv3, InsertKeroseneTurbofanEngineNacelle)
{
    /* Create the engine and file interface */
    std::shared_ptr<node> aircraft = std::make_shared<node>("file.xml");
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0};
    engine.set_nacelle({});

    /* Insert the engine */
    io::AircraftXML{aircraft}.insert(engine);

    /* Check the result */
    auto nacelle = aircraft->find("aircraft_exchange_file/component_design/propulsion/specific/propulsion@0/nacelle@0");    
    ASSERT_NE(nacelle, nullptr);
    ASSERT_TRUE(nacelle->find("position"));
    EXPECT_EQ(double(nacelle->at("mass_properties/mass/value")), 0.0);
    EXPECT_EQ(double(nacelle->at("mass_properties/center_of_gravity/x/value")), 0.0);
    EXPECT_EQ(double(nacelle->at("mass_properties/inertia/j_xx/value")), 0.0);
}

/**
 * @brief Test inserting the pylon of a kerosene turbofan engine
 * into the version 3 aircraft xml file.
 */
TEST(AircraftXMLv3, InsertKeroseneTurbofanEnginePylon)
{
    /* Create the engine and file interface */
    std::shared_ptr<node> aircraft = std::make_shared<node>("file.xml");
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0};
    engine.set_pylon({});

    /* Insert the engine */
    io::AircraftXML{aircraft}.insert(engine);

    /* Check the result */
    auto pylon = aircraft->find("aircraft_exchange_file/component_design/propulsion/specific/propulsion@0/pylon@0");    
    ASSERT_NE(pylon, nullptr);
    ASSERT_TRUE(pylon->find("position"));
    EXPECT_EQ(double(pylon->at("mass_properties/mass/value")), 0.0);
    EXPECT_EQ(double(pylon->at("mass_properties/center_of_gravity/x/value")), 0.0);
    EXPECT_EQ(double(pylon->at("mass_properties/inertia/j_xx/value")), 0.0);
}

/**
 * @brief Test inserting the engine data of a kerosene turbofan engine
 * into the version 3 aircraft xml file.
 */
TEST(AircraftXMLv3, InsertKeroseneTurbofanEngineData)
{
    /* Create the engine and file interface */
    std::shared_ptr<node> aircraft = std::make_shared<node>("file.xml");
    Turbofan<EnergyCarrierFamily::Kerosene> engine0{0};
    Turbofan<EnergyCarrierFamily::Kerosene> engine1{1};
    engine1.set_model("super_engine");
    engine1.set_position({1.0, 2.0, 3.0});
    engine1.set_bucket_point({1000.0, 0.5});

    /* Insert the engine */
    io::AircraftXML{aircraft}.insert(engine0);
    io::AircraftXML{aircraft}.insert(engine1);

    /* Check the result */
    auto result = aircraft->find("aircraft_exchange_file/component_design/propulsion/specific/propulsion@1");
    ASSERT_NE(result, nullptr);
    EXPECT_EQ(std::string(result->at("engine/model/value")), "super_engine");
    EXPECT_EQ(double(result->at("engine/position/x/value")), 1.0);
    EXPECT_EQ(double(result->at("engine/position/y/value")), 2.0);
    EXPECT_EQ(double(result->at("engine/position/z/value")), 3.0);
    EXPECT_EQ(double(result->at("engine/mass_properties/mass/value")), 0.0);
    EXPECT_EQ(double(result->at("engine/mass_properties/center_of_gravity/x/value")), 0.0);
    EXPECT_EQ(double(result->at("engine/mass_properties/inertia/j_xx/value")), 0.0);
    EXPECT_EQ(double(result->at("engine/scale_factor/value")), 1.0);
    EXPECT_EQ(double(result->at("engine/bucket_point/thrust/value")), 1000.0);
    EXPECT_EQ(double(result->at("engine/bucket_point/tsfc/value")), 0.5);
}
