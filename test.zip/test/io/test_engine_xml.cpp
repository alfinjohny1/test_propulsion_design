/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <filesystem>
#include <gtest/gtest.h>

/* Unit Under Test */
#include "io/engine_xml.h"

/* === Fixtures === */

/* === Tests === */
/**
 * @brief Test reading a engine xml from a provided list
 * of directories to search for the file.
 */
TEST(EngineXML, LoadEngineData)
{
    /* Create a container with the search paths */
    std::array<std::filesystem::path, 3> search_paths = {
        ".",
        std::filesystem::path{CMAKE_TEST_STUBS_DIR} / "engines",
        "not-existing"
    };

    /* Read the engine xml */
    auto data = io::load_engine_data("test-engine", search_paths);
    ASSERT_EQ(data.name(), "test-engine");

    /* Try to get a non-existing engine */
    EXPECT_THROW(io::load_engine_data("non-existing", search_paths), std::runtime_error);

    /* Try to get an engine which does not exist in the search paths*/
    search_paths[1] = "not-existing";
    EXPECT_THROW(io::load_engine_data("test-engine", search_paths), std::runtime_error);

    /* Try finding using an initializer list */
    auto data2 = io::load_engine_data("test-engine", {std::filesystem::path{CMAKE_TEST_STUBS_DIR} / "engines"});
}

/**
 * @brief Test reading a scaled engine from xml from a provided list
 * of directories to search for the file.
 */
TEST(EngineXML, LoadEngineScaled)
{
    /* Create a container with the search paths */
    std::array<std::filesystem::path, 3> search_paths = {
        ".",
        std::filesystem::path{CMAKE_TEST_STUBS_DIR} / "engines",
        "not-existing"
    };

    /* Read the engine xml */
    auto data = io::load_engine_scaled("test-engine", 2.0, search_paths);
    ASSERT_EQ(data.get_unscaled_engine().name(), "test-engine");
    EXPECT_EQ(data.get_scale_factor(), 2.0);

    /* Try to get a non-existing engine */
    EXPECT_THROW(io::load_engine_scaled("non-existing", 42.0, search_paths), std::runtime_error);

    /* Try to get an engine which does not exist in the search paths*/
    search_paths[1] = "not-existing";
    EXPECT_THROW(io::load_engine_scaled("test-engine", 21.0, search_paths), std::runtime_error);

    /* Try finding using an initializer list */
    auto data2 = io::load_engine_scaled("test-engine", 10.5, {std::filesystem::path{CMAKE_TEST_STUBS_DIR} / "engines"});
}
