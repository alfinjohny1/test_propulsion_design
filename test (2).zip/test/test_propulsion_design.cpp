/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 *
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <cmath>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <gtest/gtest.h>
#include <iomanip>
#include <iostream>
#include <memory>
#include <runtimeInfo/runtimeInfo.h>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

#include "temp_directory.h"

/* Unit Under Test (utility.cpp itself is compiled through test_utility.cpp) */
#include "propulsion_design.h"
#include "toolinfo.h"
#include "utility.h"

/* === Fixtures === */
/**
 * @brief Temporary project with a minimal aircraft file and a copy of the module configuration.
 * The aircraft has no geometry and two kerosene turbofans under the wing with thrust shares 0.5,
 * MTOM = 70000 kg and T/W = 0.3, so the required thrust per engine is
 * 9.80665 * 70000 * 0.3 * 0.5 = 102969.825 N. All outputs are switched off.
 */
class PropulsionDesignLifecycle : public ::testing::Test
{
  protected:
    void SetUp() override
    {
        /* Setup the paths in the temporary directory */
        aircraft = temp.path() / "aircraft.xml";
        config = temp.path() / "propulsion_design_conf.xml";
        database = temp.path() / "database";
        std::filesystem::create_directories(database);

        /* Write the aircraft file */
        std::ofstream aircraft_file(aircraft);
        aircraft_file << aircraft_xml;
        aircraft_file.close();

        /* Copy the configuration and switch off all outputs */
        std::filesystem::copy_file(std::filesystem::path{CMAKE_TEST_CONFIG_FILE}, config);
        auto document = aixml::openDocument(config);
        document->at("module_configuration_file/control_settings/aircraft_exchange_file_directory/value") = temp.path().string() + "/";
        document->at("module_configuration_file/control_settings/aircraft_exchange_file_name/value") = std::string{"aircraft.xml"};
        document->at("module_configuration_file/control_settings/console_output/value") = std::string{"mode_0"};
        document->at("module_configuration_file/control_settings/log_file_output/value") = std::string{"mode_0"};
        document->at("module_configuration_file/control_settings/log_file/value") = (temp.path() / "propulsion_design.log").string();
        document->at("module_configuration_file/control_settings/plot_output/enable/value") = std::string{"false"};
        document->at("module_configuration_file/control_settings/plot_output/copy_plotting_files/value") = std::string{"false"};
        document->at("module_configuration_file/control_settings/plot_output/delete_plotting_files_from_tool_folder/value") = std::string{"false"};
        document->at("module_configuration_file/control_settings/report_output/value") = std::string{"false"};
        document->at("module_configuration_file/control_settings/xml_output/value") = std::string{"false"};
        document->at("module_configuration_file/control_settings/tex_report/value") = std::string{"false"};
        document->at("module_configuration_file/control_settings/write_info_files/value") = std::string{"false"};
        document->at("module_configuration_file/program_settings/path_engine_database/value") = database.string() + "/";
        ASSERT_TRUE(aixml::saveDocument(*document));
    }

    /* Create the module from the temporary configuration */
    std::unique_ptr<PropulsionDesign> make_module()
    {
        return std::make_unique<PropulsionDesign>(TOOL_NAME, TOOL_VERSION, config);
    }

    /* Set one value in an XML file and save the file */
    void set_value(const std::filesystem::path &file, const std::string &path, const std::string &value)
    {
        auto document = aixml::openDocument(file);
        document->at(path) = value;
        ASSERT_TRUE(aixml::saveDocument(*document));
    }

    /* Replace a text of the aircraft file */
    void replace_in_aircraft(const std::string &old_text, const std::string &new_text)
    {
        std::string text = read_text(aircraft);
        const auto position = text.find(old_text);
        ASSERT_NE(position, std::string::npos);
        text.replace(position, old_text.size(), new_text);
        std::ofstream file(aircraft, std::ios::trunc);
        file << text;
    }

    /* Copy the engine PW1127G-JM of the repository's engine database into the temporary database */
    bool provide_engine_database()
    {
        if (!std::filesystem::exists(database_engine / "PW1127G-JM.xml"))
        {
            return false;
        }
        std::filesystem::copy(database_engine, database / "PW1127G-JM", std::filesystem::copy_options::recursive);
        return true;
    }

    /* Copy the reference aircraft UNICADO-SMR-01 and its geometry data into the temporary project */
    bool provide_reference_aircraft()
    {
        if (!std::filesystem::exists(reference_aircraft / "UNICADO-SMR-01.xml"))
        {
            return false;
        }
        std::filesystem::copy_file(reference_aircraft / "UNICADO-SMR-01.xml", aircraft, std::filesystem::copy_options::overwrite_existing);
        std::filesystem::copy(reference_aircraft / "geometry_data", temp.path() / "geometry_data",
                              std::filesystem::copy_options::recursive | std::filesystem::copy_options::overwrite_existing);
        return true;
    }

    /* Write the minimal aircraft file again (e.g. after a saved run) */
    void restore_aircraft()
    {
        std::ofstream aircraft_file(aircraft, std::ios::trunc);
        aircraft_file << aircraft_xml;
    }

    /* Read the mass properties of a component from the aircraft file */
    static auto read_point_mass(const std::shared_ptr<node> &document, const std::string &path) -> PointMass
    {
        PointMass point_mass;
        point_mass.mass = document->at(path + "mass/value");
        point_mass.CG = Eigen::Vector3d(document->at(path + "center_of_gravity/x/value"), document->at(path + "center_of_gravity/y/value"),
                                        document->at(path + "center_of_gravity/z/value"));
        point_mass.inertia << document->at(path + "inertia/j_xx/value"), document->at(path + "inertia/j_xy/value"), document->at(path + "inertia/j_xz/value"),
                              document->at(path + "inertia/j_yx/value"), document->at(path + "inertia/j_yy/value"), document->at(path + "inertia/j_yz/value"),
                              document->at(path + "inertia/j_zx/value"), document->at(path + "inertia/j_zy/value"), document->at(path + "inertia/j_zz/value");
        return point_mass;
    }

    /* Read a text file */
    std::string read_text(const std::filesystem::path &file)
    {
        std::ifstream stream(file);
        std::stringstream content;
        content << stream.rdbuf();
        return content.str();
    }

    /* Redirect std::cout into a string stream */
    void start_capture()
    {
        captured_cout.str("");
        old_cout = std::cout.rdbuf(captured_cout.rdbuf());
    }

    /* Restore std::cout */
    void stop_capture()
    {
        if (old_cout != nullptr)
        {
            std::cout.rdbuf(old_cout);
            old_cout = nullptr;
        }
    }

    void TearDown() override
    {
        /* Restore std::cout */
        stop_capture();
    }

    /* A death test ends its child process with exit(), so the child removes its directory at exit */
    static void remove_death_test_directory()
    {
        std::error_code ec;
        std::filesystem::remove_all(death_test_directory, ec);
    }

    inline static std::filesystem::path death_test_directory;
    const double thrust_per_engine = 9.80665 * 70000.0 * 0.3 * 0.5;
    const std::string propulsor = "aircraft_exchange_file/requirements_and_specifications/design_specification/propulsion/propulsor@";
    const std::string results = "aircraft_exchange_file/component_design/propulsion/";
    const std::filesystem::path database_engine =
        std::filesystem::path{CMAKE_TEST_STUBS_DIR} / ".." / ".." / ".." / ".." / "engines" / "PW1127G-JM";
    const std::filesystem::path reference_aircraft = std::filesystem::path{CMAKE_TEST_STUBS_DIR} / ".." / ".." / ".." / ".." /
                                                     "aircraft_references" / "UNICADO" / "UNICADO-SMR-01" / "clean_sheet_design";
    const UniqueTempDirectory temp{"test_propulsion_design"};
    std::filesystem::path aircraft;
    std::filesystem::path config;
    std::filesystem::path database;
    std::stringstream captured_cout;
    std::streambuf *old_cout{nullptr};

    /* Minimal aircraft file. Nodes read with EndnodeReadOnly need a description attribute and bounds. */
    const std::string aircraft_xml = R"(<aircraft_exchange_file>
    <requirements_and_specifications>
        <general>
            <type><value>Test</value></type>
            <model><value>FR1</value></model>
        </general>
        <design_specification>
            <configuration>
                <configuration_type><value>tube_and_wing</value></configuration_type>
                <propulsive_fuselage_definition>
                    <propulsive_fuselage_enabled><value>false</value></propulsive_fuselage_enabled>
                </propulsive_fuselage_definition>
                <aerodynamic_technologies><value>false</value></aerodynamic_technologies>
            </configuration>
            <energy_carriers>
                <energy_carrier ID="0">
                    <type><value>kerosene</value></type>
                </energy_carrier>
            </energy_carriers>
            <propulsion>
                <propulsor ID="0">
                    <powertrain><value>turbo</value></powertrain>
                    <type><value>fan</value></type>
                    <position>
                        <parent_component><value>wing</value></parent_component>
                        <x><value>front</value></x>
                        <y><value>left</value></y>
                        <z><value>under</value></z>
                    </position>
                    <energy_carrier_ID><value>0</value><unit>1</unit></energy_carrier_ID>
                    <thrust_share><value>0.5</value><unit>1</unit></thrust_share>
                </propulsor>
                <propulsor ID="1">
                    <powertrain><value>turbo</value></powertrain>
                    <type><value>fan</value></type>
                    <position>
                        <parent_component><value>wing</value></parent_component>
                        <x><value>front</value></x>
                        <y><value>right</value></y>
                        <z><value>under</value></z>
                    </position>
                    <energy_carrier_ID><value>0</value><unit>1</unit></energy_carrier_ID>
                    <thrust_share><value>0.5</value><unit>1</unit></thrust_share>
                </propulsor>
            </propulsion>
        </design_specification>
        <requirements>
            <top_level_aircraft_requirements>
                <design_mission>
                    <delta_ISA description="Temperature offset to ISA"><value>0</value><unit>K</unit><lower_boundary>-100</lower_boundary><upper_boundary>100</upper_boundary></delta_ISA>
                    <initial_cruise_mach_number description="Initial cruise Mach number"><value>0.78</value><unit>1</unit><lower_boundary>0</lower_boundary><upper_boundary>1</upper_boundary></initial_cruise_mach_number>
                    <initial_cruise_altitude description="Initial cruise altitude"><value>10668</value><unit>m</unit><lower_boundary>0</lower_boundary><upper_boundary>20000</upper_boundary></initial_cruise_altitude>
                </design_mission>
            </top_level_aircraft_requirements>
        </requirements>
    </requirements_and_specifications>
    <sizing_point>
        <thrust_to_weight description="Total thrust divided by maximum aircraft weight"><value>0.3</value><unit>1</unit><lower_boundary>-1e308</lower_boundary><upper_boundary>1e308</upper_boundary></thrust_to_weight>
    </sizing_point>
    <analysis>
        <masses_cg_inertia>
            <maximum_takeoff_mass>
                <mass_properties>
                    <mass description="Maximum takeoff mass"><value>70000</value><unit>kg</unit><lower_boundary>-1e308</lower_boundary><upper_boundary>1e308</upper_boundary></mass>
                </mass_properties>
            </maximum_takeoff_mass>
        </masses_cg_inertia>
    </analysis>
</aircraft_exchange_file>
)";
};

/* Death tests use the same fixture; the suite name follows the gtest convention for death tests */
using PropulsionDesignLifecycleDeathTest = PropulsionDesignLifecycle;

/**
 * @brief Saves and restores the global runtime-info object and redirects std::cout and std::cerr.
 */
class UtilityPrint : public ::testing::Test
{
  protected:
    void SetUp() override
    {
        /* Start without a runtime-info object */
        previous_runtime_info = myRuntimeInfo;
        myRuntimeInfo = nullptr;
    }

    void TearDown() override
    {
        /* Restore the streams and the global runtime-info object */
        stop_capture();
        delete myRuntimeInfo;
        myRuntimeInfo = previous_runtime_info;
    }

    /* Redirect std::cout and std::cerr into string streams */
    void start_capture()
    {
        captured_cout.str("");
        captured_cerr.str("");
        old_cout = std::cout.rdbuf(captured_cout.rdbuf());
        old_cerr = std::cerr.rdbuf(captured_cerr.rdbuf());
    }

    /* Restore std::cout and std::cerr */
    void stop_capture()
    {
        if (old_cout != nullptr)
        {
            std::cout.rdbuf(old_cout);
            old_cout = nullptr;
        }
        if (old_cerr != nullptr)
        {
            std::cerr.rdbuf(old_cerr);
            old_cerr = nullptr;
        }
    }

    const UniqueTempDirectory temp{"test_utility_print"};
    std::stringstream captured_cout;
    std::stringstream captured_cerr;
    runtimeInfo *previous_runtime_info{nullptr};
    std::streambuf *old_cout{nullptr};
    std::streambuf *old_cerr{nullptr};
};

/* Tests of the FR-2 inputs read by the module use the same fixture */
using PropulsionDesignInputs = PropulsionDesignLifecycle;

/* The FR-3 validation tests use the same fixture under their own suite name */
using PropulsionDesignValidity = PropulsionDesignLifecycle;

/* The FR-9 output tests use the same fixture under their own suite name */
using PropulsionDesignOutput = PropulsionDesignLifecycle;

/* The FR-10 report tests use the same fixture under their own suite name */
using PropulsionDesignReport = PropulsionDesignLifecycle;

/* The FR-11 configuration tests use the same fixture under their own suite name */
using PropulsionDesignConfiguration = PropulsionDesignLifecycle;

/* === Tests === */
/**
 * @brief Test constructing the module from a configuration file without command-line arguments.
 */
TEST_F(PropulsionDesignLifecycle, ConstructsFromConfigurationFile)
{
    /* Create the module */
    auto module = make_module();

    /* Check that the runtime uses the files and switches of the configuration */
    ASSERT_NE(module->get_RuntimeIO(), nullptr);
    EXPECT_EQ(std::filesystem::path{module->get_RuntimeIO()->acxmlAccess}, aircraft);
    EXPECT_FALSE(module->get_RuntimeIO()->xmlOn);
    EXPECT_FALSE(module->get_RuntimeIO()->reportOn);
}

/**
 * @brief Test that a missing aircraft file ends the program during construction.
 */
TEST_F(PropulsionDesignLifecycleDeathTest, MissingAircraftFileEndsProgram)
{
    /* Remove the aircraft file */
    std::filesystem::remove(aircraft);

    /* Constructing the module ends the program */
    EXPECT_EXIT(
        {
            death_test_directory = temp.path();
            std::atexit(remove_death_test_directory);
            make_module();
        },
        ::testing::ExitedWithCode(EXIT_FAILURE), "Could not find aircraft exchange file");
}

/**
 * @brief Test that a missing configuration file ends the program during construction.
 */
TEST_F(PropulsionDesignLifecycleDeathTest, MissingConfigurationFileEndsProgram)
{
    /* Remove the configuration file */
    std::filesystem::remove(config);

    /* Constructing the module ends the program */
    EXPECT_EXIT(
        {
            death_test_directory = temp.path();
            std::atexit(remove_death_test_directory);
            make_module();
        },
        ::testing::ExitedWithCode(EXIT_FAILURE), "Could not open");
}

/**
 * @brief Test initializing the module with a valid aircraft without geometry.
 */
TEST_F(PropulsionDesignLifecycle, InitializeValidAircraftWithoutGeometry)
{
    /* Create the module */
    auto module = make_module();

    /* Initialize the module */
    EXPECT_NO_THROW(module->initialize());
}

/**
 * @brief Test that initializing rejects a thrust-to-weight ratio of 0.
 */
TEST_F(PropulsionDesignLifecycle, InitializeRejectsMissingSizingPoint)
{
    /* Set T/W to 0 */
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, "aircraft_exchange_file/sizing_point/thrust_to_weight/value", "0"));
    auto module = make_module();

    /* Initialize the module and check the error */
    try
    {
        module->initialize();
        FAIL() << "Expected std::runtime_error for T/W = 0";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("No design thrust given. Get a sizing point."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that initializing rejects an MTOM of 0.
 */
TEST_F(PropulsionDesignLifecycle, InitializeRejectsMissingMtom)
{
    /* Set the MTOM to 0 */
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, "aircraft_exchange_file/analysis/masses_cg_inertia/maximum_takeoff_mass/mass_properties/mass/value", "0"));
    auto module = make_module();

    /* Initialize the module and check the error */
    try
    {
        module->initialize();
        FAIL() << "Expected std::runtime_error for MTOM = 0";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("No MTOM given. Get a MTOM."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that initializing rejects thrust shares that do not cover the required thrust.
 */
TEST_F(PropulsionDesignLifecycle, InitializeRejectsThrustShareMismatch)
{
    /* Reduce the thrust share of the second propulsor */
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "1/thrust_share/value", "0.4"));
    auto module = make_module();

    /* Initialize the module and check the error */
    try
    {
        module->initialize();
        FAIL() << "Expected std::runtime_error for thrust shares 0.5 + 0.4";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("Total thrust share of engines is not equal to one."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that initializing rejects a propulsor with an undefined energy carrier.
 */
TEST_F(PropulsionDesignLifecycle, InitializeRejectsUnknownEnergyCarrier)
{
    /* Refer to the energy carrier ID 9 */
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "0/energy_carrier_ID/value", "9"));
    auto module = make_module();

    /* Initialize the module and check the error */
    try
    {
        module->initialize();
        FAIL() << "Expected std::runtime_error for an unknown energy carrier";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("Energy carrier with ID 9 is not found in the map."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that initializing rejects an unsupported powertrain.
 */
TEST_F(PropulsionDesignLifecycle, InitializeRejectsUnsupportedPowertrain)
{
    /* Set an unsupported powertrain */
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "0/powertrain/value", "electric"));
    auto module = make_module();

    /* Initialize the module and check the error */
    try
    {
        module->initialize();
        FAIL() << "Expected std::runtime_error for an unsupported powertrain";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The powertrain 'electric' + 'fan' is not supported."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that initializing checks the validity before selecting the strategies.
 */
TEST_F(PropulsionDesignLifecycle, InitializeValidatesBeforeSelectingStrategies)
{
    /* Set T/W to 0 and an unsupported engine designer */
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, "aircraft_exchange_file/sizing_point/thrust_to_weight/value", "0"));
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/program_settings/method/engine_designer/value", "Foo"));
    auto module = make_module();

    /* Initialize the module and check that the validity error comes first */
    try
    {
        module->initialize();
        FAIL() << "Expected std::runtime_error for T/W = 0";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("No design thrust given. Get a sizing point."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that initializing rejects an unsupported engine designer method.
 */
TEST_F(PropulsionDesignLifecycle, InitializeRejectsUnsupportedEngineDesigner)
{
    /* Set an unsupported method */
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/program_settings/method/engine_designer/value", "Foo"));
    auto module = make_module();

    /* Initialize the module and check the error */
    try
    {
        module->initialize();
        FAIL() << "Expected std::runtime_error for an unsupported engine designer";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The engine designer method 'Foo' is not supported."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that initializing rejects an unsupported propulsion integrator method.
 */
TEST_F(PropulsionDesignLifecycle, InitializeRejectsUnsupportedPropulsionIntegrator)
{
    /* Set an unsupported method */
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/program_settings/method/propulsion_integrator/value", "Foo"));
    auto module = make_module();

    /* Initialize the module and check the error */
    try
    {
        module->initialize();
        FAIL() << "Expected std::runtime_error for an unsupported propulsion integrator";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The propulsion integrator method 'Foo' is not supported."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that initializing rejects an unsupported nacelle designer method.
 */
TEST_F(PropulsionDesignLifecycle, InitializeRejectsUnsupportedNacelleDesigner)
{
    /* Set an unsupported method */
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/program_settings/method/nacelle_designer/value", "Foo"));
    auto module = make_module();

    /* Initialize the module and check the error */
    try
    {
        module->initialize();
        FAIL() << "Expected std::runtime_error for an unsupported nacelle designer";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The nacelle designer method 'Foo' is not supported."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that initializing rejects an unsupported pylon designer method.
 */
TEST_F(PropulsionDesignLifecycle, InitializeRejectsUnsupportedPylonDesigner)
{
    /* Set an unsupported method */
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/program_settings/method/pylon_designer/value", "Foo"));
    auto module = make_module();

    /* Initialize the module and check the error */
    try
    {
        module->initialize();
        FAIL() << "Expected std::runtime_error for an unsupported pylon designer";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The pylon designer method 'Foo' is not supported."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that initializing rejects an unsupported mass analyzer method.
 */
TEST_F(PropulsionDesignLifecycle, InitializeRejectsUnsupportedMassAnalyzer)
{
    /* Set an unsupported method */
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/program_settings/method/mass_analyzer/value", "Foo"));
    auto module = make_module();

    /* Initialize the module and check the error */
    try
    {
        module->initialize();
        FAIL() << "Expected std::runtime_error for an unsupported mass analyzer";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The mass analyzer method 'Foo' is not supported."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that running rejects a propulsion type that the strategy does not implement.
 */
TEST_F(PropulsionDesignLifecycle, RunRejectsTypeNotImplementedByStrategy)
{
    /* Make the first propulsor a turboprop */
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "0/type/value", "prop"));
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());

    /* Run the design loop and check the error */
    try
    {
        module->run();
        FAIL() << "Expected std::invalid_argument for a turboprop";
    }
    catch (const std::invalid_argument &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The strategy does not yet implement a kerosene turboprop engine."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test running the design of all propulsors.
 */
TEST_F(PropulsionDesignLifecycle, RunDesignsAllPropulsors)
{
    /* Provide the engine database */
    ASSERT_TRUE(provide_engine_database());
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());

    /* Run the design loop */
    EXPECT_NO_THROW(module->run());
}

/**
 * @brief Test updating the aircraft data with the results of every propulsor.
 */
TEST_F(PropulsionDesignLifecycle, UpdateWritesResultsOfEveryPropulsor)
{
    /* Provide the engine database and design the engines */
    ASSERT_TRUE(provide_engine_database());
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());

    /* Update the aircraft data and save it to make it visible on disk */
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());

    /* Check the results of both propulsors */
    auto document = aixml::openDocument(aircraft);
    double sum_of_components = 0.0;
    ASSERT_NE(document->find(results + "specific/propulsion@0/engine/model/value"), nullptr);
    EXPECT_EQ(static_cast<std::string>(document->at(results + "specific/propulsion@0/engine/model/value")), "PW1127G-JM");
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@0/engine/SLST/value")), thrust_per_engine, 1e-3);
    EXPECT_GT(static_cast<double>(document->at(results + "specific/propulsion@0/engine/scale_factor/value")), 0.0);
    sum_of_components += static_cast<double>(document->at(results + "specific/propulsion@0/engine/mass_properties/mass/value"));
    sum_of_components += static_cast<double>(document->at(results + "specific/propulsion@0/nacelle/mass_properties/mass/value"));
    sum_of_components += static_cast<double>(document->at(results + "specific/propulsion@0/pylon/mass_properties/mass/value"));
    ASSERT_NE(document->find(results + "specific/propulsion@1/engine/model/value"), nullptr);
    EXPECT_EQ(static_cast<std::string>(document->at(results + "specific/propulsion@1/engine/model/value")), "PW1127G-JM");
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@1/engine/SLST/value")), thrust_per_engine, 1e-3);
    EXPECT_GT(static_cast<double>(document->at(results + "specific/propulsion@1/engine/scale_factor/value")), 0.0);
    sum_of_components += static_cast<double>(document->at(results + "specific/propulsion@1/engine/mass_properties/mass/value"));
    sum_of_components += static_cast<double>(document->at(results + "specific/propulsion@1/nacelle/mass_properties/mass/value"));
    sum_of_components += static_cast<double>(document->at(results + "specific/propulsion@1/pylon/mass_properties/mass/value"));

    /* Check the total mass against the sum of the engine, nacelle and pylon masses */
    EXPECT_GT(sum_of_components, 0.0);
    EXPECT_NEAR(static_cast<double>(document->at(results + "mass_properties/mass/value")), sum_of_components, 1e-3);

    /* Exactly the two propulsors of the aircraft were created and written */
    EXPECT_EQ(document->find(results + "specific/propulsion@2"), nullptr);
}

/**
 * @brief Test writing the XML results file in the report.
 */
TEST_F(PropulsionDesignLifecycle, ReportWritesXmlResultsFile)
{
    /* Switch on the XML output and create an old results file */
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/xml_output/value", "true"));
    const auto results_file = temp.path() / "reporting" / "report_xml" / "propulsion_design_results.xml";
    std::filesystem::create_directories(results_file.parent_path());
    std::ofstream(results_file) << "<stale_file/>";
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());

    /* Create the report */
    ASSERT_NO_THROW(module->report());

    /* Check the new results file: method name and project name (aircraft file name without extension) */
    ASSERT_TRUE(std::filesystem::exists(results_file));
    const std::string content = read_text(results_file);
    EXPECT_EQ(content.find("stale_file"), std::string::npos);
    EXPECT_NE(content.find("<value>propulsion_design</value>"), std::string::npos);
    EXPECT_NE(content.find("<value>aircraft</value>"), std::string::npos);
}

/**
 * @brief Test that the report writes no files when all outputs are off.
 */
TEST_F(PropulsionDesignLifecycle, ReportWithOutputsOffWritesNothing)
{
    /* Initialize the module */
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());

    /* Create the report */
    ASSERT_NO_THROW(module->report());

    /* Check that nothing was written */
    EXPECT_FALSE(std::filesystem::exists(temp.path() / "reporting"));
}

/**
 * @brief Test that the XML results file contains the design results.
 */
TEST_F(PropulsionDesignLifecycle, ReportXmlContainsDesignResults)
{
    /* Provide the engine database and switch on the XML output */
    ASSERT_TRUE(provide_engine_database());
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/xml_output/value", "true"));
    auto module = make_module();

    /* Run the stages of execute() one by one */
    module->get_RuntimeIO()->create_common_directories();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->report());
    ASSERT_NO_THROW(module->save());

    /* Check the SLST of both propulsors in the results file */
    const auto results_file = temp.path() / "reporting" / "report_xml" / "propulsion_design_results.xml";
    ASSERT_TRUE(std::filesystem::exists(results_file));
    auto document = aixml::openDocument(results_file);
    ASSERT_NE(document->find("module_results_file/calculation_results/propulsion/specific/propulsion@0/engine/SLST/value"), nullptr);
    EXPECT_EQ(static_cast<std::string>(document->at("module_results_file/calculation_results/propulsion/specific/propulsion@0/engine/SLST/unit")), "N");
    EXPECT_NEAR(static_cast<double>(document->at("module_results_file/calculation_results/propulsion/specific/propulsion@0/engine/SLST/value")), thrust_per_engine, 1e-3);
    ASSERT_NE(document->find("module_results_file/calculation_results/propulsion/specific/propulsion@1/engine/SLST/value"), nullptr);
    EXPECT_EQ(static_cast<std::string>(document->at("module_results_file/calculation_results/propulsion/specific/propulsion@1/engine/SLST/unit")), "N");
    EXPECT_NEAR(static_cast<double>(document->at("module_results_file/calculation_results/propulsion/specific/propulsion@1/engine/SLST/value")), thrust_per_engine, 1e-3);
}

/**
 * @brief Test that the HTML report lists the designed engine.
 */
TEST_F(PropulsionDesignLifecycle, ReportHtmlListsDesignedEngine)
{
    /* Provide the engine database and switch on the HTML report (plots stay off) */
    ASSERT_TRUE(provide_engine_database());
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/report_output/value", "true"));
    auto module = make_module();

    /* Run the stages of execute() one by one */
    module->get_RuntimeIO()->create_common_directories();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->report());
    ASSERT_NO_THROW(module->save());

    /* Check the HTML report and that no plots were written */
    const auto html = temp.path() / "reporting" / "report_html" / "propulsion_design_report.html";
    ASSERT_TRUE(std::filesystem::exists(html));
    EXPECT_NE(read_text(html).find("PW1127G-JM"), std::string::npos);
    EXPECT_FALSE(std::filesystem::exists(temp.path() / "reporting" / "plots"));
}

/**
 * @brief Test that the report with plots writes the plot files.
 */
TEST_F(PropulsionDesignLifecycle, ReportWithPlotsWritesPlotFiles)
{
    /* Provide the reference aircraft with geometry and the engine database, and switch on the report and the plots */
    ASSERT_TRUE(provide_reference_aircraft());
    ASSERT_TRUE(provide_engine_database());
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/report_output/value", "true"));
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/plot_output/enable/value", "true"));
    auto module = make_module();

    /* Run the stages of execute() one by one */
    module->get_RuntimeIO()->create_common_directories();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->report());
    ASSERT_NO_THROW(module->save());

    /* Check the bucket curve, the top view and the views of the nacelle of engine 0 */
    const auto plots = std::filesystem::path{module->get_RuntimeIO()->getPlotDir()};
    EXPECT_TRUE(std::filesystem::exists(plots / "propulsion_design_bucket_curve.svg"));
    EXPECT_TRUE(std::filesystem::exists(plots / "propulsion_design_top_view.svg"));
    EXPECT_TRUE(std::filesystem::exists(plots / "propulsion_design_nacelle_0_front.svg"));
    EXPECT_TRUE(std::filesystem::exists(plots / "propulsion_design_nacelle_0_side.svg"));
}

/**
 * @brief Test that saving creates the engine data directory and saves the aircraft file.
 */
TEST_F(PropulsionDesignLifecycle, SaveCreatesEngineDataDirectory)
{
    /* Initialize the module */
    ASSERT_FALSE(std::filesystem::exists(temp.path() / "engine_data"));
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());

    /* Save the results */
    ASSERT_NO_THROW(module->save());

    /* Check the engine data directory and the saved aircraft file */
    EXPECT_TRUE(std::filesystem::is_directory(temp.path() / "engine_data"));
    auto document = aixml::openDocument(aircraft);
    EXPECT_NEAR(static_cast<double>(document->at("aircraft_exchange_file/sizing_point/thrust_to_weight/value")), 0.3, 1e-3);
}

/**
 * @brief Test that saving copies the designed engine into the project.
 */
TEST_F(PropulsionDesignLifecycle, SaveCopiesDesignedEngineIntoProject)
{
    /* Provide the engine database and design the engines */
    ASSERT_TRUE(provide_engine_database());
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());

    /* Save the results */
    ASSERT_NO_THROW(module->save());

    /* Check the copied engine and the results in the aircraft file */
    EXPECT_TRUE(std::filesystem::exists(temp.path() / "engine_data" / "PW1127G-JM" / "PW1127G-JM.xml"));
    auto document = aixml::openDocument(aircraft);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@0/engine/SLST/value")), thrust_per_engine, 1e-3);
}

/**
 * @brief Test that executing returns EXIT_FAILURE when a stage throws.
 */
TEST_F(PropulsionDesignLifecycle, ExecuteReturnsFailureWhenStageThrows)
{
    /* Set an unsupported pylon designer */
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/program_settings/method/pylon_designer/value", "Foo"));
    auto module = make_module();

    /* Execute the module */
    int result = EXIT_SUCCESS;
    EXPECT_NO_THROW(result = module->execute());
    EXPECT_EQ(result, EXIT_FAILURE);
}

/**
 * @brief Test executing the module with valid input.
 */
TEST_F(PropulsionDesignLifecycle, ExecuteReturnsSuccessForValidInput)
{
    /* Provide the engine database */
    ASSERT_TRUE(provide_engine_database());
    auto module = make_module();

    /* Execute the module */
    EXPECT_EQ(module->execute(), EXIT_SUCCESS);

    /* Check the results in the aircraft file */
    auto document = aixml::openDocument(aircraft);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@1/engine/SLST/value")), thrust_per_engine, 1e-3);
}

/**
 * @brief Test printing without a runtime-info object.
 */
TEST_F(UtilityPrint, NoRuntimeInfoPrintsNothing)
{
    /* Print one message per level */
    start_capture();
    EXPECT_NO_THROW(utility::print("fr18-out-message", Level::Out));
    EXPECT_NO_THROW(utility::print("fr18-warning-message", Level::Warning));
    EXPECT_NO_THROW(utility::print("fr18-error-message", Level::Error));
    EXPECT_NO_THROW(utility::print("fr18-info-message", Level::Info));
    EXPECT_NO_THROW(utility::print("fr18-debug-message", Level::Debug));
    stop_capture();

    /* Check that nothing was written */
    EXPECT_TRUE(captured_cout.str().empty());
    EXPECT_TRUE(captured_cerr.str().empty());
}

/**
 * @brief Test the default print level.
 */
TEST_F(UtilityPrint, DefaultLevelIsInfo)
{
    /* Print without a level at console mode 2 */
    myRuntimeInfo = new runtimeInfo(2, 0, (temp.path() / "print.log").string(), "utility_print_test");
    start_capture();
    utility::print("fr18-default-message");
    stop_capture();

    /* Check the info prefix */
    EXPECT_NE(captured_cout.str().find("INFO: fr18-default-message"), std::string::npos);
}

/**
 * @brief Test the output stream of each print level.
 */
TEST_F(UtilityPrint, ErrorsGoToStderrOthersToStdout)
{
    /* Print one message per level at console mode 3 */
    myRuntimeInfo = new runtimeInfo(3, 0, (temp.path() / "print.log").string(), "utility_print_test");
    start_capture();
    utility::print("fr18-out-message", Level::Out);
    utility::print("fr18-warning-message", Level::Warning);
    utility::print("fr18-error-message", Level::Error);
    utility::print("fr18-info-message", Level::Info);
    utility::print("fr18-debug-message", Level::Debug);
    stop_capture();

    /* Check that only the error is written to std::cerr */
    EXPECT_NE(captured_cout.str().find("fr18-out-message"), std::string::npos);
    EXPECT_EQ(captured_cerr.str().find("fr18-out-message"), std::string::npos);
    EXPECT_NE(captured_cout.str().find("fr18-warning-message"), std::string::npos);
    EXPECT_EQ(captured_cerr.str().find("fr18-warning-message"), std::string::npos);
    EXPECT_EQ(captured_cout.str().find("fr18-error-message"), std::string::npos);
    EXPECT_NE(captured_cerr.str().find("fr18-error-message"), std::string::npos);
    EXPECT_NE(captured_cout.str().find("fr18-info-message"), std::string::npos);
    EXPECT_EQ(captured_cerr.str().find("fr18-info-message"), std::string::npos);
    EXPECT_NE(captured_cout.str().find("fr18-debug-message"), std::string::npos);
    EXPECT_EQ(captured_cerr.str().find("fr18-debug-message"), std::string::npos);
}

/**
 * @brief Test the console output of each print level in each console mode.
 */
TEST_F(UtilityPrint, ConsoleOutputFollowsMode)
{
    /* Print one message per level at console mode 0 */
    myRuntimeInfo = new runtimeInfo(0, 0, (temp.path() / "print.log").string(), "utility_print_test");
    start_capture();
    utility::print("fr18-out-message", Level::Out);
    utility::print("fr18-warning-message", Level::Warning);
    utility::print("fr18-error-message", Level::Error);
    utility::print("fr18-info-message", Level::Info);
    utility::print("fr18-debug-message", Level::Debug);
    stop_capture();
    delete myRuntimeInfo;
    myRuntimeInfo = nullptr;

    /* Check which messages appear at console mode 0 */
    EXPECT_EQ(captured_cout.str().find("fr18-out-message"), std::string::npos);
    EXPECT_EQ(captured_cout.str().find("WARNING: fr18-warning-message"), std::string::npos);
    EXPECT_EQ(captured_cerr.str().find("ERROR: fr18-error-message"), std::string::npos);
    EXPECT_EQ(captured_cout.str().find("INFO: fr18-info-message"), std::string::npos);
    EXPECT_EQ(captured_cout.str().find("DEBUG: fr18-debug-message"), std::string::npos);

    /* Print one message per level at console mode 1 */
    myRuntimeInfo = new runtimeInfo(1, 0, (temp.path() / "print.log").string(), "utility_print_test");
    start_capture();
    utility::print("fr18-out-message", Level::Out);
    utility::print("fr18-warning-message", Level::Warning);
    utility::print("fr18-error-message", Level::Error);
    utility::print("fr18-info-message", Level::Info);
    utility::print("fr18-debug-message", Level::Debug);
    stop_capture();
    delete myRuntimeInfo;
    myRuntimeInfo = nullptr;

    /* Check which messages appear at console mode 1 */
    EXPECT_NE(captured_cout.str().find("fr18-out-message"), std::string::npos);
    EXPECT_NE(captured_cout.str().find("WARNING: fr18-warning-message"), std::string::npos);
    EXPECT_NE(captured_cerr.str().find("ERROR: fr18-error-message"), std::string::npos);
    EXPECT_EQ(captured_cout.str().find("INFO: fr18-info-message"), std::string::npos);
    EXPECT_EQ(captured_cout.str().find("DEBUG: fr18-debug-message"), std::string::npos);

    /* Print one message per level at console mode 2 */
    myRuntimeInfo = new runtimeInfo(2, 0, (temp.path() / "print.log").string(), "utility_print_test");
    start_capture();
    utility::print("fr18-out-message", Level::Out);
    utility::print("fr18-warning-message", Level::Warning);
    utility::print("fr18-error-message", Level::Error);
    utility::print("fr18-info-message", Level::Info);
    utility::print("fr18-debug-message", Level::Debug);
    stop_capture();
    delete myRuntimeInfo;
    myRuntimeInfo = nullptr;

    /* Check which messages appear at console mode 2 */
    EXPECT_NE(captured_cout.str().find("fr18-out-message"), std::string::npos);
    EXPECT_NE(captured_cout.str().find("WARNING: fr18-warning-message"), std::string::npos);
    EXPECT_NE(captured_cerr.str().find("ERROR: fr18-error-message"), std::string::npos);
    EXPECT_NE(captured_cout.str().find("INFO: fr18-info-message"), std::string::npos);
    EXPECT_EQ(captured_cout.str().find("DEBUG: fr18-debug-message"), std::string::npos);

    /* Print one message per level at console mode 3 */
    myRuntimeInfo = new runtimeInfo(3, 0, (temp.path() / "print.log").string(), "utility_print_test");
    start_capture();
    utility::print("fr18-out-message", Level::Out);
    utility::print("fr18-warning-message", Level::Warning);
    utility::print("fr18-error-message", Level::Error);
    utility::print("fr18-info-message", Level::Info);
    utility::print("fr18-debug-message", Level::Debug);
    stop_capture();
    delete myRuntimeInfo;
    myRuntimeInfo = nullptr;

    /* Check which messages appear at console mode 3 */
    EXPECT_NE(captured_cout.str().find("fr18-out-message"), std::string::npos);
    EXPECT_NE(captured_cout.str().find("WARNING: fr18-warning-message"), std::string::npos);
    EXPECT_NE(captured_cerr.str().find("ERROR: fr18-error-message"), std::string::npos);
    EXPECT_NE(captured_cout.str().find("INFO: fr18-info-message"), std::string::npos);
    EXPECT_NE(captured_cout.str().find("DEBUG: fr18-debug-message"), std::string::npos);
}

/**
 * @brief Test the log file output of each print level in each log mode.
 */
TEST_F(UtilityPrint, LogOutputFollowsMode)
{
    /* Print one message per level at log mode 0, console off */
    myRuntimeInfo = new runtimeInfo(0, 0, (temp.path() / "print_0.log").string(), "utility_print_test");
    start_capture();
    utility::print("fr18-out-message", Level::Out);
    utility::print("fr18-warning-message", Level::Warning);
    utility::print("fr18-error-message", Level::Error);
    utility::print("fr18-info-message", Level::Info);
    utility::print("fr18-debug-message", Level::Debug);
    delete myRuntimeInfo;
    myRuntimeInfo = nullptr;
    stop_capture();

    /* Check that the console is empty and which messages appear in the log file at log mode 0 */
    EXPECT_TRUE(captured_cout.str().empty());
    EXPECT_TRUE(captured_cerr.str().empty());
    std::ifstream stream_0(temp.path() / "print_0.log");
    std::stringstream log_0;
    log_0 << stream_0.rdbuf();
    EXPECT_EQ(log_0.str().find("fr18-out-message"), std::string::npos);
    EXPECT_EQ(log_0.str().find("WARNING: fr18-warning-message"), std::string::npos);
    EXPECT_EQ(log_0.str().find("ERROR: fr18-error-message"), std::string::npos);
    EXPECT_EQ(log_0.str().find("INFO: fr18-info-message"), std::string::npos);
    EXPECT_EQ(log_0.str().find("DEBUG: fr18-debug-message"), std::string::npos);

    /* Print one message per level at log mode 1, console off */
    myRuntimeInfo = new runtimeInfo(0, 1, (temp.path() / "print_1.log").string(), "utility_print_test");
    start_capture();
    utility::print("fr18-out-message", Level::Out);
    utility::print("fr18-warning-message", Level::Warning);
    utility::print("fr18-error-message", Level::Error);
    utility::print("fr18-info-message", Level::Info);
    utility::print("fr18-debug-message", Level::Debug);
    delete myRuntimeInfo;
    myRuntimeInfo = nullptr;
    stop_capture();

    /* Check that the console is empty and which messages appear in the log file at log mode 1 */
    EXPECT_TRUE(captured_cout.str().empty());
    EXPECT_TRUE(captured_cerr.str().empty());
    std::ifstream stream_1(temp.path() / "print_1.log");
    std::stringstream log_1;
    log_1 << stream_1.rdbuf();
    EXPECT_NE(log_1.str().find("fr18-out-message"), std::string::npos);
    EXPECT_NE(log_1.str().find("WARNING: fr18-warning-message"), std::string::npos);
    EXPECT_NE(log_1.str().find("ERROR: fr18-error-message"), std::string::npos);
    EXPECT_EQ(log_1.str().find("INFO: fr18-info-message"), std::string::npos);
    EXPECT_EQ(log_1.str().find("DEBUG: fr18-debug-message"), std::string::npos);

    /* Print one message per level at log mode 2, console off */
    myRuntimeInfo = new runtimeInfo(0, 2, (temp.path() / "print_2.log").string(), "utility_print_test");
    start_capture();
    utility::print("fr18-out-message", Level::Out);
    utility::print("fr18-warning-message", Level::Warning);
    utility::print("fr18-error-message", Level::Error);
    utility::print("fr18-info-message", Level::Info);
    utility::print("fr18-debug-message", Level::Debug);
    delete myRuntimeInfo;
    myRuntimeInfo = nullptr;
    stop_capture();

    /* Check that the console is empty and which messages appear in the log file at log mode 2 */
    EXPECT_TRUE(captured_cout.str().empty());
    EXPECT_TRUE(captured_cerr.str().empty());
    std::ifstream stream_2(temp.path() / "print_2.log");
    std::stringstream log_2;
    log_2 << stream_2.rdbuf();
    EXPECT_NE(log_2.str().find("fr18-out-message"), std::string::npos);
    EXPECT_NE(log_2.str().find("WARNING: fr18-warning-message"), std::string::npos);
    EXPECT_NE(log_2.str().find("ERROR: fr18-error-message"), std::string::npos);
    EXPECT_NE(log_2.str().find("INFO: fr18-info-message"), std::string::npos);
    EXPECT_EQ(log_2.str().find("DEBUG: fr18-debug-message"), std::string::npos);

    /* Print one message per level at log mode 3, console off */
    myRuntimeInfo = new runtimeInfo(0, 3, (temp.path() / "print_3.log").string(), "utility_print_test");
    start_capture();
    utility::print("fr18-out-message", Level::Out);
    utility::print("fr18-warning-message", Level::Warning);
    utility::print("fr18-error-message", Level::Error);
    utility::print("fr18-info-message", Level::Info);
    utility::print("fr18-debug-message", Level::Debug);
    delete myRuntimeInfo;
    myRuntimeInfo = nullptr;
    stop_capture();

    /* Check that the console is empty and which messages appear in the log file at log mode 3 */
    EXPECT_TRUE(captured_cout.str().empty());
    EXPECT_TRUE(captured_cerr.str().empty());
    std::ifstream stream_3(temp.path() / "print_3.log");
    std::stringstream log_3;
    log_3 << stream_3.rdbuf();
    EXPECT_NE(log_3.str().find("fr18-out-message"), std::string::npos);
    EXPECT_NE(log_3.str().find("WARNING: fr18-warning-message"), std::string::npos);
    EXPECT_NE(log_3.str().find("ERROR: fr18-error-message"), std::string::npos);
    EXPECT_NE(log_3.str().find("INFO: fr18-info-message"), std::string::npos);
    EXPECT_NE(log_3.str().find("DEBUG: fr18-debug-message"), std::string::npos);
}

/**
 * @brief Test that an incomplete aircraft geometry falls back to no geometry.
 */
TEST_F(PropulsionDesignInputs, IncompleteGeometryFallsBackToNoGeometry)
{
    /* Add a wing surface without position node and log the warnings */
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("</aircraft_exchange_file>",
                                                "<component_design><wing><specific><geometry><aerodynamic_surface ID=\"0\"><name><value>wing</value></name>"
                                                "</aerodynamic_surface></geometry></specific></wing></component_design></aircraft_exchange_file>"));
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/log_file_output/value", "mode_1"));
    auto module = make_module();

    /* Initialize the module */
    EXPECT_NO_THROW(module->initialize());
    module.reset();

    /* Check the warning */
    EXPECT_NE(read_text(temp.path() / "propulsion_design.log").find("No aircraft geometry available. -> Setting it to NULL."), std::string::npos);
}

/**
 * @brief Test that four wing engines keep their thrust and input order after the re-ordering.
 */
TEST_F(PropulsionDesignInputs, FourWingEnginesKeepTheirThrustAfterReordering)
{
    /* Provide the engine database */
    ASSERT_TRUE(provide_engine_database());

    /* Add a second engine on each side and set different thrust shares */
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("</propulsion>",
                                                "<propulsor ID=\"2\"><powertrain><value>turbo</value></powertrain><type><value>fan</value></type>"
                                                "<position><parent_component><value>wing</value></parent_component><x><value>front</value></x>"
                                                "<y><value>left</value></y><z><value>under</value></z></position>"
                                                "<energy_carrier_ID><value>0</value><unit>1</unit></energy_carrier_ID>"
                                                "<thrust_share><value>0.25</value><unit>1</unit></thrust_share></propulsor>"
                                                "<propulsor ID=\"3\"><powertrain><value>turbo</value></powertrain><type><value>fan</value></type>"
                                                "<position><parent_component><value>wing</value></parent_component><x><value>front</value></x>"
                                                "<y><value>right</value></y><z><value>under</value></z></position>"
                                                "<energy_carrier_ID><value>0</value><unit>1</unit></energy_carrier_ID>"
                                                "<thrust_share><value>0.25</value><unit>1</unit></thrust_share></propulsor></propulsion>"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "0/thrust_share/value", "0.2"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "1/thrust_share/value", "0.3"));
    auto module = make_module();

    /* Design, update and save */
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());

    /* Check the thrust of every engine by its ID */
    auto document = aixml::openDocument(aircraft);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@0/engine/SLST/value")), 41187.93, 1e-3);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@1/engine/SLST/value")), 61781.895, 1e-3);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@2/engine/SLST/value")), 51484.9125, 1e-3);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@3/engine/SLST/value")), 51484.9125, 1e-3);

    /* Check that the engines are written in the input order */
    const auto propulsion = document->getVector(results + "specific/propulsion");
    ASSERT_EQ(propulsion.size(), 4);
    EXPECT_EQ(propulsion[0]->getStringAttrib("ID"), "0");
    EXPECT_EQ(propulsion[1]->getStringAttrib("ID"), "1");
    EXPECT_EQ(propulsion[2]->getStringAttrib("ID"), "2");
    EXPECT_EQ(propulsion[3]->getStringAttrib("ID"), "3");
}

/**
 * @brief Test the intended restoration of the input order of four wing engines in mixed order (candidate defect, O-21).
 */
TEST_F(PropulsionDesignInputs, MixedOrderWingEnginesRestoredToInputOrder)
{
    /* Provide the engine database */
    ASSERT_TRUE(provide_engine_database());

    /* Add a second engine on each side, swap the sides of the first two and set different thrust shares */
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("</propulsion>",
                                                "<propulsor ID=\"2\"><powertrain><value>turbo</value></powertrain><type><value>fan</value></type>"
                                                "<position><parent_component><value>wing</value></parent_component><x><value>front</value></x>"
                                                "<y><value>right</value></y><z><value>under</value></z></position>"
                                                "<energy_carrier_ID><value>0</value><unit>1</unit></energy_carrier_ID>"
                                                "<thrust_share><value>0.4</value><unit>1</unit></thrust_share></propulsor>"
                                                "<propulsor ID=\"3\"><powertrain><value>turbo</value></powertrain><type><value>fan</value></type>"
                                                "<position><parent_component><value>wing</value></parent_component><x><value>front</value></x>"
                                                "<y><value>left</value></y><z><value>under</value></z></position>"
                                                "<energy_carrier_ID><value>0</value><unit>1</unit></energy_carrier_ID>"
                                                "<thrust_share><value>0.2</value><unit>1</unit></thrust_share></propulsor></propulsion>"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "0/position/y/value", "right"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "0/thrust_share/value", "0.1"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "1/position/y/value", "left"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "1/thrust_share/value", "0.3"));
    auto module = make_module();

    /* Design, update and save */
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());

    /* Check the thrust of every engine by its ID */
    auto document = aixml::openDocument(aircraft);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@0/engine/SLST/value")), 20593.965, 1e-3);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@1/engine/SLST/value")), 61781.895, 1e-3);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@2/engine/SLST/value")), 82375.86, 1e-3);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@3/engine/SLST/value")), 41187.93, 1e-3);

    /* Check that the engines are written in the input order */
    const auto propulsion = document->getVector(results + "specific/propulsion");
    ASSERT_EQ(propulsion.size(), 4);
    EXPECT_EQ(propulsion[0]->getStringAttrib("ID"), "0");
    EXPECT_EQ(propulsion[1]->getStringAttrib("ID"), "1");
    EXPECT_EQ(propulsion[2]->getStringAttrib("ID"), "2");
    EXPECT_EQ(propulsion[3]->getStringAttrib("ID"), "3");
}

/**
 * @brief Test that four wing engines in mixed order are written when the result nodes of all IDs already exist.
 */
TEST_F(PropulsionDesignInputs, MixedOrderWingEnginesWrittenToExistingResultNodes)
{
    /* Provide the engine database */
    ASSERT_TRUE(provide_engine_database());

    /* Add a second engine on each side, swap the sides of the first two and set different thrust shares */
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("</propulsion>",
                                                "<propulsor ID=\"2\"><powertrain><value>turbo</value></powertrain><type><value>fan</value></type>"
                                                "<position><parent_component><value>wing</value></parent_component><x><value>front</value></x>"
                                                "<y><value>right</value></y><z><value>under</value></z></position>"
                                                "<energy_carrier_ID><value>0</value><unit>1</unit></energy_carrier_ID>"
                                                "<thrust_share><value>0.4</value><unit>1</unit></thrust_share></propulsor>"
                                                "<propulsor ID=\"3\"><powertrain><value>turbo</value></powertrain><type><value>fan</value></type>"
                                                "<position><parent_component><value>wing</value></parent_component><x><value>front</value></x>"
                                                "<y><value>left</value></y><z><value>under</value></z></position>"
                                                "<energy_carrier_ID><value>0</value><unit>1</unit></energy_carrier_ID>"
                                                "<thrust_share><value>0.2</value><unit>1</unit></thrust_share></propulsor></propulsion>"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "0/position/y/value", "right"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "0/thrust_share/value", "0.1"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "1/position/y/value", "left"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "1/thrust_share/value", "0.3"));
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("</aircraft_exchange_file>",
                                                "<component_design><propulsion><position/><mass_properties/><specific>"
                                                "<propulsion ID=\"0\"/><propulsion ID=\"1\"/><propulsion ID=\"2\"/><propulsion ID=\"3\"/>"
                                                "</specific></propulsion></component_design></aircraft_exchange_file>"));
    auto module = make_module();

    /* Design, update and save */
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());

    /* Check the thrust of every engine by its ID */
    auto document = aixml::openDocument(aircraft);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@0/engine/SLST/value")), 20593.965, 1e-3);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@1/engine/SLST/value")), 61781.895, 1e-3);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@2/engine/SLST/value")), 82375.86, 1e-3);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@3/engine/SLST/value")), 41187.93, 1e-3);
}

/**
 * @brief Test that the larger wing engine of each side is placed inboard for a mixed input order.
 */
TEST_F(PropulsionDesignInputs, LargerWingEngineIsPlacedInboard)
{
    /* Provide the reference aircraft and the engine database */
    ASSERT_TRUE(provide_reference_aircraft());
    ASSERT_TRUE(provide_engine_database());

    /* Add a second engine on each side, swap the sides of the first two and set different thrust shares */
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("</propulsion>",
                                                "<propulsor ID=\"2\"><powertrain><value>turbo</value></powertrain><type><value>fan</value></type>"
                                                "<position><parent_component><value>wing</value></parent_component><x><value>front</value></x>"
                                                "<y><value>right</value></y><z><value>under</value></z></position>"
                                                "<energy_carrier_ID><value>0</value><unit>1</unit></energy_carrier_ID>"
                                                "<thrust_share><value>0.4</value><unit>1</unit></thrust_share></propulsor>"
                                                "<propulsor ID=\"3\"><powertrain><value>turbo</value></powertrain><type><value>fan</value></type>"
                                                "<position><parent_component><value>wing</value></parent_component><x><value>front</value></x>"
                                                "<y><value>left</value></y><z><value>under</value></z></position>"
                                                "<energy_carrier_ID><value>0</value><unit>1</unit></energy_carrier_ID>"
                                                "<thrust_share><value>0.2</value><unit>1</unit></thrust_share></propulsor></propulsion>"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "0/position/y/value", "right"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "0/thrust_share/value", "0.1"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "1/position/y/value", "left"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "1/thrust_share/value", "0.3"));
    auto module = make_module();

    /* Design, update and save */
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());

    /* Check that the larger engine of each side is the inner one */
    auto document = aixml::openDocument(aircraft);
    const double y_0 = static_cast<double>(document->at(results + "specific/propulsion@0/engine/position/y/value"));
    const double y_1 = static_cast<double>(document->at(results + "specific/propulsion@1/engine/position/y/value"));
    const double y_2 = static_cast<double>(document->at(results + "specific/propulsion@2/engine/position/y/value"));
    const double y_3 = static_cast<double>(document->at(results + "specific/propulsion@3/engine/position/y/value"));
    EXPECT_LT(std::abs(y_1), std::abs(y_3));
    EXPECT_LT(std::abs(y_2), std::abs(y_0));
}

/**
 * @brief Test that the larger wing engine of each side is placed inboard when it is listed second.
 */
TEST_F(PropulsionDesignInputs, LargerWingEngineIsPlacedInboardWhenListedSecond)
{
    /* Provide the reference aircraft and the engine database */
    ASSERT_TRUE(provide_reference_aircraft());
    ASSERT_TRUE(provide_engine_database());

    /* Add two engines on the right side, move the second engine to the left and set different thrust shares */
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("</propulsion>",
                                                "<propulsor ID=\"2\"><powertrain><value>turbo</value></powertrain><type><value>fan</value></type>"
                                                "<position><parent_component><value>wing</value></parent_component><x><value>front</value></x>"
                                                "<y><value>right</value></y><z><value>under</value></z></position>"
                                                "<energy_carrier_ID><value>0</value><unit>1</unit></energy_carrier_ID>"
                                                "<thrust_share><value>0.3</value><unit>1</unit></thrust_share></propulsor>"
                                                "<propulsor ID=\"3\"><powertrain><value>turbo</value></powertrain><type><value>fan</value></type>"
                                                "<position><parent_component><value>wing</value></parent_component><x><value>front</value></x>"
                                                "<y><value>right</value></y><z><value>under</value></z></position>"
                                                "<energy_carrier_ID><value>0</value><unit>1</unit></energy_carrier_ID>"
                                                "<thrust_share><value>0.4</value><unit>1</unit></thrust_share></propulsor></propulsion>"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "0/thrust_share/value", "0.2"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "1/position/y/value", "left"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "1/thrust_share/value", "0.1"));
    auto module = make_module();

    /* Design, update and save */
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());

    /* Check that the larger engine of each side is the inner one */
    auto document = aixml::openDocument(aircraft);
    const double y_0 = static_cast<double>(document->at(results + "specific/propulsion@0/engine/position/y/value"));
    const double y_1 = static_cast<double>(document->at(results + "specific/propulsion@1/engine/position/y/value"));
    const double y_2 = static_cast<double>(document->at(results + "specific/propulsion@2/engine/position/y/value"));
    const double y_3 = static_cast<double>(document->at(results + "specific/propulsion@3/engine/position/y/value"));
    EXPECT_LT(std::abs(y_0), std::abs(y_1));
    EXPECT_LT(std::abs(y_3), std::abs(y_2));
}

/**
 * @brief Test reading the design condition from the design mission.
 */
TEST_F(PropulsionDesignInputs, DesignConditionReadFromDesignMission)
{
    /* Change Mach number, altitude and delta ISA and log the info messages */
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("<value>0.78</value>", "<value>0.8</value>"));
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("<value>10668</value>", "<value>11000</value>"));
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("<delta_ISA description=\"Temperature offset to ISA\"><value>0</value>",
                                                "<delta_ISA description=\"Temperature offset to ISA\"><value>-10</value>"));
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/log_file_output/value", "mode_2"));
    auto module = make_module();

    /* Initialize the module */
    ASSERT_NO_THROW(module->initialize());
    module.reset();

    /* Check the design condition */
    const std::string log = read_text(temp.path() / "propulsion_design.log");
    EXPECT_NE(log.find("Design condition: Mach = 0.80, altitude = 11000 m, ISA-10"), std::string::npos);
}

/**
 * @brief Test the current behaviour that a missing cruise Mach number is read as zero.
 */
TEST_F(PropulsionDesignInputs, MissingCruiseMachReadAsZero)
{
    /* Remove the Mach number node and log the info messages */
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("<initial_cruise_mach_number description=\"Initial cruise Mach number\"><value>0.78</value><unit>1</unit>"
                                                "<lower_boundary>0</lower_boundary><upper_boundary>1</upper_boundary></initial_cruise_mach_number>",
                                                ""));
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/log_file_output/value", "mode_2"));
    auto module = make_module();

    /* Initialize the module */
    ASSERT_NO_THROW(module->initialize());
    module.reset();

    /* Check the warning and the design condition */
    const std::string log = read_text(temp.path() / "propulsion_design.log");
    EXPECT_NE(log.find("Node to read not existing"), std::string::npos);
    EXPECT_NE(log.find("Design condition: Mach = 0.00, altitude = 10668 m"), std::string::npos);
}

/**
 * @brief Test that a higher design altitude lowers the bucket point thrust.
 */
TEST_F(PropulsionDesignInputs, HigherDesignAltitudeLowersBucketThrust)
{
    /* Provide the engine database */
    ASSERT_TRUE(provide_engine_database());

    /* Design at 10668 m and read the bucket point thrust */
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());
    module.reset();
    const double thrust_low = static_cast<double>(aixml::openDocument(aircraft)->at(results + "specific/propulsion@0/engine/bucket_point/thrust/value"));

    /* Restore the aircraft file and design at 11000 m */
    restore_aircraft();
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("<value>10668</value>", "<value>11000</value>"));
    module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());
    module.reset();
    const double thrust_high = static_cast<double>(aixml::openDocument(aircraft)->at(results + "specific/propulsion@0/engine/bucket_point/thrust/value"));

    /* Check that the thrust decreases with altitude */
    EXPECT_LT(thrust_high, thrust_low);
}

/**
 * @brief Test the warning for missing offtake requirements.
 */
TEST_F(PropulsionDesignInputs, MissingOfftakesGiveWarning)
{
    /* Log the warnings */
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/log_file_output/value", "mode_1"));
    auto module = make_module();

    /* Initialize the module */
    ASSERT_NO_THROW(module->initialize());
    module.reset();

    /* Check the warning */
    EXPECT_NE(read_text(temp.path() / "propulsion_design.log").find("No average offtake requirements found in the XML file. Using default values."),
              std::string::npos);
}

/**
 * @brief Test reading the offtake requirements from the systems.
 */
TEST_F(PropulsionDesignInputs, OfftakesReadFromSystems)
{
    /* Add the offtake requirements and log the warnings */
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("</aircraft_exchange_file>",
                                                "<component_design><systems><specific>"
                                                "<average_bleed_air_demand description=\"average bleed air demand\"><value>0.5</value><unit>kg/s</unit>"
                                                "<lower_boundary>0</lower_boundary><upper_boundary>100</upper_boundary></average_bleed_air_demand>"
                                                "<average_power_demand description=\"average power demand\"><value>100000</value><unit>W</unit>"
                                                "<lower_boundary>0</lower_boundary><upper_boundary>1e9</upper_boundary></average_power_demand>"
                                                "</specific></systems></component_design></aircraft_exchange_file>"));
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/log_file_output/value", "mode_1"));
    auto module = make_module();

    /* Initialize the module */
    ASSERT_NO_THROW(module->initialize());
    module.reset();

    /* Check that there is no warning */
    EXPECT_EQ(read_text(temp.path() / "propulsion_design.log").find("No average offtake requirements found"), std::string::npos);
}

/**
 * @brief Test the warning for incomplete offtake requirements.
 */
TEST_F(PropulsionDesignInputs, IncompleteOfftakesGiveWarning)
{
    /* Add only the bleed air demand and log the warnings */
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("</aircraft_exchange_file>",
                                                "<component_design><systems><specific>"
                                                "<average_bleed_air_demand description=\"average bleed air demand\"><value>0.5</value><unit>kg/s</unit>"
                                                "<lower_boundary>0</lower_boundary><upper_boundary>100</upper_boundary></average_bleed_air_demand>"
                                                "</specific></systems></component_design></aircraft_exchange_file>"));
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/log_file_output/value", "mode_1"));
    auto module = make_module();

    /* Initialize the module */
    ASSERT_NO_THROW(module->initialize());
    module.reset();

    /* Check the warning */
    EXPECT_NE(read_text(temp.path() / "propulsion_design.log").find("No average offtake requirements found in the XML file. Using default values."),
              std::string::npos);
}

/**
 * @brief Test the current behaviour that delta ISA does not change the bucket point without offtakes.
 */
TEST_F(PropulsionDesignInputs, DeltaIsaWithoutOfftakesLeavesBucketPointUnchanged)
{
    /* Provide the engine database */
    ASSERT_TRUE(provide_engine_database());

    /* Design at ISA and read the bucket point */
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());
    module.reset();
    auto document = aixml::openDocument(aircraft);
    const double thrust_isa = static_cast<double>(document->at(results + "specific/propulsion@0/engine/bucket_point/thrust/value"));
    const double tsfc_isa = static_cast<double>(document->at(results + "specific/propulsion@0/engine/bucket_point/tsfc/value"));

    /* Design again at ISA-10 */
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, "aircraft_exchange_file/requirements_and_specifications/requirements/top_level_aircraft_requirements/design_mission/delta_ISA/value", "-10"));
    module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());
    module.reset();

    /* Check that the bucket point is unchanged */
    document = aixml::openDocument(aircraft);
    EXPECT_DOUBLE_EQ(static_cast<double>(document->at(results + "specific/propulsion@0/engine/bucket_point/thrust/value")), thrust_isa);
    EXPECT_DOUBLE_EQ(static_cast<double>(document->at(results + "specific/propulsion@0/engine/bucket_point/tsfc/value")), tsfc_isa);
}

/**
 * @brief Test that delta ISA changes the bucket point with bleed air.
 */
TEST_F(PropulsionDesignInputs, DeltaIsaWithBleedAirChangesBucketPoint)
{
    /* Provide the engine database and add a bleed air demand of 0.5 kg/s without shaft power */
    ASSERT_TRUE(provide_engine_database());
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("</aircraft_exchange_file>",
                                                "<component_design><systems><specific>"
                                                "<average_bleed_air_demand description=\"average bleed air demand\"><value>0.5</value><unit>kg/s</unit>"
                                                "<lower_boundary>0</lower_boundary><upper_boundary>100</upper_boundary></average_bleed_air_demand>"
                                                "<average_power_demand description=\"average power demand\"><value>0</value><unit>W</unit>"
                                                "<lower_boundary>0</lower_boundary><upper_boundary>1e9</upper_boundary></average_power_demand>"
                                                "</specific></systems></component_design></aircraft_exchange_file>"));

    /* Design at ISA and read the bucket point thrust */
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());
    module.reset();
    const double thrust_isa = static_cast<double>(aixml::openDocument(aircraft)->at(results + "specific/propulsion@0/engine/bucket_point/thrust/value"));

    /* Design again at ISA-10 */
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, "aircraft_exchange_file/requirements_and_specifications/requirements/top_level_aircraft_requirements/design_mission/delta_ISA/value", "-10"));
    module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());
    module.reset();
    const double thrust_cold = static_cast<double>(aixml::openDocument(aircraft)->at(results + "specific/propulsion@0/engine/bucket_point/thrust/value"));

    /* Check that delta ISA changes the result */
    EXPECT_GT(std::abs(thrust_cold - thrust_isa), 1e-3);
}

/**
 * @brief Test that the bleed air offtake raises the bucket point TSFC.
 */
TEST_F(PropulsionDesignInputs, BleedAirOfftakeRaisesBucketPointTsfc)
{
    /* Provide the engine database */
    ASSERT_TRUE(provide_engine_database());

    /* Design with both offtake requirements set to zero and read the bucket point TSFC */
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("</aircraft_exchange_file>",
                                                "<component_design><systems><specific>"
                                                "<average_bleed_air_demand description=\"average bleed air demand\"><value>0</value><unit>kg/s</unit>"
                                                "<lower_boundary>0</lower_boundary><upper_boundary>100</upper_boundary></average_bleed_air_demand>"
                                                "<average_power_demand description=\"average power demand\"><value>0</value><unit>W</unit>"
                                                "<lower_boundary>0</lower_boundary><upper_boundary>1e9</upper_boundary></average_power_demand>"
                                                "</specific></systems></component_design></aircraft_exchange_file>"));
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());
    module.reset();
    const double tsfc_zero = static_cast<double>(aixml::openDocument(aircraft)->at(results + "specific/propulsion@0/engine/bucket_point/tsfc/value"));

    /* Set only the bleed air demand to 0.5 kg/s and design again */
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, "aircraft_exchange_file/component_design/systems/specific/average_bleed_air_demand/value", "0.5"));
    module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());
    module.reset();
    const double tsfc_offtake = static_cast<double>(aixml::openDocument(aircraft)->at(results + "specific/propulsion@0/engine/bucket_point/tsfc/value"));

    /* Check that this offtake alone raises the TSFC */
    EXPECT_GT(tsfc_offtake, tsfc_zero);
}

/**
 * @brief Test that the shaft power offtake raises the bucket point TSFC.
 */
TEST_F(PropulsionDesignInputs, ShaftPowerOfftakeRaisesBucketPointTsfc)
{
    /* Provide the engine database */
    ASSERT_TRUE(provide_engine_database());

    /* Design with both offtake requirements set to zero and read the bucket point TSFC */
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("</aircraft_exchange_file>",
                                                "<component_design><systems><specific>"
                                                "<average_bleed_air_demand description=\"average bleed air demand\"><value>0</value><unit>kg/s</unit>"
                                                "<lower_boundary>0</lower_boundary><upper_boundary>100</upper_boundary></average_bleed_air_demand>"
                                                "<average_power_demand description=\"average power demand\"><value>0</value><unit>W</unit>"
                                                "<lower_boundary>0</lower_boundary><upper_boundary>1e9</upper_boundary></average_power_demand>"
                                                "</specific></systems></component_design></aircraft_exchange_file>"));
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());
    module.reset();
    const double tsfc_zero = static_cast<double>(aixml::openDocument(aircraft)->at(results + "specific/propulsion@0/engine/bucket_point/tsfc/value"));

    /* Set only the power demand to 100 kW and design again */
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, "aircraft_exchange_file/component_design/systems/specific/average_power_demand/value", "100000"));
    module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());
    module.reset();
    const double tsfc_offtake = static_cast<double>(aixml::openDocument(aircraft)->at(results + "specific/propulsion@0/engine/bucket_point/tsfc/value"));

    /* Check that this offtake alone raises the TSFC */
    EXPECT_GT(tsfc_offtake, tsfc_zero);
}

/**
 * @brief Test that incomplete offtake requirements give the bucket point without offtakes.
 */
TEST_F(PropulsionDesignInputs, IncompleteOfftakesGiveSameBucketPointAsNone)
{
    /* Provide the engine database */
    ASSERT_TRUE(provide_engine_database());

    /* Design without offtakes and read the bucket point */
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());
    module.reset();
    auto document = aixml::openDocument(aircraft);
    const double thrust_none = static_cast<double>(document->at(results + "specific/propulsion@0/engine/bucket_point/thrust/value"));
    const double tsfc_none = static_cast<double>(document->at(results + "specific/propulsion@0/engine/bucket_point/tsfc/value"));

    /* Restore the aircraft file, add only the bleed air demand and design again */
    restore_aircraft();
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("</aircraft_exchange_file>",
                                                "<component_design><systems><specific>"
                                                "<average_bleed_air_demand description=\"average bleed air demand\"><value>0.5</value><unit>kg/s</unit>"
                                                "<lower_boundary>0</lower_boundary><upper_boundary>100</upper_boundary></average_bleed_air_demand>"
                                                "</specific></systems></component_design></aircraft_exchange_file>"));
    module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());
    module.reset();

    /* Check that the bucket point is unchanged */
    document = aixml::openDocument(aircraft);
    EXPECT_DOUBLE_EQ(static_cast<double>(document->at(results + "specific/propulsion@0/engine/bucket_point/thrust/value")), thrust_none);
    EXPECT_DOUBLE_EQ(static_cast<double>(document->at(results + "specific/propulsion@0/engine/bucket_point/tsfc/value")), tsfc_none);
}

/**
 * @brief Test distributing the required thrust by the thrust shares.
 */
TEST_F(PropulsionDesignInputs, ThrustDistributedByShare)
{
    /* Provide the engine database and set unequal thrust shares */
    ASSERT_TRUE(provide_engine_database());
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "0/thrust_share/value", "0.6"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "1/thrust_share/value", "0.4"));
    auto module = make_module();

    /* Design, update and save */
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());

    /* Check the thrust of both engines */
    auto document = aixml::openDocument(aircraft);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@0/engine/SLST/value")), 123563.79, 1e-3);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@1/engine/SLST/value")), 82375.86, 1e-3);
}

/**
 * @brief Test the current behaviour that thrust shares outside 0 to 1 are accepted.
 */
TEST_F(PropulsionDesignInputs, ThrustSharesOutsideZeroToOneAccepted)
{
    /* Set thrust shares 1.2 and -0.2 */
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "0/thrust_share/value", "1.2"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "1/thrust_share/value", "-0.2"));
    auto module = make_module();

    /* Initialize the module */
    EXPECT_NO_THROW(module->initialize());
}

/**
 * @brief Test importing the complete geometry of the reference aircraft.
 */
TEST_F(PropulsionDesignInputs, CompleteGeometryIsImported)
{
    /* Copy the reference aircraft file and its geometry data into the temporary project */
    ASSERT_TRUE(provide_reference_aircraft());
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/log_file_output/value", "mode_1"));
    auto module = make_module();

    /* Initialize the module */
    ASSERT_NO_THROW(module->initialize());
    module.reset();

    /* Check that the geometry was not set to null */
    EXPECT_EQ(read_text(temp.path() / "propulsion_design.log").find("No aircraft geometry available"), std::string::npos);
}

/**
 * @brief Test that moving the wing moves the wing engines.
 */
TEST_F(PropulsionDesignInputs, WingPositionShiftsWingEngines)
{
    /* Provide the reference aircraft and the engine database */
    ASSERT_TRUE(provide_reference_aircraft());
    ASSERT_TRUE(provide_engine_database());

    /* Design with the original wing position and read the engine positions */
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());
    module.reset();
    auto document = aixml::openDocument(aircraft);
    const double wing_x = static_cast<double>(document->at("aircraft_exchange_file/component_design/wing/position/x/value"));
    const double x_0 = static_cast<double>(document->at(results + "specific/propulsion@0/engine/position/x/value"));
    const double y_0 = static_cast<double>(document->at(results + "specific/propulsion@0/engine/position/y/value"));
    const double z_0 = static_cast<double>(document->at(results + "specific/propulsion@0/engine/position/z/value"));
    const double x_1 = static_cast<double>(document->at(results + "specific/propulsion@1/engine/position/x/value"));
    const double y_1 = static_cast<double>(document->at(results + "specific/propulsion@1/engine/position/y/value"));
    const double z_1 = static_cast<double>(document->at(results + "specific/propulsion@1/engine/position/z/value"));

    /* Copy the reference aircraft again, move the wing 1 m aft and design again */
    ASSERT_TRUE(provide_reference_aircraft());
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, "aircraft_exchange_file/component_design/wing/position/x/value", std::to_string(wing_x + 1.0)));
    module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());
    module.reset();

    /* Check that both engines moved 1 m aft */
    document = aixml::openDocument(aircraft);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@0/engine/position/x/value")), x_0 + 1.0, 1e-3);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@0/engine/position/y/value")), y_0, 1e-3);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@0/engine/position/z/value")), z_0, 1e-3);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@1/engine/position/x/value")), x_1 + 1.0, 1e-3);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@1/engine/position/y/value")), y_1, 1e-3);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@1/engine/position/z/value")), z_1, 1e-3);
}

/**
 * @brief Test that moving the fuselage moves the fuselage engines.
 */
TEST_F(PropulsionDesignInputs, FuselagePositionShiftsFuselageEngines)
{
    /* Provide the reference aircraft and the engine database */
    ASSERT_TRUE(provide_reference_aircraft());
    ASSERT_TRUE(provide_engine_database());

    /* Mount both engines at the rear fuselage */
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "0/position/parent_component/value", "fuselage"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "0/position/x/value", "rear"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "0/position/z/value", "mid"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "1/position/parent_component/value", "fuselage"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "1/position/x/value", "rear"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "1/position/z/value", "mid"));

    /* Design with the original fuselage position and read the engine positions */
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());
    module.reset();
    auto document = aixml::openDocument(aircraft);
    const double fuselage_x = static_cast<double>(document->at("aircraft_exchange_file/component_design/fuselage/position/x/value"));
    const double x_0 = static_cast<double>(document->at(results + "specific/propulsion@0/engine/position/x/value"));
    const double y_0 = static_cast<double>(document->at(results + "specific/propulsion@0/engine/position/y/value"));
    const double z_0 = static_cast<double>(document->at(results + "specific/propulsion@0/engine/position/z/value"));
    const double x_1 = static_cast<double>(document->at(results + "specific/propulsion@1/engine/position/x/value"));
    const double y_1 = static_cast<double>(document->at(results + "specific/propulsion@1/engine/position/y/value"));
    const double z_1 = static_cast<double>(document->at(results + "specific/propulsion@1/engine/position/z/value"));

    /* Move the fuselage 1 m aft and design again */
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, "aircraft_exchange_file/component_design/fuselage/position/x/value", std::to_string(fuselage_x + 1.0)));
    module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());
    module.reset();

    /* Check that both engines moved 1 m aft */
    document = aixml::openDocument(aircraft);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@0/engine/position/x/value")), x_0 + 1.0, 1e-3);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@0/engine/position/y/value")), y_0, 1e-3);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@0/engine/position/z/value")), z_0, 1e-3);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@1/engine/position/x/value")), x_1 + 1.0, 1e-3);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@1/engine/position/y/value")), y_1, 1e-3);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@1/engine/position/z/value")), z_1, 1e-3);
}

/**
 * @brief Test that moving the empennage moves the empennage engine.
 */
TEST_F(PropulsionDesignInputs, EmpennagePositionShiftsEmpennageEngine)
{
    /* Provide the reference aircraft and the engine database */
    ASSERT_TRUE(provide_reference_aircraft());
    ASSERT_TRUE(provide_engine_database());

    /* Add a third engine in the vertical tail */
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("</propulsion>",
                                                "<propulsor ID=\"2\"><powertrain><value>turbo</value></powertrain><type><value>fan</value></type>"
                                                "<position><parent_component><value>empennage</value></parent_component><x><value>front</value></x>"
                                                "<y><value>mid</value></y><z><value>in</value></z></position>"
                                                "<energy_carrier_ID><value>0</value><unit>1</unit></energy_carrier_ID>"
                                                "<thrust_share><value>0.3</value><unit>1</unit></thrust_share></propulsor></propulsion>"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "0/thrust_share/value", "0.35"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "1/thrust_share/value", "0.35"));

    /* Design with the original empennage position and read the engine position */
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());
    module.reset();
    auto document = aixml::openDocument(aircraft);
    const double empennage_x = static_cast<double>(document->at("aircraft_exchange_file/component_design/empennage/position/x/value"));
    const double x_2 = static_cast<double>(document->at(results + "specific/propulsion@2/engine/position/x/value"));
    const double y_2 = static_cast<double>(document->at(results + "specific/propulsion@2/engine/position/y/value"));

    /* Move the empennage 1 m aft and design again */
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, "aircraft_exchange_file/component_design/empennage/position/x/value", std::to_string(empennage_x + 1.0)));
    module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());
    module.reset();

    /* Check that the engine moved 1 m aft */
    document = aixml::openDocument(aircraft);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@2/engine/position/x/value")), x_2 + 1.0, 1e-3);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@2/engine/position/y/value")), y_2, 1e-3);
}

/**
 * @brief Test that initializing rejects a negative thrust-to-weight ratio.
 */
TEST_F(PropulsionDesignValidity, InitializeRejectsNegativeThrustToWeight)
{
    /* Set T/W to -0.3 */
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, "aircraft_exchange_file/sizing_point/thrust_to_weight/value", "-0.3"));
    auto module = make_module();

    /* Initialize the module and check the error */
    try
    {
        module->initialize();
        FAIL() << "Expected std::runtime_error for T/W = -0.3";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("No design thrust given. Get a sizing point."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that initializing rejects a missing thrust-to-weight ratio.
 */
TEST_F(PropulsionDesignValidity, InitializeRejectsMissingThrustToWeightNode)
{
    /* Remove the thrust-to-weight node */
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("<thrust_to_weight description=\"Total thrust divided by maximum aircraft weight\"><value>0.3</value><unit>1</unit>"
                                                "<lower_boundary>-1e308</lower_boundary><upper_boundary>1e308</upper_boundary></thrust_to_weight>", ""));
    auto module = make_module();

    /* Initialize the module and check the error */
    try
    {
        module->initialize();
        FAIL() << "Expected std::runtime_error for a missing T/W node";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("No design thrust given. Get a sizing point."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that initializing rejects a negative MTOM.
 */
TEST_F(PropulsionDesignValidity, InitializeRejectsNegativeMtom)
{
    /* Set the MTOM to -70000 kg */
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, "aircraft_exchange_file/analysis/masses_cg_inertia/maximum_takeoff_mass/mass_properties/mass/value", "-70000"));
    auto module = make_module();

    /* Initialize the module and check the error */
    try
    {
        module->initialize();
        FAIL() << "Expected std::runtime_error for MTOM = -70000 kg";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("No MTOM given. Get a MTOM."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that initializing rejects a missing MTOM.
 */
TEST_F(PropulsionDesignValidity, InitializeRejectsMissingMtomNode)
{
    /* Remove the MTOM node */
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("<mass description=\"Maximum takeoff mass\"><value>70000</value><unit>kg</unit>"
                                                "<lower_boundary>-1e308</lower_boundary><upper_boundary>1e308</upper_boundary></mass>", ""));
    auto module = make_module();

    /* Initialize the module and check the error */
    try
    {
        module->initialize();
        FAIL() << "Expected std::runtime_error for a missing MTOM node";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("No MTOM given. Get a MTOM."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that initializing accepts a thrust mismatch below the tolerance.
 */
TEST_F(PropulsionDesignValidity, InitializeAcceptsThrustMismatchBelowTolerance)
{
    /* Increase the thrust share of the second propulsor by 0.00004 */
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "1/thrust_share/value", "0.50004"));
    auto module = make_module();

    /* Initialize the module */
    EXPECT_NO_THROW(module->initialize());
}

/**
 * @brief Test that initializing rejects a thrust mismatch above the tolerance.
 */
TEST_F(PropulsionDesignValidity, InitializeRejectsThrustMismatchAboveTolerance)
{
    /* Increase the thrust share of the second propulsor by 0.00005 */
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "1/thrust_share/value", "0.50005"));
    auto module = make_module();

    /* Initialize the module and check the error */
    try
    {
        module->initialize();
        FAIL() << "Expected std::runtime_error for a thrust excess of 10.30 N";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("Total thrust share of engines is not equal to one."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that running rejects an asymmetric thrust distribution.
 */
TEST_F(PropulsionDesignValidity, AsymmetricThrustRejectedAfterRun)
{
    /* Provide the reference aircraft and the engine database */
    ASSERT_TRUE(provide_reference_aircraft());
    ASSERT_TRUE(provide_engine_database());

    /* Set unequal thrust shares on the left and the right engine */
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "0/thrust_share/value", "0.7"));
    ASSERT_NO_FATAL_FAILURE(set_value(aircraft, propulsor + "1/thrust_share/value", "0.3"));
    auto module = make_module();

    /* Initialize the module */
    ASSERT_NO_THROW(module->initialize());

    /* Design the engines and check the error of the validity check after the placement */
    try
    {
        module->run();
        FAIL() << "Expected std::runtime_error for asymmetric thrust";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("Non-symmetrical thrust"), std::string::npos) << error.what();
    }
}

/**
 * @brief Test the reference position and the center of gravity of the propulsion assembly in the aircraft file.
 */
TEST_F(PropulsionDesignOutput, UpdateWritesAggregateReferenceAndCentreOfGravity)
{
    /* Provide the reference aircraft and the engine database */
    ASSERT_TRUE(provide_reference_aircraft());
    ASSERT_TRUE(provide_engine_database());

    /* Design, update and save */
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());

    /* Read the mass and the CG of the engine, nacelle and pylon of both propulsors */
    auto document = aixml::openDocument(aircraft);
    const std::string p0 = results + "specific/propulsion@0/";
    const std::string p1 = results + "specific/propulsion@1/";
    const double m_e0 = document->at(p0 + "engine/mass_properties/mass/value");
    const double m_n0 = document->at(p0 + "nacelle/mass_properties/mass/value");
    const double m_p0 = document->at(p0 + "pylon/mass_properties/mass/value");
    const double m_e1 = document->at(p1 + "engine/mass_properties/mass/value");
    const double m_n1 = document->at(p1 + "nacelle/mass_properties/mass/value");
    const double m_p1 = document->at(p1 + "pylon/mass_properties/mass/value");
    const double m_total = m_e0 + m_n0 + m_p0 + m_e1 + m_n1 + m_p1;
    const double x_moment = m_e0 * static_cast<double>(document->at(p0 + "engine/mass_properties/center_of_gravity/x/value")) +
                            m_n0 * static_cast<double>(document->at(p0 + "nacelle/mass_properties/center_of_gravity/x/value")) +
                            m_p0 * static_cast<double>(document->at(p0 + "pylon/mass_properties/center_of_gravity/x/value")) +
                            m_e1 * static_cast<double>(document->at(p1 + "engine/mass_properties/center_of_gravity/x/value")) +
                            m_n1 * static_cast<double>(document->at(p1 + "nacelle/mass_properties/center_of_gravity/x/value")) +
                            m_p1 * static_cast<double>(document->at(p1 + "pylon/mass_properties/center_of_gravity/x/value"));
    const double y_moment = m_e0 * static_cast<double>(document->at(p0 + "engine/mass_properties/center_of_gravity/y/value")) +
                            m_n0 * static_cast<double>(document->at(p0 + "nacelle/mass_properties/center_of_gravity/y/value")) +
                            m_p0 * static_cast<double>(document->at(p0 + "pylon/mass_properties/center_of_gravity/y/value")) +
                            m_e1 * static_cast<double>(document->at(p1 + "engine/mass_properties/center_of_gravity/y/value")) +
                            m_n1 * static_cast<double>(document->at(p1 + "nacelle/mass_properties/center_of_gravity/y/value")) +
                            m_p1 * static_cast<double>(document->at(p1 + "pylon/mass_properties/center_of_gravity/y/value"));
    const double z_moment = m_e0 * static_cast<double>(document->at(p0 + "engine/mass_properties/center_of_gravity/z/value")) +
                            m_n0 * static_cast<double>(document->at(p0 + "nacelle/mass_properties/center_of_gravity/z/value")) +
                            m_p0 * static_cast<double>(document->at(p0 + "pylon/mass_properties/center_of_gravity/z/value")) +
                            m_e1 * static_cast<double>(document->at(p1 + "engine/mass_properties/center_of_gravity/z/value")) +
                            m_n1 * static_cast<double>(document->at(p1 + "nacelle/mass_properties/center_of_gravity/z/value")) +
                            m_p1 * static_cast<double>(document->at(p1 + "pylon/mass_properties/center_of_gravity/z/value"));

    /* Check the reference position at the origin and the mass-weighted CG of the six components (Eq. 34) */
    EXPECT_NEAR(static_cast<double>(document->at(results + "position/x/value")), 0.0, 1e-9);
    EXPECT_NEAR(static_cast<double>(document->at(results + "position/y/value")), 0.0, 1e-9);
    EXPECT_NEAR(static_cast<double>(document->at(results + "position/z/value")), 0.0, 1e-9);
    EXPECT_NEAR(static_cast<double>(document->at(results + "mass_properties/mass/value")), m_total, 1e-6);
    EXPECT_NEAR(static_cast<double>(document->at(results + "mass_properties/center_of_gravity/x/value")), x_moment / m_total, 1e-6);
    EXPECT_NEAR(static_cast<double>(document->at(results + "mass_properties/center_of_gravity/y/value")), y_moment / m_total, 1e-6);
    EXPECT_NEAR(static_cast<double>(document->at(results + "mass_properties/center_of_gravity/z/value")), z_moment / m_total, 1e-6);
}

/**
 * @brief Test that the exported inertia of the propulsion assembly is consistent with the exported component point masses.
 */
TEST_F(PropulsionDesignOutput, UpdateWritesConsistentAggregateInertia)
{
    /* Provide the reference aircraft and the engine database */
    ASSERT_TRUE(provide_reference_aircraft());
    ASSERT_TRUE(provide_engine_database());

    /* Design, update and save */
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());

    /* Read the six component point masses and combine them as the propulsion assembly: engine, nacelle, pylon per propulsor */
    auto document = aixml::openDocument(aircraft);
    const std::string p0 = results + "specific/propulsion@0/";
    const std::string p1 = results + "specific/propulsion@1/";
    const PointMass propulsor_0 = PointMass{} + read_point_mass(document, p0 + "engine/mass_properties/") +
                                  read_point_mass(document, p0 + "nacelle/mass_properties/") + read_point_mass(document, p0 + "pylon/mass_properties/");
    const PointMass propulsor_1 = PointMass{} + read_point_mass(document, p1 + "engine/mass_properties/") +
                                  read_point_mass(document, p1 + "nacelle/mass_properties/") + read_point_mass(document, p1 + "pylon/mass_properties/");
    const PointMass expected = PointMass{} + propulsor_0 + propulsor_1;

    /* Check the inertia of the propulsion assembly (Eq. 36) */
    const PointMass assembly = read_point_mass(document, results + "mass_properties/");
    EXPECT_FALSE(assembly.inertia.isZero());
    EXPECT_TRUE(assembly.inertia.isApprox(expected.inertia, 1e-6));
}

/**
 * @brief Test that the engine center of gravity is written in the global frame.
 */
TEST_F(PropulsionDesignOutput, UpdateWritesEngineCentreOfGravityInGlobalFrame)
{
    /* Provide the reference aircraft and the engine database */
    ASSERT_TRUE(provide_reference_aircraft());
    ASSERT_TRUE(provide_engine_database());

    /* Design, update and save */
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());

    /* Read the engine position, its CG and the scale factor of the first propulsor */
    auto document = aixml::openDocument(aircraft);
    const std::string engine = results + "specific/propulsion@0/engine/";
    const double x = document->at(engine + "position/x/value");
    const double y = document->at(engine + "position/y/value");
    const double z = document->at(engine + "position/z/value");
    const double k = document->at(engine + "scale_factor/value");

    /* Check CG = engine position + (L / 2, 0, 0) with the scaled length L = 3.401 m * k^0.4 of PW1127G-JM */
    EXPECT_GT(std::abs(y), 1.0);
    EXPECT_NEAR(static_cast<double>(document->at(engine + "mass_properties/center_of_gravity/x/value")), x + 0.5 * 3.401 * std::pow(k, 0.4), 1e-6);
    EXPECT_NEAR(static_cast<double>(document->at(engine + "mass_properties/center_of_gravity/y/value")), y, 1e-6);
    EXPECT_NEAR(static_cast<double>(document->at(engine + "mass_properties/center_of_gravity/z/value")), z, 1e-6);

    /* Check the nacelle CG: its sections are symmetric about L / 2, so it is at the engine position + (L / 2, 0, 0) as well */
    const std::string nacelle = results + "specific/propulsion@0/nacelle/mass_properties/center_of_gravity/";
    EXPECT_NEAR(static_cast<double>(document->at(nacelle + "x/value")), x + 0.5 * 3.401 * std::pow(k, 0.4), 1e-6);
    EXPECT_NEAR(static_cast<double>(document->at(nacelle + "y/value")), y, 1e-6);
    EXPECT_NEAR(static_cast<double>(document->at(nacelle + "z/value")), z, 1e-6);

    /* Check the pylon CG: both pylon ends are at the span station of the engine and the profile is symmetric,
     * so the CG has the y coordinate of the engine and lies above the engine under the wing */
    const std::string pylon = results + "specific/propulsion@0/pylon/mass_properties/center_of_gravity/";
    EXPECT_NEAR(static_cast<double>(document->at(pylon + "y/value")), y, 1e-6);
    EXPECT_GT(static_cast<double>(document->at(pylon + "z/value")), z);
}

/**
 * @brief Test that saving writes a result of a lower tool level with the own tool level.
 */
TEST_F(PropulsionDesignOutput, SaveRaisesToolLevelOfResults)
{
    /* Provide the engine database and an existing result with tool level 2 */
    ASSERT_TRUE(provide_engine_database());
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("</aircraft_exchange_file>",
                                                "<component_design><propulsion><specific><propulsion ID=\"0\"><engine>"
                                                "<SLST description=\"Sea level static thrust of the engine\"><value ToolLevel=\"2\">1</value><unit>N</unit></SLST>"
                                                "</engine></propulsion></specific></propulsion></component_design></aircraft_exchange_file>"));

    /* Design, update and save */
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());

    /* Check the result with the own tool level 3 of the configuration */
    auto document = aixml::openDocument(aircraft);
    EXPECT_EQ(document->at(results + "specific/propulsion@0/engine/SLST/value").getStringAttrib("ToolLevel"), "3");
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@0/engine/SLST/value")), thrust_per_engine, 1e-3);
}

/**
 * @brief Test that saving rejects changing a result of a higher tool level.
 */
TEST_F(PropulsionDesignOutput, SaveRejectsResultsOfHigherToolLevel)
{
    /* Provide the engine database and an existing result with tool level 4 */
    ASSERT_TRUE(provide_engine_database());
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("</aircraft_exchange_file>",
                                                "<component_design><propulsion><specific><propulsion ID=\"0\"><engine>"
                                                "<SLST description=\"Sea level static thrust of the engine\"><value ToolLevel=\"4\">1</value><unit>N</unit></SLST>"
                                                "</engine></propulsion></specific></propulsion></component_design></aircraft_exchange_file>"));

    /* Design and update */
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());

    /* Save and check the error */
    try
    {
        module->save();
        FAIL() << "Expected std::string for a result of a higher tool level";
    }
    catch (const std::string &error)
    {
        EXPECT_NE(error.find("tool level to low"), std::string::npos) << error;
    }
}

/**
 * @brief Test saving with the own tool level of the configuration.
 */
TEST_F(PropulsionDesignOutput, SaveUsesConfiguredToolLevel)
{
    /* Provide the engine database, an existing result with tool level 4 and the own tool level 5 */
    ASSERT_TRUE(provide_engine_database());
    ASSERT_NO_FATAL_FAILURE(replace_in_aircraft("</aircraft_exchange_file>",
                                                "<component_design><propulsion><specific><propulsion ID=\"0\"><engine>"
                                                "<SLST description=\"Sea level static thrust of the engine\"><value ToolLevel=\"4\">1</value><unit>N</unit></SLST>"
                                                "</engine></propulsion></specific></propulsion></component_design></aircraft_exchange_file>"));
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/own_tool_level/value", "5"));

    /* Design, update and save */
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());

    /* Check the result with the own tool level 5 */
    auto document = aixml::openDocument(aircraft);
    EXPECT_EQ(document->at(results + "specific/propulsion@0/engine/SLST/value").getStringAttrib("ToolLevel"), "5");
}

/**
 * @brief Test that saving writes new results without a tool level.
 */
TEST_F(PropulsionDesignOutput, SaveWritesNewResultsWithoutToolLevel)
{
    /* Provide the engine database */
    ASSERT_TRUE(provide_engine_database());

    /* Design, update and save */
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());

    /* Check that the new result has its value and no tool level */
    auto document = aixml::openDocument(aircraft);
    EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@0/engine/SLST/value")), thrust_per_engine, 1e-3);
    EXPECT_FALSE(document->at(results + "specific/propulsion@0/engine/SLST/value").hasAttrib("ToolLevel"));
}

/**
 * @brief Test that the XML results file copies the structure and the units of the propulsion results (the values are checked by ReportXmlContainsDesignResults).
 */
TEST_F(PropulsionDesignReport, ReportXmlCopiesStructureAndUnits)
{
    /* Provide the engine database and switch on the XML output */
    ASSERT_TRUE(provide_engine_database());
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/xml_output/value", "true"));
    auto module = make_module();

    /* Run the stages of execute() one by one */
    module->get_RuntimeIO()->create_common_directories();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->report());
    ASSERT_NO_THROW(module->save());

    /* Check the result nodes of both propulsors with their units and the description attribute */
    const auto results_file = temp.path() / "reporting" / "report_xml" / "propulsion_design_results.xml";
    ASSERT_TRUE(std::filesystem::exists(results_file));
    auto document = aixml::openDocument(results_file);
    const std::string copied = "module_results_file/calculation_results/propulsion/";
    ASSERT_NE(document->find(copied + "specific/propulsion@1/engine/SLST/value"), nullptr);
    EXPECT_EQ(static_cast<std::string>(document->at(copied + "specific/propulsion@0/engine/SLST/unit")), "N");
    EXPECT_EQ(static_cast<std::string>(document->at(copied + "specific/propulsion@1/engine/SLST/unit")), "N");
    EXPECT_EQ(static_cast<std::string>(document->at(copied + "specific/propulsion@0/engine/position/x/unit")), "m");
    EXPECT_EQ(static_cast<std::string>(document->at(copied + "mass_properties/mass/unit")), "kg");
    EXPECT_EQ(document->at(copied + "specific/propulsion@0/engine/SLST").getStringAttrib("description"),
              aixml::openDocument(aircraft)->at(results + "specific/propulsion@0/engine/SLST").getStringAttrib("description"));
    EXPECT_EQ(document->find(copied + "specific/propulsion@2"), nullptr);
}

/**
 * @brief Test the design summary and the engine tables of the HTML report.
 */
TEST_F(PropulsionDesignReport, ReportHtmlContainsSummaryAndEngineTables)
{
    /* Provide the engine database and switch on the HTML report (plots stay off) */
    ASSERT_TRUE(provide_engine_database());
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/report_output/value", "true"));
    auto module = make_module();

    /* Run the stages of execute() one by one */
    module->get_RuntimeIO()->create_common_directories();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->report());
    ASSERT_NO_THROW(module->save());

    /* Check the summary with the total SLST 2 * 102.97 kN and its point performance table */
    const std::string html = read_text(temp.path() / "reporting" / "report_html" / "propulsion_design_report.html");
    EXPECT_NE(html.find("Design Summary"), std::string::npos);
    EXPECT_NE(html.find("<td>SLST</td><td>205.94</td><td>kN</td>"), std::string::npos);
    EXPECT_NE(html.find("Point Performance"), std::string::npos);
    EXPECT_NE(html.find("<td>Thrust</td><td>kN</td>"), std::string::npos);
    EXPECT_NE(html.find("<td>Fuel Flow</td><td>kg/s</td>"), std::string::npos);
    EXPECT_NE(html.find("<td>TSFC</td><td>(kg/s)/N</td>"), std::string::npos);

    /* Check the table of both engines with model and SLST of 102.97 kN */
    EXPECT_NE(html.find("Engine ID: 0"), std::string::npos);
    EXPECT_NE(html.find("Engine ID: 1"), std::string::npos);
    EXPECT_NE(html.find("<td>Model</td><td>PW1127G-JM</td><td>-</td>"), std::string::npos);
    EXPECT_NE(html.find("<td>SLST</td><td>102.97</td><td>kN</td>"), std::string::npos);
    EXPECT_NE(html.find("<td>Bucket TSFC</td>"), std::string::npos);

    /* Check that no plots are referenced */
    EXPECT_EQ(html.find("<img"), std::string::npos);
}

/**
 * @brief Test that the HTML report with plots references the plot of every nacelle.
 */
TEST_F(PropulsionDesignReport, ReportHtmlWithPlotsReferencesPlotFiles)
{
    /* Provide the reference aircraft with geometry and the engine database, and switch on the report and the plots */
    ASSERT_TRUE(provide_reference_aircraft());
    ASSERT_TRUE(provide_engine_database());
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/report_output/value", "true"));
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/plot_output/enable/value", "true"));
    auto module = make_module();

    /* Run the stages of execute() one by one */
    module->get_RuntimeIO()->create_common_directories();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->report());
    ASSERT_NO_THROW(module->save());

    /* Check the references to the bucket curve, the top view and the views of both nacelles */
    const std::string html = read_text(temp.path() / "reporting" / "report_html" / "propulsion_design_report.html");
    EXPECT_NE(html.find("propulsion_design_bucket_curve.svg"), std::string::npos);
    EXPECT_NE(html.find("propulsion_design_top_view.svg"), std::string::npos);
    EXPECT_NE(html.find("propulsion_design_nacelle_0_front.svg"), std::string::npos);
    EXPECT_NE(html.find("propulsion_design_nacelle_0_side.svg"), std::string::npos);
    EXPECT_NE(html.find("propulsion_design_nacelle_1_front.svg"), std::string::npos);
    EXPECT_NE(html.find("propulsion_design_nacelle_1_side.svg"), std::string::npos);

    /* Check the views of the nacelle of engine 1 */
    const auto plots = std::filesystem::path{module->get_RuntimeIO()->getPlotDir()};
    EXPECT_TRUE(std::filesystem::exists(plots / "propulsion_design_nacelle_1_front.svg"));
    EXPECT_TRUE(std::filesystem::exists(plots / "propulsion_design_nacelle_1_side.svg"));
}

/**
 * @brief Test the axis labels, the legend and the title of the bucket curve plot.
 */
TEST_F(PropulsionDesignReport, BucketCurvePlotLabelsAndTitle)
{
    /* Provide the reference aircraft with geometry and the engine database, and switch on the report and the plots */
    ASSERT_TRUE(provide_reference_aircraft());
    ASSERT_TRUE(provide_engine_database());
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/report_output/value", "true"));
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/plot_output/enable/value", "true"));
    auto module = make_module();

    /* Run the stages of execute() one by one */
    module->get_RuntimeIO()->create_common_directories();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->report());
    ASSERT_NO_THROW(module->save());

    /* Check the labels, the legend entries and the design condition Mach 0.78 at 10058.4 m of UNICADO-SMR-01 in the title */
    const std::string svg = read_text(std::filesystem::path{module->get_RuntimeIO()->getPlotDir()} / "propulsion_design_bucket_curve.svg");
    EXPECT_NE(svg.find("Thrust, kN"), std::string::npos);
    EXPECT_NE(svg.find("TSFC, (kg/s)/N"), std::string::npos);
    EXPECT_NE(svg.find("with offtakes"), std::string::npos);
    EXPECT_NE(svg.find("without offtakes"), std::string::npos);
    EXPECT_NE(svg.find("bucket point"), std::string::npos);
    EXPECT_NE(svg.find("Bucket curve at Ma = 0.780, FL =  10058 m"), std::string::npos);
}

/**
 * @brief Test that the top view draws the nacelle and the engine outline of every engine under the wing.
 */
TEST_F(PropulsionDesignReport, TopViewDrawsOutlinesOfEnginesUnderWing)
{
    /* Provide the reference aircraft with geometry and the engine database, and switch on the report and the plots */
    ASSERT_TRUE(provide_reference_aircraft());
    ASSERT_TRUE(provide_engine_database());
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/report_output/value", "true"));
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/plot_output/enable/value", "true"));
    auto module = make_module();

    /* Run the stages of execute() one by one */
    module->get_RuntimeIO()->create_common_directories();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->report());
    ASSERT_NO_THROW(module->save());

    /* Count the polygons filled with the engine color green (162, 173, 0) in the top view */
    const std::string svg = read_text(std::filesystem::path{module->get_RuntimeIO()->getPlotDir()} / "propulsion_design_top_view.svg");
    std::size_t outlines = 0;
    for (auto position = svg.find("fill:#a2ad00"); position != std::string::npos; position = svg.find("fill:#a2ad00", position + 1))
    {
        ++outlines;
    }

    /* Check the nacelle and the engine outline of both engines of UNICADO-SMR-01 under the wing */
    EXPECT_EQ(outlines, 4U);
}

/**
 * @brief Test the dimensions in the front and the side view of the nacelle.
 */
TEST_F(PropulsionDesignReport, NacelleViewsShowNacelleDimensions)
{
    /* Provide the reference aircraft with geometry and the engine database, and switch on the report and the plots */
    ASSERT_TRUE(provide_reference_aircraft());
    ASSERT_TRUE(provide_engine_database());
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/report_output/value", "true"));
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/plot_output/enable/value", "true"));
    auto module = make_module();

    /* Run the stages of execute() one by one */
    module->get_RuntimeIO()->create_common_directories();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->report());
    ASSERT_NO_THROW(module->save());

    /* Expected dimensions with the scale factor k: width and height 1.21 * 2.224 m * sqrt(k), length 3.401 m * k^0.4 of PW1127G-JM */
    const double k = aixml::openDocument(aircraft)->at(results + "specific/propulsion@0/engine/scale_factor/value");
    std::stringstream diameter;
    diameter << std::setprecision(4) << 1.21 * 2.224 * std::sqrt(k) << " m";
    std::stringstream length;
    length << std::setprecision(4) << 3.401 * std::pow(k, 0.4) << " m";

    /* Check the outer diameter in the front view and the length and height in the side view */
    const auto plots = std::filesystem::path{module->get_RuntimeIO()->getPlotDir()};
    const std::string front = read_text(plots / "propulsion_design_nacelle_0_front.svg");
    const std::string side = read_text(plots / "propulsion_design_nacelle_0_side.svg");
    EXPECT_NE(front.find(diameter.str()), std::string::npos);
    EXPECT_NE(side.find(length.str()), std::string::npos);
    EXPECT_NE(side.find(diameter.str()), std::string::npos);
}

/**
 * @brief Test that the configuration file selects the implemented method of every design domain.
 */
TEST(PropulsionDesignConfigurationFile, DefaultMethodsAreImplemented)
{
    /* Open the configuration file of the module */
    auto document = aixml::openDocument(std::filesystem::path{CMAKE_TEST_CONFIG_FILE});
    const std::string method = "module_configuration_file/program_settings/method/";

    /* Check Rubber for the engine designer and Default for the other four domains */
    EXPECT_EQ(static_cast<std::string>(document->at(method + "engine_designer/value")), "Rubber");
    EXPECT_EQ(static_cast<std::string>(document->at(method + "nacelle_designer/value")), "Default");
    EXPECT_EQ(static_cast<std::string>(document->at(method + "pylon_designer/value")), "Default");
    EXPECT_EQ(static_cast<std::string>(document->at(method + "propulsion_integrator/value")), "Default");
    EXPECT_EQ(static_cast<std::string>(document->at(method + "mass_analyzer/value")), "Default");
}

/**
 * @brief Test the default program settings of the configuration file.
 */
TEST(PropulsionDesignConfigurationFile, DefaultProgramSettings)
{
    /* Open the configuration file of the module */
    auto document = aixml::openDocument(std::filesystem::path{CMAKE_TEST_CONFIG_FILE});
    const std::string settings = "module_configuration_file/program_settings/";

    /* Check the engine database, the wing of the engines and the kink placement */
    EXPECT_EQ(static_cast<std::string>(document->at(settings + "path_engine_database/value")), "../databases/engines/");
    EXPECT_EQ(static_cast<std::string>(document->at(settings + "name_wing_engines/value")), "front_wing");
    EXPECT_EQ(static_cast<std::string>(document->at(settings + "engine_at_kink/value")), "true");

    /* Check the default engine model and the section profiles of the Default propulsion entry */
    EXPECT_EQ(static_cast<std::string>(document->at(settings + "propulsion@Default/engine/Rubber/engine_model/value")), "PW1127G-JM");
    EXPECT_EQ(static_cast<std::string>(document->at(settings + "propulsion@Default/nacelle/profile/value")), "nacelle.dat");
    EXPECT_EQ(static_cast<std::string>(document->at(settings + "propulsion@Default/pylon/profile/value")), "pylon.dat");

    /* Check the own tool level */
    EXPECT_EQ(static_cast<std::string>(document->at("module_configuration_file/control_settings/own_tool_level/value")), "3");
}

/**
 * @brief Test the neutral technology factors and their lower boundary in the configuration file.
 */
TEST(PropulsionDesignConfigurationFile, TechnologyFactorsNeutralWithLowerBoundaryZero)
{
    /* Open the configuration file of the module */
    auto document = aixml::openDocument(std::filesystem::path{CMAKE_TEST_CONFIG_FILE});
    const std::string factors = "module_configuration_file/program_settings/technology_factors/";

    /* Check the value 1 and the lower boundary 0 of the four technology factors */
    EXPECT_DOUBLE_EQ(document->at(factors + "engine_mass/value"), 1.0);
    EXPECT_DOUBLE_EQ(document->at(factors + "engine_mass/lower_boundary"), 0.0);
    EXPECT_DOUBLE_EQ(document->at(factors + "nacelle_mass/value"), 1.0);
    EXPECT_DOUBLE_EQ(document->at(factors + "nacelle_mass/lower_boundary"), 0.0);
    EXPECT_DOUBLE_EQ(document->at(factors + "pylon_mass/value"), 1.0);
    EXPECT_DOUBLE_EQ(document->at(factors + "pylon_mass/lower_boundary"), 0.0);
    EXPECT_DOUBLE_EQ(document->at(factors + "engine_efficiency/value"), 1.0);
    EXPECT_DOUBLE_EQ(document->at(factors + "engine_efficiency/lower_boundary"), 0.0);
}

/**
 * @brief Test the default engine shift entry of the configuration file.
 */
TEST(PropulsionDesignConfigurationFile, DefaultEngineShiftIsZero)
{
    /* Open the configuration file of the module */
    auto document = aixml::openDocument(std::filesystem::path{CMAKE_TEST_CONFIG_FILE});
    const std::string shifts = "module_configuration_file/program_settings/repositioning/engine_shifts";

    /* Check one entry with ID 0 and no shift */
    ASSERT_EQ(document->at(shifts).getVector("engine").size(), 1U);
    EXPECT_EQ(static_cast<int>(document->at(shifts + "/engine/id/value")), 0);
    EXPECT_DOUBLE_EQ(document->at(shifts + "/engine/shift_x/value"), 0.0);
    EXPECT_DOUBLE_EQ(document->at(shifts + "/engine/shift_y/value"), 0.0);
    EXPECT_DOUBLE_EQ(document->at(shifts + "/engine/shift_z/value"), 0.0);
}

/**
 * @brief Test that initializing rejects the engine designer Empirical listed in the configuration file.
 */
TEST_F(PropulsionDesignConfiguration, InitializeRejectsEmpiricalEngineDesigner)
{
    /* Select the engine designer Empirical */
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/program_settings/method/engine_designer/value", "Empirical"));
    auto module = make_module();

    /* Initialize the module and check the error */
    try
    {
        module->initialize();
        FAIL() << "Expected std::runtime_error for the engine designer Empirical";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The engine designer method 'Empirical' is not supported."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that initializing rejects the engine designer GasTurb listed in the configuration file.
 */
TEST_F(PropulsionDesignConfiguration, InitializeRejectsGasTurbEngineDesigner)
{
    /* Select the engine designer GasTurb */
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/program_settings/method/engine_designer/value", "GasTurb"));
    auto module = make_module();

    /* Initialize the module and check the error */
    try
    {
        module->initialize();
        FAIL() << "Expected std::runtime_error for the engine designer GasTurb";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The engine designer method 'GasTurb' is not supported."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test the current behaviour that the method names are case sensitive.
 */
TEST_F(PropulsionDesignConfiguration, MethodNamesAreCaseSensitive)
{
    /* Select the nacelle designer in lower case */
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/program_settings/method/nacelle_designer/value", "default"));
    auto module = make_module();

    /* Initialize the module and check the error */
    try
    {
        module->initialize();
        FAIL() << "Expected std::runtime_error for the nacelle designer default";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("'default'"), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that the technology factor of the engine mass is applied once to the designed engine.
 */
TEST_F(PropulsionDesignConfiguration, EngineMassFactorAppliedOnce)
{
    /* Provide the engine database and the technology factor 0.8 for the engine mass */
    ASSERT_TRUE(provide_engine_database());
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/program_settings/technology_factors/engine_mass/value", "0.8"));

    /* Design, update and save */
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());

    /* Check the engine mass 0.8 * 2858 kg * k^1.1 of PW1127G-JM with the scale factor k */
    auto document = aixml::openDocument(aircraft);
    const std::string engine = results + "specific/propulsion@0/engine/";
    const double k = document->at(engine + "scale_factor/value");
    EXPECT_NEAR(static_cast<double>(document->at(engine + "mass_properties/mass/value")), 0.8 * 2858.0 * std::pow(k, 1.1), 1e-6);
}

/**
 * @brief Test that the technology factors of the nacelle and pylon mass from the configuration scale the designed masses.
 */
TEST_F(PropulsionDesignConfiguration, NacelleAndPylonMassFactorsScaleMasses)
{
    /* Provide the reference aircraft and the engine database */
    ASSERT_TRUE(provide_reference_aircraft());
    ASSERT_TRUE(provide_engine_database());

    /* Design, update and save with the neutral technology factors */
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());
    module.reset();
    auto document = aixml::openDocument(aircraft);
    const std::string propulsor_0 = results + "specific/propulsion@0/";
    const double engine_mass = document->at(propulsor_0 + "engine/mass_properties/mass/value");
    const double nacelle_mass = document->at(propulsor_0 + "nacelle/mass_properties/mass/value");
    const double pylon_mass = document->at(propulsor_0 + "pylon/mass_properties/mass/value");

    /* Design, update and save the reference aircraft again with the factors 0.9 for the nacelle and 1.1 for the pylon */
    ASSERT_TRUE(provide_reference_aircraft());
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/program_settings/technology_factors/nacelle_mass/value", "0.9"));
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/program_settings/technology_factors/pylon_mass/value", "1.1"));
    module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());

    /* Check the scaled nacelle and pylon masses and the unchanged engine mass */
    auto scaled = aixml::openDocument(aircraft);
    EXPECT_GT(pylon_mass, 0.0);
    EXPECT_NEAR(static_cast<double>(scaled->at(propulsor_0 + "engine/mass_properties/mass/value")), engine_mass, 1e-6);
    EXPECT_NEAR(static_cast<double>(scaled->at(propulsor_0 + "nacelle/mass_properties/mass/value")), 0.9 * nacelle_mass, 1e-6);
    EXPECT_NEAR(static_cast<double>(scaled->at(propulsor_0 + "pylon/mass_properties/mass/value")), 1.1 * pylon_mass, 1e-6);
}

/**
 * @brief Test the current behaviour that a negative technology factor is accepted despite the lower boundary 0 of the configuration file.
 */
TEST_F(PropulsionDesignConfiguration, NegativeTechnologyFactorAccepted)
{
    /* Provide the engine database and the technology factor -1 for the nacelle mass */
    ASSERT_TRUE(provide_engine_database());
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/program_settings/technology_factors/nacelle_mass/value", "-1.0"));

    /* Design, update and save */
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    ASSERT_NO_THROW(module->update());
    ASSERT_NO_THROW(module->save());

    /* Check that the nacelle mass is negative */
    auto document = aixml::openDocument(aircraft);
    EXPECT_LT(static_cast<double>(document->at(results + "specific/propulsion@0/nacelle/mass_properties/mass/value")), 0.0);
}

/**
 * @brief Test the console output of the designed engine with the console mode of the configuration.
 */
TEST_F(PropulsionDesignConfiguration, ConsoleOutputFollowsConfiguration)
{
    /* Provide the engine database and switch on the console output mode 1 */
    ASSERT_TRUE(provide_engine_database());
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/console_output/value", "mode_1"));
    auto module = make_module();

    /* Design the engines and capture the output */
    start_capture();
    EXPECT_NO_THROW(module->initialize());
    EXPECT_NO_THROW(module->run());
    stop_capture();

    /* Check the message of the designed engine */
    EXPECT_NE(captured_cout.str().find("Designed engine: PW1127G-JM"), std::string::npos);
}

/**
 * @brief Test that the console mode 0 of the configuration suppresses the output of the designed engine.
 */
TEST_F(PropulsionDesignConfiguration, ConsoleOutputOffSuppressesMessages)
{
    /* Provide the engine database; the console output mode 0 is set by the fixture */
    ASSERT_TRUE(provide_engine_database());
    auto module = make_module();

    /* Design the engines and capture the output */
    start_capture();
    EXPECT_NO_THROW(module->initialize());
    EXPECT_NO_THROW(module->run());
    stop_capture();

    /* Check that the message of the designed engine is not printed */
    EXPECT_EQ(captured_cout.str().find("Designed engine: PW1127G-JM"), std::string::npos);
}

/**
 * @brief Test the log file output of the designed engine with the log mode of the configuration.
 */
TEST_F(PropulsionDesignConfiguration, LogFileOutputFollowsConfiguration)
{
    /* Provide the engine database and switch on the log file output mode 1 */
    ASSERT_TRUE(provide_engine_database());
    ASSERT_NO_FATAL_FAILURE(set_value(config, "module_configuration_file/control_settings/log_file_output/value", "mode_1"));

    /* Design the engines and close the module */
    auto module = make_module();
    ASSERT_NO_THROW(module->initialize());
    ASSERT_NO_THROW(module->run());
    module.reset();

    /* Check the message of the designed engine in the configured log file */
    const auto log_file = temp.path() / "propulsion_design.log";
    ASSERT_TRUE(std::filesystem::exists(log_file));
    EXPECT_NE(read_text(log_file).find("Designed engine: PW1127G-JM"), std::string::npos);
}
