/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include "report_data.h"
#include "../io/engine_xml.h"
#include "engine/engine.h"
#include <algorithm>
#include <ranges>
#include <valarray>
#include <vector>

namespace report
{
    auto BucketCurve::bucket_point() -> BucketPoint
    {
        /* Update the cached bucket point if not valid */
        if (!this->bucket_point_valid_)
        {
            this->update_bucket_point();
        }

        /* Return the cached bucket point */
        return this->bucket_point_;
    }

    auto BucketCurve::bucket_point() const -> BucketPoint
    {
        return this->bucket_point_valid_ ? this->bucket_point_ : this->find_bucket_point();
    }

    auto BucketCurve::find_bucket_point() const -> BucketPoint
    {
        /* Get the tsfc */
        auto tsfc = this->tsfc();

        /* Find the bucket values */
        const auto tsfc_bucket = std::min_element(std::begin(tsfc), std::end(tsfc));
        const auto thrust_bucket = std::begin(this->thrust_) + std::distance(std::begin(tsfc), tsfc_bucket);

        /* Return the bucket point */
        return BucketPoint{*thrust_bucket, *tsfc_bucket};
    }

    void BucketCurve::update_bucket_point()
    {
        this->bucket_point_ = this->find_bucket_point();
        this->bucket_point_valid_ = true;
    }

    auto BucketCurve::operator+=(const BucketCurve &other) -> BucketCurve &
    {
        this->bucket_point_valid_ = false;
        this->thrust_ += other.thrust_;
        this->fuel_flow_ += other.fuel_flow_;
        return *this;
    }

    auto BucketCurve::operator+(const BucketCurve &other) const -> BucketCurve
    {
        return BucketCurve(this->thrust_ + other.thrust_, this->fuel_flow_ + other.fuel_flow_);
    }

    auto BucketCurve::from_engine_data(
        Engine *engine,
        const Offtakes &offtakes,
        const FlightCondition &condition) -> BucketCurve
    {
        /* Extract the lower speed limits */
        engine->calculate_N1_with_penalties(
            condition.altitude,
            condition.mach,
            condition.ambiance,
            1.0,
            "idle",
            offtakes.bleed_air,
            offtakes.shaft_power);
        const double N1_min = engine->get_operating_point().N;

        /* Extract the higher speed limits */
        engine->calculate_N1_with_penalties(
            condition.altitude,
            condition.mach,
            condition.ambiance,
            1.0,
            "takeoff",
            offtakes.bleed_air,
            offtakes.shaft_power);
        const double N1_max = engine->get_operating_point().N;

        /* Arrange a vector from N_min to N_max with n points*/
        std::vector<double> N1(bucket_points);
        std::iota(N1.begin(), N1.end(), 0.0);
        std::transform(N1.begin(), N1.end(), N1.begin(), [N1_min, N1_max](const auto &N1)
                       { return N1_min + N1 * (N1_max - N1_min) / (bucket_points - 1); });

        /* Get the fuel flow for each N1 value */
        BucketCurve curve;
        std::transform(
            N1.begin(),
            N1.end(),
            std::begin(curve.fuel_flow()),
            [&engine](const auto &N1)
            {
                auto op = engine->get_operating_point();
                op.N = N1;
                engine->set_operating_point(op);
                return engine->get_fuelflow();
            });

        /* Calculate thrust for each N1 value */
        std::transform(
            N1.begin(),
            N1.end(),
            std::begin(curve.thrust()),
            [&engine](const auto &N1)
            {
                auto op = engine->get_operating_point();
                op.N = N1;
                engine->set_operating_point(op);
                return engine->get_thrust();
            });

        /* Return the bucket curve */
        return curve; /* NRVO should be applied here. */
    }

    /**
     * @brief Update the report data with the engine data.
     *
     * @tparam Carrier The energy carrier of the engine.
     * @param data The data object to update.
     * @param engine The engine to extract the data from.
     * @param condition The design flight condition to calculate the bucket curve for.
     * @param engine_directory The directory where the engine data is stored.
     * @param engine_database The database where the engine data is stored.
     */
    template <EnergyCarrierFamily Carrier>
    void update_report_data(
        Data *data,
        const Propulsion<Carrier> &engine,
        const FlightCondition &condition,
        const std::filesystem::path &engine_directory,
        const std::filesystem::path &engine_database)
    {
        /* Load the scaled engine */
        auto engine_scaled = io::load_engine_scaled(
            engine.model(),
            engine.scale(),
            {engine_directory, engine_database});

        /* Calculate the bucket curves */
        try {
            data->bucket_curves.at("with offtakes") += BucketCurve::from_engine_data(
                &engine_scaled, engine.offtakes(), condition);
            } catch (const std::exception& e) {
                std::cout << "Bucket curve plot could not be created! Reason: " << e.what() << std::endl;}
        try{
            data->bucket_curves.at("without offtakes") += BucketCurve::from_engine_data(
                &engine_scaled, {}, condition);
            }catch (const std::exception& e) {
                std::cout << "Plot for bucket curve without offtakes could not be created! Reason: " << e.what() << std::endl;}
        

        /* Calculate the max. takeoff values */
        engine_scaled.calculate_N1_with_penalties(
            0.0,
            0.0,
            condition.ambiance,
            1.0,
            "takeoff",
            engine.offtakes().bleed_air,
            engine.offtakes().shaft_power);
        data->SLST_total += engine.required_thrust();
        data->thrust_takeoff += engine_scaled.get_thrust();
        data->fuel_flow_takeoff += engine_scaled.get_fuelflow();
    }

    auto generate_data(
        const std::vector<PropulsionType> &propulsions,
        const FlightCondition &condition,
        const std::filesystem::path &engine_directory,
        const std::filesystem::path &engine_database) -> Data
    {
        /* Create the data object and insert empty bucket curves */
        Data data{};
        data.bucket_curves["with offtakes"] = BucketCurve{};
        data.bucket_curves["without offtakes"] = BucketCurve{};

        /* Loop through the installed propulsors and add their contribution */
        for (auto &propulsor : propulsions)
        {
            std::visit(
                [&data, &condition, &engine_directory, &engine_database](auto &propulsor)
                {
                    update_report_data(&data, propulsor, condition, engine_directory, engine_database);
                },
                propulsor);
        }

        return data;
    };

}; // namespace report
