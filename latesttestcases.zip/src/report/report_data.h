/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

#ifndef SRC_REPORT_REPORT_DATA_H_
#define SRC_REPORT_REPORT_DATA_H_

/* === Includes === */
#include "../propulsion.h"
#include <engine/engine.h>
#include <filesystem>
#include <string>
#include <unordered_map>
#include <valarray>
#include <vector>

namespace report
{
    /* === Classes === */
    /**
     * @class BucketCurve
     * @brief Class representing the bucket curve of an engine.
     */
    constexpr std::size_t bucket_points = 100U; /**< The number of points in the bucket curve. */
    class BucketCurve
    {
      public:
        /* === Constructors === */
        BucketCurve() = default;
        BucketCurve(const std::valarray<double> &thrust, const std::valarray<double> &fuel_flow) : thrust_{thrust}, fuel_flow_{fuel_flow} {}
        BucketCurve(const BucketCurve &) = default;
        BucketCurve(BucketCurve &&) = default;
        auto operator=(const BucketCurve &) -> BucketCurve & = default;
        auto operator=(BucketCurve &&) -> BucketCurve & = default;

        /* === Getters === */
        [[nodiscard]] auto fuel_flow() const -> const std::valarray<double> & { return this->fuel_flow_; }
        [[nodiscard]] auto fuel_flow() -> std::valarray<double> & { return this->fuel_flow_; }
        [[nodiscard]] auto thrust() const -> const std::valarray<double> & { return this->thrust_; }
        [[nodiscard]] auto thrust() -> std::valarray<double> & { return this->thrust_; }
        [[nodiscard]] auto tsfc() const -> std::valarray<double> { return this->fuel_flow() / this->thrust(); }

        /* === Setters === */
        void set_thrust(const std::valarray<double> &thrust) { this->thrust_ = thrust; }
        void set_fuel_flow(const std::valarray<double> &flow) { this->fuel_flow_ = flow; }

        /* === Methods === */
        /**
         * @brief Get the bucket point of the curve.
         * @note This uses a cached value if available and
         * recalculates the bucket point if the cached value
         * is invalid and updates the cached value.
         *
         * @return BucketPoint The bucket point of the curve.
         */
        [[nodiscard]] auto bucket_point() -> BucketPoint;

        /**
         * @brief Const version of getting the bucket point
         * of the curve.
         * @note This uses a cached value if available and
         * recalculates the bucket point if the cached value
         * is invalid, but does not update the cached value.
         *
         * @return BucketPoint The bucket point of the curve.
         */
        [[nodiscard]] auto bucket_point() const -> BucketPoint;

        /**
         * @brief Recalculate the bucket point of the curve
         * and update the cached bucket point.
         */
        void update_bucket_point();

        /* === Operators to add the curves === */
        /**
         * @brief Add the bucket curves.
         * @note This invalidates the cached bucket point.
         *
         * @param other The other bucket curve to add.
         * @return BucketCurve & The bucket curve after adding the other curve.
         */
        auto operator+=(const BucketCurve &other) -> BucketCurve &;

        /**
         * @brief Add the bucket curves.
         * @note This invalidates the cached bucket point.
         *
         * @param other The other bucket curve to add.
         * @return BucketCurve The bucket curve after adding the other curve.
         */
        auto operator+(const BucketCurve &other) const -> BucketCurve;

        /* === Static Methods === */
        /**
         * @brief Calculate the bucket curve of the given engine.
         * @note The engine is passed by reference since its operating
         * point will be varied during the bucket curve calculation. The
         * given engine therefore is modified!
         *
         * @param engine The engine to create the bucket curve from.
         * @param offtakes [kg/s, W] The offtakes (bleed air, shaft power) of the engine.
         * @param condition The flight condition where the bucket curve should be calculated for.
         * @return BucketCurve The bucket curve of the engine with the given conditions.
         */
        [[nodiscard]] static auto from_engine_data(
            Engine *engine,
            const Offtakes &offtakes,
            const FlightCondition &condition) -> BucketCurve;

      private:
        /* === Methods === */
        /**
         * @brief Find the bucket point of the curve.
         *
         * @return BucketPoint The bucket point of the curve.
         */
        auto find_bucket_point() const -> BucketPoint;

        /* === Properties === */
        bool bucket_point_valid_{false}; /**< Whether the bucket point is valid. */
        BucketPoint bucket_point_{};     /**< The cached bucket point of the curve. */
        /* Call the explicit constructor of valarray to initiate the array with n points */
        std::valarray<double> thrust_ = std::valarray<double>(bucket_points);    /**< [N] The thrust values. */
        std::valarray<double> fuel_flow_ = std::valarray<double>(bucket_points); /**< [kg/s] The fuel flow values. */
    };

    /* Container to track different bucket curves */
    using BucketCurves = std::unordered_map<std::string, BucketCurve>;

    /**
     * @struct report::Data
     * @brief Struct containing all the data needed for the report.
     */
    struct Data
    {
        double SLST_total{-0.0};        /**< [N] The total SLST of all installed engines. */
        double thrust_takeoff{-0.0};    /**< [N] The max. T/O thrust at sea level of all installed engines. */
        double fuel_flow_takeoff{-0.0}; /**< [kg/s]  the max. T/O fuel flow at sea level of all installed engines. */
        BucketCurves bucket_curves;     /**< The bucket curves of the aircraft. */
    };

    /* === Functions === */
    /**
     * @brief Generate the necessary data for the report.
     * @attention This is an expensive function since a lot data
     * is computed here, like the bucket curves of each engine which
     * results in the bucket curve of the aircraft.
     *
     * @param propulsions The designed propulsion systems.
     * @param condition The design flight condition of the aircraft.
     * @param engine_directory The directory where the engine decks of the project can be found.
     * @param engine_database The directory of the engine data base.
     * @return Data Returns the report data object with valid data.
     */
    [[nodiscard]] auto generate_data(
        const std::vector<PropulsionType> &propulsions,
        const FlightCondition &condition,
        const std::filesystem::path &engine_directory,
        const std::filesystem::path &engine_database) -> Data;
}; // namespace report

#endif // SRC_REPORT_REPORT_DATA_H_
