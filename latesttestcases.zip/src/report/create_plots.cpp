/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include "../propulsion_design.h"
#include "../propulsion.h"
#include "../aircraft_geometry.h"
#include "file_names.h"
#include "report_data.h"
#include <algorithm>
#include <format>
#include <ranges>
#include <sstream>
#include <boost/range.hpp>
#include <matplot/matplot.h>
#include <aircraftGeometry2/processing/measure.h>
#include <aircraftGeometry2/processing/transform.h>
#include <moduleBasics/svg.h>
#include <moduleBasics/runtimeIO.h>

/* === Define colors and names of the plots ===*/
constexpr svg::Colors::Color_t Grey{128, 128, 128};
constexpr svg::Colors::Color_t BlueLight{100, 160, 200};
constexpr svg::Colors::Color_t BlueDark{0, 51, 89};
constexpr svg::Colors::Color_t Orange{227, 114, 43};
constexpr svg::Colors::Color_t Green{162, 173, 0};

namespace detail
{
    /**
     * @brief Apply an offset to the aircraft geometry.
     *
     * The svg plots need the origin of the aircraft to be in the center of the image.
     * This function applies an offset to the aircraft geometry to move it to the center.
     *
     * @param aircraft The aircraft to apply the offset to.
     * @param offset The offset to apply.
     */
    void apply_offset(
        const std::shared_ptr<geometry::Aircraft> aircraft,
        const geom2::Vector_3 &offset)
    {
        /* Lambda to apply the offset */
        auto add_offset = [&offset](auto &surface)
        {
            surface.origin += offset;
        };

        /* Apply the offset to the aircraft geometry */
        std::ranges::for_each(aircraft->wings, add_offset);
        std::ranges::for_each(aircraft->fuselages, add_offset);
        std::ranges::for_each(aircraft->empennage, add_offset);
    }

    auto convert_color(const svg::Colors::Color_t &color) -> std::array<float, 3>
    {
        return {
            std::get<0>(color) / 255.0F,
            std::get<1>(color) / 255.0F,
            std::get<2>(color) / 255.0F,
        };
    }
} // namespace detail

namespace draw
{
    /**
     * @brief Draw the outline of the surface with the specified view direction.
     * If the surface is symmetric, the symmetric part is also drawn.
     *
     * @param image The svg image to draw to.
     * @param surface The surface to draw.
     * @param view_direction The direction to view the surface from.
     */
    template <typename SectionType>
    void surface(
        svg::ofstream &image,
        const geom2::MultisectionSurface<SectionType> &surface,
        const geom2::Direction_3 &view_direction)
    {
        /* Get the outline of the surface */
        auto outline = geom2::transform::outline_2d(surface, view_direction);
        image << svg::Polygon(outline, svg::Colors::White);

        /* Finish the surface if it is symmetric */
        if (surface.is_symmetric)
        {
            /* Mirror in y around origin */
            const auto origin = surface.origin;
            auto outline_sym = outline | std::views::transform(
                                             [&origin](const auto &point) -> geom2::Point_2
                                             {
                                                 return geom2::Point_2{point.x(), -1.0 * (2 * origin.y() + point.y())};
                                             });

            /* Draw the symmetric part */
            image << svg::Polygon(outline_sym, svg::Colors::White);
        }
    }
} // namespace draw

namespace plot
{
    /* === Implementations === */
    /**
     * @brief Add a bucket curve plot to the axis.
     *
     * @param axis The axis to add the plot to.
     * @param bucket_curve The bucket curve to plot.
     */
    void add_bucket_curve(matplot::axes_handle axis, report::BucketCurves::value_type bucket_curve)
    {
        /* Get the bucket point */
        const auto bucket_point = bucket_curve.second.bucket_point();

        /* Convert the thrust to kN */
        auto thrust_kN = bucket_curve.second.thrust();
        thrust_kN /= 1000.0;

        /* Get the TSFC data */
        auto tsfc = bucket_curve.second.tsfc();

        /* Plot the curve */
        axis->plot(
                boost::make_iterator_range(std::begin(thrust_kN), std::end(thrust_kN)),
                boost::make_iterator_range(std::begin(tsfc), std::end(tsfc)))
            ->line_width(2)
            .color(detail::convert_color(BlueDark));

        /* Add legend entry */
        if (axis->legend() == nullptr)
        {
            axis->legend({bucket_curve.first});
        }
        else
        {
            axis->legend()->strings().back() = bucket_curve.first;
        }

        /* Plot the bucket point */
        axis->scatter({bucket_point.thrust/1000}, {bucket_point.tsfc})
            ->marker("o");
        axis->legend()->strings().back() = "bucket point";
    }

    void bucket_curve(
        const std::shared_ptr<RuntimeIO>& rtIO,
        const report::BucketCurves &bucket_curves,
        const FlightCondition &flight_condition)
    {
        /* Use the matplotplusplus namespace */
        namespace plt = matplot;

        /* Setup the figure and axes (reuse shared figure to avoid gnuplot hangs on Linux) */
        auto figure = rtIO->get_figure();
        auto ax = figure->add_axes(true);
        figure->size(800, 600);
        figure->position({0, 0, 800, 600});
        ax->hold(true);

        /* Plot each available bucket curve */
        std::for_each(
            bucket_curves.begin(),
            bucket_curves.end(),
            [ax](const auto &bucket_curve)
            {
                add_bucket_curve(ax, bucket_curve);
            });

        /* Format the plot */
        ax->grid(true);
        ax->font_size(18);
        ax->xlabel("Thrust, kN");
        ax->x_axis().label_font_size(18);
        ax->ylabel("TSFC, (kg/s)/N");
        ax->y_axis().label_font_size(18);
        ax->ytickformat("   %1.1e");
        ax->legend()->location(plt::legend::general_alignment::topright);
        ax->legend()->num_rows(2);
        ax->legend()->font_size(16);
        ax->title(
            std::format(
                "Bucket curve at Ma = {:1.3f}, FL = {:6.0f} m",
                flight_condition.mach, flight_condition.altitude));

        /* Save the finished plot */
        utility::print("Plotting bucket curve to: " + std::string(report::name_bucket_curve()), Level::Debug);
        rtIO->save_and_clear_figure(std::string(report::name_bucket_curve()));
    }

    void nacelle_front(const std::filesystem::path &plot_dir, const geom2::MultisectionSurface<geom2::PolygonSection> &nacelle, const geom2::MultisectionSurface<geom2::PolygonSection> &engine_geom)
    {
        /* Get the minimum and maximum dimensions of the nacelle */
        svg::Size nacelle_max = {geom2::measure::width_max(nacelle), geom2::measure::height_max(nacelle)};
        svg::Size nacelle_min = {
            nacelle.sections[0].get_contour(true).bbox().x_span(),
            nacelle.sections[0].get_contour(true).bbox().y_span()};

        svg::Size engine_geom_max = {geom2::measure::width_max(engine_geom), geom2::measure::height_max(engine_geom)};
        svg::Size engine_geom_min = {
            engine_geom.sections[0].get_contour(true).bbox().x_span(),
            engine_geom.sections[0].get_contour(true).bbox().y_span()};

        /* Create the svg */
        svg::ofstream image{plot_dir / report::name_front_view(nacelle.name), 1.25 * nacelle_max, 20};
        svg::Coordinate center = {0.1 + nacelle_max.width / 2, 0.1 + nacelle_max.height / 2};

        /* Draw the front of nacelle */
        image << svg::Ellipse(center, nacelle_max, BlueLight)
              << svg::Ellipse(center, nacelle_min, svg::Colors::White)
              << svg::Ellipse(center, engine_geom_max, BlueDark)
              << svg::Ellipse(center, engine_geom_min, BlueDark);

        /* Add the outer diameter dimension */
        const svg::Coordinate nacelle_left{-nacelle_max.width / 2, 0};
        image << svg::HorizontalDimension(nacelle_left + center, {nacelle_max.width, 0.2 + nacelle_max.height / 2});

        /* Finalize the view */
        image.close();
    }

    void nacelle_side(const std::filesystem::path &plot_dir, const geom2::MultisectionSurface<geom2::PolygonSection> &nacelle, const geom2::MultisectionSurface<geom2::PolygonSection> &engine_geom)
    {
        /* Get the minimum and maximum dimensions of the nacelle */
        svg::Size nacelle_bbox = {geom2::measure::length(nacelle), geom2::measure::height_max(nacelle)};

        /* Create the svg */
        svg::ofstream image{plot_dir / report::name_side_view(nacelle.name), 1.3 * nacelle_bbox, 20};
        svg::Coordinate center = {0.1 + nacelle_bbox.width / 2, 0.1 + nacelle_bbox.height / 2};

        /* Draw the side of the nacelle */
        const auto side_view = geom2::transform::outline_2d(nacelle, {0, 1, 0});
        image << svg::Polygon(
            (side_view | std::views::transform(
                             [&center](const auto &point)
                             {
                                 geom2::Kernel::Vector_2 offset{0.5, center.y};
                                 return point + offset;
                             })),
            BlueLight);


        const auto side_view_engine = geom2::transform::outline_2d(engine_geom, {0, 1, 0});
        image << svg::Polygon(
            (side_view_engine | std::views::transform(
                            [&center](const auto &point)
                            {
                                geom2::Kernel::Vector_2 offset{0.5, center.y};
                                return point + offset;
                            })),
            BlueDark);
        

        /* Dimension the length of the nacelle */
        const svg::Coordinate left{0.4-nacelle_bbox.width / 2, 0};
        const svg::Coordinate top{0, -nacelle_bbox.height / 2};
        image << svg::HorizontalDimension(left + center, {nacelle_bbox.width, 0.2 + nacelle_bbox.height / 2})
              << svg::VerticalDimension(top + center, {0.9 + nacelle_bbox.width / 2, nacelle_bbox.height});

        /* Finalize the view */
        image.close();
    }

    void top_overview(
        const std::filesystem::path &plot_dir,
        const std::shared_ptr<geometry::Aircraft> aircraft,
        const std::vector<PropulsionType> &engines)
    {
        /* Get the dimensions of the aircraft */
        /** @todo Check which wing and fuselage to use to get the bounding box */
        const double span = geom2::measure::span(aircraft->wings[0]);
        const double length = geom2::measure::length(aircraft->fuselages[0]);

        /* Setup the image */
        const geom2::Direction_3 view_direction{0, 0, -1};
        const svg::Size aircraft_bbox{length, span};
        svg::ofstream top_view{plot_dir / report::name_top_view(), 1.1 * aircraft_bbox};

        /* Offset the components to be in the center of the image */
        const geom2::Vector_3 offset{1, -1.1 * span / 2, 0};
        detail::apply_offset(aircraft, offset);

        /* Lambda to create the top view */
        auto draw_top = [&top_view, &view_direction](const auto &surface)
            {
                draw::surface(top_view, surface, view_direction);
            };

        for (auto& engine : engines)
        {
            auto parent_comp = std::visit(
                [](const auto& engine)
                {
                    /* Return the parent component */
                    return std::get<Vertical>(engine.parent_component());
                },
                engine);
            if (parent_comp == Vertical::Under) {
                std::visit(
                    [&top_view, &offset, &view_direction](auto& arg)
                    {
                        auto nacelle = arg.nacelle();
                        nacelle.origin = arg.position() + offset;
                        auto outline = geom2::transform::outline_2d(nacelle, view_direction);
                        top_view << svg::Polygon(outline, Green);

                        auto engine_geom = arg.engine_geom();
                        engine_geom.origin = arg.position() + offset;
                        auto outline_engine = geom2::transform::outline_2d(engine_geom, view_direction);
                        top_view << svg::Polygon(outline_engine, Green);
                    },
                    engine);
            }
        }

        /* Draw the wing top view */
        std::ranges::for_each(aircraft->wings.begin(), aircraft->wings.end(), draw_top);

        /* Draw horizontal empennage surfaces */
        std::ranges::for_each(
            aircraft->empennage | std::views::filter(std::not_fn(geometry::is_vertical)),
            draw_top);

        /* Draw the fuselage */
        std::ranges::for_each(aircraft->fuselages, draw_top);

        /* Draw vertical empennage surfaces */
        std::ranges::for_each(
            aircraft->empennage | std::views::filter(geometry::is_vertical),
            draw_top);

        /* Draw all nacelles */
        for (auto& engine : engines)
        {
            auto parent_comp = std::visit(
                [](const auto& engine)
                {
                    /* Return the parent component */
                    return std::get<Vertical>(engine.parent_component());
                },
                engine);
            if (parent_comp == Vertical::In || parent_comp == Vertical::Over || parent_comp == Vertical::Mid) {
                std::visit(
                    [&top_view, &offset, &view_direction](auto& arg)
                    {
                        auto nacelle = arg.nacelle();
                        nacelle.origin = arg.position() + offset;
                        auto outline = geom2::transform::outline_2d(nacelle, view_direction);
                        top_view << svg::Polygon(outline, Green);
                    },
                    engine);
            }
        }

        /* Save the svg file */
        top_view.close();
    }
}; // namespace plot

/* === Generate the plots of the module ===*/
void PropulsionDesign::create_plots()
{
    /* Get the plotting directory */
    const std::filesystem::path plot_dir = this->get_RuntimeIO()->getPlotDir();

    /* Create the bucket curve */
    plot::bucket_curve(
        this->get_RuntimeIO(),
        this->report_data.bucket_curves,
        this->engine_designer->flight_condition());

    /* Create the top view */
    plot::top_overview(plot_dir, this->aircraft_geometry, this->engines);

    /* Create the plot of each nacelle */
    for (auto &engine : engines)
    {
        std::visit(
            [&plot_dir](auto &arg)
            {
                plot::nacelle_front(plot_dir, arg.nacelle(), arg.engine_geom());
                plot::nacelle_side(plot_dir, arg.nacelle(), arg.engine_geom());
            },
            engine);
    }
}
