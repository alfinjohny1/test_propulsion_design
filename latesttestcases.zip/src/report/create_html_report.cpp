/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include "../propulsion_design.h"
#include "file_names.h"
#include "report_data.h"
#include <filesystem>
#include <moduleBasics/html.h>
#include <moduleBasics/report.h>
#include <sstream>

/* === Functions === */
template <EnergyCarrierFamily Carrier>
void insert_engine(
    std::stringstream *stream,
    const Propulsion<Carrier> &engine)
{
    /* Insert the engine data */
    (*stream) << html::h3("Engine ID: " + std::to_string(engine.id()))
              << html::table_begin({"Parameter", "Value", "Unit"})
              << html::table_row("Model", engine.model(), "-")
              << html::table_row("Scale Factor", engine.scale(), "-")
              << html::table_row("SLST", engine.required_thrust() / 1000, "kN")
              //    << html::table_row("Thrust Share", engine.thrust_share(), "-")
              << html::table_row("Mass", engine.pointmass(Component::Engine).mass, "kg")
              << html::table_row("Bucket Thrust", engine.bucket_point().thrust / 1000, "kN")
              << html::table_row("Bucket TSFC", engine.bucket_point().tsfc, "(kg/s)/N")
              << html::table_end;
}

void insert_nacelle(std::stringstream *stream,
                    const geom2::MultisectionSurface<geom2::PolygonSection> &nacelle,
                    const std::filesystem::path &plot_dir_relative)
{
    (*stream) << "<div style=\"padding: 5 0 30 0;\">\n"
              << html::h2("Dimensions of <b>" + nacelle.name + "</b>")
              << html::image((plot_dir_relative / report::name_front_view(nacelle.name)).string(), "height=\"200px\"")
              << html::image((plot_dir_relative / report::name_side_view(nacelle.name)).string(), "height=\"200px\"")
              << "</div>\n";
}

void insert_plots(
    std::stringstream *stream,
    const std::vector<PropulsionType> &engines,
    const std::filesystem::path &plot_dir_relative)
{
    (*stream)
        << html::div_start("class=\"box plot\"")
        << html::h2("Bucket curve of the aircraft")
        << html::image((plot_dir_relative / report::name_bucket_curve()).string(), "style=\"margin: 10 0 5 0\"")
        << html::h2("Top view of the aircraft")
        << html::image((plot_dir_relative / report::name_top_view()).string(), "width=\"600px\"");

    /* Insert the nacelles */
    for (auto &engine : engines)
    {
        std::visit(
            [stream, &plot_dir_relative](auto &arg)
            {
                insert_nacelle(stream, arg.nacelle(), plot_dir_relative);
            },
            engine);
    }

    /* Close the plots div */
    (*stream) << html::div_end;
}

void insert_summary(
    std::stringstream *stream,
    const report::Data &data)
{
    /* Get the bucket points */
    const auto with_offtakes = data.bucket_curves.at("with offtakes").bucket_point();
    const auto without_offtakes = data.bucket_curves.at("without offtakes").bucket_point();

    /* Insert the summary into the html stream */
    (*stream) << html::h2("Design Summary")
              << html::h3("Total Values")
              << html::table_begin({"Parameter", "Value", "Unit"})
              << html::table_row("SLST", data.SLST_total / 1000, "kN")
              << html::table_end
              << html::h3("Point Performance")
              << html::table_begin({"Parameter", "Unit", "Max. T/O with offtakes", "Bucket Point with offtakes", "Bucket Point without offtakes"});

    /* Insert the thrust row */
    (*stream) << html::table_row(
        "Thrust",
        "kN",
        data.thrust_takeoff / 1000,
        with_offtakes.thrust / 1000,
        without_offtakes.thrust / 1000);

    /* Insert the fuel flow row */
    (*stream) << html::table_row(
        "Fuel Flow",
        "kg/s",
        data.fuel_flow_takeoff,
        with_offtakes.tsfc * with_offtakes.thrust,
        without_offtakes.tsfc * without_offtakes.thrust);

    /* Insert the tsfc row */
    (*stream) << html::table_row(
        "TSFC",
        "(kg/s)/N",
        data.fuel_flow_takeoff / data.thrust_takeoff,
        with_offtakes.tsfc,
        without_offtakes.tsfc);

    /* Close the table */
    (*stream) << html::table_end;
}

/* === Create the module html report === */
void PropulsionDesign::create_html_report()
{
    /* Setup the report */
    Report report(this->get_RuntimeIO());
    auto &html_stream = report.htmlReportStream();

    /* Get the relative plot directory for the html report */
    std::filesystem::path plot_dir_relative{
        std::filesystem::relative(this->get_RuntimeIO()->getPlotDir(),
                                  this->get_RuntimeIO()->getHtmlDir())};

    /* Start the data div */
    html_stream << html::div_start("class=\"box data\"");

    /* Add summary*/
    insert_summary(&html_stream, this->report_data);

    /* Add list with installed engines */
    html_stream << html::h3("List of installed engines:") << "<ul>\n";
    for (const auto &model : this->engine_designer->designed_engines())
    {
        html_stream << "<li>" << model << "</li>\n";
    }
    html_stream << "</ul>\n"
                << "<hr style=\"margin: 5 10 5 10;\">\n";

    /* Insert the engines */
    for (auto &engine : this->engines)
    {
        std::visit(
            [&html_stream](const auto &engine_)
            {
                insert_engine(&html_stream, engine_);
            },
            engine);
    }
    html_stream << html::div_start("style=\"margin: 0 0 20 0;\"")
                << "<b>Note:</b> All bucket values are at the design flight condition with offtakes unless noted otherwise.\n"
                << html::div_end;

    /* Close the data div */
    html_stream << html::div_end;

    /* Insert the plots for the report if they are enabled */
    if (this->get_RuntimeIO()->plotOn)
    {
        insert_plots(&html_stream, this->engines, plot_dir_relative);
    }

    /* Finish the html report */
    report.generateHtmlReport("");
}
