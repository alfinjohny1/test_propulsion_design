/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

#ifndef SRC_REPORT_FILE_NAMES_H_
#define SRC_REPORT_FILE_NAMES_H_

/* === Includes === */
#include <string>
#include <string_view>

namespace report
{
    /**
     * @brief The name of the bucket curve plot.
     */
    consteval auto name_bucket_curve() -> std::string_view
    {
        return "propulsion_design_bucket_curve.svg";
    }

    /**
     * @brief The name of the top view plot.
     */
    consteval auto name_top_view() -> std::string_view
    {
        return "propulsion_design_top_view.svg";
    }

    /**
     * @brief The name of the nacelle front view plots.
     */
    constexpr auto name_front_view(const std::string &nacelle_name) -> std::string
    {
        return "propulsion_design_" + nacelle_name + "_front.svg";
    }

    /**
     * @brief The name of the nacelle side view plots.
     */
    constexpr auto name_side_view(const std::string &nacelle_name) -> std::string
    {
        return "propulsion_design_" + nacelle_name + "_side.svg";
    }
}; // namespace report

#endif // SRC_REPORT_FILE_NAMES_H_
