/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include "../propulsion_design.h"
#include <filesystem>
#include <sstream>


void PropulsionDesign::create_xml_report()
    {
        // Write propulsion_design_results.xml by copying propulsion node from aircraft XML
        auto get_current_datetime = []() -> std::string {
            std::time_t t = std::time(nullptr);
            std::tm tm = *std::localtime(&t);
            std::ostringstream oss;
            oss << std::put_time(&tm, "%Y-%m-%d_%H-%M-%S");
            return oss.str();
        };
        // Setup the XML report output stream and directory
        std::string results_xml_path = this->get_RuntimeIO()->getXmlDir() + "/propulsion_design_results.xml";
        std::filesystem::path xml_dir = this->get_RuntimeIO()->getXmlDir();
        if (!std::filesystem::exists(xml_dir)) {
            std::filesystem::create_directories(xml_dir);
        }
        // Always delete the old results file if it exists
        if (std::filesystem::exists(results_xml_path)) {
            std::error_code ec;
            std::filesystem::remove(results_xml_path, ec);
            if (ec) {
                utility::print("Warning: Could not delete old propulsion_design_results.xml: " + ec.message(), Level::Warning);
            } else {
                utility::print("Deleted old propulsion_design_results.xml at: " + results_xml_path, Level::Debug);
            }
        }
            // Extract project name from configuration_xml
            std::string project_name_full = EndnodeReadOnly<std::string>("control_settings/aircraft_exchange_file_name").read(*this->configuration_xml).value();
            std::string project_name = project_name_full.substr(0, project_name_full.find_last_of('.'));
        std::ofstream outstream(results_xml_path);
        if (outstream) 
        {
            outstream << "<module_results_file Name=\"Propulsion Design specific outputs\">" << std::endl;
            outstream << "  <general_information description=\"General information on module execution\">" << std::endl;
            outstream << "    <execution_date description=\"Execution date and time of the code\">" << std::endl;
            outstream << "      <value>" << get_current_datetime() << "</value>" << std::endl;
            outstream << "    </execution_date>" << std::endl;
            outstream << "    <project_name description=\"Name of the current aircraft project\">" << std::endl;
            outstream << "      <value>" << project_name << "</value>" << std::endl;
            outstream << "    </project_name>" << std::endl;
            outstream << "    <method_name description=\"Name of current module calculation method\">" << std::endl;
            outstream << "      <value>propulsion_design</value>" << std::endl;
            outstream << "    </method_name>" << std::endl;
            outstream << "  </general_information>" << std::endl;
            outstream << "  <calculation_results description=\"Results of calculation method\">" << std::endl;
            outstream << "  </calculation_results>" << std::endl;
            outstream << "</module_results_file>" << std::endl;
            outstream.close();
        } 
        else 
        {
            utility::print("Failed to create minimal propulsion_design_results.xml at: " + results_xml_path, Level::Warning);
        }

        try 
        {
            node& file_results = aixml::openDocument(results_xml_path);
            // Find or create <calculation_results> node (replace contents if exists)
            node* calculation_results = file_results.find("calculation_results");
            node* src_propulsion = aircraft_xml->find("aircraft_exchange_file/component_design/propulsion");
            if (src_propulsion) {
                auto copy_structure_and_end_values = [](const node& source_node, node& dest_parent_node, auto& self_ref) -> void {
                    bool is_end_node = source_node.getChildren().empty();
                    std::string node_name = source_node.getName();
                    if (is_end_node && node_name != "value" && node_name != "unit") {
                        return;
                    }
                    node& new_dest_node = dest_parent_node.appendChild(node_name, true);
                    std::map<std::string, std::string> attributes = source_node.getAttribMap();
                    for (const auto& pair : attributes) {
                        new_dest_node.setAttrib(pair.first, pair.second);
                    }
                    if (!is_end_node) {
                        const std::vector<node*>& children = source_node.getChildren();
                        for (const auto& child_ptr : children) {
                            if (child_ptr) {
                                self_ref(*child_ptr, new_dest_node, self_ref);
                            }
                        }
                    } else {
                        new_dest_node = static_cast<std::string>(const_cast<node&>(source_node));
                    }
                };
                copy_structure_and_end_values(*src_propulsion, *calculation_results, copy_structure_and_end_values);
            }
            aixml::saveDocument(file_results);
            aixml::closeDocument(file_results);
        } 
        catch (const std::exception& e) 
        {
            utility::print(std::string("Error writing propulsion_design_results.xml: ") + e.what(), Level::Out);
        }
    }