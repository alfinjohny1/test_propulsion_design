/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

#ifndef SRC_PROPULSION_DESIGN_H_
#define SRC_PROPULSION_DESIGN_H_

/* === Includes === */
#include <moduleBasics/module.h>
#include <string>
#include <vector>
#include <unordered_map>
#include <memory>
#include "aircraft_geometry.h"
#include "engine_design/engine_design.h"
#include "integration/propulsion_integration.h"
#include "mass/mass_analysis.h"
#include "nacelle/nacelle_design.h"
#include "propulsion.h"
#include "pylon/pylon_design.h"
#include "utility.h"
#include "report/report_data.h"

/* === Classes === */
/**
 * @class PropulsionDesign
 * @brief The propulsionDesign module.
 */
class PropulsionDesign : public Module
{
  public:
    /* === Constructors === */
    /**
     * @brief Construct a new PropulsionDesign module instance.
     *
     * @param argc The number of command line arguments.
     * @param argv The command line arguments.
     * @param toolName The name of the tool.
     * @param toolVersion The version of the tool.
     */
    PropulsionDesign(const int argc, char **argv, const std::string &toolName, const std::string &toolVersion)
        : Module(argc, argv, toolName, toolVersion)
    {
    }

    PropulsionDesign(const std::string& toolName, const std::string& toolVersion, const std::filesystem::path& rtConfigXML)
        : Module(toolName, toolVersion, rtConfigXML)
    {
    }

    /**
     * @brief Destroy the PropulsionDesign module instance.
     */
    ~PropulsionDesign() = default;

    /* === Populate the module template methods === */
    void initialize() override;
    void run() override;
    void update() override;
    void report() override;
    void save() override;

  private:
    /* === Methods === */
    /**
     * @brief Create a aircraft geometry object from the aircraft XML input.
     * @note When the aircraft XML file does not yet contain valid geometry,
     * the aircraft geometry will be a null pointer! The design strategies
     * have to check the validity of the geometry before using it.
     * @attention All geometry is referenced to the GLOBAL aircraft coordinate system!
     */
    void create_aircraft_geometry();

    /**
     * @brief Create the html report for the propulsion design.
     */
    void create_html_report();

    /**
     * @brief Create the xml report for the propulsion design.
     */

    void create_xml_report();

    /**
     * @brief Create the plots for the propulsion design report.
     */
    void create_plots();

    /**
     * @brief Populate the vector with all the propulsion systems which should be designed
     */
    void create_propulsors();

    /**
     * @brief Sort the inputs to be correct for the calculation methodology in the tool
     */
    void sort_propulsors();

    void check_validity();

    /**
     * @brief Get the design flight condition from the aircraft xml.
     * The condition is taken from the initial cruise condition.
     *
     * @return design::FlightCondition The design flight condition.
     */
    auto get_design_condition() const -> FlightCondition;

    void select_engine_designer();
    void select_propulsion_integrator();
    void select_nacelle_designer();
    void select_pylon_designer();
    void select_mass_analyzer();

    /* === Properties === */
    std::shared_ptr<node> aircraft_xml;                                  /** [-] The aircraft xml data. */
    std::shared_ptr<geometry::Aircraft> aircraft_geometry;               /** [-] The aircraft geometry. */
    std::shared_ptr<node> configuration_xml;                             /** [-] The configuration xml data. */
    std::vector<PropulsionType> engines{};                               /** [-] The engines to be designed. */
    std::unique_ptr<design::EngineDesigner> engine_designer;             /** [-] The engine designer. */
    std::unique_ptr<design::PropulsionIntegrator> propulsion_integrator; /** [-] The propulsion integrator. */
    std::unique_ptr<geometry::NacelleDesigner> nacelle_designer;         /** [-] The nacelle designer. */
    std::unique_ptr<geometry::PylonDesigner> pylon_designer;             /** [-] The pylon designer. */
    std::unique_ptr<mass::MassAnalyzer> mass_analyzer;                   /** [-] The mass analyzer. */
    geom2::Vector_3 reference_offset;                                    /** [m] The offset from the propulsion reference point to the aircraft origin. */
    report::Data report_data;                                            /** [-] The data for the report. */
    std::vector<int> swapped_order = {};
};

#endif // SRC_PROPULSION_DESIGN_H_
