/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

#ifndef SRC_MASS_MASS_ANALYSIS_H_
#define SRC_MASS_MASS_ANALYSIS_H_

/* === Includes === */
#include "../propulsion.h"
#include "../propulsion_strategy.h"
#include <memory>
#include <string>
#include <unordered_map>

namespace mass
{
    /* === Classes === */
    /** @class MassAnalyzer
     * @brief The base mass class for mass analysis
     */
    class MassAnalyzer : public PropulsionStrategy
    {
      public:
        /* === Constructors === */
        /**
         * @brief Construct a new Mass Analyzer object
         * @param configuration The module configuration provided by the user.
         */
        explicit MassAnalyzer(const std::shared_ptr<node> &configuration) : PropulsionStrategy(configuration)
        {
            /* Default technology factors */
            /**
             * @ref technology_factors_mass Technology Factors for Masses
             *
             * The available technology factors are:
             *
             * |Name|Description|
             * |---|---|
             * |`engine_mass`|The technology factor for the engine mass.|
             * |`nacelle_mass`|The technology factor for the nacelle mass.|
             * |`pylon_mass`|The technology factor for the pylon mass.|
             *
             */
            this->technology_factors["engine_mass"] = 1.0;
            this->technology_factors["nacelle_mass"] = 1.0;
            this->technology_factors["pylon_mass"] = 1.0;
        }

        /**
         * @brief Initialize the default mass analyzer.
         */
        void initialize() override
        {
            this->technology_factors["engine_mass"] = this->configuration()->at("/module_configuration_file/program_settings/technology_factors/engine_mass/value");
            this->technology_factors["nacelle_mass"] = this->configuration()->at("/module_configuration_file/program_settings/technology_factors/nacelle_mass/value");
            this->technology_factors["pylon_mass"] = this->configuration()->at("/module_configuration_file/program_settings/technology_factors/pylon_mass/value");
        }

        /* === Getters ===*/
        /**
         * @brief Get the technology factor of a specific component as defined in the settings.
         * @details See @ref technology_factors_mass for a list of available technology factors.
         * @throws std::out_of_range if the technology factor of the component
         * does not exist.
         *
         * @param name The name of the technology factor to get.
         * @return double The technology factor of the component as defined in the settings.
         */
        [[nodiscard]] auto technology_factor(const std::string &name) const -> double
        {
            return this->technology_factors.at(name);
        }

    private:
        std::unordered_map<std::string, double> technology_factors; /** [-] The technology factors of the components. */
    };
}; // namespace mass

#endif // SRC_MASS_MASS_ANALYSIS_H_
