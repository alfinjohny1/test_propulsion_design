/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

#ifndef SRC_MASS_DEFAULT_DEFAULT_MASS_H_
#define SRC_MASS_DEFAULT_DEFAULT_MASS_H_

/* === Includes === */
#include "../mass_analysis.h"
#include <memory>

namespace mass
{
/* === Classes === */
/**
 * @class Default
 * @brief The default engine mass analyzer.
 */
class Default: public MassAnalyzer
{
public:
    /* === Constructors === */
    /**
     * @brief Construct a new default mass analyzer object.
     * @param configuration The module configuration provided by the user.
     */
    explicit Default(const std::shared_ptr<node>& configuration): MassAnalyzer(configuration) {}

    /* === Methods === */
    /**
     * @brief Analyze the mass of a turbofan engine with kerosene as fuel.
     *
     * @param engine The engine to analyze the mass for.
     */
    template <EnergyCarrierFamily EC>
    void turbofan_method(Turbofan<EC>& engine);

    /* === Methods === */
    /**
     * @brief Analyze the mass of a openrotorfan engine with kerosene as fuel.
     *
     * @param engine The engine to analyze the mass for.
     */
    template <EnergyCarrierFamily EC>
    void openrotorfan_method(Openrotorfan<EC>& engine);

    void operator() (Openrotorfan<EnergyCarrierFamily::Kerosene>& engine);

    void operator() (Turbofan<EnergyCarrierFamily::Kerosene>& engine);

    void operator() (Turbofan<EnergyCarrierFamily::Liquid_Hydrogen> &engine);
};
}; // namespace mass

#endif // SRC_MASS_DEFAULT_DEFAULT_MASS_H_
