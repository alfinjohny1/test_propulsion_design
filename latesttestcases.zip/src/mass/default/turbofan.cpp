/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include "default_mass.h"
#include <aircraftGeometry2/processing/measure.h>
#include <aircraftGeometry2/processing/transform.h>

/* === Design implementations === */
namespace mass
{
/**
 * @brief Method to calculate the engine mass based on a regression line of the LTH-data.
 * @cite Pet13
 */
auto calculate_engine_mass(const double engine_technology_factor , const double thrust) -> double
{
    return engine_technology_factor * (0.0159 * thrust + 306.57);
}

/**
 * @brief Method to calculate the engine CG assuming a circular cylinder
 */
auto calculate_engine_CG(double length) -> Eigen::Vector3d
{
    /* Calculate local center of gravity position (local KOS @ circle center of fan/propeller) */
    double cg_x_local = 0.5 * length;
    Eigen::Vector3d engine_local_cg(cg_x_local, 0, 0);
    Eigen::Vector3d engine_cg = engine_local_cg;
    return engine_cg;
}

/**
 * @brief Method to calculate the engine inertia with respect to the center of gravity assuming a solid cylinder
 */
auto calculate_engine_inertia(double height, double width, double length, double mass) -> Eigen::Matrix3d
{
    Eigen::Matrix3d inertia_tensor = Eigen::Matrix3d::Zero();
    /* Assume average of height and width as engine diameter, respective radius */
    double engine_radius_average = (height + width)/ 4;
    inertia_tensor(0, 0) = mass / 2 * pow(engine_radius_average, 2); // in length (x) axis
    inertia_tensor(1, 1) = mass / 12 * (3 * pow(engine_radius_average, 2) + pow(length, 2)); // in y axis
    inertia_tensor(2, 2) = mass / 12 * (3 * pow(engine_radius_average, 2) + pow(length, 2)); // in z axis - assumed symmetrical
    return inertia_tensor;
}

/**
 * @brief Method to calculate the nacelle mass based on a regression line of the LTH-data.
 * @cite Pet13
 */
auto calculate_nacelle_mass(const double nacelle_technology_factor, const double thrust)-> double
{
    return nacelle_technology_factor * (thrust * 0.0039 + 595.42);
}

/**
 * @brief Method to calculate the nacelle CG with the aircraftGeometry2 lib
 */
auto calculate_nacelle_CG(const geom2::MultisectionSurface<geom2::PolygonSection> &nacelle_surface) -> Eigen::Vector3d
{
    /*
     * Get the CG in the engine LOCAL coordinate frame
     * => We always assume the CG to be in the LOCAL coordinate frame of the engine
     */
    geom2::Point_3 nacelle_geom2_cg_local = geom2::transform::to_parent(
        nacelle_surface,
        geom2::measure::centroid(nacelle_surface));

    /* Convert Point_3 in Vector3d */
    Eigen::Vector3d nacelle_cg;
    nacelle_cg << nacelle_geom2_cg_local.x(), nacelle_geom2_cg_local.y(), nacelle_geom2_cg_local.z();
    return nacelle_cg;
}

/**
 * @brief Method to calculate the nacelle inertia with respect to the center of gravity with the aircraftGeometry2 lib
 */
auto calculate_nacelle_inertia(const geom2::MultisectionSurface<geom2::PolygonSection> &nacelle_surface) -> Eigen::Matrix3d
{
    /* Use geom2 lib to calculate the inertia tensor */
    CGAL::Eigen_matrix inertia_tensor_cgal = geom2::measure::inertia(nacelle_surface);
    /* Convert CGAL Eigen_matrix to Eigen Matrix3d */
    Eigen::Matrix3d inertia_tensor = inertia_tensor_cgal.eigen_object();
    return inertia_tensor;
}

/**
 * @brief Method to calculate the pylon mass based on a regression line of the LTH-data.
 * @cite Pet13
 */
auto calculate_pylon_mass(const double pylon_technology_factor, const double thrust)-> double
{
    return pylon_technology_factor  * (thrust * 0.0024 + 233.29);
}

/**
 * @brief Method to calculate the pylon CG with the aircraftGeometry2 lib
 * @return Eigen::Vector3d The center of gravity of the pylon in the engine LOCAL coordinate system.
 */
auto calculate_pylon_CG(const geom2::MultisectionSurface<geom2::AirfoilSection> & pylon_surface)-> Eigen::Vector3d
{
    /* Calculate centroid with aircraft geometry lib */
    geom2::Point_3 pylon_geom2_cg_local = geom2::transform::to_parent(
        pylon_surface,
        geom2::measure::centroid(pylon_surface));

    /* Convert Point_3 in Vector3d */
    Eigen::Vector3d pylon_cg;
    pylon_cg << pylon_geom2_cg_local.x(), pylon_geom2_cg_local.y(), pylon_geom2_cg_local.z();
    return pylon_cg;
}

/**
 * @brief Method to calculate the pylon inertia with respect to the center of gravity with the aircraftGeometry2 lib
 */
auto calculate_pylon_inertia(const geom2::MultisectionSurface<geom2::AirfoilSection> &pylon_surface) -> Eigen::Matrix3d
{
    /* Use geom2 lib to calculate the inertia tensor */
    CGAL::Eigen_matrix inertia_tensor_cgal = geom2::measure::inertia(pylon_surface);
    /* Convert CGAL Eigen_matrix to Eigen Matrix3d */
    Eigen::Matrix3d inertia_tensor = inertia_tensor_cgal.eigen_object();
    return inertia_tensor;
}

template <EnergyCarrierFamily EC>
void Default::turbofan_method(Turbofan<EC>& engine)
{
    const double thrust = engine.required_thrust();
    Dimension_3 dimension_engine = engine.dimension();

    /* Mass, CG and inertia of engine (mass only if not calculated already) */
    Eigen::Vector3d CG_engine = calculate_engine_CG(dimension_engine.length);
    double mass_engine = engine.pointmass(Component::Engine).mass;
    if (mass_engine == 0.0)
    {
        /* Calculate engine mass with massAnalyzer function */
        const double tf_engine = this->technology_factor("engine_mass");
        mass_engine = calculate_engine_mass(tf_engine, thrust);
    }
    Eigen::Matrix3d inertia_engine = calculate_engine_inertia(dimension_engine.height,
                        dimension_engine.width, dimension_engine.length, mass_engine);
    engine.set_pointmass(Component::Engine, {CG_engine, inertia_engine, mass_engine});


    /* Mass, CG and inertia  of nacelle */
    const double tf_nacelle = this->technology_factor("nacelle_mass");
    double mass_nacelle = calculate_nacelle_mass(tf_nacelle, thrust);
    Eigen::Vector3d CG_nacelle = calculate_nacelle_CG(engine.nacelle());
    Eigen::Matrix3d inertia_nacelle = calculate_nacelle_inertia(engine.nacelle());
    engine.set_pointmass(Component::Nacelle, {CG_nacelle, inertia_nacelle, mass_nacelle});

    /* Mass, CG and inertia  of pylon (if geometry not empty)*/
    if (!engine.pylon().sections.empty())
    {
        const double tf_pylon = this->technology_factor("pylon_mass");
        double mass_pylon = calculate_pylon_mass(tf_pylon, thrust);
        Eigen::Vector3d CG_pylon = calculate_pylon_CG(engine.pylon());
        Eigen::Matrix3d inertia_pylon = calculate_pylon_inertia(engine.pylon());
        engine.set_pointmass(Component::Pylon, {CG_pylon, inertia_pylon, mass_pylon});
    }

}

void Default::operator()(Turbofan<EnergyCarrierFamily::Kerosene>& engine)
{
    turbofan_method(engine);
}

void Default::operator()(Turbofan<EnergyCarrierFamily::Liquid_Hydrogen>& engine)
{
    turbofan_method(engine);
}

} //namespace mass
