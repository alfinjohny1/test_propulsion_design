/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

#ifndef SRC_MASS_POINT_MASS_H_
#define SRC_MASS_POINT_MASS_H_

/* === Includes === */
#include <Eigen/Dense>

/**
 * @struct PointMass
 * @brief Represents the mass properties of a component as a point mass.
 *
 */
struct PointMass
{
    Eigen::Vector3d CG = Eigen::Vector3d::Zero();      /** [m] The center of gravity of the object. This should be in the engine LOCAL coordinate frame! */
    Eigen::Matrix3d inertia = Eigen::Matrix3d::Zero(); /** [kgm^2] The inertia of the object. */
    double mass{0.0};                                  /** [kg] The mass of the object. */
};

/**
 * @brief Operator to add two point masses together.
 * This adds the masses and calculates the new
 * center of gravity and inertia. The inertia
 * is calculated with the Steiner theorem.
 * @note The call signature is that way so
 * that algorithms can find/use the operator.
 *
 * @param lhs The left hand side point mass.
 * @param rhs The right hand side point mass.
 * @return PointMass The resulting point mass.
 */
auto operator+(PointMass lhs, const PointMass &rhs) -> PointMass;

#endif // SRC_MASS_POINT_MASS_H_
