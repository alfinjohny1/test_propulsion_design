/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include "point_mass.h"
#include <cmath>

/* === Functions === */
auto operator+(PointMass lhs, const PointMass &rhs) -> PointMass
{
    /* Initialize result */
    PointMass result;

    /* Calculate CG and mass of the result */
    result.mass = lhs.mass + rhs.mass;
    result.CG = (lhs.mass * lhs.CG + rhs.mass * rhs.CG) / result.mass;

    /* Calculate inertia of all components together */
    result.inertia = lhs.inertia;
    /* Calculate the additional inertia with the Steiner theorem */
    Eigen::Vector3d r = lhs.CG - result.CG;
    result.inertia(0, 0) += lhs.mass * (std::pow(r.y(), 2) + std::pow(r.z(), 2));
    result.inertia(1, 1) += lhs.mass * (std::pow(r.x(), 2) + std::pow(r.z(), 2));
    result.inertia(2, 2) += lhs.mass * (std::pow(r.x(), 2) + std::pow(r.y(), 2));
    result.inertia(0, 1) = result.inertia(1, 0) += lhs.mass * r.x() * r.y();
    result.inertia(0, 2) = result.inertia(2, 0) += lhs.mass * r.x() * r.z();
    result.inertia(1, 2) = result.inertia(2, 1) += lhs.mass * r.y() * r.z();

    /* Sum inertia without Steiner */
    result.inertia += rhs.inertia;
    /* Calculate the additional inertia with the Steiner theorem */
    r = rhs.CG - result.CG;
    result.inertia(0, 0) += rhs.mass * (std::pow(r.y(), 2) + std::pow(r.z(), 2));
    result.inertia(1, 1) += rhs.mass * (std::pow(r.x(), 2) + std::pow(r.z(), 2));
    result.inertia(2, 2) += rhs.mass * (std::pow(r.x(), 2) + std::pow(r.y(), 2));
    result.inertia(0, 1) = result.inertia(1, 0) += rhs.mass * r.x() * r.y();
    result.inertia(0, 2) = result.inertia(2, 0) += rhs.mass * r.x() * r.z();
    result.inertia(1, 2) = result.inertia(2, 1) += rhs.mass * r.y() * r.z();

    /* Return the resulting point mass */
    return result;
}
