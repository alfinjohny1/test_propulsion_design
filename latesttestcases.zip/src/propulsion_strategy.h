/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */
#ifndef SRC_PROPULSION_STRATEGY_H_
#define SRC_PROPULSION_STRATEGY_H_

/* === Includes === */
#include <memory>
#include <moduleBasics/strategySelector.h>
#include <aixml/node.h>
#include "propulsion.h"

/* === Classes === */
/**
 * @class PropulsionStrategy
 * @brief The specialization of the strategy class for the propulsionDesign tool.
 */
class PropulsionStrategy : public Strategy
{
  public:
    /* === Constructors === */
    /**
     * @brief Construct a new PropulsionStrategy instance.
     * @param settings The module settings provided by the user.
     */
    explicit PropulsionStrategy(const std::shared_ptr<node> &configuration) : configuration_(configuration) {}

    /**
     * @brief Destroy the PropulsionStrategy instance.
     */
    ~PropulsionStrategy() override = default;

    /* === Populate the strategy template methods === */
    void initialize() override{};
    void run() override{};
    void update() override{};
    void report() override{};
    void save() override{};

    /* === Define the strategy specialization methods === */
    virtual void operator()(Turbofan<EnergyCarrierFamily::Kerosene> &engine) // NOLINT runtime/reference
    {
        throw std::invalid_argument("The strategy does not yet implement a kerosene turbofan engine.");
    };
    virtual void operator()(Turbofan<EnergyCarrierFamily::Liquid_Hydrogen> &engine) // NOLINT runtime/reference
    {
        throw std::invalid_argument("The strategy does not yet implement a liquid hydrogen turbofan engine.");
    };
    virtual void operator()(Turboprop<EnergyCarrierFamily::Kerosene> &engine) // NOLINT runtime/reference
    {
        throw std::invalid_argument("The strategy does not yet implement a kerosene turboprop engine.");
    };
    virtual void operator()(Turboprop<EnergyCarrierFamily::Liquid_Hydrogen> &engine) // NOLINT runtime/reference
    {
        throw std::invalid_argument("The strategy does not yet implement a liquid hydrogen turboprop engine.");
    };
    virtual void operator()(Openrotorfan<EnergyCarrierFamily::Kerosene> &engine) // NOLINT runtime/reference
    {
        throw std::invalid_argument("The strategy does not yet implement a kerosene openrotorfan engine.");
    };

    /* === Methods === */
    /**
     * @brief Get the configuration of the module.
     *
     * @return std::shared_ptr<node> The configuration of the module.
     */
    [[nodiscard]] auto configuration() const -> const std::shared_ptr<node> { return configuration_; }

  private:
    /* === Properties ===*/
    std::shared_ptr<node> configuration_; /** The configuration of the module. */
};

#endif // SRC_PROPULSION_STRATEGY_H_
