/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include "default_nacelle.h"
#include <algorithm>
#include <aircraftGeometry2/geometry/builder.h>

/* === Design implementations === */
namespace geometry
{
    namespace nacelle
    {
        template <EnergyCarrierFamily EC>
        void Default::turbofan_method(Turbofan<EC> &engine)
        {
            /* Initialize the surface and its builder */
            geom2::MultisectionSurface<geom2::PolygonSection> surface{};
            geom2::MultisectionSurface<geom2::PolygonSection> surface_engine{};
            geom2::SectionBuilder<geom2::PolygonSection> builder{};
            geom2::SectionBuilder<geom2::PolygonSection> builder_engine{};

            /* Get the maximum diameter the nacelle has to fit */
            const double diameter_inner = std::max(
                { engine.dimension().width, engine.dimension().height, engine.fan().diameter });

            /* Create the cross section shape */
            geom2::PolygonSection shape = this->get_section_shape(engine.id());
            shape.set_width(diameter_inner);
            shape.set_height(diameter_inner);

            /* Create the cross section shape */
            geom2::PolygonSection shape_engine = this->get_section_shape(engine.id());
            shape_engine.set_width(diameter_inner);
            shape_engine.set_height(diameter_inner);

            /* 
             * Transform the scaled polygon coordinates to
             * absolute values, so that the section can be
             * scaled using the scale factor.
             */
            shape.set_contour(shape.get_contour(true));
            shape_engine.set_contour(shape_engine.get_contour(true));

            /* Section 0 */
            shape_engine.set_scale(0.0);
            builder_engine.insert_back(shape_engine, {0.0, 0.0, - engine.dimension().length * 0.1});

            /* Section 0 */
            shape_engine.set_scale(0.15);
            builder_engine.insert_back(shape_engine, {0.0, 0.0, engine.dimension().length * 0.1});

            /* Section 0 */
            shape.set_scale(1.0);
            builder.insert_back(shape, {0.0, 0.0, 0.0});

            /* Section 1 */
            shape.set_scale(1.21); // \cite Ata10 p. 45
            builder.insert_back(shape, {0.0, 0.0, engine.dimension().length * 0.25});

            /* Section 2 */
            shape.set_scale(1.21); // \cite Ata10 p. 45
            builder.insert_back(shape, {0.0, 0.0, engine.dimension().length * 0.50});

            /* Section 3 */
            shape.set_scale(1.0);
            builder.insert_back(shape, {0.0, 0.0, engine.dimension().length * 0.25});

            /* Build the surface and insert it into the engine */
            surface.name = "nacelle_" + std::to_string(engine.id());
            surface.normal = {1.0, 0.0, 0.0}; // Orient the nacelle along the global X direction
            surface.sections = builder.get_result();
            engine.set_nacelle(surface);

            surface_engine.name = "engine_" + std::to_string(engine.id());
            surface_engine.normal = {1.0, 0.0, 0.0}; // Orient the nacelle along the global X direction
            surface_engine.sections = builder_engine.get_result();
            engine.set_enginegeometry(surface_engine);
            
        }

        void Default::operator()(Turbofan<EnergyCarrierFamily::Kerosene>& engine) 
        {
            turbofan_method(engine);
        };

        // void Default::operator()(Openrotorfan<EnergyCarrierFamily::Kerosene>& engine) 
        // {
        //     openrotor_method(engine);
        // };

        void Default::operator()(Turbofan<EnergyCarrierFamily::Liquid_Hydrogen>& engine)
        {
            turbofan_method(engine);
        };

    } // namespace nacelle
} // namespace geometry
