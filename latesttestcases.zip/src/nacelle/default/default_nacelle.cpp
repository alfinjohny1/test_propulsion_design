/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include "default_nacelle.h"
#include <algorithm>
#include <aircraftGeometry2/geometry/builder.h>
#include <aircraftGeometry2/io/dat.h>

/* === Design implementations === */
namespace geometry
{
    namespace nacelle
    {
        void Default::initialize()
        {
            /* Loop through all propulsion settings */
            for (const auto &propulsion : this->configuration()->getVector("module_configuration_file/program_settings/propulsion"))
            {
                /* Read the configuration parameters */
                std::string id = propulsion->getStringAttrib("ID");
                std::string nacelle_shape(propulsion->at("nacelle/profile/value"));

                /* Transform all strings to lower case */
                std::transform(id.begin(), id.end(), id.begin(), ::tolower);
                std::transform(nacelle_shape.begin(), nacelle_shape.end(), nacelle_shape.begin(), ::tolower);

                /* Set the default or custom settings */
                if (id == "default")
                {
                    /* Set the default engine settings */
                    this->section_shapes[-1] = nacelle_shape;
                } else {
                    /* Set the specific engine settings */
                    const int engine_id = std::stoi(id);
                    this->section_shapes[engine_id] = nacelle_shape;
                }
            }
        }

        auto Default::get_section_shape(const int engine_id) const -> geom2::PolygonSection
        {
            /* Read what the user specified for this engine */
            const std::string_view shape_name = this->section_shapes.contains(engine_id)
                                                    ? this->section_shapes.at(engine_id)
                                                    : this->section_shapes.at(-1);

            /* Check whether the shape is a circle or ellipse */
            geom2::PolygonSection shape{};
            if ( shape_name == "circle" || shape_name == "ellipse" )
            {
                /* Create a unity circle */
                shape = geom2::build::ellipse(1.0, 1.0);
                shape.name = shape_name;
            } else if (shape_name.ends_with(".dat")) {
                /* Read the shape from a file if file exists */
                if (std::filesystem::exists(this->geometry_directory() / shape_name))
                {
                    try
                    {
                        shape.set_contour(geom2::io::read_dat_file(this->geometry_directory() / shape_name));
                    }
                    catch (const std::exception &e)
                    {
                        std::cerr << "error while reading the: " << e.what() << '\n';
                        throw; 
                    }
                }
                else
                {
                    // If file does not exist, create it.
                    try
                    {
                        // Construct the file path and convert to absolute path
                        std::filesystem::path filePath = std::filesystem::absolute(this->geometry_directory() / shape_name);
                        // Ensure the directory exists
                        if (!std::filesystem::exists(filePath.parent_path()))
                        {
                            std::filesystem::create_directories(filePath.parent_path());
                        }   

                        std::cout << "File does not exist, create new file: " << this->geometry_directory() / shape_name << '\n';
                        std::ofstream file(this->geometry_directory() / shape_name);
                        if (!file.is_open())
                        {
                            throw std::runtime_error("Error while creating the file for nacelle.");
                        }

                        // nacelle.dat
                        file << "# Circular data\n\n";
                        file << "0.50000   0.00000\n";
                        file << "0.49384   0.07822\n";
                        file << "0.47553   0.15451\n";
                        file << "0.44550   0.22700\n";
                        file << "0.40451   0.29389\n";
                        file << "0.35355   0.35355\n";
                        file << "0.29389   0.40451\n";
                        file << "0.22700   0.44550\n";
                        file << "0.15451   0.47553\n";
                        file << "0.07822   0.49384\n";
                        file << "0.00000   0.50000\n";
                        file << "-0.07822  0.49384\n";
                        file << "-0.15451  0.47553\n";
                        file << "-0.22700  0.44550\n";
                        file << "-0.29389  0.40451\n";
                        file << "-0.35355  0.35355\n";
                        file << "-0.40451  0.29389\n";
                        file << "-0.44550  0.22700\n";
                        file << "-0.47553  0.15451\n";
                        file << "-0.49384  0.07822\n";
                        file << "-0.50000  0.00000\n";
                        file << "-0.49384  -0.07822\n";
                        file << "-0.47553  -0.15451\n";
                        file << "-0.44550  -0.22700\n";
                        file << "-0.40451  -0.29389\n";
                        file << "-0.35355  -0.35355\n";
                        file << "-0.29389  -0.40451\n";
                        file << "-0.22700  -0.44550\n";
                        file << "-0.15451  -0.47553\n";
                        file << "-0.07822  -0.49384\n";
                        file << "-0.00000  -0.50000\n";
                        file << "0.07822   -0.49384\n";
                        file << "0.15451   -0.47553\n";
                        file << "0.22700   -0.44550\n";
                        file << "0.29389   -0.40451\n";
                        file << "0.35355   -0.35355\n";
                        file << "0.40451   -0.29389\n";
                        file << "0.44550   -0.22700\n";
                        file << "0.47553   -0.15451\n";
                        file << "0.49384   -0.07822\n";
                        // file << "0.50000   -0.00000\n";

                        file.close();

                        // Create the geometry based on the new file
                        shape.set_contour(geom2::io::read_dat_file(this->geometry_directory() / shape_name));
                    }
                    catch (const std::exception &e)
                    {
                        std::cerr << "Error while creating the file: " << e.what() << '\n';
                        throw; 
                    }
                }

                /* Remove the dat part of the name */
                shape.name = shape_name.substr(0, shape_name.size() - 4);
            } else {
                /* Throw an error if the shape is not supported */
                throw std::invalid_argument("[geometry::nacelle::Default] The nacelle shape '" + std::string(shape_name) +
                                            "' is not supported.");
            }
            return shape;
        }
    } // namespace nacelle
} // namespace geometry
