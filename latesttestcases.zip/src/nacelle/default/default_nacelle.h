/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

#ifndef SRC_NACELLE_DEFAULT_DEFAULT_NACELLE_H_
#define SRC_NACELLE_DEFAULT_DEFAULT_NACELLE_H_

/* === Includes === */
#include "../nacelle_design.h"
#include <memory>
#include <string>
#include <unordered_map>

namespace geometry
{
    namespace nacelle
    {
        /* === Classes === */
        /**
         * @class Default
         * @brief The default nacelle geometry designer.
         */
        class Default : public NacelleDesigner
        {
          public:
            /* === Constructors === */
            /**
             * @brief Construct a new default nacelle geometry designer.
             * @param configuration The module settings provided by the user.
             * @param geometry_directory The directory where the geometry files are stored.
             */
            Default(const std::shared_ptr<node> &configuration, std::filesystem::path geometry_directory)
                : NacelleDesigner(configuration, geometry_directory) {}

            /**
             * @brief Initialize the default nacelle geometry designer.
             */
            void initialize() final;

            /* === Methods === */
            /**
             * @brief Design the geometry of a turbofan nacelle
             * with kerosene as fuel.
             *
             * @param engine The engine to design the geometry for.
             */
            void operator()(Turbofan<EnergyCarrierFamily::Kerosene> &engine);
            void operator()(Turbofan<EnergyCarrierFamily::Liquid_Hydrogen>& engine);
            void operator()(Openrotorfan<EnergyCarrierFamily::Kerosene> &engine);

            template <EnergyCarrierFamily EC>
            void turbofan_method(Turbofan<EC>& engine);

            /* === Methods === */
            /**
             * @brief Design the geometry of a turbofan nacelle
             * with kerosene as fuel.
             *
             * @param engine The engine to design the geometry for.
             */

            template <EnergyCarrierFamily EC>
            void openrotor_method(Openrotorfan<EC>& engine);

          private:
            /* === Methods === */
            /**
             * @brief Create the section shape as defined in the user settings.
             * @note The shape is usually normalized and has to be scaled to
             * fit the engine.
             * @throws std::invalid_argument If the section shape is not supported.
             *
             * @param engine_id The id of the engine to create the section shape for.
             * @return geom2::PolygonSection The created section shape.
             */
            [[nodiscard]] auto get_section_shape(const int engine_id) const -> geom2::PolygonSection;

            /* === Properties === */
            std::unordered_map<int, std::string> section_shapes; /** [-] The section shapes of the nacelle. */
        };
    }; // namespace nacelle
};     // namespace geometry

#endif // SRC_NACELLE_DEFAULT_DEFAULT_NACELLE_H_
