/* === Includes === */
#include "default_nacelle.h"
#include <algorithm>
#include <aircraftGeometry2/geometry/builder.h>

/* === Design implementations === */
namespace geometry
{
    namespace nacelle
    {
    template <EnergyCarrierFamily EC>
        void Default::openrotor_method(Openrotorfan<EC> &engine)
        {
            /* Initialize the surface and its builder */
            geom2::MultisectionSurface<geom2::PolygonSection> surface_test{};
            geom2::MultisectionSurface<geom2::PolygonSection> surface_engine{};
            geom2::SectionBuilder<geom2::PolygonSection> builder_test{};
            geom2::SectionBuilder<geom2::PolygonSection> builder_engine{};

            /* Get the maximum diameter the nacelle has to fit */
            const double diameter_inner = std::max(
                {engine.dimension().width, engine.dimension().height, engine.fan().diameter});

            /* Create the cross section shape */
            geom2::PolygonSection shape_test = this->get_section_shape(engine.id());
            shape_test.set_width(diameter_inner);
            shape_test.set_height(diameter_inner);

            /* Create the cross section shape */
            geom2::PolygonSection shape_engine = this->get_section_shape(engine.id());
            shape_engine.set_width(diameter_inner);
            shape_engine.set_height(diameter_inner);

            /* 
                * Transform the scaled polygon coordinates to
                * absolute values, so that the section can be
                * scaled using the scale factor.
                */
            shape_test.set_contour(shape_test.get_contour(true));
            shape_engine.set_contour(shape_engine.get_contour(true));

            /* Section 0 */
            shape_engine.set_scale(0.3);
            builder_engine.insert_back(shape_engine, {0.0, 0.0, 0.0});
            
            shape_test.set_scale(0.001);
            builder_test.insert_back(shape_test, {0.0, 0.0, 0});

            shape_test.set_scale(0.3);
            builder_test.insert_back(shape_test, {0.0, 0.0, engine.dimension().length * 0.01});

            shape_test.set_scale(0.4);
            builder_test.insert_back(shape_test, {0.0, 0.0, engine.dimension().length * 0.3});

            shape_test.set_scale(0.4);
            builder_test.insert_back(shape_test, {0.0, 0.0, engine.dimension().length * 0.3});

            shape_test.set_scale(1.0);
            builder_test.insert_back(shape_test, {0.0, 0.0, 0.0});

            shape_test.set_scale(1.0);
            builder_test.insert_back(shape_test, {0.0, 0.0, engine.dimension().length * 0.01});

            shape_test.set_scale(0.4);
            builder_test.insert_back(shape_test, {0.0, 0.0, engine.dimension().length * 0.0});

            shape_test.set_scale(0.4);
            builder_test.insert_back(shape_test, {0.0, 0.0, engine.dimension().length * 0.15});

            shape_test.set_scale(1.0);
            builder_test.insert_back(shape_test, {0.0, 0.0, 0.0});

            shape_test.set_scale(1.0);
            builder_test.insert_back(shape_test, {0.0, 0.0, engine.dimension().length * 0.01});

            shape_test.set_scale(0.3);
            builder_test.insert_back(shape_test, {0.0, 0.0, engine.dimension().length * 0.0});

            shape_test.set_scale(0.2);
            builder_test.insert_back(shape_test, {0.0, 0.0, engine.dimension().length * 0.1});

            /* Build the surface and insert it into the engine */
            surface_test.name = "nacelle_" + std::to_string(engine.id());
            surface_test.normal = {1.0, 0.0, 0.0}; // Orient the nacelle along the global X direction
            surface_test.sections = builder_test.get_result();
            engine.set_nacelle(surface_test);

            surface_engine.name = "engine_" + std::to_string(engine.id());
            surface_engine.normal = {1.0, 0.0, 0.0}; // Orient the nacelle along the global X direction
            surface_engine.sections = builder_engine.get_result();
            engine.set_enginegeometry(surface_engine);
            
        }

    void Default::operator()(Openrotorfan<EnergyCarrierFamily::Kerosene>& engine) 
    {
        openrotor_method(engine);
    };

    }
}