/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include "rubber_design.h"
#include <cmath>
#include <format>
#include "../../utility.h"
#include "../../io/engine_xml.h"

/* === Design implementations === */
namespace design
{
    void Rubber::operator()(Turbofan<EnergyCarrierFamily::Kerosene> &engine)
    {
        /* Check whether the engine model is preselected */
        auto model_preselected = this->preselected_engine(engine.id());
        if (model_preselected.has_value())
        {
            engine.set_model(*model_preselected);
        }
        else
        {
            /** @todo Should this selection always take place or should we stick to the selection
             * in the following iteration loops even if there is a better fitting engine now?
             */
            engine.set_model(this->select_engine(engine.required_thrust()));
        }

        /* Get the engine data from the project or database directory */
        EngineData engine_data =
            io::load_engine_data(engine.model(),
                                {this->engine_directory(), this->engine_database()});



        /* Scale the engine */

        /* Load the unscaled engine */
        auto engine_unscaled = io::load_engine_scaled(
            engine.model(),
            1,
            {this->engine_directory(),
             this->engine_database()});

        /* Get the unscaled SLST value from the deck values as the highest N1 at SLS */
        engine_unscaled.calculate_N1_with_penalties(0 , 0, this->flight_condition().ambiance, 1.0, "takeoff", 0, 0);

        /* Scale the engine */
        engine.set_scale(
            engine.required_thrust() > 0.0 ? engine.required_thrust() / engine_unscaled.get_thrust() : 1.0); // engine_unscaled.get_thrust()

        /* Set and sale the parameters according to Ray12 p. 285 */
        engine.set_dimension({engine_data.dimensions().height * std::pow(engine.scale(), 0.5),
                              engine_data.dimensions().width * std::pow(engine.scale(), 0.5),
                              engine_data.dimensions().length * std::pow(engine.scale(), 0.4)});
        engine.set_fan({engine_data.dimensions().diameter * std::pow(engine.scale(), 0.5)});

        /* Set the engine mass */
        PointMass engine_mass;
        engine_mass.mass = std::pow(engine.scale(), 1.1) * engine_data.dry_mass(); // Ray12 p. 285
        engine_mass.mass *= this->technology_factor("engine_mass"); // Apply the technology factor
        engine.set_pointmass(Component::Engine, engine_mass);

        /* Set the bucket point of the engine */
        engine.set_bucket_point(
            this->calculate_bucket_point(engine)
        );

        /* At this point the engine was successfully sized */
        this->add_designed_engine(engine.model());

        /* Print information */
        utility::print(std::format(
            "Designed engine: {} with thrust = {:6.2f} kN, mass = {:5.1f} kg, scale = {:1.2f}",
            engine.model(), engine.required_thrust() / 1000, engine_mass.mass, engine.scale()), Level::Out);
    }

    void Rubber::operator()(Turbofan<EnergyCarrierFamily::Liquid_Hydrogen> &engine)
    {
        /* Check whether the engine model is preselected */
        auto model_preselected = this->preselected_engine(engine.id());
        if (model_preselected.has_value())
        {
            engine.set_model(*model_preselected);
        }
        else
        {
            /** @todo Should this selection always take place or should we stick to the selection
             * in the following iteration loops even if there is a better fitting engine now?
             */
            engine.set_model(this->select_engine(engine.required_thrust()));
        }

        /* Get the engine data from the project or database directory */
        const EngineData engine_data =
            io::load_engine_data(engine.model(),
                { this->engine_directory(), this->engine_database() });
        /* Check if the selected type is also given in the config */
        std::cout << engine_data.type() << std::endl;
        if (engine_data.type() != "turbofan")
            {
                utility::print(std::format(
                "The engine chosen in the config file is not the correct type (turbofan)"), Level::Error);
            }

        /* Scale the engine */

        /* Load the unscaled engine */
        auto engine_unscaled = io::load_engine_scaled(
            engine.model(),
            1,
            { this->engine_directory(),
             this->engine_database() });

        /* Get the unscaled SLST value from the deck values as the highest N1 at SLS */
        engine_unscaled.calculate_N1_with_penalties(0, 0, this->flight_condition().ambiance, 1.0, "takeoff", 0, 0);

        /* Scale the engine */
        engine.set_scale(
            engine.required_thrust() > 0.0 ? engine.required_thrust() / engine_unscaled.get_thrust() : 1.0); // engine_unscaled.get_thrust()

        /* Set and sale the parameters according to Ray12 p. 285 */
        engine.set_dimension({ engine_data.dimensions().height * std::pow(engine.scale(), 0.5),
                              engine_data.dimensions().width * std::pow(engine.scale(), 0.5),
                              engine_data.dimensions().length * std::pow(engine.scale(), 0.4) });
        engine.set_fan({ engine_data.dimensions().diameter * std::pow(engine.scale(), 0.5) });

        /* Set the engine mass */
        PointMass engine_mass;
        engine_mass.mass = std::pow(engine.scale(), 1.1) * engine_data.dry_mass(); // Ray12 p. 285
        engine_mass.mass *= this->technology_factor("engine_mass"); // Apply the technology factor
        engine.set_pointmass(Component::Engine, engine_mass);

        /* Set the bucket point of the engine */
        engine.set_bucket_point(
            this->calculate_bucket_point(engine)
        );

        /* At this point the engine was successfully sized */
        this->add_designed_engine(engine.model());

        /* Print debug information */
        utility::print(std::format(
            "Designed engine: {} with thrust = {:6.2f} kN, mass = {:5.1f} kg, scale = {:1.2f}",
            engine.model(), engine.required_thrust() / 1000, engine_mass.mass, engine.scale()), Level::Info);
    }

} // namespace design
