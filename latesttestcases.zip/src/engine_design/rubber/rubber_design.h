/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

#ifndef SRC_ENGINE_DESIGN_RUBBER_RUBBER_DESIGN_H_
#define SRC_ENGINE_DESIGN_RUBBER_RUBBER_DESIGN_H_

/* === Includes === */
#include "../engine_design.h"
#include <filesystem>
#include <memory>
#include <optional>
#include <unordered_map>
#include <unordered_set>
#include <string>
#include <string_view>

namespace design
{
    /* === Classes === */
    /**
     * @class Rubber
     * @brief The rubber engine designer
     */
    class Rubber : public EngineDesigner
    {
      public:
        /* === Constructors === */
        /**
         * @brief Construct a new rubber engine designer.
         * @param configuration The module configuration provided by the user.
         * @param engine_directory The directory where the engine results are stored.
         * @param design_condition The design flight condition of the aircraft.
         */
        explicit Rubber(
            const std::shared_ptr<node> &configuration,
            const std::filesystem::path &engine_directory,
            const FlightCondition &design_condition)
            : EngineDesigner(configuration, engine_directory, design_condition) {}

        /* === Methods === */
        /**
         * @brief Finalize the initialization of the engine designer.
         */
        void initialize() final;

        /**
         * @brief Finalize the saving of the engine results.
         */
        void save() final;

        /**
         * @brief Design a turbofan engine with kerosene as fuel.
         * @note The engine WILL be modified!
         *
         * @param engine The engine to design.
         */
        void operator()(Turbofan<EnergyCarrierFamily::Kerosene> &engine); // NOLINT runtime/references

        void operator()(Turbofan<EnergyCarrierFamily::Liquid_Hydrogen> &engine); // NOLINT runtime/references

        void operator()(Openrotorfan<EnergyCarrierFamily::Kerosene> &engine); // NOLINT runtime/references

    private:
        /* === Methods === */
        /**
         * @brief Calculate the bucket point of the engine.
         * The design flight condition and the current engine offtakes
         * are taken as the boundary conditions for the bucket point.
         *
         * @tparam carrier The energy carrier of the engine.
         * @param engine The engine to calculate the bucket point for.
         * @return BucketPoint [N, (kg/s)/N] The bucket point (thrust, tsfc) of the engine
         * at the current operating conditions.
         */
        template <EnergyCarrierFamily carrier>
        [[nodiscard]] auto calculate_bucket_point(const Propulsion<carrier> &engine) const -> BucketPoint;

        /**
         * @brief Get the preselected engine for the given engine id.
         * When the specific id does not have a preselected engine,
         * the default preselected engine is returned. If there is no
         * default preselected engine, an empty optional is returned.
         *
         * @param engine_id The id of the engine.
         * @return std::optional<std::string_view> The preselected engine if available.
         */
        [[nodiscard]] auto preselected_engine(int engine_id) -> std::optional<std::string_view>;

        /**
         * @brief Selects the engine with the thrust closest to the required thrust.
         * It searches the database directory for the engine with the thrust closest
         * to the required thrust.
         *
         * @param thrust_required [N] The required thrust.
         * @return std::string The name of the selected engine.
         * @throws std::runtime_error if no engine is found in the database.
         */
        [[nodiscard]] auto select_engine(const double thrust_required) const -> std::string;

        /* === Properties === */
        std::unordered_map<int, std::string> preselected_engines_; /**< The manual selected engines. */
    };
}; // namespace design

#endif // SRC_ENGINE_DESIGN_RUBBER_RUBBER_DESIGN_H_
