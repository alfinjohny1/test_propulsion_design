/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include "rubber_design.h"
#include <algorithm>
#include <filesystem>
#include <format>
#include <list>
#include <ranges>
#include "../../io/engine_xml.h"
#include "../../utility.h"

/* === Design implementations === */
namespace design
{
    void Rubber::initialize()
    {
        /* Initialize the EngineDesigner */
        EngineDesigner::initialize();

        /* Loop through all propulsion settings */
        for (const auto &propulsion : this->configuration()->getVector("module_configuration_file/program_settings/propulsion"))
        {
            /* Get the preselected engine */
            node *engine_model = propulsion->find("engine/Rubber/engine_model/value");

            /* Check whether the engine is preselected */
            if (engine_model != nullptr)
            {
                /* Get the engine id */
                const std::string id = propulsion->getStringAttrib("ID");
                const int engine_id = id == "Default" ? -1 : std::stoi(id);

                /* Get the engine model */
                const std::string model(*engine_model);

                /* Store the preselected engine */
                this->preselected_engines_[engine_id] = model;

                if (std::filesystem::exists(this->engine_directory() / model))
                    {
                        EngineData engine_data = io::load_engine_data(model, {this->engine_directory()});
                        const auto efficiency_factor = static_cast<float>(
                        this->configuration()->at(
                            "module_configuration_file/program_settings/technology_factors/engine_efficiency/value"));
                        std::filesystem::path path_to_csv = EngineDesigner::engine_directory(); 
                        std::string engine_name = this->configuration()->at("module_configuration_file/program_settings/propulsion/engine/Rubber/engine_model/value");
                        std::string added_path = (std::filesystem::path(path_to_csv) / engine_name / engine_name).string();
                        DeckData deck_data = DeckData::from_csv(added_path.append("_WF.csv"));
                                    /* Check in engine dataset in engine xml if a engine_efficiency_factor was already applied */
                        double engine_xml_efficiency_factor = engine_data.engine_efficiency_factor();

                        /* Compare to technology_factor for engine efficiency in config file */
                        if (std::abs(engine_xml_efficiency_factor - efficiency_factor) > 1e-6)
                        {
                            
                            utility::print(std::format("Warning: The engine efficiency factor in the engine XML ({:.3f}) differs from the technology factor in the configuration file ({:.3f}). The engine dataset will be adjusted to the configuration file efficiency_factor.", engine_xml_efficiency_factor, efficiency_factor), Level::Warning);
                            /*Calculate the new overall technology_factor*/

                            double new_efficiency_factor = 2-(2-efficiency_factor)/(2-engine_xml_efficiency_factor);
                            this->update_efficiency_factor(new_efficiency_factor);
                            try {
                                engine_data.set_engine_efficiency_factor(efficiency_factor);
                            } 
                            catch (const std::exception &ex) {
                                utility::print(std::string(ex.what()), Level::Error);
                                //throw std::runtime_error(std::string(ex.what()));
                                exit(EXIT_FAILURE);
                            }

                            DeckData deck_data_scaled = EngineDesigner::scale_deck_data_values(deck_data, EngineDesigner::technology_factor("engine_efficiency"));    
                            EngineDesigner::write_deck_value(deck_data_scaled, engine_name);
                            if (std::abs(efficiency_factor - 1.0) > 1e-6)
                            {
                                /* Print information only when the deck was manipulated */
                                utility::print(std::format(
                                    "Engine efficiency manipulated using the efficiency factor = {:1.2f} ",
                                    efficiency_factor), Level::Out);
                        }
                            
                        }
                        
                    }
                }
            
        }
    }

    void Rubber::save()
    {
        /* Copy all engines which do not exist in the engine directory */
        utility::print("Saving the rubber engine results", Level::Info);
        auto is_in_project = [this](const std::string &engine)
        {
            return std::filesystem::exists(this->engine_directory() / engine);
        };
        std::list<std::string> engines_to_copy;
        std::ranges::copy_if(
            this->designed_engines(),
            std::back_inserter(engines_to_copy),
            std::not_fn(is_in_project));

        /* Copy the engines */
        for (const auto &engine : engines_to_copy)
        {
            utility::print("Copying engine: " + engine, Level::Debug);
            std::filesystem::copy(this->engine_database() / engine, this->engine_directory() / engine);
            // /* Check whether the engine efficiency technology factor is 1.0 */
            EngineData engine_data = io::load_engine_data(engine, {this->engine_directory()});
            const auto efficiency_factor = static_cast<float>(this->configuration()->at( "module_configuration_file/program_settings/technology_factors/engine_efficiency/value"));
            std::filesystem::path path_to_csv = EngineDesigner::engine_directory(); 
            std::string engine_name = this->configuration()->at("module_configuration_file/program_settings/propulsion/engine/Rubber/engine_model/value");
            std::string added_path = (std::filesystem::path(path_to_csv) / engine_name / engine_name).string();
            DeckData deck_data = DeckData::from_csv(added_path.append("_WF.csv"));
                        /* Check in engine dataset in engine xml if a engine_efficiency_factor was already applied */
            double engine_xml_efficiency_factor = engine_data.engine_efficiency_factor();

            /* Compare to technology_factor for engine efficiency in config file */
            if (std::abs(engine_xml_efficiency_factor - efficiency_factor) > 1e-6)
            {
                
                utility::print(std::format("Warning: The engine efficiency factor in the engine XML ({:.3f}) differs from the technology factor in the configuration file ({:.3f}). The engine dataset will be adjusted to the configuration file efficiency_factor.", engine_xml_efficiency_factor, efficiency_factor), Level::Warning);
                /*Calculate the new overall technology_factor*/

                double new_efficiency_factor = 2-(2-efficiency_factor)/(2-engine_xml_efficiency_factor);
                this->update_efficiency_factor(new_efficiency_factor);
                try {
                      engine_data.set_engine_efficiency_factor(efficiency_factor);
                } 
                catch (const std::exception &ex) {
                    utility::print(std::string(ex.what()), Level::Error);
                    //throw std::runtime_error(std::string(ex.what()));
                    exit(EXIT_FAILURE);
                }
              
                DeckData deck_data_scaled = EngineDesigner::scale_deck_data_values(deck_data, EngineDesigner::technology_factor("engine_efficiency"));    
                EngineDesigner::write_deck_value(deck_data_scaled, engine_name);
                if (std::abs(efficiency_factor - 1.0) > 1e-6)
                {
                    /* Print information only when the deck was manipulated */
                    utility::print(std::format(
                        "Engine efficiency manipulated using the efficiency factor = {:1.2f} ",
                        efficiency_factor), Level::Out);
                }
                
            } 
    }
}

    template <EnergyCarrierFamily carrier>
    auto Rubber::calculate_bucket_point(const Propulsion<carrier> &engine) const -> BucketPoint
    {
        /* Set the step size when looking for the minimum of the bucket curve */
        constexpr double step_size = 1e-2;
        constexpr auto maxiter = static_cast<std::size_t>(1.0 / step_size);

        /* Load the scaled engine */
        auto engine_scaled = io::load_engine_scaled(
            engine.model(),
            engine.scale(),
            {this->engine_directory(),
             this->engine_database()});

        /* Try to calculate the N1 */
        try
        {
            /* Get the maximum N1 */
            engine_scaled.calculate_N1_with_penalties(
                this->flight_condition().altitude,
                this->flight_condition().mach,
                this->flight_condition().ambiance,
                1.0,
                "idle",
                engine.offtakes().bleed_air,
                engine.offtakes().shaft_power / 1000);
        } catch (const std::exception &error) {
            utility::print("Calculating the N1 failed:" + std::string(error.what()) + "Bucket point will not be set!", Level::Warning);
            return {0.0, 0.0};
        }
        const double N1_min = engine_scaled.get_operating_point().N;

        /* Initialize the search point an lowest N1 */
        engine_scaled.calculate_N1_with_penalties(
            this->flight_condition().altitude,
            this->flight_condition().mach,
            this->flight_condition().ambiance,
            1.0,
            "takeoff",
            engine.offtakes().bleed_air,
            engine.offtakes().shaft_power / 1000);
        const double N1_max = engine_scaled.get_operating_point().N;

        /* Print the bucket curve range */
        utility::print(
            std::format(
                "Calculating bucket point for engine {} => N1_min = {:.2f}, N1_max = {:.2f}",
                engine.model(),
                N1_min,
                N1_max),
            Level::Debug);

        /* Set the engine operating point to the lower starting point of N1 */
        auto op = engine_scaled.get_operating_point();
        op.N = N1_min;
        engine_scaled.set_operating_point(op);

        /* Initialize the bucket N1 and TSFC */
        double N1_previous = N1_min;
        double tsfc_previous = engine_scaled.get_fuelflow() / engine_scaled.get_thrust();

        /* Loop until the fuel flow gradient becomes positive */
        for (std::size_t i = 0; i < maxiter; ++i)
        {
            /* Update the operating point of the engine */
            const double N1 = N1_previous + step_size;
            op.N = N1;
            engine_scaled.set_operating_point(op);

            /* Calculate the fuel flow at the current N1 */
            const double tsfc = engine_scaled.get_fuelflow() / engine_scaled.get_thrust();

            /* Check whether the gradient is positive */
            if (tsfc > tsfc_previous)
            {
                break;
            } else {
                /* Update the tsfc and N1 */
                tsfc_previous = tsfc;
                N1_previous = N1;
            }

            /* Check whether N1 is still valid */
            if (N1 > N1_max)
            {
                utility::print("Maximum N1 reached in bucket point calculation!", Level::Warning);
                break;
            }

            /* Warn if iter reached maxiter */
            if (i == maxiter - 1)
            {
                utility::print("Maximum number of iterations reached in bucket point calculation!", Level::Warning);
            }
        }

        /* Calculate the found bucket point */
        op.N = N1_previous;
        engine_scaled.set_operating_point(op);
        const double thrust_bucket = engine_scaled.get_thrust();
        const double fuel_flow_bucket = engine_scaled.get_fuelflow();
        utility::print(
            std::format(
                "Found bucket point for engine {} at N1 = {:.2f} => thrust = {:3.1f} kN, TSFC = {:1.3e} kg/Ns",
                engine.model(), N1_previous, thrust_bucket / 1000, fuel_flow_bucket / thrust_bucket),
            Level::Info);

        /* Return the bucket point */
        return {
            thrust_bucket,
            fuel_flow_bucket / thrust_bucket};
    };
    template auto Rubber::calculate_bucket_point(const Propulsion<EnergyCarrierFamily::Kerosene> &) const -> BucketPoint;
    template auto Rubber::calculate_bucket_point(const Propulsion<EnergyCarrierFamily::Liquid_Hydrogen> &) const -> BucketPoint;

    auto Rubber::preselected_engine(const int engine_id) -> std::optional<std::string_view>
    {
        /* Check whether the engine id has a pre-selected model */
        if (this->preselected_engines_.contains(engine_id))
        {
            return this->preselected_engines_.at(engine_id);
        }

        /* Check whether there is a default preselection */
        if (this->preselected_engines_.contains(-1))
        {
            return this->preselected_engines_.at(-1);
        }

        /* No preselection available */
        return std::nullopt;
    }

    auto Rubber::select_engine(const double thrust_required) const -> std::string
    {
        /* Define the criteria for a valid engine entry */
        /** @todo Make the valid engine criteria more precise */
        const auto is_valid_engine = [](const auto &entry) -> bool
        {
            return entry.is_directory();
        };

        /* Get a list with all valid folder names in the database path */
        const auto database = this->engine_database();
        std::list<std::string> engine_names;
        std::ranges::copy(
            std::filesystem::directory_iterator{database} | std::views::filter(is_valid_engine) | std::views::transform([](const auto &entry)
                                                                                                                        { return entry.path().filename().string(); }),
            std::back_inserter(engine_names));

        /* Find the minimum deviation to the required thrust of the engines */
        const auto best_engine = std::ranges::min_element(
            engine_names,
            [&database, &thrust_required](const auto &lhs, const auto &rhs)
            {
            const auto lhs_thrust = io::load_engine_data(lhs, {database}).SLST();
            const auto rhs_thrust = io::load_engine_data(rhs, {database}).SLST();
            return std::abs(lhs_thrust - thrust_required) < std::abs(rhs_thrust - thrust_required); });

        /* Check whether there is a result */
        if (best_engine == engine_names.end())
        {
            throw std::runtime_error("No engine found in the database");
        }

        /* Return the name of the best engine */
        return *best_engine;
    }

} // namespace design
