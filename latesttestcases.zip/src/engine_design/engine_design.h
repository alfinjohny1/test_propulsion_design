/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

#ifndef SRC_ENGINE_DESIGN_ENGINE_DESIGN_H_
#define SRC_ENGINE_DESIGN_ENGINE_DESIGN_H_

/* === Includes === */
#include "../propulsion.h"
#include "../propulsion_strategy.h"
#include <memory>
#include <unordered_map>
#include <unordered_set>
#include <string>
#include <engine/engine_deck.h>

namespace design
{
    /* === Classes === */
    /** @class EngineDesigner
     * @brief The base design class for engine design.
     */
    class EngineDesigner : public PropulsionStrategy
    {
      public:
        /* === Constructors === */
        /**
         * @brief Construct a new Engine Designer object
         * @param configuration The module settings provided by the user.
         * @param engine_directory The directory where the engine results are stored.
         * @param design_condition The design flight condition of the aircraft.
         */
        explicit EngineDesigner(
            const std::shared_ptr<node> &configuration,
            const std::filesystem::path &engine_directory,
            const FlightCondition &design_condition)
            : PropulsionStrategy(configuration), engine_directory_(engine_directory), flight_condition_(design_condition)
        {
            /* Default technology factors */
            /**
             * @ref technology_factors_mass Technology Factors for Masses
             *
             * The available technology factors are:
             *
             * |Name|Description|
             * |---|---|
             * |`engine_mass`|The technology factor for the engine mass.|
             * |`engine_efficiency`|The technology factor for the fuel_flow adaption.|
             *
             */
            this->technology_factors["engine_mass"] = 1.0;
            this->technology_factors["engine_efficiency"] = 1.0;
        }

        /* === Getters ===*/
        /**
         * @brief Get the designed engines.
         * @return const std::unordered_set<std::string> & The designed engines.
         */
        [[nodiscard]] auto designed_engines() const -> const std::unordered_set<std::string> &
        {
            return this->engine_models_;
        }

        /**
         * @brief Get the engine database directory.
         * @return const std::filesystem::path The engine database directory.
         */
        [[nodiscard]] auto engine_database() const -> const std::filesystem::path { return this->engine_database_; }

        /**
         * @brief Get the engine directory of the current project.
         * @return const std::filesystem::path The engine directory.
         */
        [[nodiscard]] auto engine_directory() const -> const std::filesystem::path { return this->engine_directory_; }

        /**
         * @brief Get the flight condition of the aircraft.
         * @return const FlightCondition & The flight condition of the aircraft.
         */
        [[nodiscard]] auto flight_condition() const -> const FlightCondition & { return this->flight_condition_; }

        /* === Methods ===*/
        /**
         * @brief Initialize the default engine designer.
         */
        void initialize() override
        {
            /* Read the technology factors */
            this->technology_factors["engine_mass"] = this->configuration()->at("module_configuration_file/program_settings/technology_factors/engine_mass/value");
            this->technology_factors["engine_efficiency"] = this->configuration()->at("module_configuration_file/program_settings/technology_factors/engine_efficiency/value");

            /* Read the engine database directory */
            this->engine_database_ = std::string(this->configuration()->at("/module_configuration_file/program_settings/path_engine_database/value"));
        }

        /**
         * @brief Get the technology factor of a specific component as defined in the settings.
         * @details See @ref technology_factors_mass for a list of available technology factors.
         * @throws std::out_of_range if the technology factor of the component
         * does not exist.
         *
         * @param name The name of the technology factor to get.
         * @return double The technology factor of the component as defined in the settings.
         */
        [[nodiscard]] auto technology_factor(const std::string &name) const -> double
        {
            return this->technology_factors.at(name);
        }

        /**
         * @brief Add a designed engine to the list of designed engines.
         * The list of designed engines contains all unique engine models which
         * have been designed by the engine designer.
         *
         * @param engine_model The engine model to add.
         * @return true The engine model was not already in the set and has been added.
         */
        auto add_designed_engine(const std::string_view engine_model) -> bool
        {
            return this->engine_models_.emplace(engine_model).second;
        }

        /**
         * @brief Write the deck value to the engine directory.
         * This saves the deck data as a csv file to the current engine directory.
         *
         * @param data The deck data to write.
         */
        void write_deck_value(const DeckData &data, std::string engine_name) const;

         /**
         * @brief Recalculate the engine data deck with the efficiency defined in the engine.xml.
         *
         * @param deck_data Engine deck data values.
         * @param efficiency_factor Value of the efficiency factor defined in the engine.xml.
         * @return scaled deck data.
         */
        auto scale_deck_data_values(DeckData &deck_data, double efficiency_factor) -> DeckData;

        /**
         * @brief Update the technology factor for engine efficiency.
         *
         * @param new_efficiency_factor: Vaalue of the new engine efficiency factor.
         */
        void update_efficiency_factor(double new_efficiency_factor);


                 /**
         * @brief Recalculate the engine data deck with the efficiency defined in the engine.xml.
         *
         * @param deck_data Engine deck data values.
         * @param efficiency_factor Value of the efficiency factor defined in the engine.xml.
         * @return scaled deck data.
         */
        auto generate_empty_deck_data(std::string name, std::vector<double> FL,  std::vector<double> Mach, std::vector<double> N) -> DeckData;

      private:
        /* === Properties === */
        std::unordered_map<std::string, double> technology_factors; /** [-] The technology factors of the components. */
        std::filesystem::path engine_database_{};                   /** The directory where the aircraft engine files are stored. */
        std::filesystem::path engine_directory_{};                  /** The directory where the engine decks for the designed aircraft should be saved. */
        std::unordered_set<std::string> engine_models_;             /**< The designed engine models. */
        FlightCondition flight_condition_;                          /**< The flight condition of the aircraft. */
    };
}; // namespace design

#endif // SRC_ENGINE_DESIGN_ENGINE_DESIGN_H_
