/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include "engine_design.h"
#include <format>
#include "../io/engine_xml.h"
#include "../utility.h"

namespace design
{
    void EngineDesigner::write_deck_value(const DeckData &data, std::string engine_name) const
    {
        /* The deck values assume a ; as separator */
        constexpr char delimiter = ';';

        /* Get the file name to export to */
        const std::filesystem::path file_name = engine_directory_ / engine_name / (data.name + ".csv");

        /* Open the file */
        std::ofstream file(file_name, std::ios::out | std::ios::trunc);

        /* Cache the Mach line */
        std::stringstream mach_line;
        std::for_each(data.Mach.begin(), data.Mach.end(), [&mach_line](const auto &mach)
                      { mach_line << mach << delimiter; });

        /* Insert the data lines in the file */
        for (size_t index_N = 0; index_N < data.N.size(); ++index_N)
        {
            /* Insert the N value and the cached Mach values */
            file << data.N.at(index_N) << delimiter << mach_line.str() << '\n';

            /* Insert the FL values and the data values */
            for (size_t index_FL = 0; index_FL < data.FL.size(); ++index_FL)
            {
                file << data.FL.at(index_FL) << delimiter;
                std::for_each(
                    data.values[index_N][index_FL].begin(),
                    data.values[index_N][index_FL].end(),
                    [&file](const auto &value)
                    {
                        file << value << delimiter;
                    });
                file << '\n';
            }
        }

        /* Close the file */
        file.close();
    }

     // Scale values in DeckData
    auto EngineDesigner::scale_deck_data_values(DeckData &deck_data, double efficiency_factor) -> DeckData
    {
        double technology_factor = 1+(1-efficiency_factor);
        for (auto i = 0; i < deck_data.values.shape()[0]; ++i) {
            for (auto j = 0; j < deck_data.values.shape()[1]; ++j) {
                for (auto k = 0; k < deck_data.values.shape()[2]; ++k) {
                    if (deck_data.values[i][j][k] != -9999) {
                        deck_data.values[i][j][k] *= technology_factor;
                    }
                }
            }
        }
        return deck_data;
    }

    // Update technology factor: engine efficiency
    void EngineDesigner::update_efficiency_factor(double new_efficiency_factor)
    {
        this->technology_factors["engine_efficiency"] = new_efficiency_factor;
    }

    // Function, that generates an empty deck data
    auto EngineDesigner::generate_empty_deck_data(std::string name, std::vector<double> FL,  std::vector<double> Mach, std::vector<double> N) -> DeckData
    {
    DeckData deck;

    // Assign values of the arguments to the deck
    deck.name = name;
    deck.FL = FL; // Example flight levels in meters
    deck.Mach = Mach;    // Example Mach numbers
    deck.N = N;     // Example engine speeds

    
    // Set a default value
    const double default_value = -9999.0;

    // Define the shape of the multi_array
    boost::array<std::size_t, 3> shape = {deck.N.size(), deck.FL.size(), deck.Mach.size()};
    deck.values.resize(shape);

    // Populate the multi_array with example values
    for (std::size_t i = 0; i < shape[0]; ++i) {
        for (std::size_t j = 0; j < shape[1]; ++j) {
            for (std::size_t k = 0; k < shape[2]; ++k) {
                deck.values[i][j][k] = default_value; // Set each value to -9999
            }
        }
    }

    return deck;
}

}; // namespace design
