/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

#ifndef SRC_UTILITY_H_
#define SRC_UTILITY_H_

/* === Includes === */
#include "aircraft_geometry.h"
#include "energy_carrier.h"
#include "propulsion.h"
#include <aixml/node.h>
#include <memory>
#include <string_view>

/* === Typedefs === */
/**
 * @brief Enum class to define the different log levels.
 */
enum class Level
{
    Out,
    Debug,
    Info,
    Warning,
    Error
};

namespace utility
{
    /* === Functions === */
    /**
     * @brief Convert the energy carrier name given in the requirements
     * of the aircraft exchange xml file to the corresponding enum value.
     * @note The name is not case sensitive.
     * @throws std::runtime_error if the energy carrier is not supported.
     *
     * @param carrier_name The name of the energy carrier.
     * @return EnergyCarrierFamily The corresponding enum value.
     */
    [[nodiscard]] auto to_energy_carrier(std::string_view carrier_name) -> EnergyCarrierFamily;

    /**
     * @brief Creates a energy carrier map.
     *
     * @param energy_carriers_node The node in acXML with the energy carriers listed.
     * @return EnergyCarriersMap Map of energy carriers with ID and EnergyCarrierFamily.
     */
    auto create_energy_carrier_map(const node &energy_carriers_node) -> EnergyCarriersMap;

    /**
     * @brief Create a engine object from the given requirements.
     * @note The returned engine is default constructed and the
     * engine ID is set to the ID of the given xml node!
     *
     * @param propulsor The xml node containing the engine configuration.
     * @param total_installed_thrust [N] The total installed thrust needed by the aircraft.
     * Default is 0.0.
     * @param total_offtakes_required The total engine offtakes required by the aircraft.
     * @return PropulsionType Returns the created engine.
     */
    [[nodiscard]] auto create_engine(
        const node &propulsor,
        const EnergyCarriersMap &energy_carriers_map,
        double total_installed_thrust = 0.0,
        const Offtakes &total_offtakes_required = {}) -> PropulsionType;

    /**
     * @brief Print a message to the console with the given log level.
     *
     * @param message The message to print.
     * @param level The log level of the message.
     */
    void print(std::string_view message, Level level = Level::Info);
}; // namespace utility

#endif // SRC_UTILITY_H_
