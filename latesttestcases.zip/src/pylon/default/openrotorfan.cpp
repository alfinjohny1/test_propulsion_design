/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include "default_pylon.h"
#include <aircraftGeometry2/io/dat.h>
#include <aircraftGeometry2/processing/measure.h>
#include <aircraftGeometry2/processing/transform.h>
#include <cmath>
#include <set>
#include <utility>

/* === Design implementations === */
namespace geometry
{
    namespace pylon
    {
        template <EnergyCarrierFamily EC>
        void Default::openrotorfan_method(Openrotorfan<EC> &engine)
        {
            auto computeOffsets = [&](double lengthFactor, geom2::Vector_3 extraOffset = {0, 0, 0}) {
                return std::make_pair(
                    engine.position() - CGAL::ORIGIN - geom2::Vector_3(engine.dimension().length * lengthFactor, 0.0, -(engine.dimension().height) / 6.0),
                    engine.position() - CGAL::ORIGIN + extraOffset
                );
            };
        
            /* Check whether a pylon can be designed */
            if (
                std::get<Vertical>(engine.parent_component()) == Vertical::In ||
                !this->aircraft()
            )
            {
                return;
            }
            /* Get the start and end points of pylon */
            const auto attachment = this->get_attachment_points(
                engine.position(), engine.nacelle(), engine.parent_component());

            /* Get profile of each section */
            auto profile = this->get_section_profile(engine.id());

            /* Set the global location and orientation of the pylon */
            geometry::Pylon pylon{};
            pylon.origin = CGAL::ORIGIN;
            pylon.normal = (engine.position() - attachment.first).direction();

            /* Set the pylon name */
            pylon.name = "pylon_" + std::to_string(engine.id());

            /*
             * The offset of the engine to the origin since
             * the pylon origin relative to the position of 
             * the second segment of the nacelle. Therefore,
             * the pylon is also elevated to the second of
             * the nacelle height.
             */
            
            std::pair<geom2::Vector_3, geom2::Vector_3> offsets;
            
            if (std::get<Parent>(engine.parent_component()) == Parent::Wing)
            {
                if (std::get<Vertical>(engine.parent_component()) == Vertical::Over)
                {
                    offsets = computeOffsets(0.3, geom2::Vector_3(-0.5, engine.position().y() * 0.5, -0.8));
                }
                else if (std::get<Vertical>(engine.parent_component()) == Vertical::Under)
                {
                    offsets = computeOffsets(0.3, geom2::Vector_3(0.0, engine.position().y() * 0.5, 0.0));
                }
                else if (std::get<Vertical>(engine.parent_component()) == Vertical::In)
                {
                    offsets = computeOffsets(0.3, geom2::Vector_3(0.0, engine.position().y() * 0.5, 0.0));
                }
            }
            if (std::get<Parent>(engine.parent_component()) == Parent::Fuselage)
            {
                offsets = computeOffsets(0.3, geom2::Vector_3(-0.5, engine.position().y() * 1.0, -0.7));  
            }

            const auto& offset_start = offsets.first;
            const auto& offset_end = offsets.second + geom2::Vector_3(-1.0, -engine.position().y() / 2.0, 0.0);


            /* Section at nacelle attachment */
            pylon.sections.emplace_back(profile);
            pylon.sections.back().origin = geom2::transform::to_local(pylon, attachment.first - offset_start);
            pylon.sections.back().set_chord_length(engine.dimension().length/2.0);

            /* Section attaching to the parent component */
            pylon.sections.emplace_back(profile);
            pylon.sections.back().origin = geom2::transform::to_local(pylon, attachment.second - offset_end);
            pylon.sections.back().set_chord_length(engine.dimension().length * 0.4); 

            /* Add the pylon to the engine */
            engine.set_pylon(pylon);
        }

        void Default::operator()(Openrotorfan<EnergyCarrierFamily::Kerosene> &engine)
        {
            openrotorfan_method(engine);
        };

    } // namespace pylon
} // namespace geometry
