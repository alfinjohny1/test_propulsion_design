/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

#ifndef SRC_PYLON_DEFAULT_DEFAULT_PYLON_H_
#define SRC_PYLON_DEFAULT_DEFAULT_PYLON_H_

/* === Includes === */
#include "../pylon_design.h"
#include <memory>
#include <string>
#include <unordered_map>
#include <utility>

namespace geometry
{
    namespace pylon
    {
        /* === Classes === */
        /**
         * @class Default
         * @brief The default pylon geometry designer.
         */
        class Default : public PylonDesigner
        {
          public:
            /* === Constructors === */
            /**
             * @brief Construct a new default pylon geometry designer.
             * @param configuration The module configuration provided by the user.
             * @param aircraft_geometry The aircraft geometry.
             * @param geometry_directory The directory where the geometry files are stored.
            */
            Default(
                const std::shared_ptr<node> &configuration,
                const std::shared_ptr<geometry::Aircraft> &aircraft_geometry,
                const std::filesystem::path &geometry_directory)
            : PylonDesigner(configuration, aircraft_geometry, geometry_directory) {}

            /* === Methods === */
            /**
             * @brief Design the geometry of a turbofan and openrotorfan pylon
             * with kerosene as fuel.
             *
             * @param engine The engine to design the geometry for.
             */
            void operator()(Turbofan<EnergyCarrierFamily::Kerosene> &engine);
            void operator()(Turbofan<EnergyCarrierFamily::Liquid_Hydrogen> &engine);
            void operator()(Openrotorfan<EnergyCarrierFamily::Kerosene> &engine);

            template <EnergyCarrierFamily EC>
            void turbofan_method(Turbofan<EC> &engine);

            template <EnergyCarrierFamily EC>
            void openrotorfan_method(Openrotorfan<EC> &engine);

            /**
             * @brief Initialize the default pylon geometry designer.
             */
            void initialize() final;


        private:
            /* === Methods === */
            /**
             * @brief Get the attachment points of the pylon from the nacelle
             * to the parent component.
             * @attention The returned points are in the global coordinate frame
             * of the aircraft.
             *
             * @param position The position of the engine
             * @param nacelle The nacelle surrounding the engine
             * @param parent The parent component of the engine
             * @return std::pair<geom2::Point_3, geom2::Point_3> Returns the attachment points.
             * The first point is the attachment point of the pylon to the nacelle and the second
             * point is the attachment point of the pylon to the parent component.
             */
            [[nodiscard]] auto get_attachment_points(
                const geom2::Point_3 &position,
                const geometry::Nacelle &nacelle,
                const ParentComponent &parent) -> std::pair<geom2::Point_3, geom2::Point_3>;
            /**
             * @brief Create the section profile as defined in the user settings.
             * @note The profile should be a normalized airfoil coordinates.
             * @throws std::invalid_argument If the section profile is not supported.
             *
             * @param engine_id The id of the engine to create the section profile for.
             * @return geom2::AirfoilSection The created section profile.
             */
            [[nodiscard]] auto get_section_profile(const int engine_id) const -> geom2::AirfoilSection;

            /**
             * @brief Select the wing from the aircraft geometry.
             *
             * @param aircraft The aircraft geometry.
             * @return geometry::Wing The selected wing.
             * @throws std::runtime_error When the aircraft wing configuration is not supported.
             */
            [[nodiscard]] auto select_wing() -> geometry::Wing&;

            /* === Properties === */
            std::unordered_map<int, std::string> section_profiles; /** [-] The section profiles of the pylon. */
        };
    }; // namespace pylon
};     // namespace geometry

#endif // SRC_PYLON_DEFAULT_DEFAULT_PYLON_H_
