/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include "default_pylon.h"
#include "../../utility.h"
#include <aircraftGeometry2/io/dat.h>
#include <aircraftGeometry2/processing/measure.h>
#include <aircraftGeometry2/processing/transform.h>
#include <algorithm>
#include <cmath>
#include <set>
#include <utility>

/* === Design implementations === */
namespace geometry
{
    namespace pylon
    {
        template <EnergyCarrierFamily EC>
        void Default::turbofan_method(Turbofan<EC> &engine)
        {
            /* Check whether a pylon can be designed */
            if (
                std::get<Vertical>(engine.parent_component()) == Vertical::In ||
                !this->aircraft()
            )
            {
                return;
            }

            /* Get the start and end points of pylon */
            const auto attachment = this->get_attachment_points(
                engine.position(), engine.nacelle(), engine.parent_component());

            /* Get profile of each section */
            auto profile = this->get_section_profile(engine.id());

                /* Set the global location and orientation of the pylon */
                geometry::Pylon pylon{};
                pylon.origin = CGAL::ORIGIN;
                pylon.normal = (engine.position() - attachment.first).direction();

                /* Set the pylon name */
                pylon.name = "pylon_" + std::to_string(engine.id());

                /*
                * Resolve the wing the SAME way get_attachment_points() just did for this engine
                * (see Default::select_wing()), instead of assuming aircraft()->wings[0] is still
                * the right one - for an aircraft with wing-mounted engines on more than one wing,
                * a different engine's integration call can have left wings[0] pointing at the
                * WRONG wing by the time this one is designed.
                */
                auto &wing = this->select_wing();

                /* Get the engine position in the wing coordinate frame */
                const auto local_position = geom2::transform::to_local(wing, engine.position());

                /* Get the leading edge point of the wing at the engine plane */
                auto local_wing = geom2::measure::offset_LE(wing, local_position.z());

                /* Check whether the engine is under the wing */
                const bool engine_is_under_wing = (local_position - local_wing).y() < 0;

                /*
                * Both pylon/nacelle "position" fields are exported to the exchange XML
                * documented as "RELATIVE to the engine position" (io/aircraft_xml.cpp) -
                * i.e. any consumer reconstructing absolute coordinates is expected to do
                * global = engine.position() + rotate(section.origin). That only holds if
                * BOTH sections are re-based by exactly engine.position() before rotating
                * into the pylon's local frame (pylon.origin is always CGAL::ORIGIN, so
                * to_local()/to_parent() here do pure rotation, no translation of their own).
                *
                * The previous version subtracted a DIFFERENT reference per section
                * (offset_start for the nacelle side, offset_end for the wing side, each
                * differing from engine.position() by an engine-size-dependent inset vector)
                * to visually align the nacelle-side root with the nacelle's own second
                * cross-section ring (built at 0.25*engine.length along the nacelle axis,
                * see nacelle/default/turbofan.cpp). That inset is a real, meaningful shift
                * of WHERE the nacelle-side attachment point sits - but folding it into the
                * subtracted reference instead of into the point itself broke the
                * "relative to engine position" contract: any consumer following that
                * contract (engine.position() + section.origin) reconstructed a pylon whose
                * two ends were each additionally offset by their own, DIFFERENT inset -
                * up to ~1.3 m apart for a large turbofan - visibly displacing the
                * wing-attachment section past the wing's own local trailing edge in
                * exports, even though attachment.second itself (what the trailing-edge cap
                * below is actually validated against) sits comfortably inside the chord.
                *
                * Fix: apply the nacelle-side inset to the ATTACHMENT POINT itself, then
                * subtract exactly engine.position() for both sections.
                */
                const auto nacelle_root_inset = engine_is_under_wing ?
                    geom2::Vector_3(engine.dimension().length * 0.25, 0, (engine.dimension().height) * 0.21 / 2) :
                    geom2::Vector_3(engine.dimension().length * 0.25, 0, -(engine.dimension().height) * 0.21 / 2);
                const auto nacelle_attachment_point = attachment.first + nacelle_root_inset;
                const auto engine_ref = engine.position() - CGAL::ORIGIN;

                /* The pylon's own chord direction, needed both to shift the OTW wing-side
                 * anchor below and for the trailing-edge check further down. See the
                 * @attention note on exceeds_trailing_edge for why this has to be a true 3D
                 * direction rather than a 1D wing-local x-difference: a pylon's chord is
                 * typically built close to streamwise (real pylons are usually much less
                 * swept than the wing, if at all), so it does not in general run parallel
                 * to the wing's local chord line. */
                const auto chord_axis_global = geom2::transform::to_parent(pylon, geom2::Point_3{1.0, 0.0, 0.0}) -
                    geom2::transform::to_parent(pylon, geom2::Point_3{0.0, 0.0, 0.0});

                const double mac = geom2::measure::mean_aerodynamic_chord(wing);
                const double desired_chord = std::min(1.15 * engine.dimension().length, 0.9 * mac);
                const double min_chord_floor = 0.3 * engine.dimension().length;

                /*
                * The real, twist-corrected local trailing-edge x at a given span
                * position. Section twist rotates the section (and with it the
                * trailing edge) around its own leading edge, in the local
                * chord/thickness plane - a flat "LE.x + chord" approximation edges
                * the true 3D trailing edge inward whenever a section has non-zero
                * twist, letting the pylon's own (untwisted, chord_axis_global-
                * aligned) tip visibly poke out past the actual wing surface even
                * though it stays within the flat/untwisted planform chord.
                * Confirmed on real data: UNISELECT-TW-LR-01's front wing carries
                * -1.0 deg of twist at the engine span station - measure::twist()
                * already exists in aircraftGeometry2 for exactly this (same
                * span-interpolation pattern as offset_LE()/chord()), no need for a
                * new geometry-library function.
                */
                const auto local_trailing_edge_x = [&](double z) -> double
                {
                    return geom2::measure::offset_LE(wing, z).x() +
                        geom2::measure::chord(wing, z) * std::cos(geom2::measure::twist(wing, z));
                };

                /*
                * Cap the nacelle-side chord so it can't extend past the engine's own rear
                * end. engine.position() is the engine's FRONT/inlet reference (confirmed
                * from nacelle/default/turbofan.cpp's section-builder: nacelle sections run
                * from local z=0 at engine.position() to z=+1.0*engine.length at the rear),
                * so the engine's rear sits at engine.length from this section's start
                * (nacelle_attachment_point, itself already engine.length*0.25 aft of
                * engine.position() via nacelle_root_inset). Previously the under-wing
                * chord was set to the FULL engine.length regardless of that 0.25*length
                * head start, so the section always ran 0.25*length past the engine's own
                * casing - the pylon visibly outgrew the engine it's attached to.
                */
                const double nacelle_chord_limit = engine.dimension().length - nacelle_root_inset.x();
                pylon.sections.emplace_back(profile);
                pylon.sections.back().origin = geom2::transform::to_local(pylon, nacelle_attachment_point - engine_ref);
                pylon.sections.back().set_chord_length(std::min(engine.dimension().length, nacelle_chord_limit));
                if (!engine_is_under_wing)
                {
                    pylon.sections.back().set_chord_length(std::min(engine.dimension().length / 2., nacelle_chord_limit));
                }

                /*
                * Where the wing-side chord starts, chordwise. `attachment.second` is
                * always the wing's own local LEADING EDGE at this span station now (see
                * get_wing_attachment_points()/get_wing_body_attachment_points()) - correct
                * as-is for an under-wing pylon, whose fairing leading edge blends into the
                * wing's own leading edge on a real aircraft.
                *
                * For an over-wing pylon the equivalent real-world reference is the
                * TRAILING edge instead (the engine sits well aft, near the wing's own TE)
                * - so shift the start aft by (LE-to-TE reach - desired_chord), i.e. far
                * enough that starting there and running the full desired_chord lands
                * exactly on the wing's real (twist-corrected) local TE. If desired_chord
                * doesn't fit at all (bigger than the whole local wing chord), don't shift
                * past the LE - leave it there and let the trailing-edge cap below shrink
                * the chord, same as the under-wing case.
                */
                const double wing_le_to_te_x = local_trailing_edge_x(local_position.z()) - local_wing.x();
                const auto wing_chord_start = engine_is_under_wing ? attachment.second :
                    attachment.second + std::max(0.0, wing_le_to_te_x - desired_chord) * chord_axis_global;

                pylon.sections.emplace_back(profile);
                pylon.sections.back().origin = geom2::transform::to_local(pylon, wing_chord_start - engine_ref);

                /* Whether extending the wing-attachment section by `chord` along the pylon's
                 * own chord direction, starting at wing_chord_start, would cross the wing's
                 * LOCAL trailing edge at the point actually reached (which may sit at a
                 * slightly different span station than the attachment point itself, e.g.
                 * near a tip with forward-swept trailing edge). This is mostly a safety net
                 * now that wing_chord_start is already chosen to land on the TE for OTW (or
                 * on the LE for UTW) by construction in the common, unswept-ish case - real
                 * sweep/dihedral can still make the straight-line projection along
                 * chord_axis_global miss the same span station's TE slightly, which this
                 * catches. */
                const auto exceeds_trailing_edge = [&](double chord) -> bool
                {
                    const auto candidate_end = wing_chord_start + chord * chord_axis_global;
                    const auto local_end = geom2::transform::to_local(wing, candidate_end);
                    return local_end.x() > local_trailing_edge_x(local_end.z());
                };

                /* Bisect for the longest chord (up to desired_chord) that still stays within
                 * the local trailing edge, since the boundary generally isn't linear in chord
                 * (the wing's local chord/sweep can vary along the pylon's own direction). */
                double max_fitting_chord = desired_chord;
                if (exceeds_trailing_edge(desired_chord))
                {
                    double low = 0.0;
                    double high = desired_chord;
                    for (int i = 0; i < 20; ++i)
                    {
                        const double mid = 0.5 * (low + high);
                        if (exceeds_trailing_edge(mid)) { high = mid; } else { low = mid; }
                    }
                    max_fitting_chord = low;
                }

                /*
                * Never let the pylon overhang the wing's local trailing edge, even if that
                * means going below the usual minimum chord - `min_chord_floor` used to WIN
                * this clamp whenever the fitted chord fell below it, i.e. the code detected
                * the overhang, warned about it, and produced it anyway. The whole point of
                * `exceeds_trailing_edge`/`max_fitting_chord` is a hard geometric constraint;
                * a short pylon chord is a cosmetic compromise, an overhanging one is not.
                */
                if (max_fitting_chord < min_chord_floor)
                {
                    utility::print(
                        "[geometry::pylon::Default] The local wing chord at the engine span position is "
                        "too small to fit a full-size pylon wing-attachment section without overhanging "
                        "the trailing edge. Shrinking the chord below the usual minimum instead.",
                        Level::Warning);
                }
                const double chord_wing_attachment = std::clamp(max_fitting_chord, 0.001, desired_chord);
                pylon.sections.back().set_chord_length(chord_wing_attachment);

                /* Add the pylon to the engine */
                engine.set_pylon(pylon);
            }

        void Default::operator()(Turbofan<EnergyCarrierFamily::Kerosene> &engine)
        {
            turbofan_method(engine);
        };

        void Default::operator()(Turbofan<EnergyCarrierFamily::Liquid_Hydrogen> &engine)
        {
            turbofan_method(engine);
        };
    } // namespace pylon
} // namespace geometry
