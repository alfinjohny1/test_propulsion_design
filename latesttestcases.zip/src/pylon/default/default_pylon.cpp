/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include "default_pylon.h"
#include "../../utility.h"
#include <aircraftGeometry2/io/dat.h>
#include <aircraftGeometry2/processing/measure.h>
#include <aircraftGeometry2/processing/transform.h>
#include <algorithm>
#include <cmath>
#include <set>
#include <string>
#include <utility>

/* === Design implementations === */
namespace geometry
{
    namespace pylon
    {
        namespace detail
        {
            /**
             * @brief Set of supported parent components for the pylon design.
             */
            const std::set<ParentComponent> supported_parents = {
                {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under},
                {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under},
                {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Over},
                {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Over},
                {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Mid},
                {Parent::Fuselage, Lateral::Left, Longitudinal::Rear, Vertical::Mid},
                {Parent::WingBody, Lateral::Left, Longitudinal::Rear, Vertical::Over},
                {Parent::WingBody, Lateral::Right, Longitudinal::Rear, Vertical::Over}
            };

            /**
             * @brief Get the attachment points of the pylon from the nacelle
             * to the wing parent.
             * @attention The returned points are in the global coordinate frame
             * of the aircraft.
             *
             * @param position The position of the engine
             * @param nacelle The nacelle surrounding the engine
             * @param wing The wing the engine is attached to
             * @return std::pair<geom2::Point_3, geom2::Point_3> Returns the attachment points.
             * The first point is the attachment point of the pylon to the nacelle and the second
             * point is the attachment point of the pylon to the wing component.
             */
            [[nodiscard]] auto get_wing_attachment_points(
                const geom2::Point_3 &position,
                const geometry::Nacelle &nacelle,
                const geometry::Wing &wing) -> std::pair<geom2::Point_3, geom2::Point_3>
            {
                /* Get the engine position in the fuselage coordinate frame */
                const auto local_position = geom2::transform::to_local(wing, position);

                /* Get the leading edge point of the wing at the engine plane */
                auto local_wing = geom2::measure::offset_LE( wing, local_position.z());

                /* Check whether the engine is under the wing */
                const bool engine_is_under_wing = (local_position - local_wing).y() < 0;

                /* Get the coordinates of the nacelle attachment point */
                const auto local_nacelle = engine_is_under_wing ?
                    geom2::measure::top(nacelle, 0.0) :
                    geom2::measure::bottom(nacelle, 0.0);

                /*
                * The wing attachment point is the wing's own LEADING EDGE at this span
                * station - matching a real pylon fairing, whose leading edge blends into
                * the wing's leading edge for an under-wing installation. (A previous
                * version anchored this at the engine's own chordwise position instead, to
                * avoid a large gap for OTW engines sitting well aft of the LE - but that
                * traded the gap for a pylon with no chordwise offset between its two ends
                * at all, i.e. no taper/sweep between nacelle and wing whatsoever. The
                * OTW-specific gap is now closed differently, by anchoring that case's
                * wing-side chord at the trailing edge instead - see turbofan.cpp.)
                */

                /* Transform the attachment points into the global coordinate frame */
                const auto global_wing = geom2::transform::to_parent(wing, local_wing);
                const auto global_nacelle = geom2::transform::to_parent(nacelle, local_nacelle) +
                    (position - CGAL::ORIGIN); //Nacelle has the engine position as origin

                /* Return the attachment points in the global coordinate frame */
                return {global_nacelle, global_wing};
            }

            [[nodiscard]] auto get_wing_body_attachment_points(
                const geom2::Point_3& position,
                const geometry::Nacelle& nacelle,
                const geometry::Wing& wing) -> std::pair<geom2::Point_3, geom2::Point_3>
            {
                /* Get the engine position in the fuselage coordinate frame */
                const auto local_position = geom2::transform::to_local(wing, position);

                /* Get the leading edge point of the wing at the engine plane */
                auto local_wing = geom2::measure::offset_LE(wing, local_position.z());

                /* Check whether the engine is under the wing */
                const bool engine_is_under_wing = (local_position - local_wing).y() < 0;

                /* Get the coordinates of the nacelle attachment point */
                const auto local_nacelle = engine_is_under_wing ?
                    geom2::measure::top(nacelle, 0.0) :
                    geom2::measure::bottom(nacelle, 0.0);

                /*
                * The wing attachment point is the wing's own LEADING EDGE at this span
                * station - see the identical comment in get_wing_attachment_points()
                * above for why (previously anchored at the engine's own chordwise
                * position; the OTW gap that was meant to avoid is now closed by
                * anchoring that case's wing-side chord at the trailing edge instead,
                * in turbofan.cpp).
                */

                /* Transform the attachment points into the global coordinate frame */
                const auto global_wing = geom2::transform::to_parent(wing, local_wing);
                const auto global_nacelle = geom2::transform::to_parent(nacelle, local_nacelle) +
                    (position - CGAL::ORIGIN); //Nacelle has the engine position as origin

                /* Return the attachment points in the global coordinate frame */
                return { global_nacelle, global_wing };
            }

            /**
             * @brief Get the attachment points of the pylon from the nacelle
             * to the fuselage parent.
             * @attention The returned points are in the global coordinate frame
             * of the aircraft.
             *
             * @param position The position of the engine
             * @param nacelle The nacelle surrounding the engine
             * @param fuselage The fuselage the engine is attached to
             * @return std::pair<geom2::Point_3, geom2::Point_3> Returns the attachment points.
             * The first point is the attachment point of the pylon to the nacelle and the second
             * point is the attachment point of the pylon to the fuselage component.
             */
            [[nodiscard]] auto get_fuselage_attachment_points(
                const geom2::Point_3 &position,
                const geometry::Nacelle &nacelle,
                const geometry::Fuselage &fuselage) -> std::pair<geom2::Point_3, geom2::Point_3>
            {
                /* Get the engine position in the fuselage coordinate frame */
                const auto local_position = geom2::transform::to_local(fuselage, position);

                /* Check on which side the engine is */
                const bool engine_is_right_of_fuselage = local_position.x() > 0;

                /* Local attachment point at fuselage */
                const geom2::Point_3 local_fuselage = engine_is_right_of_fuselage ?
                    geom2::measure::right(fuselage, local_position.z()) :
                    geom2::measure::left(fuselage, local_position.z());

                /* Local attachment point at nacelle */
                const geom2::Point_3 local_nacelle = engine_is_right_of_fuselage ?
                    geom2::measure::left(nacelle, 0.0) :
                    geom2::measure::right(nacelle, 0.0);

                /* Transform each local coordinate into the global aircraft space */
                const auto global_fuselage = geom2::transform::to_parent(fuselage, local_fuselage);
                const auto global_nacelle = geom2::transform::to_parent(nacelle, local_nacelle) +
                    (position - CGAL::ORIGIN); //Nacelle has the engine position as origin

                /* Return the attachment points in the global aircraft space */
                return {global_nacelle, global_fuselage};
            }
        } // namespace detail

        void Default::initialize()
        {
            /* Loop through all propulsion settings */
            for (const auto &propulsion : this->configuration()->getVector("module_configuration_file/program_settings/propulsion"))
            {
                /* Read the configuration parameters */
                std::string id = propulsion->getStringAttrib("ID");
                std::string nacelle_shape(propulsion->at("pylon/profile/value"));

                /* Transform all strings to lower case */
                std::transform(id.begin(), id.end(), id.begin(), ::tolower);
                std::transform(nacelle_shape.begin(), nacelle_shape.end(), nacelle_shape.begin(), ::tolower);

                /* Set the default or custom settings */
                if (id == "default")
                {
                    /* Set the default engine settings */
                    this->section_profiles[-1] = nacelle_shape;
                }
                else
                {
                    /* Set the specific engine settings */
                    const int engine_id = std::stoi(id);
                    this->section_profiles[engine_id] = nacelle_shape;
                }
            }
        }

        auto Default::select_wing() -> geometry::Wing&
        {
            /*
             * Mirrors design::integration::Default::select_wing() (default_integration.cpp):
             * sorts the wing named in the config to the front of aircraft()->wings and returns
             * it. That function's rotation is a side effect on the SHARED aircraft geometry, done
             * once per engine during the integration phase - for an aircraft with wing-mounted
             * engines on more than one wing (e.g. a tandem-wing front AND rear wing, or a mix of
             * Parent::Wing and Parent::WingBody engines), whichever engine was integrated LAST
             * decides the final order for every module that runs afterwards, including this one.
             * The pylon designer used to just read aircraft()->wings[0] directly everywhere,
             * trusting that order to still be correct by the time it runs - re-deriving the
             * selection here instead makes every pylon computation independent of integration's
             * call order and of how many other engines/wings exist on the aircraft.
             */
            if (this->aircraft()->wings.size() != 1)
            {
                const std::string name =
                    this->configuration()->at("module_configuration_file/program_settings/name_wing_engines/value");

                auto it = std::find_if(this->aircraft()->wings.begin(), this->aircraft()->wings.end(),
                    [&](const auto &wing) { return wing.name == name; });
                if (it != this->aircraft()->wings.end())
                {
                    std::rotate(this->aircraft()->wings.begin(), it, it + 1);
                }
                else
                {
                    utility::print(
                        "[geometry::pylon::Default::select_wing()] "
                        "The wing to carry the engine has not been specified correctly. "
                        "Taking the first one.",
                        Level::Warning);
                }
            }
            return this->aircraft()->wings[0];
        }

        auto Default::get_attachment_points(
            const geom2::Point_3 &position,
            const geometry::Nacelle &nacelle,
            const ParentComponent &parent) -> std::pair<geom2::Point_3, geom2::Point_3>
        {

            /* Check if the parent component is supported */
            if (!detail::supported_parents.contains(parent))
            {
                throw std::runtime_error("[geometry::pylon::Default] The parent component is not supported!");
            }
            /* Get the direction where the pylon should point to */
            switch (std::get<Parent>(parent))
            {
                case Parent::Wing:
                        return geometry::pylon::detail::get_wing_attachment_points(position, nacelle, this->select_wing());
                case Parent::WingBody:
                    return geometry::pylon::detail::get_wing_body_attachment_points(position, nacelle, this->select_wing());
                case Parent::Fuselage:
                    return geometry::pylon::detail::get_fuselage_attachment_points(position, nacelle, this->aircraft()->fuselages[0]);
                case Parent::Empennage:
                default:
                    return {};
            }
        }

        auto Default::get_section_profile(const int engine_id) const -> geom2::AirfoilSection
        {
            /* Read what the user specified for this engine */
            const std::string_view profile_name = this->section_profiles.contains(engine_id)
                                                      ? this->section_profiles.at(engine_id)
                                                      : this->section_profiles.at(-1);

            /* Read the shape from a file */
            geom2::AirfoilSection profile{};

            if (std::filesystem::exists(this->geometry_directory() / profile_name))
                {
                    // If file exists read the file.
                    try
                    {
                        profile.set_contour(geom2::io::read_dat_file(this->geometry_directory() / profile_name));
                    }
                    catch (const std::exception &e)
                    {
                        std::cerr << "Error while reading the file: " << e.what() << '\n';
                        throw; 
                    }
                }
                else
                {
                    // If file does not exist, create it.
                    try
                    {
                        // Construct the file path and convert to absolute path
                        std::filesystem::path filePath = std::filesystem::absolute(this->geometry_directory() / profile_name);
                        // Ensure the directory exists
                        if (!std::filesystem::exists(filePath.parent_path()))
                        {
                            std::filesystem::create_directories(filePath.parent_path());
                        }   
                        std::cout << "File does not exist, create new file: " << this->geometry_directory() / profile_name << '\n';
                        std::ofstream file(this->geometry_directory() / profile_name);
                        if (!file.is_open())
                        {
                            throw std::runtime_error("Error while creating the file for pylon.");
                        }

                        // pylon.dat
                        file << "#NACA0012\n";
                        file << "0\t0\n";
                        file << "0.00024672\t0.00277913\n";
                        file << "0.00098664\t0.00551947\n";
                        file << "0.00221902\t0.00821995\n";
                        file << "0.00394265\t0.0108792\n";
                        file << "0.00615583\t0.01349561\n";
                        file << "0.00885637\t0.01606733\n";
                        file << "0.01204162\t0.01859226\n";
                        file << "0.01570842\t0.02106812\n";
                        file << "0.01985316\t0.02349241\n";
                        file << "0.02447174\t0.02586248\n";
                        file << "0.02955962\t0.02817553\n";
                        file << "0.03511176\t0.03042863\n";
                        file << "0.04112269\t0.03261878\n";
                        file << "0.04758647\t0.0347429\n";
                        file << "0.05449674\t0.03679788\n";
                        file << "0.06184666\t0.03878062\n";
                        file << "0.06962899\t0.04068804\n";
                        file << "0.07783604\t0.04251711\n";
                        file << "0.08645971\t0.04426491\n";
                        file << "0.0954915\t0.04592861\n";
                        file << "0.10492249\t0.04750555\n";
                        file << "0.11474338\t0.04899323\n";
                        file << "0.12494447\t0.05038933\n";
                        file << "0.13551569\t0.05169178\n";
                        file << "0.14644661\t0.05289871\n";
                        file << "0.15772645\t0.05400853\n";
                        file << "0.16934407\t0.05501991\n";
                        file << "0.18128801\t0.05593181\n";
                        file << "0.19354647\t0.05674347\n";
                        file << "0.20610737\t0.05745444\n";
                        file << "0.21895831\t0.05806456\n";
                        file << "0.2320866\t0.05857399\n";
                        file << "0.24547929\t0.05898318\n";
                        file << "0.25912316\t0.05929288\n";
                        file << "0.27300475\t0.05950414\n";
                        file << "0.28711035\t0.05961828\n";
                        file << "0.30142605\t0.0596369\n";
                        file << "0.31593772\t0.05956186\n";
                        file << "0.33063104\t0.05939525\n";
                        file << "0.3454915\t0.0591394\n";
                        file << "0.36050445\t0.05879685\n";
                        file << "0.37565506\t0.05837033\n";
                        file << "0.39092838\t0.05786273\n";
                        file << "0.40630934\t0.05727711\n";
                        file << "0.42178277\t0.05661666\n";
                        file << "0.43733338\t0.05588468\n";
                        file << "0.45294584\t0.05508455\n";
                        file << "0.46860474\t0.05421975\n";
                        file << "0.48429462\t0.05329379\n";
                        file << "0.5\t0.05231025\n";
                        file << "0.51570538\t0.05127272\n";
                        file << "0.53139526\t0.05018478\n";
                        file << "0.54705416\t0.04905004\n";
                        file << "0.56266662\t0.04787208\n";
                        file << "0.57821723\t0.04665444\n";
                        file << "0.59369066\t0.04540065\n";
                        file << "0.60907162\t0.04411417\n";
                        file << "0.62434494\t0.04279845\n";
                        file << "0.63949555\t0.04145686\n";
                        file << "0.6545085\t0.04009273\n";
                        file << "0.66936896\t0.03870931\n";
                        file << "0.68406228\t0.03730984\n";
                        file << "0.69857395\t0.03589746\n";
                        file << "0.71288965\t0.03447529\n";
                        file << "0.72699525\t0.03304638\n";
                        file << "0.74087684\t0.03161375\n";
                        file << "0.75452071\t0.03018037\n";
                        file << "0.7679134\t0.02874916\n";
                        file << "0.78104169\t0.02732304\n";
                        file << "0.79389263\t0.02590486\n";
                        file << "0.80645353\t0.02449747\n";
                        file << "0.81871199\t0.02310368\n";
                        file << "0.83065593\t0.02172629\n";
                        file << "0.84227355\t0.02036807\n";
                        file << "0.85355339\t0.01903179\n";
                        file << "0.86448431\t0.01772019\n";
                        file << "0.87505553\t0.01643599\n";
                        file << "0.88525662\t0.01518188\n";
                        file << "0.89507751\t0.01396055\n";
                        file << "0.9045085\t0.01277464\n";
                        file << "0.91354029\t0.01162677\n";
                        file << "0.92216396\t0.01051952\n";
                        file << "0.93037101\t0.00945542\n";
                        file << "0.93815334\t0.00843693\n";
                        file << "0.94550326\t0.00746647\n";
                        file << "0.95241353\t0.00654638\n";
                        file << "0.95887731\t0.00567891\n";
                        file << "0.96488824\t0.00486623\n";
                        file << "0.97044038\t0.00411038\n";
                        file << "0.97552826\t0.00341331\n";
                        file << "0.98014684\t0.00277684\n";
                        file << "0.98429158\t0.00220264\n";
                        file << "0.98795838\t0.00169224\n";
                        file << "0.99114363\t0.00124702\n";
                        file << "0.99384417\t0.0008682\n";
                        file << "0.99605735\t0.00055681\n";
                        file << "0.99778098\t0.00031372\n";
                        file << "0.99901336\t0.00013959\n";
                        file << "0.99975328\t0.00003492\n";
                        file << "1\t0\n";

                        // second abstract with negative values
                        file << "0\t0\n";
                        file << "0.00024672\t-0.00277913\n";
                        file << "0.00098664\t-0.00551947\n";
                        file << "0.00221902\t-0.00821995\n";
                        file << "0.00394265\t-0.0108792\n";
                        file << "0.00615583\t-0.01349561\n";
                        file << "0.00885637\t-0.01606733\n";
                        file << "0.01204162\t-0.01859226\n";
                        file << "0.01570842\t-0.02106812\n";
                        file << "0.01985316\t-0.02349241\n";
                        file << "0.02447174\t-0.02586248\n";
                        file << "0.02955962\t-0.02817553\n";
                        file << "0.03511176\t-0.03042863\n";
                        file << "0.04112269\t-0.03261878\n";
                        file << "0.04758647\t-0.0347429\n";
                        file << "0.05449674\t-0.03679788\n";
                        file << "0.06184666\t-0.03878062\n";
                        file << "0.06962899\t-0.04068804\n";
                        file << "0.07783604\t-0.04251711\n";
                        file << "0.08645971\t-0.04426491\n";
                        file << "0.0954915\t-0.04592861\n";
                        file << "0.10492249\t-0.04750555\n";
                        file << "0.11474338\t-0.04899323\n";
                        file << "0.12494447\t-0.05038933\n";
                        file << "0.13551569\t-0.05169178\n";
                        file << "0.14644661\t-0.05289871\n";
                        file << "0.15772645\t-0.05400853\n";
                        file << "0.16934407\t-0.05501991\n";
                        file << "0.18128801\t-0.05593181\n";
                        file << "0.19354647\t-0.05674347\n";
                        file << "0.20610737\t-0.05745443\n";
                        file << "0.21895831\t-0.05806456\n";
                        file << "0.2320866\t-0.05857399\n";
                        file << "0.24547929\t-0.05898318\n";
                        file << "0.25912316\t-0.05929288\n";
                        file << "0.27300475\t-0.05950414\n";
                        file << "0.28711035\t-0.05961828\n";
                        file << "0.30142605\t-0.0596369\n";
                        file << "0.31593772\t-0.05956186\n";
                        file << "0.33063104\t-0.05939525\n";
                        file << "0.3454915\t-0.0591394\n";
                        file << "0.36050445\t-0.05879685\n";
                        file << "0.37565506\t-0.05837033\n";
                        file << "0.39092838\t-0.05786273\n";
                        file << "0.40630934\t-0.05727711\n";
                        file << "0.42178277\t-0.05661666\n";
                        file << "0.43733338\t-0.05588468\n";
                        file << "0.45294584\t-0.05508455\n";
                        file << "0.46860474\t-0.05421975\n";
                        file << "0.48429462\t-0.05329379\n";
                        file << "0.5\t-0.05231025\n";
                        file << "0.51570538\t-0.05127272\n";
                        file << "0.53139526\t-0.05018478\n";
                        file << "0.54705416\t-0.04905004\n";
                        file << "0.56266662\t-0.04787208\n";
                        file << "0.57821723\t-0.04665444\n";
                        file << "0.59369066\t-0.04540064\n";
                        file << "0.60907162\t-0.04411417\n";
                        file << "0.62434494\t-0.04279845\n";
                        file << "0.63949555\t-0.04145686\n";
                        file << "0.6545085\t-0.04009273\n";
                        file << "0.66936896\t-0.03870931\n";
                        file << "0.68406228\t-0.03730984\n";
                        file << "0.69857395\t-0.03589746\n";
                        file << "0.71288965\t-0.03447529\n";
                        file << "0.72699525\t-0.03304638\n";
                        file << "0.74087684\t-0.03161375\n";
                        file << "0.75452071\t-0.03018037\n";
                        file << "0.7679134\t-0.02874916\n";
                        file << "0.78104169\t-0.02732304\n";
                        file << "0.79389263\t-0.02590486\n";
                        file << "0.80645353\t-0.02449747\n";
                        file << "0.81871199\t-0.02310368\n";
                        file << "0.83065593\t-0.02172629\n";
                        file << "0.84227355\t-0.02036807\n";
                        file << "0.85355339\t-0.01903179\n";
                        file << "0.86448431\t-0.01772019\n";
                        file << "0.87505553\t-0.01643599\n";
                        file << "0.88525662\t-0.01518188\n";
                        file << "0.89507751\t-0.01396055\n";
                        file << "0.9045085\t-0.01277464\n";
                        file << "0.91354029\t-0.01162677\n";
                        file << "0.92216396\t-0.01051952\n";
                        file << "0.93037101\t-0.00945542\n";
                        file << "0.93815334\t-0.00843693\n";
                        file << "0.94550326\t-0.00746647\n";
                        file << "0.95241353\t-0.00654638\n";
                        file << "0.95887731\t-0.00567891\n";
                        file << "0.96488824\t-0.00486623\n";
                        file << "0.97044038\t-0.00411038\n";
                        file << "0.97552826\t-0.00341331\n";
                        file << "0.98014684\t-0.00277684\n";
                        file << "0.98429158\t-0.00220264\n";
                        file << "0.98795838\t-0.00169224\n";
                        file << "0.99114363\t-0.00124702\n";
                        file << "0.99384417\t-0.0008682\n";
                        file << "0.99605735\t-0.00055681\n";
                        file << "0.99778098\t-0.00031372\n";
                        file << "0.99901336\t-0.00013959\n";
                        file << "0.99975328\t-0.00003492\n";
                        file << "1\t0\n";
                        file.close();

                        // Create the geometry with created file
                        profile.set_contour(geom2::io::read_dat_file(this->geometry_directory() / profile_name));
                    }
                    catch (const std::exception &e)
                    {
                        std::cerr << "Error while creating the file: " << e.what() << '\n';
                        throw; 
                    }
                }

            /* Set section name without the dat part and return it */
            profile.name = profile_name.substr(0, profile_name.size() - 4);

            return profile;
        }
    } // namespace pylon
} // namespace geometry
