/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

#ifndef SRC_PYLON_PYLON_DESIGN_H_
#define SRC_PYLON_PYLON_DESIGN_H_

/* === Includes === */
#include "../propulsion.h"
#include "../propulsion_strategy.h"
#include "../aircraft_geometry.h"
#include <memory>

namespace geometry
{
    /* === Classes === */
    /**
     * @class PylonDesigner
     * @brief The base design class for pylon geometry design.
     *
     */
    class PylonDesigner : public PropulsionStrategy
    {
      public:
        /* === Constructors === */
        /**
         * @brief Construct a new Pylon Designer object
         * @param configuration The module configuration provided by the user.
         * @param aircraft_geometry The aircraft geometry.
         * @param geometry_directory The directory where the geometry files are stored.
         */
        PylonDesigner(
            const std::shared_ptr<node> &configuration,
            const std::shared_ptr<geometry::Aircraft> &aircraft_geometry,
            const std::filesystem::path &geometry_directory)
            : PropulsionStrategy(configuration)
            , aircraft_{aircraft_geometry}
            , geometry_directory_{geometry_directory}
            {}

        /* === Methods === */
        [[nodiscard]] auto geometry_directory() const -> const std::filesystem::path { return this->geometry_directory_; }
        [[nodiscard]] auto aircraft() const -> const std::shared_ptr<geometry::Aircraft> & { return aircraft_; };

      private:
        /* === Properties === */
        const std::shared_ptr<geometry::Aircraft> aircraft_;
        const std::filesystem::path geometry_directory_; /**< The directory where the geometry files are stored. */
    };
}; // namespace geometry

#endif // SRC_PYLON_PYLON_DESIGN_H_
