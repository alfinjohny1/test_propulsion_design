/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

#ifndef SRC_PROPULSION_H_
#define SRC_PROPULSION_H_

/* === Includes === */
#include "aircraft_geometry.h"
#include "mass/point_mass.h"
#include "energy_carrier.h"
#include <algorithm>
#include <array>
#include <memory>
#include <optional>
#include <string>
#include <string_view>
#include <tuple>
#include <utility>
#include <variant>
#include <atmosphere/atmosphere.h>

/* === Types === */
/**
 * @brief Enum to index the components of one propulsion.
 * @details The entry Component::Other is used to specify
 * the number of valid components which is used to size the
 * point masses array.
 */
enum class Component : std::size_t
{
    Engine = 0,
    Nacelle = 1,
    Pylon = 2,
    Other = 3
};

/**
 * @brief Enum specifying valid parent components of a propulsion.
 */
enum class Parent
{
    Fuselage,
    Wing,
    Empennage,
    WingBody
};

/**
 * @brief Enum specifying valid lateral positions in the parent component
 * of a propulsion.
 */
enum class Lateral
{
    Left,
    Mid,
    Right
};

/**
 * @brief Enum specifying valid longitudinal positions in the parent component
 * of a propulsion.
 */
enum class Longitudinal
{
    Front,
    Rear
};

/**
 * @brief Enum specifying valid vertical positions in the parent component
 * of a propulsion.
 */
enum class Vertical
{
    Over,
    Mid,
    Under,
    In
};

/**
 * @brief The type alias for the parent component of a propulsion.
 */
using ParentComponent = std::tuple<Parent, Lateral, Longitudinal, Vertical>;

/* === Classes === */
/**
 * @struct BucketPoint
 * @brief Helper struct which defines a bucket point.
 */
struct BucketPoint
{
    double thrust{-1.0}; /**< [N] The thrust of the bucket point. */
    double tsfc{-1.0};   /**< [(kg/s)/N] The thrust specific fuel consumption of the bucket point. */
};

/**
 * @struct Dimension_3
 * @brief Helper which holds outline dimensions.
 *
 */
struct Dimension_3
{
    double height{0.0}; /**< [m] The height of the object. */
    double width{0.0};  /**< [m] The width of the object.  */
    double length{0.0}; /**< [m] The length of the object. */
};

/**
 * @struct FlightCondition
 * @brief Struct containing the flight condition of the aircraft for which
 * the engine(s) should be designed.
 */
struct FlightCondition
{
    /* @note We cannot use the name *atmosphere* here, because it would shadow the class definition. */
    atmosphere ambiance;  /**< The atmosphere of the flight condition. */
    double altitude{0.0}; /**< [m] The flight altitude of the aircraft. */
    double mach{0.0};     /**< [-] The flight Mach number of the aircraft. */
};

/**
 * @struct Offtakes
 * @brief Helper which holds the additional engine offtake quantities.
 */
struct Offtakes
{
    double bleed_air{0.0};   /**< [kg/s] The bleed air offtake. */
    double shaft_power{0.0}; /**< [W] The shaft power offtake. */
};

/**
 * @struct Fan
 * @brief Represents the properties of a ducted fan.
 */
struct Fan
{
    double diameter{0.0}; /** [m] The diameter of the fan. */
};

/**
 * @struct Propeller
 * @brief Represents the properties of a propeller.
 */
struct Propeller
{
    double diameter{0.0}; /** [m] The diameter of the propeller. */
};

/**
 * @class Propulsion
 * @brief Base class for all propulsion types.
 *
 * @tparam carrier The energy carrier of the propulsion.
 */
template <EnergyCarrierFamily carrier>
class Propulsion
{
  public:
    /* The energy carrier defining the template instances */
    static constexpr EnergyCarrierFamily energy_carrier{carrier}; /** The energy carrier of the propulsion. */

    /* === Constructors === */
    /**
     * @brief Default construct a new Propulsion object.
     *
     */
    Propulsion() = default;

    /**
     * @brief Construct a new Propulsion object
     *
     * @param id The id of the propulsion.
     * @param parent The parent component of the propulsion.
     * @param required_thrust [N] The required thrust of the propulsion.
     * @param required_offtakes [-] The required offtakes of the propulsion.
     */
    Propulsion(const int id, const ParentComponent parent,
               const double required_thrust, const Offtakes &required_offtakes)
               : id_{id}, offtakes_{required_offtakes}, parent_{parent}, required_thrust_{required_thrust}
    {
    }

    /**
     * @brief Construct a new Propulsion object
     *
     * @param id The id of the propulsion.
     * @param parent The parent component of the propulsion.
     * @param required_thrust [N] The required thrust of the propulsion.
     */
    Propulsion(const int id, const ParentComponent parent,
               const double required_thrust)
               : Propulsion(id, parent, required_thrust, Offtakes{})
    {
    }

    /**
     * @brief Construct a new Propulsion object
     *
     * @param id The id of the propulsion.
     * @param parent The parent component of the propulsion.
     */
    Propulsion(const int id, const ParentComponent parent) : Propulsion(id, parent, 0.0) {}

    /**
     * @brief Construct a new Propulsion object
     *
     * @param id The id of the propulsion.
     */
    explicit Propulsion(const int id) : Propulsion(id, ParentComponent{}) {}

    /**
     * @brief Move construct a new Propulsion object.
     * This will swap the properties from the other object to this one.
     *
     * @param other The other propulsion object.
     */
    Propulsion(Propulsion &&other) noexcept
    {
        /* Swap the propulsion */
        this->swap(other);
    }

    /**
     * @brief Move assign a new Propulsion object.
     * This will swap the properties from the other object to this one.
     *
     * @param other The other propulsion object.
     */
    auto operator=(Propulsion &&other) noexcept -> Propulsion &
    {
        /* Swap the propulsion */
        this->swap(other);
        return *this;
    }

    /**
     * @brief Swap the properties of this object with the other one.
     */
    void swap(Propulsion &other) noexcept
    {
        /* Copy the trivial type properties */
        std::swap(this->dimension_, other.dimension_);
        std::swap(this->required_thrust_, other.required_thrust_);
        std::swap(this->id_, other.id_);
        std::swap(this->scale_, other.scale_);

        /* Swap the non trivial type properties */
        std::swap(this->bucket_point_, other.bucket_point_);
        std::swap(this->model_, other.model_);
        std::swap(this->nacelle_, other.nacelle_);
        std::swap(this->offtakes_, other.offtakes_);
        std::swap(this->parent_, other.parent_);
        std::swap(this->pointmasses_, other.pointmasses_);
        std::swap(this->position_, other.position_);
        std::swap(this->pylon_, other.pylon_);
    }

    /* === Deleted Constructors === */
    Propulsion(const Propulsion &other) = delete;
    auto operator=(const Propulsion &other) -> Propulsion & = delete;

    /* === Destructor === */
    virtual ~Propulsion() = default;

    /* === Getters === */
    /**
     * @brief Get the bucket point of the propulsion.
     * @note This is the bucket point which **includes** the engine offtakes.
     *
     * @return BucketPoint [N, kg/Ns] The bucket point (thrust, TSFC) of the propulsion.
     */
    [[nodiscard]] auto bucket_point() const -> BucketPoint { return this->bucket_point_; }

    /**
     * @brief Get the dimension of the propulsion.
     *
     * @return Dimension_3 [m, m, m] The dimension (height, width, length)
     * of the propulsion.
    */
    [[nodiscard]] auto dimension() const -> Dimension_3 { return this->dimension_; }

    /**
     * @brief Get the required thrust of the propulsion.
     *
     * @return double [N] The required thrust of the propulsion.
     */
    [[nodiscard]] auto required_thrust() const -> double { return this->required_thrust_; }

    /**
     * @brief Get the id of the propulsion.
     *
     * @return int The id of the propulsion.
     */
    [[nodiscard]] auto id() const -> int { return this->id_; }

    /**
     * @brief Get the model of the propulsion.
     *
     * @return std::string_view The model of the propulsion.
     */
    [[nodiscard]] auto model() const -> std::string_view { return this->model_; }

    /**
     * @brief Get the nacelle of the propulsion.
     *
     * @return const geometry::Nacelle& The nacelle of the propulsion.
     */
    [[nodiscard]] auto nacelle() const -> const geometry::Nacelle & { return this->nacelle_; }

    /**
     * @brief Get the engine_geom of the propulsion.
     *
     * @return const geometry::Engine_geom& The engine geometry of the propulsion.
     */
    [[nodiscard]] auto engine_geom() const -> const geometry::Engine_geom & { return this->engine_geom_; }

    /**
     * @brief Get the offtakes of the propulsion.
     *
     * @return Offtakes [kg/s, W] The offtakes (bleed air, shaft power) of the propulsion.
     */
    [[nodiscard]] auto offtakes() const -> Offtakes { return this->offtakes_; }

    /**
     * @brief Get the parent component of the propulsion.
     * The parent component defines where the propulsion will
     * be placed on the aircraft.
     *
     * @return ParentComponent The parent component of the propulsion.
     */
    [[nodiscard]] auto parent_component() const -> const ParentComponent { return this->parent_; }

    /**
     * @brief Get the point mass of the propulsion.
     * @note The point mass of the component (i.e. the CG)
     * is in the engine coordinate system!
     *
     * @param component The component of the propulsion.
     * @return PointMass The point mass of the propulsion.
     */
    [[nodiscard]] auto pointmass(const Component component) const -> PointMass { return this->pointmasses_[static_cast<std::size_t>(component)]; }

    /**
     * @brief Get the position of the propulsion.
     *
     * @return geom2::Point_3 [m] The position of the propulsion.
     */
    [[nodiscard]] auto position() const -> geom2::Point_3 { return this->position_; }

    /**
     * @brief Get the pylon of the propulsion.
     *
     * @return const geometry::Pylon& The pylon of the propulsion.
     */
    [[nodiscard]] auto pylon() const -> const geometry::Pylon & { return this->pylon_; }

    /**
     * @brief Get the scale of the propulsion.
     * @attention This is only used to track the
     * result of the engine sizing. It does not
     * affect the other properties of the propulsion.
     *
     * @return double The scale of the propulsion.
     */
    [[nodiscard]] auto scale() const -> double { return this->scale_; }

    /**
     * @brief Get the total mass of the propulsion.
     * @note The point mass of all the components (i.e. the CG)
     * is in the engine coordinate system!
     *
     * @return PointMass The total mass of the propulsion.
     */
    [[nodiscard]] auto total_mass() const -> PointMass { return std::accumulate(this->pointmasses_.begin(), this->pointmasses_.end(), PointMass{}); }

    /* === Setters === */
    /**
     * @brief Set the bucket point of the propulsion.
     * @note This should be the bucket point which **includes** the engine offtakes.
     *
     * @param bucket_point [N, kg/Ns] The bucket point (thrust, TSFC) of the propulsion.
     */
    void set_bucket_point(const BucketPoint &bucket_point) noexcept { this->bucket_point_ = bucket_point; }

    /**
     * @brief Set the dimension of the propulsion.
     *
     * @param dimension [m, m, m] The dimension (height, width, lenght)
     * of the propulsion.
     */
    void set_dimension(const Dimension_3 &dimension) noexcept { this->dimension_ = dimension; }

    /**
     * @brief Set the required thrust of the propulsion.
     *
     * @param thrust [N] The required thrust of the propulsion.
     */
    void set_required_thrust(const double thrust) noexcept { this->required_thrust_ = thrust; }

    /**
     * @brief Set the model name of the propulsion.
     *
     * @param model The model name of the propulsion.
     */
    void set_model(const std::string_view model) noexcept { this->model_ = model; }

    /**
     * @brief Insert the nacelle into the propulsion.
     *
     * @param nacelle The nacelle of the propulsion.
     */
    void set_nacelle(const geometry::Nacelle &nacelle) noexcept { this->nacelle_ = std::move(nacelle); }

        /**
     * @brief Insert the engine (geometry model) into the propulsion.
     *
     * @param engine_geometrymodel The engine_geometrymodel of the propulsion.
     */
    void set_enginegeometry(const geometry::Engine_geom &engine_geom) noexcept { this->engine_geom_ = std::move(engine_geom); }

    /**
     * @brief Set the offtakes of the propulsion.
     *
     * @param offtakes [kg/s, W] The offtakes (bleed air, shaft power) of the propulsion.
     */
    void set_offtakes(const Offtakes &offtakes) noexcept { this->offtakes_ = offtakes; }

    /**
     * @brief Set the parent component of the propulsion.
     * The parent component defines where the propulsion will
     * be placed on the aircraft.
     *
     * @param parent The parent component of the propulsion.
     */
    void set_parent(const ParentComponent &parent) noexcept { this->parent_ = parent; }

    /**
     * @brief Set the point mass of a component of the propulsion.
     * @note The point mass of the component (i.e. the CG)
     * should be in the engine coordinate system!
     *
     * @param component The component of the propulsion.
     * @param pointmass The point mass of the propulsion.
     */
    void set_pointmass(const Component component, const PointMass &pointmass) noexcept { this->pointmasses_[static_cast<std::size_t>(component)] = pointmass; }

    /**
     * @brief Set the position of the propulsion.
     *
     * @param position [m] The position of the propulsion.
     */
    void set_position(const geom2::Point_3 &position) noexcept { this->position_ = position; }

    /**
     * @brief Insert the pylon into the propulsion.
     *
     * @param pylon The pylon of the propulsion.
     */
    void set_pylon(const geometry::Pylon &pylon) noexcept { this->pylon_ = std::move(pylon); }

    /**
     * @brief Set the scale of the propulsion.
     * @attention This is only used to track the
     * result of the engine sizing. It does not
     * affect the other properties of the propulsion!
     *
     * @param scale The scale of the propulsion.
     */
    void set_scale(const double scale) noexcept { this->scale_ = scale; }

    /* === Methods === */
    /**
     * @brief Change the reference frame of the propulsion.
     * @attention This function changes the engine properties!
     * You can use `revert_to_local_reference_frame` to revert
     * the changes.
     * @details This function applies the global reference point
     * to all relevant data for the aircraft XML file. Especially,
     * the mass properties are expected to be in global coordinates
     * and not in the engine local coordinate system.
     *
     * @param global_reference The global reference point of the aircraft.
     */
    void change_to_global_reference_frame(const Eigen::Vector3d &global_reference) {
        /* Remove the reference offset from the engine position */
        this->position_ = {
            this->position_.x() - global_reference.x(),
            this->position_.y() - global_reference.y(),
            this->position_.z() - global_reference.z()
        };

        /* Add the new engine position to each CG to get the global CG */
        for (auto &pointmass : this->pointmasses_) {
            pointmass.CG.x() += this->position_.x();
            pointmass.CG.y() += this->position_.y();
            pointmass.CG.z() += this->position_.z();
        }
    }

    /**
     * @brief Revert the reference frame of the propulsion.
     * @attention This function reverts the changes made by
     * `change_to_global_reference_frame`.
     *
     * @param global_reference The global reference point of the aircraft.
     */
    void revert_to_local_reference_frame(const Eigen::Vector3d &global_reference) {
        /* Remove the global engine position from each CG to get the local CG */
        for (auto &pointmass : this->pointmasses_) {
            pointmass.CG.x() -= this->position_.x();
            pointmass.CG.y() -= this->position_.y();
            pointmass.CG.z() -= this->position_.z();
        }

        /* Add the reference offset to the engine position */
        this->position_ = {
            this->position_.x() + global_reference.x(),
            this->position_.y() + global_reference.y(),
            this->position_.z() + global_reference.z()
        };
    }

  private:
    /* === Properties === */
    BucketPoint bucket_point_{};                                                          /** [-] The bucket point of the propulsion. */
    Dimension_3 dimension_{};                                                             /** [m] The dimension of the propulsion. */
    int id_{0};                                                                           /** [-] The id of the propulsion. */
    std::string model_{};                                                                 /** [-] The model of the propulsion. */
    geometry::Nacelle nacelle_{};                                                         /** [-] The nacelle of the propulsion. */
    geometry::Engine_geom engine_geom_{};                                                     /** [-] The engine geometry of the propulsion. */
    Offtakes offtakes_{};                                                                 /** [-] The offtakes of the propulsion. */
    ParentComponent parent_{};                                                            /** [-] The parent component of the propulsion. */
    std::array<PointMass, static_cast<std::size_t>(Component::Other) + 1> pointmasses_{}; /** [m; kgm^2; kg] The point masses CG, inertia and mass of the propulsion. */
    geom2::Point_3 position_{0, 0, 0};                                                    /** [m] The position of the propulsion which defines the center of the Propeller/Fan */
    geometry::Pylon pylon_{};                                                             /** [-] The pylon of the propulsion. */
    double required_thrust_{0.0};                                                         /** [N] Required thrust - will need to be read in from T/W from arcXML. */
    double scale_{1.0};                                                                   /** [-] The scale of the propulsion. */
};

/**
 * @ref propulsion Types of possible powertrain architectures
 * In the aircraftXML, you can choose in the design spec a powertrain, type and energy_carrier for one propulsor. Following powertrain architectures (powertrain-type-energy_carrier) currently exist:
 * - turbo-fan-kerosene
 *
 * In the future, following is possible:
 *  - turbo-fan-kerosene
 *  - turbo-fan-liquid_hydrogen
 *  - turbo-fan-saf
 *  - turbo-prop-kerosene
 *  - turbo-prop-liquid_hydrogen
 *  - turbo-prop-saf
 *  - electric-fan-battery
 *  - electric-prop-battery
 *  - fuel_cell-fan-kerosene = electric-fan-kerosene
 *  - fuel_cell-fan-liquid_hydrogen = electric-fan-liquid_hydrogen
 *  - fuel_cell-fan-saf = electric-fan-saf
 *  - fuel_cell-prop-kerosene = electric-prop-kerosene
 *  - fuel_cell-prop-liquid_hydrogen = electric-prop-liquid_hydrogen
 *  - fuel_cell-prop-battery
 *  - fuel_cell-prop-saf = electric-prop-saf
 */

/**
 * @class Turbofan
 * @brief Propulsion specialization for turbofan engines.
 *
 * @tparam carrier The energy carrier of the propulsion.
 */
template <EnergyCarrierFamily carrier>
class Turbofan : public Propulsion<carrier>
{
  public:
    Turbofan() = default;
    explicit Turbofan(const int id) : Propulsion<carrier>(id) {}
    Turbofan(const int id, const ParentComponent parent) : Propulsion<carrier>(id, parent) {}
    Turbofan(const int id, const ParentComponent parent, const double required_thrust) : Propulsion<carrier>(id, parent, required_thrust) {}
    Turbofan(const int id, const ParentComponent parent, const double required_thrust, const Offtakes &required_offtakes) : Propulsion<carrier>(id, parent, required_thrust, required_offtakes) {}
    Turbofan(const Turbofan &other) = delete;
    Turbofan(Turbofan &&other) = default;
    auto operator=(const Turbofan &other) -> Turbofan & = delete;
    auto operator=(Turbofan &&other) -> Turbofan & = default;
    ~Turbofan() override = default;

    /* === Getters === */
    [[nodiscard]] auto bypass_ratio() const -> double { return this->bypass_ratio_; }
    [[nodiscard]] auto fan() const -> Fan { return this->fan_; }

    /* === Setters === */
    void set_bypass_ratio(const double bypass_ratio) noexcept { this->bypass_ratio_ = bypass_ratio; }
    void set_fan(const Fan fan) noexcept { this->fan_ = fan; }

  private:
    /* === Properties === */
    Fan fan_{};                /** [-] The fan of the propulsion. */
    double bypass_ratio_{0.0}; /** [-] The bypass ratio of the propulsion. */
};

/**
 * @class Turboprop
 * @brief Propulsion specialization for turboprop engines.
 *
 * @tparam carrier The energy carrier of the propulsion.
 */
template <EnergyCarrierFamily carrier>
class Turboprop : public Propulsion<carrier>
{
  public:
    Turboprop() = default;
    explicit Turboprop(const int id) : Propulsion<carrier>(id) {}
    Turboprop(const int id, const ParentComponent parent) : Propulsion<carrier>(id, parent) {}
    Turboprop(const int id, const ParentComponent parent, const double required_thrust) : Propulsion<carrier>(id, parent, required_thrust) {}
    Turboprop(const int id, const ParentComponent parent, const double required_thrust, const Offtakes &required_offtakes) : Propulsion<carrier>(id, parent, required_thrust, required_offtakes) {}
    Turboprop(const Turboprop &other) = delete;
    Turboprop(Turboprop &&other) = default;
    auto operator=(const Turboprop &other) -> Turboprop & = delete;
    auto operator=(Turboprop &&other) -> Turboprop & = default;
    ~Turboprop() override = default;
};

/**
 * @class Openrotorfan
 * @brief Propulsion specialization for turbofan engines.
 *
 * @tparam carrier The energy carrier of the propulsion.
 */
template <EnergyCarrierFamily carrier>
class Openrotorfan : public Propulsion<carrier>
{
  public:
    Openrotorfan() = default;
    explicit Openrotorfan(const int id) : Propulsion<carrier>(id) {}
    Openrotorfan(const int id, const ParentComponent parent) : Propulsion<carrier>(id, parent) {}
    Openrotorfan(const int id, const ParentComponent parent, const double required_thrust) : Propulsion<carrier>(id, parent, required_thrust) {}
    Openrotorfan(const int id, const ParentComponent parent, const double required_thrust, const Offtakes &required_offtakes) : Propulsion<carrier>(id, parent, required_thrust, required_offtakes) {}
    Openrotorfan(const Openrotorfan &other) = delete;
    Openrotorfan(Openrotorfan &&other) = default;
    auto operator=(const Openrotorfan &other) -> Openrotorfan & = delete;
    auto operator=(Openrotorfan &&other) -> Openrotorfan & = default;
    ~Openrotorfan() override = default;

    /* === Getters === */
    [[nodiscard]] auto bypass_ratio() const -> double { return this->bypass_ratio_; }
    [[nodiscard]] auto fan() const -> Fan { return this->fan_; }

    /* === Setters === */
    void set_bypass_ratio(const double bypass_ratio) noexcept { this->bypass_ratio_ = bypass_ratio; }
    void set_fan(const Fan fan) noexcept { this->fan_ = fan; }

  private:
    /* === Properties === */
    Fan fan_{};                /** [-] The fan of the propulsion. */
    double bypass_ratio_{0.0}; /** [-] The bypass ratio of the propulsion. */
};

/* === Type Aliases === */
/**
 * @brief The type alias for the different propulsion types used
 * for the visitor pattern.
 */
using PropulsionType = std::variant<
    Turbofan<EnergyCarrierFamily::Kerosene>,
    Turbofan<EnergyCarrierFamily::Liquid_Hydrogen>,
    Openrotorfan<EnergyCarrierFamily::Kerosene>,
    Turboprop<EnergyCarrierFamily::Kerosene>,
    Turboprop<EnergyCarrierFamily::Liquid_Hydrogen>>;

/* === Convenience Operators === */
/**
 * @brief Multiply the offtakes with a factor.
 * @note The definition of the operator is done
 * in *utility.cpp*.
 *
 * @param factor The factor to multiply the offtakes with.
 * @param offtakes The offtakes to multiply.
 * @return Offtakes The multiplied offtakes.
 */
auto operator* (const double factor, const Offtakes &offtakes) -> Offtakes;

/**
 * @brief Add two offtakes together.
 * @note The definition of the operator is done
 * in *utility.cpp*.
 *
 * @param lhs The left hand side offtakes.
 * @param rhs The right hand side offtakes.
 * @return Offtakes The sum of the offtakes.
 */
auto operator+ (const Offtakes &lhs, const Offtakes &rhs) -> Offtakes;

#endif // SRC_PROPULSION_H_
