/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

#ifndef SRC_IO_AIRCRAFT_XML_H_
#define SRC_IO_AIRCRAFT_XML_H_

/* === Includes === */
#include "../propulsion.h"
#include "aixml/node.h"
#include <functional>
#include <memory>

namespace io
{
    namespace detail
    {
        /**
         * @class AircraftXMLInterface
         * @brief The abstract interface to the aircraft xml file.
         *
         */
        struct AircraftXMLInterface
        {
            virtual ~AircraftXMLInterface() = default;
            virtual void insert(const geom2::Point_3 &reference_position) = 0;
            virtual void insert(const PointMass &mass_properties) = 0;
            virtual void insert(const Turbofan<EnergyCarrierFamily::Kerosene> &engine) = 0;
            virtual void insert(const Turbofan<EnergyCarrierFamily::Liquid_Hydrogen> &engine) = 0;
            virtual void insert(const Turboprop<EnergyCarrierFamily::Kerosene> &engine) = 0;
            virtual void insert(const Turboprop<EnergyCarrierFamily::Liquid_Hydrogen> &engine) = 0;
            virtual void insert(const Openrotorfan<EnergyCarrierFamily::Kerosene> &engine) = 0;
        };
    }; // namespace detail

    /**
     * @class AircraftXML
     * @brief The main interface to the aircraft xml file.
     *
     */
    class AircraftXML
    {
      public:
        /**
         * @brief Construct a new AircraftXML object.
         * @note The appropriate xml interface implementation
         * is automatically selected based on the provided xml data.
         *
         * @param aircraft_xml The aircraft xml data.
         */
        explicit AircraftXML(std::shared_ptr<node> aircraft_xml);

        /**
         * @brief Insert the reference position into the aircraft xml.
         *
         * @param reference_position The reference position to insert into the xml.
         */
        void insert(const geom2::Point_3 &reference_position)
        {
            this->xml_interface->insert(reference_position);
        }

        /**
         * @brief Insert the mass properties of the propulsion assembly.
         *
         * @param mass_properties The mass properties to insert into the xml.
         */
        void insert(const PointMass &mass_properties)
        {
            this->xml_interface->insert(mass_properties);
        }

        /**
         * @brief Insert the data of a turbofan engine
         * into the aircraft xml.
         *
         * @tparam carrier The energy carrier of the engine.
         * @param engine The engine to insert into the xml.
         */
        template <EnergyCarrierFamily carrier>
        void insert(const Turbofan<carrier> &engine)
        {
            this->xml_interface->insert(engine);
        }

        /**
         * @brief Insert the data of a turboprop engine
         * into the aircraft xml.
         *
         * @tparam carrier The energy carrier of the engine.
         * @param engine The engine to insert into the xml.
         */
        template <EnergyCarrierFamily carrier>
        void insert(const Turboprop<carrier> &engine)
        {
            this->xml_interface->insert(engine);
        }

        /**
         * @brief Insert the data of a turboprop engine
         * into the aircraft xml.
         *
         * @tparam carrier The energy carrier of the engine.
         * @param engine The engine to insert into the xml.
         */
        template <EnergyCarrierFamily carrier>
        void insert(const Openrotorfan<carrier> &engine)
        {
            this->xml_interface->insert(engine);
        }

      private:
        std::unique_ptr<detail::AircraftXMLInterface> xml_interface; /** [-] The pointer to the xml interface. */
    };
}; // namespace io

#endif // SRC_IO_AIRCRAFT_XML_H_
