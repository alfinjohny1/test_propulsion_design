/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include "aircraft_xml.h"
#include <string>
#include <memory>
#include <aixml/endnode.h>
#include <aircraftGeometry2/io/convert.h>

namespace io
{
    namespace detail
    {
        /**
         * @brief Create a endnode object and set its properties.
         *
         * @tparam T The value type of the endnode.
         * @param value The value of the endnode.
         * @param unit The unit of the endnode.
         * @param node_path The location in the parent node of the endnode.
         * @param description The description of the endnode.
         * @return Endnode<T> Return the created endnode.
         */
        template<typename T>
        auto create_endnode(const T value, const std::string& unit, const std::string& node_path, const std::string& description) -> Endnode<T>
        {
            /* Create the node an set its properties */
            Endnode<T> new_node{node_path, description};
            new_node.set_value(value);
            new_node.set_unit(unit);

            /* Return the new node */
            return new_node;
        }

    }; // namespace detail

    /**
     * @class AircraftXMLv3
     * @brief The xml interface for the aircraft xml file version 3.
     *
     */
    class AircraftXMLv3 : public detail::AircraftXMLInterface
    {
      public:
        /* === Constructors ===*/
        /**
         * @brief Construct a new AircraftXMLv3 object.
         *
         * @param aircraft_xml The aircraft xml data.
         */
        explicit AircraftXMLv3(std::shared_ptr<node> aircraft_xml) noexcept
            : aircraft_data(aircraft_xml)
        {
            /* Create the propulsion section if not existing */
            if (!this->aircraft_data->find("aircraft_exchange_file/component_design/propulsion"))
            {
                /* Setup the first node level of the propulsion section */
                this->aircraft_data->operator[]("aircraft_exchange_file/component_design/propulsion") = "";
                this->aircraft_data->operator[]("aircraft_exchange_file/component_design/propulsion/position") = "";
                this->aircraft_data->operator[]("aircraft_exchange_file/component_design/propulsion/mass_properties") = "";
                this->aircraft_data->operator[]("aircraft_exchange_file/component_design/propulsion/specific") = "";
            }
        }

        /* === Destructor === */
        ~AircraftXMLv3() override = default;

        /* === Methods ===*/
        /**
         * @brief Insert the reference position into the xml.
         *
         * @param reference_position The reference position to insert into the xml.
         */
        void insert(const geom2::Point_3 &reference_position) override
        {
            /* Set the node meta data */
            geom2::io::AixmlConverter::NodeInfo info;
            info.name = "position";
            info.description = "Reference position of the propulsion assembly";

            /* Insert the point */
            this->insert_point(
                this->aircraft_data->find("aircraft_exchange_file/component_design/propulsion"),
                reference_position, info);
        }

        /**
         * @brief Insert the mass properties of the propulsion assembly.
         *
         * @param mass_properties The mass properties to insert into the xml.
         */
        void insert(const PointMass &mass_properties) override
        {
            /* Set the node meta data */
            geom2::io::AixmlConverter::NodeInfo info;
            info.name = "mass_properties";
            info.description = "Mass properties of the propulsion assembly";

            /* Insert the properties */
            this->insert_point_mass(
                this->aircraft_data->find("aircraft_exchange_file/component_design/propulsion"),
                mass_properties, info);
        }

        /**
         * @brief Insert the data of a turbofan engine.
         *
         * @param engine The engine to insert into the xml.
         */
        void insert(const Turbofan<EnergyCarrierFamily::Kerosene> &engine) override
        {
            this->insert_propulsion<EnergyCarrierFamily::Kerosene>(engine);
        }

        /**
         * @brief Insert the data of a turboprop engine.
         *
         * @param engine The engine to insert into the xml.
         */
        void insert(const Turbofan<EnergyCarrierFamily::Liquid_Hydrogen> &engine) override
        {
            this->insert_propulsion<EnergyCarrierFamily::Liquid_Hydrogen>(engine);
        }

        /**
         * @brief Insert the data of a turboprop engine.
         *
         * @param engine The engine to insert into the xml.
         */
        void insert(const Turboprop<EnergyCarrierFamily::Kerosene> &engine) override
        {
            this->insert_propulsion<EnergyCarrierFamily::Kerosene>(engine);
        }

        /**
         * @brief Insert the data of a turboprop engine.
         *
         * @param engine The engine to insert into the xml.
         */
        void insert(const Turboprop<EnergyCarrierFamily::Liquid_Hydrogen> &engine) override
        {
            this->insert_propulsion<EnergyCarrierFamily::Liquid_Hydrogen>(engine);
        }

        /**
         * @brief Insert the data of a turbofan engine.
         *
         * @param engine The engine to insert into the xml.
         */
        void insert(const Openrotorfan<EnergyCarrierFamily::Kerosene> &engine) override
        {
            this->insert_propulsion<EnergyCarrierFamily::Kerosene>(engine);
        }

      private:
        /* === Methods === */
        /**
         * @brief Insert the bucket point of a propulsion into the xml.
         *
         * @param target The target node to insert the bucket point into.
         * @param bucket_point The bucket point to insert.
         * @param info The meta data of the bucket point.
         */
        void insert_bucket_point(
            node* target,
            const BucketPoint bucket_point,
            geom2::io::AixmlConverter::NodeInfo info)
        {
            /* Create the bucket point node and use its reference to further access it*/
            node& bucket_point_node = (*target)[info.name];
            bucket_point_node.setAttrib("description", info.description);

            /* Create and add the value end nodes */
            auto thrust_value = detail::create_endnode(bucket_point.thrust, "N", "thrust", "Thrust of the engine at the bucket point");
            thrust_value.update(bucket_point_node);
            auto tsfc_value = detail::create_endnode(bucket_point.tsfc, "kg/Ns", "tsfc", "Thrust specific fuel consumption of the engine at the bucket point");
            tsfc_value.update(bucket_point_node);
        }

        /**
         * @brief Insert a point into the xml.
         *
         * @param target The target node to insert the point into.
         * @param point The point to insert.
         * @param info The meta data of the point.
         */
        void insert_point(node* target, const geom2::Point_3 point, geom2::io::AixmlConverter::NodeInfo info)
        {
            /* Create the position node and use its reference to further access it*/
            node& point_node = (*target)[info.name];
            point_node.setAttrib("description", info.description);

            /* Create and add the value end nodes */
            auto x_value = detail::create_endnode(point.x(), "m", "x", "x coordinate of point");
            auto y_value = detail::create_endnode(point.y(), "m", "y", "y coordinate of point");
            auto z_value = detail::create_endnode(point.z(), "m", "z", "z coordinate of point");
            x_value.update(point_node);
            y_value.update(point_node);
            z_value.update(point_node);
        }

        /**
         * @brief Insert a string into the xml.
         *
         * @param target The target node to insert the string into.
         * @param string The string to insert.
         * @param info The meta data of the string.
         */
        void insert_string(node* target, const std::string_view string, geom2::io::AixmlConverter::NodeInfo info)
        {
            /* Create and add the value end node */
            auto value = Endnode<std::string>{info.name, info.description};
            value = std::string{string};
            value.update(*target);
        }

        /**
         * @brief Insert the mass properties of a point mass into the xml.
         *
         * @param target The target node to insert the point mass into.
         * @param mass_properties The mass properties to insert.
         * @param info The meta data of the point mass.
         */
        void insert_point_mass(node* target, const PointMass point_mass, geom2::io::AixmlConverter::NodeInfo info)
        {
            /* Create the mass properties node and use its reference to further access it*/
            node& mass_properties_node = (*target)[info.name];
            mass_properties_node.setAttrib("description", info.description);

            /* Insert the mass value */
            auto mass_value = detail::create_endnode(point_mass.mass, "kg", "mass", "mass of the of the component");
            mass_value.update(mass_properties_node);

            /* Insert the inertia */
            node& inertia_node = mass_properties_node[static_cast<std::string>("inertia")];
            inertia_node.setAttrib("description", "Inertia of the component in respect to the CG");
            // Ixx
            auto Ixx = detail::create_endnode(point_mass.inertia(0, 0), "kgm^2", "j_xx", "inertia of the component");
            Ixx.update(inertia_node);
            // Iyy
            auto Iyy = detail::create_endnode(point_mass.inertia(1, 1), "kgm^2", "j_yy", "inertia of the component");
            Iyy.update(inertia_node);
            // Izz
            auto Izz = detail::create_endnode(point_mass.inertia(2, 2), "kgm^2", "j_zz", "inertia of the component");
            Izz.update(inertia_node);
            // Ixy
            auto Ixy = detail::create_endnode(point_mass.inertia(0, 1), "kgm^2", "j_xy", "inertia of the component");
            Ixy.update(inertia_node);
            // Ixz
            auto Ixz = detail::create_endnode(point_mass.inertia(0, 2), "kgm^2", "j_xz", "inertia of the component");
            Ixz.update(inertia_node);
            // Iyx
            auto Iyx = detail::create_endnode(point_mass.inertia(1, 0), "kgm^2", "j_yx", "inertia of the component");
            Iyx.update(inertia_node);
            // Iyz
            auto Iyz = detail::create_endnode(point_mass.inertia(1, 2), "kgm^2", "j_yz", "inertia of the component");
            Iyz.update(inertia_node);
            // Izx
            auto Izx = detail::create_endnode(point_mass.inertia(2, 0), "kgm^2", "j_zx", "inertia of the component");
            Izx.update(inertia_node);
            // Izy
            auto Izy = detail::create_endnode(point_mass.inertia(2, 1), "kgm^2", "j_zy", "inertia of the component");
            Izy.update(inertia_node);

            /* Insert the center of gravity */
            node& center_of_gravity_node = mass_properties_node[static_cast<std::string>("center_of_gravity")];
            center_of_gravity_node.setAttrib("description", "Center of gravity of the component with respect to the global coordinate system");
            auto x_value = detail::create_endnode(point_mass.CG(0), "m", "x", "x coordinate of the center of gravity");
            x_value.update(center_of_gravity_node);
            auto y_value = detail::create_endnode(point_mass.CG(1), "m", "y", "y coordinate of the center of gravity");
            y_value.update(center_of_gravity_node);
            auto z_value = detail::create_endnode(point_mass.CG(2), "m", "z", "z coordinate of the center of gravity");
            z_value.update(center_of_gravity_node);
        }

        /**
         * @brief Insert the data of a general propulsion.
         *
         * @tparam carrier The energy carrier of the engine.
         * @param engine The engine to insert into the xml.
         */
        template<EnergyCarrierFamily carrier>
        void insert_propulsion(const Propulsion<carrier> &engine)
        {
            /* Get the propulsion node and create it if not existing */
            node& propulsion_node = (*this->aircraft_data)["aircraft_exchange_file/component_design/propulsion/specific/propulsion@" + std::to_string(engine.id())];
            propulsion_node.setAttrib("description", "Description of one propulsion");

            /* Set the node meta data */
            geom2::io::AixmlConverter::NodeInfo info;

            /* === Nacelle === */
            /* Insert the nacelle */
            info.name = "nacelle";
            info.id = "0";
            info.description = "Nacelle of the propulsion assembly";
            geom2::io::AixmlConverter nacelle_converter(&propulsion_node, info);
            nacelle_converter(geom2::io::Hull{engine.nacelle()});
            propulsion_node.at("nacelle/position").setAttrib("description", "Origin of the nacelle RELATIVE to the engine position.");

            /* Insert nacelle mass properties */
            info.name = "nacelle/mass_properties";
            info.description = "Mass properties of the nacelle";
            this->insert_point_mass(&propulsion_node, engine.pointmass(Component::Nacelle), info);

            /* === Pylon === */
            /* Insert the pylon */
            info.name = "pylon";
            info.id = "0";
            info.description = "pylon of the propulsion assembly";
            geom2::io::AixmlConverter pylon_converter(&propulsion_node, info);
            pylon_converter(geom2::io::AirfoilSurface{engine.pylon()});
            propulsion_node.at("pylon/position").setAttrib("description", "Position of the pylon RELATIVE to the engine position.");

            /* Insert pylon mass properties */
            info.name = "pylon/mass_properties";
            info.description = "Mass properties of the pylon";
            this->insert_point_mass(&propulsion_node, engine.pointmass(Component::Pylon), info);

            /* === Engine Data ===*/
            /* Insert engine model */
            info.name = "engine/model";
            info.description = "Name of selected engine model";
            this->insert_string(&propulsion_node, engine.model(), info);

            /* Insert engine position */
            info.name = "engine/position";
            info.description = "Position of the engine in the global coordinate system";
            this->insert_point(&propulsion_node, engine.position(), info);

            /* Insert engine mass properties */
            info.name = "engine/mass_properties";
            info.description = "Mass properties of the engine";
            this->insert_point_mass(&propulsion_node, engine.pointmass(Component::Engine), info);

            /* Insert SLST*/
            auto SLST = detail::create_endnode(engine.required_thrust(), "N", "engine/SLST", "Sea level static thrust of the engine");
            SLST.update(propulsion_node);

            /* Insert engine scale */
            auto scale = detail::create_endnode(engine.scale(), "1", "engine/scale_factor", "Scale factor of the engine");
            scale.update(propulsion_node);

            /* Insert engine bucket point */
            info.name = "engine/bucket_point";
            info.description = "Bucket point of the engine at initial cruise flight phase";
            this->insert_bucket_point(&propulsion_node, engine.bucket_point(), info);
        }

        /* === Properties ===*/
        std::shared_ptr<node> aircraft_data; /** (-) The aircraft xml data. */
    };

    AircraftXML::AircraftXML(std::shared_ptr<node> aircraft_xml)
    {
        /* Select the fitting xml interface implementation */
        this->xml_interface = std::make_unique<AircraftXMLv3>(aircraft_xml);
    }
}; // namespace io
