/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

#ifndef SRC_IO_ENGINE_XML_H_
#define SRC_IO_ENGINE_XML_H_

/* === Includes === */
#include "../propulsion.h"
#include "aixml/node.h"
#include <engine/engine_data.h>
#include <engine/engine.h>
#include <initializer_list>
#include <ranges>
#include <string>
#include <string_view>

namespace io
{
    /**
     * @brief Takes a range of search paths and finds the
     * path containing the engine model. Then loads the engine
     * XML file and returns the engine data.
     * @note This function assumes that the directory structure
     * is as follows: `search_path/engine_name/engine_name.xml`.
     *
     * @param engine_name The name of the engine model.
     * @param search_paths The paths to search for the engine model.
     * @return The engine data if found in one of the search paths.
     * @throws std::runtime_error if the engine XML file does not exist.
     */
    auto load_engine_data(
        const std::string_view engine_name,
        const std::ranges::input_range auto search_paths) -> EngineData
    {
        /* Get the file extension to search for. */
        std::filesystem::path file_path{engine_name};
        file_path /= engine_name;
        file_path += ".xml";

        std::string paths_searched;

        /* Search for the engine XML file. */
        for (const auto &search_path : search_paths)
        {
            std::filesystem::path engine_xml_path = search_path / file_path;
            if (std::filesystem::exists(engine_xml_path))
            {
                return EngineData{aixml::openDocument(engine_xml_path), true};
            }
            paths_searched += " " + engine_xml_path.string().substr(0, engine_xml_path.string().find(file_path.string())) + " ,";
        }
        throw std::runtime_error("The engine XML file" + file_path.string() + " could not be found in the following folders:" + paths_searched.substr(0, paths_searched.size() - 1));
    }

    /**
     * @brief Overload of the `io::load_engine_data` function to take an
     * initializer list of search paths.
     *
     * @tparam T The type of the search paths.
     * @param engine_name The name of the engine model.
     * @param search_paths The list of search paths.
     * @return EngineData The engine data if found in one of the search paths.
     * @throws std::runtime_error if the engine XML file does not exist.
     */
    template <typename T> requires std::convertible_to<T, std::filesystem::path>
    auto load_engine_data(
        const std::string_view engine_name,
        const std::initializer_list<T> search_paths) -> EngineData
    {
        return load_engine_data(engine_name, std::views::all(search_paths));
    }

    /**
     * @brief Takes a range of search paths and finds the
     * path containing the engine model. Then loads the engine
     * XML file and returns the scaled engine object.
     * @note This function assumes that the directory structure
     * is as follows: `search_path/engine_name/engine_name.xml`.
     *
     * @param engine_name The name of the engine model.
     * @param scale_factor The scale factor of the engine.
     * @param search_paths The paths to search for the engine model.
     * @return The scaled engine if found in one of the search paths.
     * @throws std::runtime_error if the engine XML file does not exist.
     */
    auto load_engine_scaled(
        const std::string_view engine_name,
        const double scale_factor,
        const std::ranges::input_range auto search_paths) -> Engine
    {
        /* Get the folder name to search for. */
        std::filesystem::path file_path{engine_name};

        /* Search for the engine XML file. */
        for (const auto &search_path : search_paths)
        {
            std::filesystem::path engine_xml_path = search_path / file_path;
            if (std::filesystem::exists(engine_xml_path))
            {
                return Engine{engine_xml_path, scale_factor};
            }
        }
        throw std::runtime_error("The engine XML file: " + file_path.string() + " could not be found!");
    }

    /**
     * @brief Overload of the `io::load_engine_scaled` function to take an
     * initializer list of search paths.
     *
     * @tparam T The type of the search paths.
     * @param engine_name The name of the engine model.
     * @param scale_factor The scale factor of the engine.
     * @param search_paths The list of search paths.
     * @return Engine The scaled engine object if found in one of the search paths.
     * @throws std::runtime_error if the engine XML file does not exist.
     */
    template <typename T> requires std::convertible_to<T, std::filesystem::path>
    auto load_engine_scaled(
        const std::string_view engine_name,
        const double scale_factor,
        const std::initializer_list<T> search_paths) -> Engine
    {
        return load_engine_scaled(engine_name, scale_factor, std::views::all(search_paths));
    }

}; // namespace io

#endif // SRC_IO_ENGINE_XML_H_
