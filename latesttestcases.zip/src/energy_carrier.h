/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

#ifndef SRC_ENERGY_CARRIER_H_
#define SRC_ENERGY_CARRIER_H_

/* === Includes === */
#include <unordered_map>

/* === Types === */
/**
 * @brief Enumerates the different available energy carriers.
 */
enum class EnergyCarrierFamily
{
    Kerosene,       /**< Kerosene (Jet A-1) */
    Liquid_Hydrogen /**< Hydrogen */
};

/* === Type Aliases === */
/**
 * @brief Alias for energy carriers map.
 */
using EnergyCarriersMap = std::unordered_map<int, EnergyCarrierFamily>;

#endif // SRC_ENERGY_CARRIER_H_
