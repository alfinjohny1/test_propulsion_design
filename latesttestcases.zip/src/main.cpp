/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */
/* === Includes === */
#include "propulsion_design.h"
#include "toolinfo.h"

/* === Main === */
/**
 * @brief Main executable of the propulsionDesign tool.
 *
 * @param argc The number of command line arguments.
 * @param argv The command line arguments.
 * @return int The exit code of the tool.
 */
int main(int argc, char **argv)
{
    /* Add exception handling since the constructor of the module can throw. */
    try{
        PropulsionDesign propulsion_module(argc, argv, TOOL_NAME, TOOL_VERSION);
        return propulsion_module.execute();
    } catch (const std::string &error) {
        std::cerr << error << std::endl;
    } catch (const std::exception &error) {
        std::cerr << error.what() << std::endl;
    } catch (...) {
        std::cerr << "Unknown error occurred." << std::endl;
    }
    return EXIT_FAILURE;
}
