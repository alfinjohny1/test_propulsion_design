/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

#ifndef SRC_AIRCRAFT_GEOMETRY_H_
#define SRC_AIRCRAFT_GEOMETRY_H_

/* === Includes === */
#include <aircraftGeometry2/geometry/surface.h>
#include <aixml/node.h>
#include <vector>

/* === Classes === */
namespace geometry
{
    /* === Typedefs for the geometry components === */
    using Fuselage = geom2::MultisectionSurface<geom2::PolygonSection>;
    using Wing = geom2::MultisectionSurface<geom2::AirfoilSection>;
    using Nacelle = geom2::MultisectionSurface<geom2::PolygonSection>;
    using Pylon = geom2::MultisectionSurface<geom2::AirfoilSection>;
    using Engine_geom = geom2::MultisectionSurface<geom2::PolygonSection>;

    /* === Classes === */
    /**
     * @struct Aircraft
     * @brief Groups the aircraft geometry components.
     */
    struct Aircraft
    {
        std::vector<Fuselage> fuselages;
        std::vector<Wing> wings;
        std::vector<Wing> empennage;
    };

    /* === Functions === */
    /**
     * @brief Check whether the given entity is aligned parallel
     * to the global Z axis.
     *
     * @param entity The entity to check.
     * @return true If the entity is aligned vertical.
     */
    [[nodiscard, maybe_unused]] static auto is_vertical(const geom2::Entity3D &entity) -> bool
    {
        /* Check whether a line defined by the surface normal is parallel to the z Axis */
        return CGAL::parallel(
            geom2::Line_3(CGAL::ORIGIN, entity.normal),
            geom2::Line_3(CGAL::ORIGIN, geom2::Direction_3{0, 0, 1})
        );
    }
}; // namespace geometry

#endif // SRC_AIRCRAFT_GEOMETRY_H_
