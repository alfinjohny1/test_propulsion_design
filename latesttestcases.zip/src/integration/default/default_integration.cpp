/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include "default_integration.h"
#include <algorithm>
#include <cmath>
#include <aircraftGeometry2/geometry/entity3d.h>

/* === Design implementations === */
namespace design
{
    namespace integration
    {
        auto Default::select_fuselage() -> geometry::Fuselage&
        {
            /** @todo Make it possible to select a fuselage when there are more than one. */
            if (this->aircraft()->fuselages.size() != 1)
            {
                /** @todo Should we throw here or just issue a warning and select the first available fuselage? */
                throw std::runtime_error("[design::integrator::Default::select_fuselage()] The aircraft does not contain exactly one fuselage.");
            }
            return this->aircraft()->fuselages[0];
        }

        auto Default::select_vertical_tail() -> geometry::Wing&
        {
            /* Find the empennage surface which is vertical */
            auto empennage = std::ranges::find_if(this->aircraft()->empennage, geometry::is_vertical);
            if (empennage == this->aircraft()->empennage.end())
            {
                throw std::runtime_error("[design::integrator::Default::select_vertical_tail()] The aircraft does not contain a vertical tail.");
            }

            /* Return the vertical tail */
            return *empennage;
        }

        auto Default::select_wing() -> geometry::Wing& {
        // Search for the wing specified in the config
        // Sort the wwing that is wanted as the first wing
        // If not found, take the first wing and issue a warning
        // This is necessary for the other files that then assume wing zero
        if (this->aircraft()->wings.size() != 1) {
            const std::string name =
                configuration()->at("module_configuration_file/program_settings/name_wing_engines/value");

            auto it = std::find_if(this->aircraft()->wings.begin(), this->aircraft()->wings.end(),
                [&](const auto& wing) {
                    return wing.name == name;
                });
            // Sort wing to the front if found
            if (it != this->aircraft()->wings.end()) {
                std::rotate(this->aircraft()->wings.begin(), it, it + 1);
                } else {
                utility::print(
                "[design::integrator::Default::select_wing()] "
                "The wing to carry the engine has not been specified correctly. "
                "Taking the first one.",
                Level::Warning);
                }
        }
        // Always return the zero wing because it is sorted now
        return this->aircraft()->wings[0];
        }

        auto Default::max_slots_per_side() const -> std::size_t
        {
            switch (this->n_engines_.wing)
            {
            case 2:
                return 1;
            case 4:
                return 2;
            default:
                throw std::runtime_error(
                    "[design::integrator::Default::max_slots_per_side] "
                    "Unsupported number of wing-mounted engines.");
            }
        }
        auto Default::slot_index_on_side(const ParentComponent& parent) const -> std::size_t
        {
            switch (std::get<Parent>(parent))
            {
            case Parent::Wing:
            {
                const std::size_t max_slots = this->max_shift_ids();

                if (max_slots == 0U)
                {
                    return 0U;
                }

                return static_cast<std::size_t>(this->engines_done.wing % max_slots);
            }

            case Parent::Fuselage:
            case Parent::Empennage:
            default:
                return 0U;
            }
        }
        auto Default::max_shift_ids() const -> std::size_t
        {
            if (this->n_engines_.wing > 0)
            {
                return static_cast<std::size_t>(this->n_engines_.wing / 2);
            }

            if (this->n_engines_.fuselage > 0)
            {
                return static_cast<std::size_t>(this->n_engines_.fuselage / 2);
            }

            if (this->n_engines_.empennage > 0)
            {
                return static_cast<std::size_t>(this->n_engines_.empennage);
            }

            return 0U;
        }

        // Calculates the user shift based of the config input
        auto Default::calculate_user_shift(
            geom2::Point_3 position,
            const EngineShift& shift) const -> geom2::Point_3
        {
            return {
                position.x() + shift.x,
                position.y() + shift.y,
                position.z() - shift.z
            };
        }

        //gets the user shift in the config file and does some first order validity checks
        auto Default::get_user_shift(std::size_t slot_index) -> EngineShift
        {
            EngineShift shift{};

            const std::size_t max_slots = this->max_shift_ids();

            if (max_slots == 0U)
            {
                return shift;
            }

            if (slot_index >= max_slots)
            {
                slot_index = max_slots - 1U;

            }

            const std::string engine_shift_base =
                "/module_configuration_file/program_settings/repositioning/engine_shifts";

            std::vector<node*> engine_nodes;
            try
            {
                engine_nodes = this->configuration()->getVector(engine_shift_base + "/engine", 1);
            }
            catch (const std::string&)
            {
                return shift;
            }

            for (node* engine_node : engine_nodes)
            {
                std::string cfg_id;
                try
                {
                    cfg_id = std::string(engine_node->at("id/value", 1));
                }
                catch (const std::string& e)
                {
                    throw std::runtime_error(
                        "[design::integrator::Default::get_user_shift] "
                        "Failed to read id/value from engine shift entry: " + e);
                }

                std::size_t cfg_numeric_id{};
                try
                {
                    cfg_numeric_id = static_cast<std::size_t>(std::stoul(cfg_id));
                }
                catch (...)
                {
                    throw std::runtime_error(
                        "[design::integrator::Default::get_user_shift] "
                        "Configured slot ID '" + cfg_id + "' is not a valid numeric ID.");
                }

                if (cfg_numeric_id >= max_slots)
                {
                    throw std::runtime_error(
                        "[design::integrator::Default::get_user_shift] "
                        "Invalid configuration: slot ID '" + cfg_id +
                        "' is out of range for the wing side.");
                }

                if (cfg_numeric_id == slot_index)
                {
                    shift.x = engine_node->at("shift_x/value", 1);
                    shift.y = engine_node->at("shift_y/value", 1);
                    shift.z = engine_node->at("shift_z/value", 1);

                    utility::print(
                        "[design::integrator::Default::get_user_shift()] "
                        "Applying user shift for slot_index=" + std::to_string(slot_index) +
                        " -> (" + std::to_string(shift.x) + ", "
                        + std::to_string(shift.y) + ", "
                        + std::to_string(shift.z) + ")",
                        Level::Debug);
                    break;
                }
            }

            return shift;
        }

        //gets called in the constructor of Default and validates the user shift inputs
        void Default::validate_user_shift_configuration() const
        {
            const std::string engine_shift_base =
                "/module_configuration_file/program_settings/repositioning/engine_shifts";

            const std::size_t max_allowed = this->max_shift_ids();
            std::set<std::size_t> seen_ids;

            std::vector<node*> engine_nodes;
            try
            {
                engine_nodes = this->configuration()->getVector(engine_shift_base + "/engine", 1);
            }
            catch (const std::string&)
            {
                // No engine_shifts defined -> nothing to validate
                utility::print(
                    "[design::integrator::Default::validate_user_shift_configuration()] "
                    "No engine shift entries found. Using default (zero) shifts.",
                    Level::Info);
                return;
            }

            utility::print(
                "[design::integrator::Default::validate_user_shift_configuration()] "
                "Found " + std::to_string(engine_nodes.size()) + " engine shift entries.",
                Level::Info);

            for (node* engine_node : engine_nodes)
            {
                std::string cfg_id;
                try
                {
                    cfg_id = std::string(engine_node->at("id/value", 1));
                }
                catch (const std::string& e)
                {
                    throw std::runtime_error(
                        "[design::integrator::Default::validate_user_shift_configuration] "
                        "Failed to read id/value from engine shift entry: " + e);
                }

                std::size_t cfg_numeric_id{};
                try
                {
                    cfg_numeric_id = static_cast<std::size_t>(std::stoul(cfg_id));
                }
                catch (...)
                {
                    throw std::runtime_error(
                        "[design::integrator::Default::validate_user_shift_configuration] "
                        "Configured engine slot ID '" + cfg_id + "' is not a valid numeric ID.");
                }

                if (cfg_numeric_id >= max_allowed)
                {
                    throw std::runtime_error(
                        "[design::integrator::Default::validate_user_shift_configuration] "
                        "Invalid configuration: engine slot ID '" + cfg_id +
                        "' is out of range. Allowed slot IDs are 0 to " +
                        std::to_string(max_allowed - 1) + ".");
                }

                if (!seen_ids.insert(cfg_numeric_id).second)
                {
                    throw std::runtime_error(
                        "[design::integrator::Default::validate_user_shift_configuration] "
                        "Duplicate shift definition for propulsor ID '" + cfg_id + "'.");
                }
            }

            if (engine_nodes.size() > max_allowed)
            {
                throw std::runtime_error(
                    "[design::integrator::Default::validate_user_shift_configuration] "
                    "Too many propulsor shift entries defined in configuration.");
            }
        }
        auto Default::find_kink_span_position(const geometry::Wing &wing, double min_abs_span) const -> std::optional<double>
        {
            /*
             * A kink shows up as the interior section where the leading-edge sweep
             * slope (dx/dz between consecutive sections) changes noticeably - i.e.
             * where the otherwise straight leading-edge line bends. This works
             * purely off the generated wing geometry (wing.sections), independent
             * of which wing_design strategy produced it.
             *
             * min_abs_span excludes candidates too close to the centerline (e.g. inside
             * the fuselage width): a slope change there - from a wing-fuselage fairing/
             * fillet, for instance - is not a kink an engine could ever be mounted at,
             * so we keep scanning outboard instead of stopping at the first one found.
             */
            constexpr double slope_tolerance = 1e-3; // [-] minimum slope change to count as a kink
            const auto &sections = wing.sections;
            if (sections.size() < 3)
            {
                /* Root + tip only -> no interior section, so no kink can exist */
                return std::nullopt;
            }

            for (std::size_t i = 1; i + 1 < sections.size(); ++i)
            {
                if (std::abs(sections[i].origin.z()) < min_abs_span)
                {
                    continue;
                }
                const double dz_prev = sections[i].origin.z() - sections[i - 1].origin.z();
                const double dz_next = sections[i + 1].origin.z() - sections[i].origin.z();
                if (std::abs(dz_prev) < 1e-9 || std::abs(dz_next) < 1e-9)
                {
                    continue;
                }
                const double slope_prev = (sections[i].origin.x() - sections[i - 1].origin.x()) / dz_prev;
                const double slope_next = (sections[i + 1].origin.x() - sections[i].origin.x()) / dz_next;
                if (std::abs(slope_next - slope_prev) > slope_tolerance)
                {
                    return sections[i].origin.z();
                }
            }
            return std::nullopt;
        }
    }; // namespace integration
}; // namespace design
