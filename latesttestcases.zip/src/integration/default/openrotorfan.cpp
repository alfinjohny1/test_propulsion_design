/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include "default_integration.h"
#include <aircraftGeometry2/processing/measure.h>
#include <aircraftGeometry2/processing/transform.h>
#include <cmath>
#include "../../utility.h"

/* === Design implementations === */
namespace design
{
    namespace integration
    {
        namespace detail
        {
            /**
             * @brief Set of supported parent components for the engine integration.
             */
            const std::set<ParentComponent> supported_parents = {
                {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under},
                {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under},
                {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::In},
                {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::In},
                {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Over},
                {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Over},
                {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Mid},
                {Parent::Fuselage, Lateral::Left, Longitudinal::Rear, Vertical::Mid},
                {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Over},
                {Parent::Fuselage, Lateral::Left, Longitudinal::Rear, Vertical::Over},
                {Parent::Empennage, Lateral::Mid, Longitudinal::Front, Vertical::In}};
        } // namespace detail

        template <EnergyCarrierFamily EC>
        void Default::openrotorfan_method(Openrotorfan<EC> &engine)
        {
            /* Check whether the parent component is supported */
            if (!detail::supported_parents.contains(engine.parent_component()))
            {
                throw std::runtime_error("[design::integrator::Default] The parent component or location of the engine is not supported.");
            }

            /* Check whether valid aircraft geometry was provided */
            if (this->aircraft())
            {
                /* Check which parent component this engine has */
                switch (std::get<Parent>(engine.parent_component()))
                {
                    case Parent::Wing:
                        /* Integrate the engine into the wing */
                        if (std::get<Vertical>(engine.parent_component()) == Vertical::Under)
                        {
                            integrate_under_wing(engine);
                        }
                        else if (std::get<Vertical>(engine.parent_component()) == Vertical::Over)
                        {
                            integrate_over_wing(engine);
                        }
                        else
                        {
                            integrate_into_wing(engine);
                        }
                        break;
                    case Parent::Fuselage:
                        if (std::get<Vertical>(engine.parent_component()) != Vertical::Over)
                        {
                            //throw std::runtime_error("[design::integrator::Default] The engine is not under the wing. This method is not applicable.");
                            integrate_into_fuselage(engine);
                        }
                        else
                        {
                        /* Integrate the engine into the fuselage */
                            integrate_into_fuselage_top(engine);
                        }
                        break;
                    case Parent::Empennage:
                        /* Integrate the engine into the empennage */
                        integrate_into_empennage(engine);
                        break;
                    default:
                        throw std::runtime_error("[design::integrator::Default] The parent component of the engine is not supported.");
                }
            }
            else
            {
                /* When no aircraft geometry exists we need to guess the initial engine position */
                this->guess_position(engine);
            }

            /* At this point we can assume the engine was placed successfully */
            this->parents_placed.insert(engine.parent_component());
        }

        template <EnergyCarrierFamily EC>
        void Default::integrate_over_wing(Openrotorfan<EC> &engine)
        {
            /*
             * => This method follows the procedure described in \cite Ata10
             * It assumes one main wing which is extruded in global Y direction
             */
            /** @fixed Add a warning when the aircraft contains more than one wing or fuselage */
            const auto &wing = this->select_wing();
            const auto &fuselage = this->select_fuselage();
            const double sign_wing_extrusion = std::signbit(wing.sections.back().origin.z()) ? -1.0 : 1.0;
            if (wing.normal != geom2::Direction_3{0, sign_wing_extrusion * 1, 0})
            {
                throw std::runtime_error("[design::integrator::Default] The wing is not oriented in y-direction. This method is not applicable.");
            }
            if (std::get<Vertical>(engine.parent_component()) != Vertical::Under)
            {
                //throw std::runtime_error("[design::integrator::Default] The engine is not under the wing. This method is not applicable.");
            }

            /* When the current parent position is already placed, we assume this is the outer engine */
            bool is_outer = this->parents_placed.contains(engine.parent_component());
            
            /* Check whether there is still space for the engine to be integrated */
            switch (this->n_engines_.wing)
            {
                case 4:
                    /* Check whether the outer position is already placed */
                    if (is_outer && this->engines_done.wing % 2)
                    {
                        break;
                    }
                    [[fallthrough]];
                case 2:
                    /* At this point there does not exist an outer engine position */
                    if (is_outer)
                    {
                        throw std::runtime_error("[design::integrator::Default] No space on the wing for the engine to be integrated.");
                    }
                    break;
                default:
                    throw std::runtime_error("[design::integrator::Default] The number of engines on the wing is not supported.");
            }

            /* !!!
             * The following assumes the wing local coordinate system:
             * - X axis: chord direction
             * - Y axis: height direction
             * - Z axis: span direction (should be negative coordinates)
             * !!!
             */
            /* Get the relevant measurements from the aircraft */
            const double span = geom2::measure::span(wing);
            const double width_fuselage = geom2::measure::width_max(fuselage);
            const double diameter_max = engine.fan().diameter;

            /* Wing local z position of engine */
            const double span_engine = sign_wing_extrusion * this->calculate_span_position_openrotor(
                                                                 width_fuselage, diameter_max, span, is_outer);

            /* Get the wing quarter coordinate at the engine span position */
            const double wing_chord = geom2::measure::chord(wing, span_engine);
            const auto wing_quarter =
                geom2::measure::offset_LE(wing, span_engine) +
                geom2::Vector_3{0.25 * wing_chord, 0, 0};

            /* Wing local x position of engine */
            const double chord_engine = 0.3 * wing_chord + geom2::measure::offset_LE(wing, span_engine).x(); // \cite Ata10 p. 48f

            /* Wing local y position of engine */
            const double height_engine = wing_quarter.y() +
                                         0.65 * diameter_max;

            /* Adjust whether the engine is left or right */
            auto position = geom2::Point_3{chord_engine, height_engine, span_engine};
            auto parent = engine.parent_component();

            const std::size_t slot_index_on_side = this->slot_index_on_side(parent);
            EngineShift shift = this->get_user_shift(slot_index_on_side);

            if (std::get<Lateral>(engine.parent_component()) == Lateral::Left)
            {
                position = { position.x(), position.y(), -position.z() };
                shift.z = -shift.z;
            }

            position = this->calculate_user_shift(position, shift);

            /* Set the position of the engine in the GLOBAL (!) reference frame */
            engine.set_position(geom2::transform::to_parent(wing, position));
            ++this->engines_done.wing;
        }

        template <EnergyCarrierFamily EC>
        void Default::integrate_under_wing(Openrotorfan<EC> &engine)
        {
            /*
             * => This method follows the procedure described in \cite Ata10
             * It assumes one main wing which is extruded in global Y direction
             */
            /** @fixed Add a warning when the aircraft contains more than one wing or fuselage */
            const auto &wing = this->select_wing();
            const auto &fuselage = this->select_fuselage();
            const double sign_wing_extrusion = std::signbit(wing.sections.back().origin.z()) ? -1.0 : 1.0;
            if (wing.normal != geom2::Direction_3{0, sign_wing_extrusion * 1, 0})
            {
                throw std::runtime_error("[design::integrator::Default] The wing is not oriented in y-direction. This method is not applicable.");
            }
            if (std::get<Vertical>(engine.parent_component()) != Vertical::Under)
            {
                //throw std::runtime_error("[design::integrator::Default] The engine is not under the wing. This method is not applicable.");
            }  
            /* When the current parent position is already placed, we assume this is the outer engine */
            bool is_outer = this->parents_placed.contains(engine.parent_component());
            
            /* Check whether there is still space for the engine to be integrated */
            switch (this->n_engines_.wing)
            {
                case 4:
                    /* Check whether the outer position is already placed */
                    if (is_outer && this->engines_done.wing % 2)
                    {
                        break;
                    }
                    [[fallthrough]];
                case 2:
                    /* At this point there does not exist an outer engine position */
                    if (is_outer)
                    {
                        throw std::runtime_error("[design::integrator::Default] No space on the wing for the engine to be integrated.");
                    }
                    break;
                default:
                    throw std::runtime_error("[design::integrator::Default] The number of engines on the wing is not supported.");
            }

            /* !!!
             * The following assumes the wing local coordinate system:
             * - X axis: chord direction
             * - Y axis: height direction
             * - Z axis: span direction (should be negative coordinates)
             * !!!
             */
            /* Get the relevant measurements from the aircraft */
            const double span = geom2::measure::span(wing);
            const double width_fuselage = geom2::measure::width_max(fuselage);
            const double diameter_max = 1.21 * engine.fan().diameter;

            /* Wing local z position of engine with more safety factor to minimize risk of damaging fuselage */
            const double span_engine = 1.3 * sign_wing_extrusion * this->calculate_span_position_openrotor(
                                                                 width_fuselage, diameter_max, span, is_outer);

            /* Get the wing quarter coordinate at the engine span position */
            const double wing_chord = geom2::measure::chord(wing, span_engine);
            const auto wing_quarter =
                geom2::measure::offset_LE(wing, span_engine) +
                geom2::Vector_3{0.25 * wing_chord, 0, 0};

            /* Wing local x position of engine */
            const double chord_engine = 0.5 * wing_chord;

            /* Wing local y position of engine */
            const double height_engine = wing_quarter.y() -
                                         0.3 * geom2::measure::height_max(engine.nacelle()); 

            /* Adjust whether the engine is left or right */
            auto position = geom2::Point_3{ chord_engine, height_engine, span_engine };
            auto parent = engine.parent_component();

            const std::size_t slot_index_on_side = this->slot_index_on_side(parent);
            EngineShift shift = this->get_user_shift(slot_index_on_side);

            if (std::get<Lateral>(engine.parent_component()) == Lateral::Left)
            {
                position = { position.x(), position.y(), -position.z() };
                shift.z = -shift.z;
            }

            position = this->calculate_user_shift(position, shift);

            /* Set the position of the engine in the GLOBAL (!) reference frame */
            engine.set_position(geom2::transform::to_parent(wing, position));
            ++this->engines_done.wing;
        }

        template <EnergyCarrierFamily EC>
        void Default::integrate_into_wing(Openrotorfan<EC> &engine)
        {
            /*
             * => This method follows the procedure described in \cite Ata10
             * It assumes one main wing which is extruded in global Y direction
             */
            /** @fixed Add a warning when the aircraft contains more than one wing or fuselage */
            const auto &wing = this->select_wing();
            const auto &fuselage = this->select_fuselage();
            const double sign_wing_extrusion = std::signbit(wing.sections.back().origin.z()) ? -1.0 : 1.0;
            if (wing.normal != geom2::Direction_3{0, sign_wing_extrusion * 1, 0})
            {
                throw std::runtime_error("[design::integrator::Default] The wing is not oriented in y-direction. This method is not applicable.");
            }
            if (std::get<Vertical>(engine.parent_component()) != Vertical::Under)
            {
                //throw std::runtime_error("[design::integrator::Default] The engine is not under the wing. This method is not applicable.");
            }  
            auto parent = engine.parent_component();

            const std::size_t slot_index_on_side = this->slot_index_on_side(parent);
            const bool is_outer = (slot_index_on_side > 0);

            if (slot_index_on_side >= this->max_slots_per_side())
            {
                throw std::runtime_error(
                    "[design::integrator::Default] No space on the wing for the engine to be integrated.");
            }
            
            /* Check whether there is still space for the engine to be integrated */
            switch (this->n_engines_.wing)
            {
                case 4:
                    /* Check whether the outer position is already placed */
                    if (is_outer && this->engines_done.wing % 2)
                    {
                        break;
                    }
                    [[fallthrough]];
                case 2:
                    /* At this point there does not exist an outer engine position */
                    if (is_outer)
                    {
                        throw std::runtime_error("[design::integrator::Default] No space on the wing for the engine to be integrated.");
                    }
                    break;
                default:
                    throw std::runtime_error("[design::integrator::Default] The number of engines on the wing is not supported.");
            }

            /* !!!
             * The following assumes the wing local coordinate system:
             * - X axis: chord direction
             * - Y axis: height direction
             * - Z axis: span direction (should be negative coordinates)
             * !!!
             */
            /* Get the relevant measurements from the aircraft */
            const double span = geom2::measure::span(wing);
            const double width_fuselage = geom2::measure::width_max(fuselage);
            const double diameter_max = 1.21 * engine.fan().diameter;

            /* Wing local z position of engine */
            const double span_engine = sign_wing_extrusion * this->calculate_span_position_openrotor(
                                                                 width_fuselage, diameter_max, span, is_outer);

            /* Get the wing quarter coordinate at the engine span position */
            const double wing_chord = geom2::measure::chord(wing, span_engine);
            const auto wing_quarter =
                geom2::measure::offset_LE(wing, span_engine) +
                geom2::Vector_3{0.25 * wing_chord, 0, 0};

            /* Wing local x position of engine */
            const double chord_engine = wing_chord + 0.0 * geom2::measure::offset_LE(wing, span_engine).x(); // \cite Ata10 p. 48f

            /* Wing local y position of engine */
            const double height_engine = 0.0; 

            /* Adjust whether the engine is left or right */
            auto position = geom2::Point_3{chord_engine, height_engine, span_engine};
            EngineShift shift = this->get_user_shift(slot_index_on_side);

            if (std::get<Lateral>(engine.parent_component()) == Lateral::Left)
            {
                position = { position.x(), position.y(), -position.z() };
                shift.z = -shift.z;
            }

            position = this->calculate_user_shift(position, shift);

            /* Set the position of the engine in the GLOBAL (!) reference frame */
            engine.set_position(geom2::transform::to_parent(wing, position));
            ++this->engines_done.wing;
        }

        template <EnergyCarrierFamily EC>
        void Default::integrate_into_fuselage_top(Openrotorfan<EC> &engine)
        {
            /*
             * It assumes one main fuselage which is extruded in global X direction
             */
            const auto &fuselage = this->select_fuselage();
            const double sign_extrusion = std::signbit(fuselage.sections.back().origin.z()) ? -1.0 : 1.0;
            if (fuselage.normal != geom2::Direction_3{sign_extrusion * 1, 0, 0})
            {
                throw std::runtime_error("[design::integrator::Default] The fuselage is not oriented in x-direction. This method is not applicable.");
            }

            /* Only two engines on the fuselage are supported right now */
            if (this->n_engines_.fuselage != 2)
            {
                throw std::runtime_error("[design::integrator::Default] The number of engines on the fuselage is not supported.");
            }

            /* Check whether there is still space for the engine to be integrated */
            if (this->parents_placed.contains(engine.parent_component()))
            {
                throw std::runtime_error("[design::integrator::Default] No space left on the fuselage for the engine to be integrated.");
            }

            /* !!!
             * The following assumes the fuselage local coordinate system:
             * - X axis: width direction
             * - Y axis: height direction
             * - Z axis: length direction
             * !!!
             */
            /* Get the engine position in local z direction */
            const double z_engine = sign_extrusion * 0.9 * geom2::measure::length(fuselage);

            /* Get the engine position in local y direction */
            const double y_engine = 1.1 * geom2::measure::height(fuselage, z_engine);

            /* Get the engine position in local x direction */
            const double x_engine = 0.9 * geom2::measure::width_max(engine.nacelle());

            /* Adjust whether engine is left or right */
            auto position = geom2::Point_3{x_engine, y_engine, z_engine};
            auto parent = engine.parent_component();

            const std::size_t slot_index_on_side = this->slot_index_on_side(parent);
            EngineShift shift = this->get_user_shift(slot_index_on_side);

            if (std::get<Lateral>(engine.parent_component()) == Lateral::Left)
            {
                position = { position.x(), position.y(), -position.z() };
                shift.z = -shift.z;
            }

            position = this->calculate_user_shift(position, shift);

            /* Set the position of the engine in the GLOBAL (!) reference frame */
            engine.set_position(geom2::transform::to_parent(fuselage,position));
            ++this->engines_done.fuselage;
        }

        template <EnergyCarrierFamily EC>
        void Default::integrate_into_fuselage(Openrotorfan<EC> &engine)
        {
            /*
             * => This method follows the procedure described in \cite Ata10
             * It assumes one main fuselage which is extruded in global X direction
             */
            /** @fixed Add a warning when there are more than one fuselages */
            const auto &fuselage = this->select_fuselage();
            const double sign_extrusion = std::signbit(fuselage.sections.back().origin.z()) ? -1.0 : 1.0;
            if (fuselage.normal != geom2::Direction_3{sign_extrusion * 1, 0, 0})
            {
                throw std::runtime_error("[design::integrator::Default] The fuselage is not oriented in x-direction. This method is not applicable.");
            }

            /* Only two engines on the fuselage are supported right now */
            if (this->n_engines_.fuselage != 2)
            {
                throw std::runtime_error("[design::integrator::Default] The number of engines on the fuselage is not supported.");
            }

            /* Check whether there is still space for the engine to be integrated */
            if (this->parents_placed.contains(engine.parent_component()))
            {
                throw std::runtime_error("[design::integrator::Default] No space left on the fuselage for the engine to be integrated.");
            }

            /* !!!
             * The following assumes the fuselage local coordinate system:
             * - X axis: width direction
             * - Y axis: height direction
             * - Z axis: length direction
             * !!!
             */
            /* Get the engine position in local z direction */
            const double z_engine = sign_extrusion * 0.9 * geom2::measure::length(fuselage);

            /* Get the engine position in local y direction */
            const double y_engine = 0.65 * geom2::measure::height(fuselage, z_engine);

            /* Get the engine position in local x direction */
            const double x_engine = 0.2 * geom2::measure::width(fuselage, z_engine) +
                                    geom2::measure::width_max(engine.nacelle());

            /* Adjust whether engine is left or right */
            auto position = geom2::Point_3{x_engine, y_engine, z_engine};
            
            auto parent = engine.parent_component();

            const std::size_t slot_index_on_side = this->slot_index_on_side(parent);
            EngineShift shift = this->get_user_shift(slot_index_on_side);

            if (std::get<Lateral>(engine.parent_component()) == Lateral::Left)
            {
                position = { position.x(), position.y(), -position.z() };
                shift.z = -shift.z;
            }

            position = this->calculate_user_shift(position, shift);

            /* Set the position of the engine in the GLOBAL (!) reference frame */
            engine.set_position(geom2::transform::to_parent(fuselage,position));
            ++this->engines_done.fuselage;
        }

        template <EnergyCarrierFamily EC>
        void Default::integrate_into_empennage(Openrotorfan<EC> &engine)
        {
            /* Get the first empennage surface */
            /** @fixed Make the selection which empennage surface to integrate the engine into a bit smarter. */
            const auto &empennage = this->select_vertical_tail();
            const auto &fuselage = this->select_fuselage();

            /* Check whether there is still space for the engine to be integrated */
            if (this->parents_placed.contains(engine.parent_component()))
            {
                throw std::runtime_error("[design::integrator::Default] No space left on the empennage for the engine to be integrated.");
            }

            /* Check whether the empennage surface is in line with the fuselage center */
            if (std::abs(fuselage.origin.y() - empennage.origin.y()) > 1e-4)
            {
                throw std::runtime_error(
                    "[design::integrator::Default] The empennage is not in line with the fuselage center. "
                    "This method is not applicable!");
            }

            /* Get quarter line point at the mac position of the empennage surface */
            const auto p_25_local = geom2::measure::mean_aerodynamic_chord_position(empennage);
            const auto p_25_global = geom2::transform::to_parent(empennage, p_25_local);
            const auto p_25_fuselage = geom2::transform::to_local(fuselage, p_25_global);

            /* Calculate the engine position */
            const auto position = geom2::Point_3{
                p_25_global.x() - 0.25 * engine.dimension().length, // Place engine 25% in front of quarter line
                fuselage.origin.y(),                                // Place engine in the middle of the fuselage
                0.5 * geom2::measure::height(fuselage, p_25_fuselage.z()) + 1.25 * 0.5 * engine.dimension().width};

            /* Set the position of the engine */
            engine.set_position(position);
            ++this->engines_done.empennage;
        }

        template <EnergyCarrierFamily EC>
        void Default::guess_position(Openrotorfan<EC> &engine)
        {
            /* Guess the position of the engine based on their parent component */
            switch (std::get<Parent>(engine.parent_component()))
            {
                /* For now place everything at the origin */
                case Parent::Wing:
                case Parent::Fuselage:
                case Parent::Empennage:
                default:
                    /* Fall back to ORIGIN as the default position */
                    engine.set_position(CGAL::ORIGIN);
                    break;
            }
        }

        auto Default::calculate_span_position_openrotor(
            const double width_fuselage,
            const double diameter_engine_max,
            const double wing_span,
            const bool is_outer) const -> double
        {
            /* How many engines on the wing */
            if (this->n_engines_.wing == 2)
            {
                return (width_fuselage / 2.0 +
                               0.5 * diameter_engine_max);
            }
            else if (this->n_engines_.wing == 4)
            {
                /* Return the position whether the engine is on the outer
                 * or inner side of the wing.
                 */
                if (is_outer)
                {
                    return 0.64 * wing_span / 2.0;
                }
                return (0.9 / 4.0) * (0.64 * wing_span +
                                    width_fuselage -
                                    diameter_engine_max);
            }
            /* Not a valid engine on the wing count */
            throw std::runtime_error("[design::integrator::Default] The number of engines on the wing is not valid.");
        }

        void Default::operator()(Openrotorfan<EnergyCarrierFamily::Kerosene>& engine)
        {
            openrotorfan_method(engine);
        };

    } // namespace integration
} // namespace design
