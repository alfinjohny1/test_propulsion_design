/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include "default_integration.h"
#include <aircraftGeometry2/processing/measure.h>
#include <aircraftGeometry2/processing/transform.h>
#include <cmath>
#include <unitConversion/constants.h>
#include "../../utility.h"

/* === Design implementations === */
namespace design
{
    namespace integration
    {
        namespace detail
        {
            /**
             * @brief Set of supported parent components for the engine integration.
             */
            const std::set<ParentComponent> supported_parents = {
                {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under},
                {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under},
                {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Over},
                {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Over},
                {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Mid},
                {Parent::Fuselage, Lateral::Left, Longitudinal::Rear, Vertical::Mid},
                {Parent::Empennage, Lateral::Mid, Longitudinal::Front, Vertical::In},
                {Parent::WingBody, Lateral::Right, Longitudinal::Rear, Vertical::Over},
                {Parent::WingBody, Lateral::Left, Longitudinal::Rear, Vertical::Over} };
        } // namespace detail

        template <EnergyCarrierFamily EC>
        void Default::turbofan_method(Turbofan<EC> &engine)
        {
            /* Check whether the parent component is supported */
            if (!detail::supported_parents.contains(engine.parent_component()))
            {
                throw std::runtime_error("[design::integrator::Default] The parent component or location of the engine is not supported.");
            }

            /* Check whether valid aircraft geometry was provided */
            if (this->aircraft())
            {
                /* Check which parent component this engine has */
                switch (std::get<Parent>(engine.parent_component()))
                {
                    case Parent::Wing:
                        /* Integrate the engine into the wing */
                        integrate_into_wing(engine);
                        break;
                    case Parent::Fuselage:
                        /* Integrate the engine into the fuselage */
                        integrate_into_fuselage(engine);
                        break;
                    case Parent::Empennage:
                        /* Integrate the engine into the empennage */
                        integrate_into_empennage(engine);
                        break;
                    case Parent::WingBody:
                        /* Integrate the engine into the wing-body */
                        integrate_into_wing_body(engine);
                        break;
                    default:
                        throw std::runtime_error("[design::integrator::Default] The parent component of the engine is not supported.");
                }
            }
            else
            {
                /* When no aircraft geometry exists we need to guess the initial engine position */
                this->guess_position(engine);
            }

            /* At this point we can assume the engine was placed successfully */
            this->parents_placed.insert(engine.parent_component());
        }

        template <EnergyCarrierFamily EC>
        void Default::integrate_into_wing(Turbofan<EC> &engine)
        {
            /*
             * => This method follows the procedure described in \cite Ata10
             * It assumes one main wing which is extruded in global Y direction
             */
            /** @fixed Add a warning when the aircraft contains more than one wing or fuselage */
            const auto &wing = this->select_wing();
            const auto &fuselage = this->select_fuselage();
            const double sign_wing_extrusion = std::signbit(wing.sections.back().origin.z()) ? -1.0 : 1.0;
            if (wing.normal != geom2::Direction_3{0, sign_wing_extrusion * 1, 0})
            {
                throw std::runtime_error("[design::integrator::Default] The wing is not oriented in y-direction. This method is not applicable.");
            }

            auto parent = engine.parent_component();

            const std::size_t slot_index_on_side = this->slot_index_on_side(parent);
            const bool is_outer = (slot_index_on_side > 0);

            if (slot_index_on_side >= this->max_slots_per_side())
            {
                throw std::runtime_error(
                    "[design::integrator::Default] No space on the wing for the engine to be integrated.");
            }

            /* !!!
             * The following assumes the wing local coordinate system:
             * - X axis: chord direction
             * - Y axis: height direction
             * - Z axis: span direction (should be negative coordinates)
             * !!!
             */
            /* Get the relevant measurements from the aircraft */
            const double span = geom2::measure::span(wing);
            const double width_fuselage = geom2::measure::width_max(fuselage);
            const double diameter_max = 1.21 * engine.fan().diameter; // \cite Ata10 p. 45

            /* Wing local z position of engine */
            double span_engine = sign_wing_extrusion * this->calculate_span_position(
                                                                 width_fuselage, diameter_max, span, is_outer);

            /*
             * If enabled, try to place the engine at the wing kink instead: the kink
             * already carries extra structure (a rib at the planform break), so
             * mounting the engine there can avoid a separate local wing reinforcement.
             * Only supported for the 2-engine wing case for now.
             */
            if (this->engine_at_kink)
            {
                if (this->n_engines_.wing != 2)
                {
                    utility::print(
                        "[design::integrator::Default] engine_at_kink is currently only supported for "
                        "2 engines per wing - falling back to the default span position.",
                        Level::Warning);
                }
                else if (const auto kink_z = this->find_kink_span_position(
                             wing, width_fuselage / 2.0 + diameter_max / 2.0 - ACCURACY_LOW))
                {
                    const bool clears_fuselage = std::abs(*kink_z) - diameter_max / 2.0 >= width_fuselage / 2.0;
                    const bool clears_tip = std::abs(*kink_z) + diameter_max / 2.0 <= span / 2.0;
                    if (clears_fuselage && clears_tip)
                    {
                        span_engine = *kink_z;
                    }
                    else
                    {
                        utility::print(
                            "[design::integrator::Default] engine_at_kink is enabled, but the engine "
                            "does not fit at the wing kink (fuselage/wingtip clearance) - falling back "
                            "to the default span position.",
                            Level::Warning);
                    }
                }
                else
                {
                    utility::print(
                        "[design::integrator::Default] engine_at_kink is enabled, but the wing has no "
                        "detectable kink - falling back to the default span position.",
                        Level::Warning);
                }
            }

            /* Get the wing quarter coordinate at the engine span position */
            const double wing_chord = geom2::measure::chord(wing, span_engine);
            const auto wing_quarter =
                geom2::measure::offset_LE(wing, span_engine) +
                geom2::Vector_3{0.25 * wing_chord, 0, 0};
            double height_engine = 0.0; // This is just a placeholder, the actual height will be calculated below
            double chord_engine = 0.0;  // This is just a placeholder, the actual position will be calculated below

            if (std::get<Vertical>(engine.parent_component()) == Vertical::Over)
            {
                /*
                * OTW (over-the-wing) x position, acc. to \cite Ata10 p. 55 (ch. 3.2.4.1):
                * the inlet lip sits at lE/c = -0.75, i.e. 75% of the local chord AFT of the
                * leading edge - deliberately near where transonic shocks first form on the
                * upper surface, to raise the aircraft's critical Mach number. engine.position()
                * is already the inlet/front reference point of the nacelle geometry (see
                * nacelle/default/turbofan.cpp), and Ata10 defines lE directly relative to the
                * leading edge for OTW, so - unlike the UTW case below - no extra translation
                * by the engine length is needed here.
                * This branch previously fell through to the UTW x-position below, placing the
                * engine near the leading edge - so the exhaust would blast across most of the
                * wing's upper surface before reaching the trailing edge.
                */
                chord_engine = geom2::measure::offset_LE(wing, span_engine).x() + 0.75 * wing_chord;

                /*
                * OTW height, acc. to \cite Ata10 ch. 3.2.4, p.51: ho/Dmax = 0.3 is the gap
                * between the wing's upper surface and the nacelle's LOWER surface. Re-expressed
                * to the engine-CENTER convention used here (add half the nacelle height to get
                * from the nacelle's lower surface to its center): 0.3 + 0.5 = 0.8.
                * A previous version of this used 0.7 (uncited, no derivation), which sat the
                * engine somewhat closer to the wing than the cited methodology suggests.
                */
                height_engine = wing_quarter.y() +
                                        0.8 * geom2::measure::height_max(engine.nacelle());
            }
            else {
                /*
                * UTW (under-the-wing) x position, acc. to \cite Ata10 p. 48f: the inlet sits
                * l/c = 0.15 (LDMF) ahead of the LOCAL quarter-chord point, and the engine's own
                * reference point trails the inlet by 0.9 * engine length. Expressed relative to
                * the leading edge (quarter-chord = LE + 0.25c) this becomes "+0.10 * wing_chord".
                * A previous version of this formula used "-0.9 * wing_chord" here instead of
                * "-0.9 * engine length" - i.e. it scaled the large offset with the WING chord
                * instead of the ENGINE length, two generally unrelated quantities that only
                * happen to be similar in magnitude for typical single-aisle tube-and-wing
                * aircraft. For a small local chord (e.g. near a kink/tip, or on a front wing of
                * a tandem-wing aircraft) that pushed the engine far ahead of the wing, needing
                * an oversized pylon to bridge the gap.
                */
                chord_engine = geom2::measure::offset_LE(wing, span_engine).x() +
                    0.10 * wing_chord - 0.9 * engine.dimension().length;

                /* Wing local y position of engine */
                height_engine = wing_quarter.y() -
                                         0.5 * geom2::measure::height_max(engine.nacelle()) -
                                         0.1 * wing_chord; // \cite Ata10 p. 48f adapted to geometry_lib
            }

            /* Adjust whether the engine is left or right */
            auto position = geom2::Point_3{chord_engine, height_engine, span_engine};
            EngineShift shift = this->get_user_shift(slot_index_on_side);
            //EngineShift shift = this->get_user_shift(engine.id());

            if (std::get<Lateral>(engine.parent_component()) == Lateral::Left)
            {
                position = { position.x(), position.y(), -position.z() };
                shift.z = -shift.z;
            }

            position = this->calculate_user_shift(position, shift);

            /* Set the position of the engine in the GLOBAL (!) reference frame */
            engine.set_position(geom2::transform::to_parent(wing, position));
            ++this->engines_done.wing;
        }

        template <EnergyCarrierFamily EC>
        void Default::integrate_into_fuselage(Turbofan<EC> &engine)
        {
            /*
             * => This method follows the procedure described in \cite Ata10
             * It assumes one main fuselage which is extruded in global X direction
             */
            /** @fixed Add a warning when there are more than one fuselages */
            const auto &fuselage = this->select_fuselage();
            const double sign_extrusion = std::signbit(fuselage.sections.back().origin.z()) ? -1.0 : 1.0;
            if (fuselage.normal != geom2::Direction_3{sign_extrusion * 1, 0, 0})
            {
                throw std::runtime_error("[design::integrator::Default] The fuselage is not oriented in x-direction. This method is not applicable.");
            }

            /* Only two engines on the fuselage are supported right now */
            if (this->n_engines_.fuselage != 2)
            {
                throw std::runtime_error("[design::integrator::Default] The number of engines on the fuselage is not supported.");
            }

            /* Check whether there is still space for the engine to be integrated */
            if (this->parents_placed.contains(engine.parent_component()))
            {
                throw std::runtime_error("[design::integrator::Default] No space left on the fuselage for the engine to be integrated.");
            }

            /* !!!
             * The following assumes the fuselage local coordinate system:
             * - X axis: width direction
             * - Y axis: height direction
             * - Z axis: length direction
             * !!!
             */
            /* Get the engine position in local z direction */
            const double z_engine = sign_extrusion * 0.8 * geom2::measure::length(fuselage);

            /* Get the engine position in local y direction */
            const double y_engine = 0.25 * geom2::measure::height(fuselage, z_engine);

            /* Get the engine position in local x direction */
            const double x_engine = 0.5 * geom2::measure::width(fuselage, z_engine) +
                                    1.25 * 0.5 * geom2::measure::width_max(engine.nacelle());

            /* Adjust whether engine is left or right */
            auto position = geom2::Point_3{x_engine, y_engine, z_engine};

            EngineShift shift = this->get_user_shift(engine.id());

            if (std::get<Lateral>(engine.parent_component()) == Lateral::Left)
            {
                position = { position.x(), position.y(), -position.z() };
                shift.z = -shift.z;
            }

            position = this->calculate_user_shift(position, shift);


            const auto shifted = calculate_user_shift(position, shift);

            /* Set the position of the engine in the GLOBAL (!) reference frame */
            engine.set_position(geom2::transform::to_parent(fuselage,position));
            ++this->engines_done.fuselage;
        }

        template <EnergyCarrierFamily EC>
        void Default::integrate_into_empennage(Turbofan<EC> &engine)
        {
            /* Get the first empennage surface */
            /** @fixed Make the selection which empennage surface to integrate the engine into a bit smarter. */
            const auto &empennage = this->select_vertical_tail();
            const auto &fuselage = this->select_fuselage();

            /* Check whether there is still space for the engine to be integrated */
            if (this->parents_placed.contains(engine.parent_component()))
            {
                throw std::runtime_error("[design::integrator::Default] No space left on the empennage for the engine to be integrated.");
            }

            /* Check whether the empennage surface is in line with the fuselage center */
            if (std::abs(fuselage.origin.y() - empennage.origin.y()) > 1e-4)
            {
                throw std::runtime_error(
                    "[design::integrator::Default] The empennage is not in line with the fuselage center. "
                    "This method is not applicable!");
            }

            /* Get quarter line point at the mac position of the empennage surface */
            const auto p_25_local = geom2::measure::mean_aerodynamic_chord_position(empennage);
            const auto p_25_global = geom2::transform::to_parent(empennage, p_25_local);
            const auto p_25_fuselage = geom2::transform::to_local(fuselage, p_25_global);

            /* Calculate the engine position */
            auto position = geom2::Point_3{
                p_25_global.x() - 0.25 * engine.dimension().length, // Place engine 25% in front of quarter line
                fuselage.origin.y(),                                // Place engine in the middle of the fuselage
                0.5 * geom2::measure::height(fuselage, p_25_fuselage.z()) + 1.25 * 0.5 * engine.dimension().width};
            EngineShift shift = this->get_user_shift(engine.id());
            position = this->calculate_user_shift(position, shift);

            engine.set_position(position);
            ++this->engines_done.empennage;
        }

        template <EnergyCarrierFamily EC>
        void Default::integrate_into_wing_body(Turbofan<EC>& engine) {

            if (std::get<Vertical>(engine.parent_component()) == Vertical::Over) {
                /** @todo Add a warning when the aircraft contains more than one wing or fuselage */
                const auto& wing = this->select_wing();
                const double sign_wing_extrusion = std::signbit(wing.sections.back().origin.z()) ? -1.0 : 1.0;
                if (wing.normal != geom2::Direction_3{ 0, sign_wing_extrusion * 1, 0 })
                {
                    throw std::runtime_error("[design::integrator::Default] The wing is not oriented in y-direction. This method is not applicable.");
                }

                /* Get the relevant measurements from the aircraft */
                const double span = geom2::measure::span(wing);
                const double diameter_max = 1.21 * engine.fan().diameter; // \cite Ata10 p. 45
                const double width_fuselage = geom2::measure::width_max(this->select_fuselage());

                /* Initiate a vector containing locations of wing mounted entities */
                std::vector<double> no_placement = { -span / 2. };

                /* For each empennage element, get the spanwise boundaries on the xy plane */
                for (std::size_t i = 0; i < this->aircraft()->empennage.size(); i++) {
                    const auto& empennage = this->aircraft()->empennage[i];

                    if (geometry::is_vertical(empennage))
                    {
                        continue;
                    }
                    if (empennage.sections.size() > 1)
                    {
                        const geom2::Point_3 back_section =
                            geom2::transform::to_parent(empennage, empennage.sections.back().origin);

                        const geom2::Point_3 front_section =
                            geom2::transform::to_parent(empennage, empennage.sections.front().origin);

                        const double projected_span =
                            std::abs(front_section.y() - back_section.y());

                        const double root_y =
                            std::min(std::abs(front_section.y()), std::abs(back_section.y()));

                        const double tip_y =
                            std::max(std::abs(front_section.y()), std::abs(back_section.y()));

                        const double lower_abs =
                            std::max(0.0, root_y - 0.25 * projected_span);

                        const double upper_abs =
                            tip_y + 0.25 * projected_span;

                        no_placement.push_back(-upper_abs);
                        no_placement.push_back(-lower_abs);
                        no_placement.push_back(lower_abs);
                        no_placement.push_back(upper_abs);
                    }
                };
                no_placement.push_back(span / 2.);
                std::sort(no_placement.begin(), no_placement.end());
                switch (this->n_engines_.wing)
                {
                case 1: {
                    /* If there is a single engine, place it at the middle of the empennage assembly */
                    /* @todo add valid logic for engine placement*/
                    std::size_t index = no_placement.size() / 2 - 1;
                    if (-diameter_max / 2. > no_placement[index] and diameter_max / 2. < no_placement[index + 1]) {
                        const double span_engine = 0.0;
                        /* Get the wing spanwise_percentage coordinate at the engine span position */
                        const double wing_chord = geom2::measure::chord(wing, span_engine);
                        const auto wing_quarter =
                            geom2::measure::offset_LE(wing, span_engine);

                        /* Wing local x position of engine */
                        const double chord_engine = wing_quarter.x() + 0.70 * wing_chord;

                        /*
                        * OTW height, acc. to \cite Ata10 ch. 3.2.4, p.51: ho/Dmax = 0.3 (gap
                        * between wing upper surface and nacelle lower surface), re-expressed to
                        * the engine-center convention used here as 0.3 + 0.5 = 0.8 - see the
                        * 2-engine case below for the same derivation.
                        */
                        const double height_engine = wing_quarter.y() +
                            0.8 * geom2::measure::height_max(engine.nacelle());
                        auto position = geom2::Point_3{ chord_engine, height_engine, span_engine };
                        auto parent = engine.parent_component();

                        const std::size_t slot_index_on_side = this->slot_index_on_side(parent);
                        EngineShift shift = this->get_user_shift(slot_index_on_side);

                        if (std::get<Lateral>(engine.parent_component()) == Lateral::Left)
                        {
                            position = { position.x(), position.y(), -position.z() };
                            shift.z = -shift.z;
                        }

                        position = this->calculate_user_shift(position, shift);

                        engine.set_position(geom2::transform::to_parent(wing, position));
                        ++this->engines_done.wing;
                    }
                    else {
                        throw std::runtime_error("[design::integrator::Default] Empennage-engine collision, engine cannot be placed over the wing.");
                    };
                    break;
                }
                case 2: {
                    std::size_t index = no_placement.size() / 2 - 1;
                    double span_engine = 0.0;
                    /* @todo add valid logic or engine placement*/
                    /* If there are two engines, place them symmetrically on the sides of the empennage assembly */
                    if (no_placement[index + 1] - no_placement[index] >= 3.4 * diameter_max) {
                        span_engine = 0.80 * diameter_max;
                    }
                    else {
                        std::size_t i = 0;
                        int available = 0;
                        while (i < no_placement.size() / 2 - 1) {
                            double dist = std::abs(no_placement[i] - no_placement[i + 1]);
                            if (dist >= diameter_max * 1.5) { available++; };
                            i += 2;
                        }
                        if (available == 0) { throw std::runtime_error("[design::integrator::Default] No available space, engine cannot be placed over the wing."); };
                        span_engine = 0.75 * diameter_max + std::abs(no_placement[2. * available - 1.]);
                    };

                                        /*
                     * If enabled, try to place the engine at the wing kink instead - reusing
                     * the same empennage-clearance window (no_placement[index]..no_placement[index+1])
                     * already established above, so the collision-avoidance guarantee is preserved.
                     */
                    if (this->engine_at_kink)
                    {
                        if (const auto kink_z = this->find_kink_span_position(
                                wing, width_fuselage / 2.0 + diameter_max / 2.0 - ACCURACY_LOW))
                        {
                            const bool clears_empennage =
                                std::abs(*kink_z) - diameter_max / 2.0 >= no_placement[index] &&
                                std::abs(*kink_z) + diameter_max / 2.0 <= no_placement[index + 1];
                            if (clears_empennage)
                            {
                                span_engine = std::abs(*kink_z);
                            }
                            else
                            {
                                utility::print(
                                    "[design::integrator::Default] engine_at_kink is enabled, but the engine "
                                    "does not fit at the wing kink within the empennage clearance window - "
                                    "falling back to the default span position.",
                                    Level::Warning);
                            }
                        }
                        else
                        {
                            utility::print(
                                "[design::integrator::Default] engine_at_kink is enabled, but the wing has "
                                "no detectable kink - falling back to the default span position.",
                                Level::Warning);
                        }
                    }

                    auto parent = engine.parent_component();

                    const std::size_t slot_index_on_side = this->slot_index_on_side(parent);
                    EngineShift shift = this->get_user_shift(slot_index_on_side);

                    if (this->engines_done.wing > 0)
                    {
                        span_engine = -span_engine;
                    }

                    /* Get the wing 80% coordinate at the engine span position */
                    const double wing_chord = geom2::measure::chord(wing, span_engine);
                    const auto wing_quarter =
                        geom2::measure::offset_LE(wing, span_engine);

                    /* Wing local x position of engine */
                    const double chord_engine = wing_quarter.x() + 0.70 * wing_chord;

                    /*
                    * OTW height, acc. to \cite Ata10 ch. 3.2.4, p.51: ho/Dmax = 0.3 is the gap
                    * between the wing's upper surface and the nacelle's LOWER surface.
                    * Re-expressed to the engine-CENTER convention used here (add half the
                    * nacelle height to get from its lower surface to its center): 0.3 + 0.5 = 0.8.
                    * A previous version of this used a bare 1.0x factor (uncited, no derivation,
                    * and inconsistent with the 0.7x previously used for the single-engine case
                    * above and for the Parent::Wing/OTW case), which sat the engine further from
                    * the wing than the cited methodology suggests.
                    */
                    const double height_engine = wing_quarter.y() +
                        0.8 * geom2::measure::height_max(engine.nacelle());

                    auto position = geom2::Point_3{ chord_engine, height_engine, span_engine };

                    if (std::get<Lateral>(engine.parent_component()) == Lateral::Left)
                    {
                        position = { position.x(), position.y(), -position.z() };
                        shift.z = -shift.z;
                    }

                    position = this->calculate_user_shift(position, shift);

                    engine.set_position(geom2::transform::to_parent(wing, position));
                    ++this->engines_done.wing;
                    break;
                };
                };
            };

        };
        template <EnergyCarrierFamily EC>
        void Default::guess_position(Turbofan<EC> &engine)
        {
            /* Guess the position of the engine based on their parent component */
            switch (std::get<Parent>(engine.parent_component()))
            {
                /* For now place everything at the origin */
                case Parent::Wing:
                case Parent::Fuselage:
                case Parent::Empennage:
                case Parent::WingBody:
                default:
                    /* Fall back to ORIGIN as the default position */
                    engine.set_position(CGAL::ORIGIN);
                    break;
            }
        }

        auto Default::calculate_span_position(
            const double width_fuselage,
            const double diameter_engine_max,
            const double wing_span,
            const bool is_outer) const -> double
        {
            /* How many engines on the wing */
            if (this->n_engines_.wing == 2)
            {
                return 0.95 * (width_fuselage / 2.0 +
                               1.3 * diameter_engine_max +
                               0.5 * diameter_engine_max); // \cite Ata10 p. 52, 0.95 additional factor
            }
            else if (this->n_engines_.wing == 4)
            {
                /* Return the position whether the engine is on the outer
                 * or inner side of the wing.
                 */
                if (is_outer)
                {
                    return 0.64 * wing_span / 2.0; // \cite Ata10 p. 83
                }
                return (0.9 / 4.0) * (0.64 * wing_span +
                                    width_fuselage -
                                    diameter_engine_max); // \cite Ata10 p. 94, 0.9 additional factor
            }
            /* Not a valid engine on the wing count */
            throw std::runtime_error("[design::integrator::Default] The number of engines on the wing is not valid.");
        }

        void Default::operator()(Turbofan<EnergyCarrierFamily::Liquid_Hydrogen>& engine)
        {
            turbofan_method(engine);
        };

        void Default::operator()(Turbofan<EnergyCarrierFamily::Kerosene>& engine)
        {
            turbofan_method(engine);
        };

    } // namespace integration
} // namespace design
