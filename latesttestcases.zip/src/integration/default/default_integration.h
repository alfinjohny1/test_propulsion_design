/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 *
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

#ifndef SRC_INTEGRATION_DEFAULT_DEFAULT_INTEGRATION_H_
#define SRC_INTEGRATION_DEFAULT_DEFAULT_INTEGRATION_H_

 /* === Includes === */
#include "../propulsion_integration.h"
#include <memory>
#include <optional>
#include <set>
#include <string>
#include "../../utility.h"

namespace design
{
    namespace integration
    {
        /**
         * @class Default
         * @brief The default integration strategy for propulsion systems.
         */
        class Default : public PropulsionIntegrator
        {
        public:
            /**
             * @struct EngineCount
             * @brief Helper struct to store the number of engines in the fuselage and wing.
             */
            struct EngineCount
            {
                int fuselage{ 0 };
                int wing{ 0 };
                int empennage{ 0 };
            };

            /**
             * @struct EngineShift
             * @brief User-defined propulsor position offset in aircraft coordinates.
             */
            struct EngineShift
            {
                double x{ 0.0 };
                double y{ 0.0 };
                double z{ 0.0 };
            };

            /**
             * @brief Construct a new default propulsion integrator.
             * @param configuration The module configuration provided by the user.
             * @param aircraft_geometry The aircraft geometry.
             * @param n_engines The number of engines in each aircraft region.
             */
            Default(
                const std::shared_ptr<node>& configuration,
                const std::shared_ptr<geometry::Aircraft>& aircraft_geometry,
                const EngineCount& n_engines)
                : PropulsionIntegrator(configuration, aircraft_geometry), n_engines_{ n_engines }
            {
                this->validate_user_shift_configuration();
            }

            /* === Methods === */
            /**
             * @brief Integrate a turbofan engine with kerosene as fuel.
             * @note The engine WILL be modified!
             *
             * @param engine The engine to integrate.
             */
            void operator()(Turbofan<EnergyCarrierFamily::Kerosene> &engine); // NOLINT runtime/references

            void operator()(Turbofan<EnergyCarrierFamily::Liquid_Hydrogen>& engine); // NOLINT runtime/references

            void operator()(Openrotorfan<EnergyCarrierFamily::Kerosene> &engine); // NOLINT runtime/references

          private:
            /* === Methods === */  
            /**
             * @brief Integrate the engine into the wing.
             * This method follows the procedure described in \cite Ata10.
             * It assumes one main wing which is extruded in global Y direction.
             * The number of engines is limited to 2 or 4 per wing.
             * @attention The given engine is modified by this method!
             * @throws std::runtime_error if the preconditions are not met.
             *
             * @param engine The engine to integrate.
             */
            
            template <EnergyCarrierFamily EC>
            void integrate_into_wing(Turbofan<EC> &engine); // NOLINT runtime/references

            template <EnergyCarrierFamily EC>
            void integrate_into_fuselage(Turbofan<EC> &engine); // NOLINT runtime/references

            template <EnergyCarrierFamily EC>
            void integrate_into_empennage(Turbofan<EC> &engine); // NOLINT runtime/references

            template <EnergyCarrierFamily EC>
            void integrate_into_wing_body(Turbofan<EC>& engine); // NOLINT runtime/references

            template <EnergyCarrierFamily EC>
            void guess_position(Turbofan<EC> &engine); // NOLINT runtime/references

            template <EnergyCarrierFamily EC>
            void turbofan_method(Turbofan<EC>& engine); // NOLINT runtime/references

            /* === Openrotorfan integration === */

            template <EnergyCarrierFamily EC>
            void integrate_over_wing(Openrotorfan<EC> &engine); // NOLINT runtime/references            
            
            template <EnergyCarrierFamily EC>
            void integrate_into_wing(Openrotorfan<EC> &engine); // NOLINT runtime/references

            template <EnergyCarrierFamily EC>
            void integrate_under_wing(Openrotorfan<EC> &engine); // NOLINT runtime/references

            template <EnergyCarrierFamily EC>
            void integrate_into_fuselage_top(Openrotorfan<EC> &engine); // NOLINT runtime/references

            template <EnergyCarrierFamily EC>
            void integrate_into_fuselage(Openrotorfan<EC> &engine); // NOLINT runtime/references

            template <EnergyCarrierFamily EC>
            void integrate_into_empennage(Openrotorfan<EC> &engine); // NOLINT runtime/references

            template <EnergyCarrierFamily EC>
            void guess_position(Openrotorfan<EC> &engine); // NOLINT runtime/references

            template <EnergyCarrierFamily EC>
            void openrotorfan_method(Openrotorfan<EC>& engine); // NOLINT runtime/references

            /* === Geometric helper methods === */
            [[nodiscard]] auto calculate_span_position(
                double width_fuselage,
                double diameter_engine_max,
                double wing_span,
                bool is_outer) const -> double;

            [[nodiscard]] auto calculate_span_position_openrotor(
                double width_fuselage,
                double diameter_engine_max,
                double wing_span,
                bool is_outer) const -> double;

            [[nodiscard]] auto select_fuselage() -> geometry::Fuselage&;
            [[nodiscard]] auto select_vertical_tail() -> geometry::Wing&;
            [[nodiscard]] auto select_wing() -> geometry::Wing&;


            /* === User shift helper methods === */
            [[nodiscard]] auto max_shift_ids() const -> std::size_t;
            [[nodiscard]] auto calculate_user_shift(
                geom2::Point_3 position,
                const EngineShift& shift) const -> geom2::Point_3;

            [[nodiscard]] auto get_user_shift(std::size_t slot_index)->EngineShift;

            void validate_user_shift_configuration() const;


            [[nodiscard]] auto max_slots_per_side() const -> std::size_t;
            [[nodiscard]] auto slot_index_on_side(const ParentComponent& parent) const -> std::size_t;

            /**
             * @brief Find the spanwise position of a wing kink from the wing geometry alone.
             * A kink is detected as the interior section where the leading-edge sweep slope
             * (dx/dz between consecutive sections) changes by more than a small tolerance -
             * i.e. where the otherwise straight leading-edge line bends. Works purely off the
             * generated wing geometry, independent of which wing_design strategy produced it.
             * Candidates within min_abs_span of the centerline (e.g. inside the fuselage) are
             * skipped rather than stopping the search, since a kink there could never be an
             * engine-mounting location anyway.
             *
             * @param wing The wing to search for a kink.
             * @param min_abs_span [m] Minimum |z| a candidate kink section must have to be
             * considered. Should be half the fuselage width PLUS half the engine's clearance
             * diameter (minus a small accuracy margin): a kinked wing's root section commonly
             * ends exactly at the fuselage side, so half the fuselage width alone is not a safe
             * threshold - it would (mis-)detect that root/fuselage-exit point itself as "the kink"
             * whenever it happens to be the first slope discontinuity found, leaving no clearance
             * for any engine at all.
             * @return std::optional<double> [m] The wing-local (signed) z position of the kink,
             * or std::nullopt if the wing has no detectable outboard kink (e.g. a simple tapered
             * wing, or a wing whose only slope changes lie within min_abs_span).
             */
            [[nodiscard]] auto find_kink_span_position(const geometry::Wing &wing, double min_abs_span) const -> std::optional<double>;

            /* === Properties === */
            const EngineCount n_engines_{};   /** The number of engines in the fuselage and wing. */
            EngineCount engines_done{}; /** Keeps track how many engines are already integrated */
            std::set<ParentComponent> parents_placed; /** Keeps track of the components where engines are already integrated */
            double usershift_x = this->configuration()->at("/module_configuration_file/program_settings/repositioning/shift_x/value");
            double usershift_y = this->configuration()->at("/module_configuration_file/program_settings/repositioning/shift_y/value");
            double usershift_z = this->configuration()->at("/module_configuration_file/program_settings/repositioning/shift_z/value");
            bool engine_at_kink = checkBoundaries(this->configuration()->at("/module_configuration_file/program_settings/engine_at_kink/value"));
        };
    } // namespace integration
} // namespace design

#endif // SRC_INTEGRATION_DEFAULT_DEFAULT_INTEGRATION_H_
