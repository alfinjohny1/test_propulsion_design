/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include "propulsion_design.h"
#include "engine_design/rubber/rubber_design.h"
#include "integration/default/default_integration.h"
#include "io/aircraft_xml.h"
#include "mass/default/default_mass.h"
#include "nacelle/default/default_nacelle.h"
#include "pylon/default/default_pylon.h"
#include <aircraftGeometry2/airfoil_surface.h>
#include <aircraftGeometry2/fuselage.h>
#include <algorithm>
#include <format>

/* === Methods === */
void PropulsionDesign::initialize()
{
    utility::print("Initializing the propulsion design module.");

    /* Get the XML resources */
    this->configuration_xml = aixml::openDocument(this->get_RuntimeIO()->moduleConfAccess);
    this->aircraft_xml = aixml::openDocument(this->get_RuntimeIO()->acxmlAccess);

    /* Set the coordinate references */
    this->reference_offset = {0, 0, 0}; // Use the origin as the reference point

    /* Get the aircraft geometry */
    utility::print("Trying to read the aircraft geometry.");
    this->create_aircraft_geometry();

    /* Populate the vector with all the propulsion systems which should be designed */
    utility::print("Creating the propulsors as specified in the requirements.");
    this->create_propulsors();

    utility::print("Sorting the inputs", Level::Debug);
    this->sort_propulsors();

    this->check_validity();

    /* Set the different design domain strategies */
    utility::print("Setting the design domain strategies.");
    this->select_engine_designer();
    this->select_propulsion_integrator();
    this->select_nacelle_designer();
    this->select_pylon_designer();
    this->select_mass_analyzer();

    /* Initialize the design domain strategies */
    utility::print("Initializing the design domain strategies.");
    this->engine_designer->initialize();
    this->propulsion_integrator->initialize();
    this->nacelle_designer->initialize();
    this->pylon_designer->initialize();
    this->mass_analyzer->initialize();
};

void PropulsionDesign::run()
{
    /* Execute the selected strategies for each design domain */
    utility::print("Running the design domain strategies.");
    for (auto &engine : this->engines)
    {
        utility::print("Sizing the engine...", Level::Out);
        std::visit(*this->engine_designer, engine);
        utility::print("Sizing the nacelle...", Level::Out);
        std::visit(*this->nacelle_designer, engine);
        utility::print("Placing the engine...", Level::Out);
        std::visit(*this->propulsion_integrator, engine);
        utility::print("Sizing the pylon...", Level::Out);
        std::visit(*this->pylon_designer, engine);
        utility::print("Analyzing the engine mass...", Level::Out);
        std::visit(*this->mass_analyzer, engine);
    }
    this->check_validity();
};

void PropulsionDesign::update()
{
    int i = 0;
    while (i < this->engines.size()) {
        std::swap(this->engines[i], this->engines[this->swapped_order[i]]);
        std::swap(this->swapped_order[i], this->swapped_order[this->swapped_order[i]]);
        i++;
    };

    /* Update the aircraft exchange data */
    utility::print("Updating the aircraft exchange data.");
    io::AircraftXML xml(this->aircraft_xml);

    /* Insert the reference position */
    xml.insert(CGAL::ORIGIN + this->reference_offset);

    /* Apply the reference offset to the engines */
    const Eigen::Vector3d reference{
        this->reference_offset.x(),
        this->reference_offset.y(),
        this->reference_offset.z()};
    for(auto& engine : this->engines)
    {
        std::visit(
            [this, &reference](auto& engine)
            {
                engine.change_to_global_reference_frame(reference);
            },
            engine);
    }

    /* Sum all engine masses and insert the total mass in the xml */
    std::vector<PointMass> masses(this->engines.size());
    std::transform(
        this->engines.begin(), this->engines.end(), masses.begin(),
        [](const auto &engine)
        {
            return std::visit(
                [](const auto &engine)
                {
                    /* Return the total engine mass */
                    return engine.total_mass();
                },
                engine);
        });
    xml.insert(std::accumulate(masses.begin(), masses.end(), PointMass{}));

    /* Engines */
    for (auto &engine : this->engines)
    {
        std::visit(
            [this, &xml, &reference](auto &engine)
            {
                /* Insert the engine data into the xml */
                xml.insert(engine);

                /* Revert the engine to the local reference frame again */
                engine.revert_to_local_reference_frame(reference);
            },
            engine);
    }

    /* Call the update methods of the design domains */
    this->engine_designer->update();
    this->nacelle_designer->update();
    this->propulsion_integrator->update();
    this->pylon_designer->update();
    this->mass_analyzer->update();

    /* Generate the report data if enabled */
    if (this->get_RuntimeIO()->reportOn)
    {
        utility::print("Generating the report data...");
        this->report_data = report::generate_data(
            this->engines,
            this->engine_designer->flight_condition(),
            this->engine_designer->engine_directory(),
            this->engine_designer->engine_database()
        );
    }
};

void PropulsionDesign::report()
{
    /* Generate module-specific XML report */
    if (!this->get_RuntimeIO()->xmlOn) {
        utility::print("XML report generation is disabled in the configuration.", Level::Warning);
    } else {
        utility::print("Creating XML report");
        this->create_xml_report();
    }
    /* Only when the reports are enabled */
    if (!this->get_RuntimeIO()->reportOn)
    {
        utility::print("Skipping the report, plots will also not be available!", Level::Warning);
        return;
    }

    /* Call the report of the design domains */
    utility::print("Calling report of the propulsion design domains");
    this->engine_designer->report();
    this->nacelle_designer->report();
    this->propulsion_integrator->report();
    this->pylon_designer->report();
    this->mass_analyzer->report();

    /* === HTML Report ===*/
    utility::print("Creating HTML report");
    this->create_html_report();

    /* === Plots ===*/
    /* Check whether plots should be created */
    if (!this->get_RuntimeIO()->plotOn)
    {
        utility::print("Skipping the creation of SVG files", Level::Debug);
        return;
    }

    /* === SVG Plots === */
    utility::print("Saving SVG files to: " + this->get_RuntimeIO()->getPlotDir(), Level::Debug);
    this->create_plots();
};

void PropulsionDesign::save()
{
    /* Create the engine directory if not existing */
    if (!std::filesystem::exists(this->get_RuntimeIO()->getEngineDataDir()))
    {
        utility::print(
            "Creating engine data directory: " + this->get_RuntimeIO()->getEngineDataDir(),
            Level::Debug);
        this->get_RuntimeIO()->createEngineDataDir();
    }

    /* Save the results */
    utility::print("Saving the results.");
    aixml::saveDocument(*this->aircraft_xml, this->get_RuntimeIO()->ownToolLevel);
    this->engine_designer->save();
    this->nacelle_designer->save();
    this->propulsion_integrator->save();
    this->pylon_designer->save();
    this->mass_analyzer->save();
};

void PropulsionDesign::select_engine_designer()
{
    /* Read the design flight condition */
    const auto flight_condition = this->get_design_condition();

    /* Select the engine designer */
    const std::string method(this->configuration_xml->at("module_configuration_file/program_settings/method/engine_designer/value"));
    if (method == "Rubber")
        this->engine_designer =
            std::make_unique<design::Rubber>(
                this->configuration_xml,
                this->get_RuntimeIO()->getEngineDataDir(),
                flight_condition);
    else
        throw std::runtime_error("[PropulsionDesign] The engine designer method '" + method + "' is not supported.");

    /* Inform the user */
    utility::print("The engine designer method '" + method + "' is selected.", Level::Debug);
};

void PropulsionDesign::select_propulsion_integrator()
{
    /* Countif here */
    const int n_wing_mounted = count_if(this->engines.begin(), this->engines.end(), [](const auto& engine) {
        auto parent_comp = std::visit(
            [](const auto& engine)
            {
                /* Return the parent component */
                return std::get<Parent>(engine.parent_component());
            },
            engine);
        return parent_comp == Parent::Wing || parent_comp == Parent::WingBody;
        });

    const int n_fuselage_mounted = count_if(this->engines.begin(), this->engines.end(), [](const auto& engine) {
        auto parent_comp = std::visit(
            [](const auto& engine)
            {
                /* Return the parent component */
                return std::get<Parent>(engine.parent_component());
            },
            engine);
        return parent_comp == Parent::Fuselage;
        });

    const int n_empennage_mounted = count_if(this->engines.begin(), this->engines.end(), [](const auto& engine) {
        auto parent_comp = std::visit(
            [](const auto& engine)
            {
                /* Return the parent component */
                return std::get<Parent>(engine.parent_component());
            },
            engine);
        return parent_comp == Parent::Empennage;
        });

    /* Select the propulsion integrator */
    const std::string method(this->configuration_xml->at("module_configuration_file/program_settings/method/propulsion_integrator/value"));
    if (method == "Default")
        this->propulsion_integrator = std::make_unique<design::integration::Default>(
            this->configuration_xml, this->aircraft_geometry, design::integration::Default::EngineCount{n_fuselage_mounted, n_wing_mounted, n_empennage_mounted});
    else
        throw std::runtime_error("[PropulsionDesign] The propulsion integrator method '" + method + "' is not supported.");

    /* Inform the user */
    utility::print("The propulsion integrator method '" + method + "' is selected.", Level::Debug);
};

void PropulsionDesign::select_nacelle_designer()
{
    /* Select the nacelle designer */
    const std::string method(this->configuration_xml->at("module_configuration_file/program_settings/method/nacelle_designer/value"));
    if (method == "Default")
        this->nacelle_designer = std::make_unique<geometry::nacelle::Default>(
            this->configuration_xml, this->get_RuntimeIO()->getGeometryDir());
    else
        throw std::runtime_error("[PropulsionDesign] The nacelle designer method '" + method + "' is not supported.");

    /* Inform the user */
    utility::print("The nacelle designer method '" + method + "' is selected.", Level::Debug);
};

void PropulsionDesign::select_pylon_designer()
{
    /* Select the pylon designer */
    const std::string method(this->configuration_xml->at("module_configuration_file/program_settings/method/pylon_designer/value"));
    if (method == "Default")
        this->pylon_designer = std::make_unique<geometry::pylon::Default>(this->configuration_xml, this->aircraft_geometry, this->get_RuntimeIO()->getGeometryDir());
    else
        throw std::runtime_error("[PropulsionDesign] The pylon designer method '" + method + "' is not supported.");

    /* Inform the user */
    utility::print("The pylon designer method '" + method + "' is selected.", Level::Debug);
};

void PropulsionDesign::select_mass_analyzer()
{
    /* Select the mass analyzer */
    const std::string method(this->configuration_xml->at("module_configuration_file/program_settings/method/mass_analyzer/value"));
    if (method == "Default")
        this->mass_analyzer = std::make_unique<mass::Default>(this->configuration_xml);
    else
        throw std::runtime_error("[PropulsionDesign] The mass analyzer method '" + method + "' is not supported.");

    /* Inform the user */
    utility::print("The mass analyzer method '" + method + "' is selected.", Level::Debug);
};

void PropulsionDesign::create_aircraft_geometry()
{
    /* Lambda to extract the component position reference */
    auto get_position = [](const node &component) -> geom2::Point_3
    {
        return geom2::Point_3{double{component.at("position/x/value")},
                              double{component.at("position/y/value")},
                              double{component.at("position/z/value")}};
    };

    /* Create the aircraft geometry */
    try
    {
        /* Find all aircraft parts in the xml file */
        const auto wings = this->aircraft_xml->getVector("aircraft_exchange_file/component_design/wing/specific/geometry/aerodynamic_surface");
        const auto wing_position = get_position(this->aircraft_xml->at("aircraft_exchange_file/component_design/wing"));
        const auto fuselages = this->aircraft_xml->getVector("aircraft_exchange_file/component_design/fuselage/specific/geometry/fuselage");
        const auto fuselage_position = get_position(this->aircraft_xml->at("aircraft_exchange_file/component_design/fuselage"));
        const auto empennage = this->aircraft_xml->getVector("aircraft_exchange_file/component_design/empennage/specific/geometry/aerodynamic_surface");
        const auto empennage_position = get_position(this->aircraft_xml->at("aircraft_exchange_file/component_design/empennage"));

        /* Create the surface builders */
        geom2::WingFactory wing_factory{this->aircraft_xml, this->get_RuntimeIO()->getAirfoilDataDir()};
        geom2::FuselageFactory fuselage_factory{this->aircraft_xml, this->get_RuntimeIO()->getGeometryDir()};
        geom2::AirfoilSurfaceFactory airfoil_factory{this->aircraft_xml, this->get_RuntimeIO()->getAirfoilDataDir()};

        /* Create the aircraft geometry */
        this->aircraft_geometry = std::make_shared<geometry::Aircraft>();
        std::transform(wings.begin(), wings.end(), std::back_inserter(this->aircraft_geometry->wings),
                       [&wing_factory](const auto &wing)
                       { return wing_factory.create(
                             "wing/specific/geometry/aerodynamic_surface@" + wing->getStringAttrib("ID")); });
        std::transform(fuselages.begin(), fuselages.end(), std::back_inserter(this->aircraft_geometry->fuselages),
                       [&fuselage_factory](const auto &fuselage)
                       { return fuselage_factory.create(
                             "fuselage/specific/geometry/fuselage@" + fuselage->getStringAttrib("ID")); });
        std::transform(empennage.begin(), empennage.end(), std::back_inserter(this->aircraft_geometry->empennage),
                       [&wing_factory](const auto &empennage)
                       { return wing_factory.create(
                             "empennage/specific/geometry/aerodynamic_surface@" + empennage->getStringAttrib("ID")); });

        /* Convert the origins of the wings to the global coordinate system */
        auto offset = wing_position - CGAL::ORIGIN;
        std::ranges::for_each(
            this->aircraft_geometry->wings,
            [&offset](auto &wing)
            { wing.origin += offset; });

        /* Convert the origins of the fuselages to the global coordinate system */
        offset = fuselage_position - CGAL::ORIGIN;
        std::ranges::for_each(
            this->aircraft_geometry->fuselages,
            [&offset](auto &fuselage)
            { fuselage.origin += offset; });

        /* Convert the origins of the empennage to the global coordinate system */
        offset = empennage_position - CGAL::ORIGIN;
        std::ranges::for_each(
            this->aircraft_geometry->empennage,
            [&offset](auto &empennage)
            { empennage.origin += offset; });
    }
    catch (const std::string &exception)
    {
        /* A string exception at this point means that the getVector method
         did not find any geometry -> Set the the aircraft geometry to a nullptr */
        utility::print(exception, Level::Warning);
        utility::print("No aircraft geometry available. -> Setting it to NULL.", Level::Warning);
        this->aircraft_geometry = nullptr;
    }
}

void PropulsionDesign::create_propulsors()
{
    /* Get the node vector to all defined propulsion systems*/
    auto propulsors = this->aircraft_xml->getVector(
        "aircraft_exchange_file/requirements_and_specifications/design_specification/propulsion/propulsor");
    /* Get the node vector to all defined energy carriers */
    const node &energy_carriers_node = this->aircraft_xml->at(
        "aircraft_exchange_file/requirements_and_specifications/design_specification/energy_carriers");
    /* Create the energy carrier map */
    EnergyCarriersMap energy_carriers_map = utility::create_energy_carrier_map(energy_carriers_node);

    /* Get the total required thrust of the aircraft */
    const auto MTOM = EndnodeReadOnly<double>{"aircraft_exchange_file/analysis/masses_cg_inertia/maximum_takeoff_mass/mass_properties/mass"}.read(*this->aircraft_xml);
    const auto thrust_to_weight = EndnodeReadOnly<double>{"aircraft_exchange_file/sizing_point/thrust_to_weight"}.read(*this->aircraft_xml);
    const double total_thrust_required = G_FORCE * MTOM.value() * thrust_to_weight.value(); // [N]
    utility::print(std::format(
        "Calculating the propulsors using the thrust-to-weight ratio: {:4.2f} with a MTOM: {:6.2f} kg comes to a total thrust: {:1.2f} kN", 
        thrust_to_weight.value(), MTOM.value() ,total_thrust_required / 1000), Level::Out);


    /* Read the average offtake requirements from systemsDesign for the bucket curve */
    Offtakes offtakes{};
    const std::string offtake_base = "aircraft_exchange_file/component_design/systems/specific/average_";
    const auto bleed = this->aircraft_xml->find(offtake_base + "bleed_air_demand");
    const auto power = this->aircraft_xml->find(offtake_base + "power_demand");
    if( bleed != nullptr && power != nullptr)
    {
        offtakes.bleed_air = EndnodeReadOnly<double>{offtake_base + "bleed_air_demand"}.read(*this->aircraft_xml).value();
        offtakes.shaft_power = EndnodeReadOnly<double>{offtake_base + "power_demand"}.read(*this->aircraft_xml).value();
    } else {
        utility::print("No average offtake requirements found in the XML file. Using default values.", Level::Warning);
    }

    /* Create the engines */
    std::for_each(
        propulsors.begin(),
        propulsors.end(),
        [this, &energy_carriers_map, total_thrust_required, &offtakes](const auto &propulsor)
        { this->engines.emplace_back(
              utility::create_engine(
                  *propulsor, energy_carriers_map, total_thrust_required, offtakes)); });
}

auto PropulsionDesign::get_design_condition() const -> FlightCondition
{
    /* The design mission base path */
    const std::string mission_base = "aircraft_exchange_file/requirements_and_specifications/requirements/top_level_aircraft_requirements/design_mission";

    /* Read the initial cruise values */
    auto mach = EndnodeReadOnly<double>{mission_base + "/initial_cruise_mach_number"}.read(*this->aircraft_xml);
    auto altitude = EndnodeReadOnly<double>{mission_base + "/initial_cruise_altitude"}.read(*this->aircraft_xml);
    auto isa = EndnodeReadOnly<double>{mission_base + "/delta_ISA"}.read(*this->aircraft_xml);

    /* Create the atmosphere and add delta ISA for bucket curve only */
    atmosphere atm{};
    atm.setAtmosphere(0, atm.T_0 + isa.value(), atm.p_0);

    /* Print information */
    utility::print(
        std::format("Design condition: Mach = {:>3.2f}, altitude = {:>5.0f} m, ISA{:+2.0f}",
                    mach.value(), altitude.value(), isa.value()),
        Level::Info);

    /* Read the initial cruise values */
    return {atm, altitude.value(), mach.value()};
}

void PropulsionDesign::sort_propulsors()
{
    int n = this->engines.size();
    std::vector<int> v(n);
    iota(v.begin(), v.end(), 0);

    const int n_wing_mounted = count_if(this->engines.begin(), this->engines.end(), [](const auto& engine) {
        auto parent_comp = std::visit(
            [](const auto& engine)
            {
                return std::get<Parent>(engine.parent_component());
            },
            engine);
        return parent_comp == Parent::Wing;
        });

    if (n_wing_mounted > 2) {
        int i = 0;
        int m = 0;
        for (auto& engine : this->engines)
        {
            auto parent_comp = std::visit(
                [](const auto& engine)
                {
                    return std::get<Lateral>(engine.parent_component());
                },
                engine);
            if (parent_comp == Lateral::Left) {
                std::swap(this->engines[i], engine);
                std::swap(v[m], v[i]);
                i++;
            }
            m++;
        }
        int j = 0;
        double temp_req_T = 0.0;
        bool change = false;
        m = 0;
        for (auto& engine : this->engines)
        {
            auto required_thrust = std::visit(
                [](const auto& engine)
                {
                    return engine.required_thrust();
                },
                engine);
            if (j < i - 1 && temp_req_T < required_thrust && !change) {
                std::swap(this->engines[j], engine);
                std::swap(v[m], v[j]);
                if (temp_req_T != 0.0) { j++; };
                temp_req_T = required_thrust;
            }
            else if (m == i)
            {
                j = 0;
                change = true;
                temp_req_T = 0.0;
            }
            if (temp_req_T < required_thrust && change)
            {
                std::swap(this->engines[j + i], engine);
                std::swap(v[m], v[i + j]);
                if (temp_req_T != 0.0) { j++; };
                temp_req_T = required_thrust;
            };
            m++;
        }
    };
    this->swapped_order = v;
}

void PropulsionDesign::check_validity()
{
    const auto MTOM = EndnodeReadOnly<double>{ "aircraft_exchange_file/analysis/masses_cg_inertia/maximum_takeoff_mass/mass_properties/mass" }.read(*this->aircraft_xml);
    const auto thrust_to_weight = EndnodeReadOnly<double>{ "aircraft_exchange_file/sizing_point/thrust_to_weight" }.read(*this->aircraft_xml);
    const double total_thrust_required = G_FORCE * MTOM.value() * thrust_to_weight.value();

    double total_thrust_actual = 0.0;

    double total_moment_x = 0.0;
    double total_moment_y = 0.0;
    double total_moment_z = 0.0;

    for (auto& engine : this->engines)
    {
        const double thrust_engine = std::visit(
            [](const auto& engine)
            {
                return engine.required_thrust();
            },
            engine);

        const auto pos = std::visit(
            [](const auto& engine)
            {
                return engine.position();
            },
            engine);

        total_thrust_actual += thrust_engine;

        // Assuming thrust acts purely in +x direction:
        // r = (x, y, z), F = (T, 0, 0)
        // M = r x F = (0, z*T, -y*T)

        const double moment_x = 0.0;
        const double moment_y = pos.z() * thrust_engine;
        const double moment_z = -pos.y() * thrust_engine;

        total_moment_x += moment_x;
        total_moment_y += moment_y;
        total_moment_z += moment_z;
    }

    if (thrust_to_weight.value() <= 0.0)
    {
        throw std::runtime_error("[PropulsionDesign] No design thrust given. Get a sizing point.");
    }
    if (MTOM.value() <= 0.0)
    {
        throw std::runtime_error("[PropulsionDesign] No MTOM given. Get a MTOM.");
    }
    if (std::abs(total_thrust_actual - total_thrust_required) >= 10.0)
    {
        throw std::runtime_error("[PropulsionDesign] Total thrust share of engines is not equal to one.");
    }

    // Keep the old symmetry check for now, but make explicit which axis it refers to 
    if (std::abs(total_moment_x) >= 10.0)
    {
        throw std::runtime_error(
            "[PropulsionDesign] Non-symmetrical thrust about y-axis. Moment: "
            + std::to_string(total_moment_y)
        );
    }
}