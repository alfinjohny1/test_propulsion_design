/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include "utility.h"
#include <algorithm>
#include <cctype>
#include <cstddef>
#include <energyCarriers/energyCarriers.h>
#include <runtimeInfo/runtimeInfo.h>
#include <stdexcept>
#include <string>
#include <vector>

/* === Functions ===*/
namespace utility
{
    auto to_energy_carrier(const std::string_view carrier_name) -> EnergyCarrierFamily
    {
        /* Normalize the name to lower case, so this function is not case sensitive */
        std::string carrier_normalized{carrier_name};
        std::transform(
            carrier_normalized.begin(),
            carrier_normalized.end(),
            carrier_normalized.begin(),
            ::tolower);

        /* Look up which family this exact fuel id belongs to via libraries/energyCarriers'
         * families() (sourced from energy_carrier.xml) - this is the single source of truth,
         * so adding a new fuel id there (any family-variant string, e.g. "SAF-HEFA-SPK")
         * never requires a matching code change here. A case-insensitive scan is used since
         * the two historical ids are lowercase ("kerosene", "liquid_hydrogen") while newer
         * ids follow the "Family-Variant" convention (e.g. "SAF-HEFA-SPK"). */
        std::string family;
        bool id_found = false;
        for (const auto& [id, id_family] : families())
        {
            std::string id_normalized = id;
            std::transform(id_normalized.begin(), id_normalized.end(), id_normalized.begin(), ::tolower);
            if (id_normalized == carrier_normalized)
            {
                family = id_family;
                id_found = true;
                break;
            }
        }
        if (!id_found)
        {
            throw std::runtime_error("The energy carrier '" + carrier_normalized + "' is not supported.");
        }
        std::transform(family.begin(), family.end(), family.begin(), ::tolower);

        /* Map the family to the physics/template model it selects */
        EnergyCarrierFamily carrier_type = EnergyCarrierFamily::Kerosene;
        if (family == "kerosene")
        {
            carrier_type = EnergyCarrierFamily::Kerosene;
        }
        else if (family == "liquidhydrogen")
        {
            carrier_type = EnergyCarrierFamily::Liquid_Hydrogen;
        }
        else
        {
            throw std::runtime_error("The energy carrier family '" + family + "' is not supported.");
        }

        /* Return the resulting energy carrier */
        return carrier_type;
    }

    auto get_parent_component(const node &position) -> ParentComponent
    {
        ParentComponent component;

        /* Read the parent */
        Parent parent;
        std::string value = position.at("parent_component/value");
        if (value == "wing")
        {
            parent = Parent::Wing;
        }
        else if (value == "wing_body")
        {
            parent = Parent::WingBody;
        }
        else if (value == "fuselage")
        {
            parent = Parent::Fuselage;
        }
        else if (value == "empennage")
        {
            parent = Parent::Empennage;
        }
        else
        {
            throw std::runtime_error("The parent component '" + value + "' is not supported.");
        }

        /* Read the lateral position */
        Lateral lateral;
        value = static_cast<std::string>(position.at("y/value"));
        if (value == "left")
        {
            lateral = Lateral::Left;
        }
        else if (value == "right")
        {
            lateral = Lateral::Right;
        }
        else if (value == "mid")
        {
            lateral = Lateral::Mid;
        }
        else
        {
            throw std::runtime_error("The lateral position '" + value + "' is not supported.");
        }

        /* Read the longitudinal position */
        Longitudinal longitudinal;
        value = static_cast<std::string>(position.at("x/value"));
        if (value == "front")
        {
            longitudinal = Longitudinal::Front;
        }
        else if (value == "rear")
        {
            longitudinal = Longitudinal::Rear;
        }
        else
        {
            throw std::runtime_error("The longitudinal position '" + value + "' is not supported.");
        }

        /* Read the vertical position */
        Vertical vertical;
        value = static_cast<std::string>(position.at("z/value"));
        if (value == "under")
        {
            vertical = Vertical::Under;
        }
        else if (value == "mid")
        {
            vertical = Vertical::Mid;
        }
        else if (value == "over")
        {
            vertical = Vertical::Over;
        }
        else if (value == "in")
        {
            vertical = Vertical::In;
        }
        else
        {
            throw std::runtime_error("The vertical position '" + value + "' is not supported.");
        }

        /* Set the component */
        return {parent, lateral, longitudinal, vertical};
    }

    auto create_energy_carrier_map(const node& energy_carriers_node) -> EnergyCarriersMap
    {
        EnergyCarriersMap energy_carriers_map;
        /* Find all energy carrier nodes within energy_carriers_node */
        std::vector<node*> energy_carrier_nodes = energy_carriers_node.getVector("energy_carrier");

        /* Iterate over each energy carrier node and add it to the map */
        std::for_each(energy_carrier_nodes.begin(), energy_carrier_nodes.end(),
        [&energy_carriers_map](const node* energy_carrier_node) {
            /* Extract ID and value from the energy carrier node */
            int energy_carrier_id = energy_carrier_node->getIntAttrib("ID");
            std::string energy_carrier_value = static_cast<std::string>(energy_carrier_node->at("value"));
            /* Convert the string value to EnergyCarrierFamily enum using to_energy_carrier function */
            EnergyCarrierFamily energy_carrier = utility::to_energy_carrier(energy_carrier_value);
            /* Add the energy carrier information to the map */
            energy_carriers_map.insert({energy_carrier_id, energy_carrier});
        });
        return energy_carriers_map;
    }

    auto create_engine(
        const node& propulsor,
        const EnergyCarriersMap& energy_carriers_map,
        const double total_installed_thrust,
        const Offtakes &total_offtakes_required) -> PropulsionType
    {
        /* Get the engine type from the configuration node */
        const std::string power_type = propulsor.at("powertrain/value");
        const std::string thrust_type = propulsor.at("type/value");

        /* Get the energy carrier */
        const int energy_carrier_id = propulsor.at("energy_carrier_ID/value");
        if (energy_carriers_map.empty()) {
            std::cerr << "Error: Energy carriers map is empty." << std::endl;
        }

        auto it = energy_carriers_map.find(energy_carrier_id);
        if (it == energy_carriers_map.end()) {
            throw std::runtime_error("Energy carrier with ID " + std::to_string(energy_carrier_id) + " is not found in the map.");
        }
        const EnergyCarrierFamily energy_carrier = it->second;

        /* Calculate the required thrust of the engine */
        const double thrust_share = propulsor.at("thrust_share/value");
        const double design_thrust = total_installed_thrust * thrust_share;

        /*
         * Calculate the offtakes of the engine
         * -> For now every offtake is just scaled by the
         * thrust share of the engine
         */
        /** @todo Make the offtake distribution take other distributions schemes into account. */
        const Offtakes engine_offtakes = thrust_share * total_offtakes_required;

        /* Get the id position from the configuration node */
        const int id = propulsor.getIntAttrib("ID");
        const ParentComponent position = get_parent_component(propulsor.at("position"));

        /* Create the engine */
        if ((power_type + thrust_type) == "turbofan")
        {
            switch (energy_carrier)
            {
                case EnergyCarrierFamily::Kerosene:
                    return Turbofan<EnergyCarrierFamily::Kerosene>{id, position, design_thrust, engine_offtakes};
                case EnergyCarrierFamily::Liquid_Hydrogen:
                    return Turbofan<EnergyCarrierFamily::Liquid_Hydrogen>{id, position, design_thrust, engine_offtakes};
                default:
                    throw std::runtime_error("The energy carrier is not supported for a turbofan engine!");
            }
        }
        else if ((power_type + thrust_type) == "turboprop")
        {
            switch (energy_carrier)
            {
                case EnergyCarrierFamily::Kerosene:
                    return Turboprop<EnergyCarrierFamily::Kerosene>{id, position, design_thrust, engine_offtakes};
                case EnergyCarrierFamily::Liquid_Hydrogen:
                    return Turboprop<EnergyCarrierFamily::Liquid_Hydrogen>{id, position, design_thrust, engine_offtakes};
                default:
                    throw std::runtime_error("The energy carrier is not supported for a turboprop engine!");
            }
        }
        else if ((power_type + thrust_type) == "openrotorfan")
        {
            switch (energy_carrier)
            {
                case EnergyCarrierFamily::Kerosene:
                    return Openrotorfan<EnergyCarrierFamily::Kerosene>{id, position, design_thrust, engine_offtakes};
                default:
                    throw std::runtime_error("The energy carrier is not supported for a openrotor engine!");
            }
        }
        else
        {
            throw std::runtime_error("The powertrain '" + power_type + "' + '" + thrust_type + "' is not supported.");
        }
    }

    void print(const std::string_view message, const Level level)
    {
        /* Check whether the global runtime info in not null*/
        if (myRuntimeInfo == nullptr)
        {
            return;
        }

        /* Print the message */
        switch (level)
        {
            case Level::Out:
                myRuntimeInfo->out << message << std::endl;
                break;
            case Level::Debug:
                myRuntimeInfo->debug << message << std::endl;
                break;
            case Level::Info:
                myRuntimeInfo->info << message << std::endl;
                break;
            case Level::Warning:
                myRuntimeInfo->warn << message << std::endl;
                break;
            case Level::Error:
                myRuntimeInfo->err << message << std::endl;
                break;
            default:
                break;
        }
    }
} // namespace utility

auto operator* (const double factor, const Offtakes &offtakes) -> Offtakes
{
    return {factor * offtakes.bleed_air, factor * offtakes.shaft_power};
}

auto operator+ (const Offtakes &lhs, const Offtakes &rhs) -> Offtakes
{
    return {lhs.bleed_air + rhs.bleed_air, lhs.shaft_power + rhs.shaft_power};
}
