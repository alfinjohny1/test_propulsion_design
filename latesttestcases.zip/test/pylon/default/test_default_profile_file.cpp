/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 *
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <aircraftGeometry2/io/dat.h>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <gtest/gtest.h>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "../../temp_directory.h"
#include "pylon_test_geometry.h"

/* Unit Under Test */
#include "pylon/default/default_pylon.h"

/* === Fixtures === */
/**
 * @brief Aircraft geometry (pylon_test_geometry.h) and under-wing engine of
 * PylonDefault.DesignTurbofanKeroseneUnderWing, with the pylon designer on an empty temporary
 * geometry directory.
 */
class PylonProfileFile : public ::testing::Test, protected PylonTestGeometry
{
  protected:
    void set_profile(const std::string &profile)
    {
        config->at("module_configuration_file/program_settings/propulsion@Default/pylon/profile/value") = profile;
    }

    /* Design the pylon with the given geometry directory and return the engine */
    auto design(const std::filesystem::path &geometry_directory) -> Turbofan<EnergyCarrierFamily::Kerosene>
    {
        geometry::pylon::Default designer{config, aircraft, geometry_directory};
        designer.initialize();
        Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
        engine.set_dimension({0.8, 0.8, 1.5});
        engine.set_fan({0.9});
        engine.set_position({2.0, 3.0, -1.0});
        engine.set_nacelle(nacelle);
        designer(engine);
        return engine;
    }

    static auto read_text(const std::filesystem::path &file) -> std::string
    {
        std::ifstream stream(file);
        std::stringstream content;
        content << stream.rdbuf();
        return content.str();
    }

    std::shared_ptr<node> config = aixml::openDocument(std::filesystem::path{CMAKE_TEST_CONFIG_FILE});
    const UniqueTempDirectory geometry{"test_pylon_profile"};
};

/* === Tests === */
/**
 * @brief Test creating a missing pylon profile file.
 */
TEST_F(PylonProfileFile, CreatesMissingProfileFile)
{
    const std::filesystem::path profile_file = geometry.path() / "pylon.dat";
    ASSERT_FALSE(std::filesystem::exists(profile_file));

    const auto engine = design(geometry.path());

    ASSERT_TRUE(std::filesystem::exists(profile_file));
    const geom2::Polygon_2 contour = geom2::io::read_dat_file(profile_file);
    ASSERT_EQ(contour.size(), 202U);
    EXPECT_EQ(*contour.vertices_begin(), geom2::Point_2(0.0, 0.0));
    EXPECT_EQ(*std::prev(contour.vertices_end()), geom2::Point_2(1.0, 0.0));

    ASSERT_EQ(engine.pylon().sections.size(), 2U);
    EXPECT_EQ(engine.pylon().sections.at(0).name, "pylon");
}

/**
 * @brief Test the created pylon profile against the NACA 0012 formula.
 */
TEST_F(PylonProfileFile, CreatedProfileMatchesNacaFormula)
{
    design(geometry.path());

    std::ifstream file(geometry.path() / "pylon.dat");
    std::string line;
    ASSERT_TRUE(std::getline(file, line));
    EXPECT_EQ(line, "#NACA0012");
    std::vector<std::pair<double, double>> points;
    while (std::getline(file, line))
    {
        std::istringstream row(line);
        double x = 0.0;
        double y = 0.0;
        if (row >> x >> y)
        {
            points.emplace_back(x, y);
        }
    }
    ASSERT_EQ(points.size(), 202U);

    /* Check the upper surface against the NACA 0012 thickness distribution with closed trailing edge (5 t = 0.6) */
    const double pi = std::acos(-1.0);
    for (int i = 0; i <= 100; ++i)
    {
        const double x = 0.5 * (1.0 - std::cos(pi * i / 100.0));
        const double y = 0.6 * (0.2969 * std::sqrt(x) - 0.1281 * x - 0.3516 * x * x + 0.2843 * x * x * x - 0.1015 * x * x * x * x);
        EXPECT_NEAR(points[i].first, x, 1e-7);
        EXPECT_NEAR(points[i].second, y, 1e-7);
    }

    /* Check the lower surface */
    for (int i = 0; i <= 100; ++i)
    {
        const double x = 0.5 * (1.0 - std::cos(pi * i / 100.0));
        const double y = 0.6 * (0.2969 * std::sqrt(x) - 0.1281 * x - 0.3516 * x * x + 0.2843 * x * x * x - 0.1015 * x * x * x * x);
        EXPECT_NEAR(points[101 + i].first, x, 1e-7);
        EXPECT_NEAR(points[101 + i].second, -y, 1e-7);
    }
}

/**
 * @brief Test that the created pylon profile gives the same pylon as the stub profile.
 */
TEST_F(PylonProfileFile, CreatedProfileGivesSamePylonAsStub)
{
    const auto from_created = design(geometry.path());
    const auto from_stub = design(std::filesystem::path{CMAKE_TEST_STUBS_DIR});

    const auto &created = from_created.pylon();
    const auto &stub = from_stub.pylon();
    ASSERT_EQ(created.sections.size(), 2U);
    ASSERT_EQ(created.sections.size(), stub.sections.size());
    EXPECT_EQ(created.origin, stub.origin);
    EXPECT_EQ(created.normal, stub.normal);
    /* Compare every section with the stub pylon */
    EXPECT_EQ(created.sections[0].name, stub.sections[0].name);
    EXPECT_EQ(created.sections[0].origin, stub.sections[0].origin);
    EXPECT_NEAR(created.sections[0].get_chord_length(), stub.sections[0].get_chord_length(), 1e-12);
    EXPECT_NEAR(created.sections[0].get_contour(true).bbox().x_span(), stub.sections[0].get_contour(true).bbox().x_span(), 1e-12);
    EXPECT_NEAR(created.sections[0].get_contour(true).bbox().y_span(), stub.sections[0].get_contour(true).bbox().y_span(), 1e-12);
    EXPECT_EQ(created.sections[1].name, stub.sections[1].name);
    EXPECT_EQ(created.sections[1].origin, stub.sections[1].origin);
    EXPECT_NEAR(created.sections[1].get_chord_length(), stub.sections[1].get_chord_length(), 1e-12);
    EXPECT_NEAR(created.sections[1].get_contour(true).bbox().x_span(), stub.sections[1].get_contour(true).bbox().x_span(), 1e-12);
    EXPECT_NEAR(created.sections[1].get_contour(true).bbox().y_span(), stub.sections[1].get_contour(true).bbox().y_span(), 1e-12);
}

/**
 * @brief Test that an existing pylon profile file is read and not created again.
 */
TEST_F(PylonProfileFile, SecondRunReadsExistingFile)
{
    const std::filesystem::path profile_file = geometry.path() / "pylon.dat";
    const auto first = design(geometry.path());
    ASSERT_EQ(first.pylon().sections.size(), 2U);
    ASSERT_EQ(first.pylon().sections.at(0).get_contour(false).size(), 202U);

    /* Replace the created NACA 0012 profile by a diamond */
    std::ofstream diamond(profile_file, std::ios::trunc);
    diamond << "#diamond\n0 0\n0.5 0.2\n1 0\n0.5 -0.2\n";
    diamond.close();
    ASSERT_FALSE(diamond.fail());
    const std::string diamond_content = read_text(profile_file);

    const auto second = design(geometry.path());

    EXPECT_EQ(read_text(profile_file), diamond_content);
    ASSERT_EQ(second.pylon().sections.size(), 2U);
    /* Check that every section is the diamond with thickness 0.4 */
    EXPECT_EQ(second.pylon().sections.at(0).get_contour(false).size(), 4U);
    EXPECT_NEAR(second.pylon().sections.at(0).get_contour(true).bbox().y_span() / second.pylon().sections.at(0).get_contour(true).bbox().x_span(), 0.4, 1e-9);
    EXPECT_EQ(second.pylon().sections.at(1).get_contour(false).size(), 4U);
    EXPECT_NEAR(second.pylon().sections.at(1).get_contour(true).bbox().y_span() / second.pylon().sections.at(1).get_contour(true).bbox().x_span(), 0.4, 1e-9);
}

/**
 * @brief Test that a pylon profile path which cannot be created throws.
 */
TEST_F(PylonProfileFile, UncreatableProfilePathThrows)
{
    std::ofstream(geometry.path() / "blocker") << "not a directory";
    set_profile("blocker/pylon.dat");

    try
    {
        design(geometry.path());
        FAIL() << "Expected std::runtime_error for an uncreatable profile path";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("Error while creating the file for pylon."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test creating a pylon profile file in a missing subdirectory.
 */
TEST_F(PylonProfileFile, CreatesMissingSubdirectory)
{
    set_profile("profiles/pylon.dat");

    const auto engine = design(geometry.path());

    EXPECT_TRUE(std::filesystem::exists(geometry.path() / "profiles" / "pylon.dat"));
    EXPECT_EQ(engine.pylon().sections.size(), 2U);
}
