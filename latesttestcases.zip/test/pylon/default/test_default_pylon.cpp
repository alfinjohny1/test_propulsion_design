/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 *
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <cmath>
#include <filesystem>
#include <fstream>
#include <gtest/gtest.h>
#include <stdexcept>
#include <string>

#include "../../temp_directory.h"
#include "pylon_test_geometry.h"
#include <aircraftGeometry2/processing/transform.h>

/* Unit Under Test */
#include "pylon/default/default_pylon.h"

/* === Fixtures === */
class PylonRules : public ::testing::Test, protected PylonTestGeometry
{
  protected:
    void SetUp() override
    {
        /* Copy the stub profile pylon.dat (NACA 0012) into the geometry directory */
        std::filesystem::copy_file(std::filesystem::path{CMAKE_TEST_STUBS_DIR} / "pylon.dat", geometry.path() / "pylon.dat");

        /* Read the configuration with the default profile pylon.dat */
        config = aixml::openDocument(std::filesystem::path{CMAKE_TEST_CONFIG_FILE});
        config->at("module_configuration_file/program_settings/propulsion@Default/pylon/profile/value") = std::string{"pylon.dat"};

        /* Wing with an airfoil contour from the leading edge at 0 to the trailing edge at the chord, mean aerodynamic chord 1.5556 m */
        geom2::Polygon_2 airfoil;
        airfoil.push_back({0.0, 0.0});
        airfoil.push_back({0.5, -0.1});
        airfoil.push_back({1.0, 0.0});
        airfoil.push_back({0.5, 0.1});
        airfoil_wing.sections.emplace_back(airfoil);
        airfoil_wing.sections.emplace_back(airfoil);
        airfoil_wing.sections.at(0).set_chord_length(2.0);
        airfoil_wing.sections.at(1).set_chord_length(1.0);
        airfoil_wing.sections.at(1).origin = geom2::Point_3(0, 0, -5.0);
        airfoil_wing.origin = geom2::Point_3(3, 0, 2);
        airfoil_wing.normal = geom2::Direction_3(0, -1, 0);
        airfoil_wing.is_symmetric = true;
    }

    const UniqueTempDirectory geometry{"test_pylon_rules"};
    geom2::MultisectionSurface<geom2::AirfoilSection> airfoil_wing;
    std::shared_ptr<node> config;
};

/* === Tests === */
/**
 * @brief Test that no pylon is designed for an open-rotor engine in the wing.
 */
TEST_F(PylonRules, OpenRotorInWingWithoutPylon)
{
    /* Create the pylon designer */
    geometry::pylon::Default designer{config, aircraft, geometry.path()};
    designer.initialize();

    /* Setup the open rotor in the wing */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::In}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({2.0, 3.0, 2.0});
    engine.set_nacelle(nacelle);

    /* Design the pylon and check that there is none */
    EXPECT_NO_THROW(designer(engine));
    EXPECT_TRUE(engine.pylon().sections.empty());
}

/**
 * @brief Test that no pylon is designed for an open-rotor engine without aircraft geometry.
 */
TEST_F(PylonRules, OpenRotorWithoutGeometryWithoutPylon)
{
    /* Create the pylon designer without aircraft geometry */
    geometry::pylon::Default designer{config, nullptr, geometry.path()};
    designer.initialize();

    /* Setup the open rotor under the wing */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({2.0, 3.0, -1.0});
    engine.set_nacelle(nacelle);

    /* Design the pylon and check that there is none */
    EXPECT_NO_THROW(designer(engine));
    EXPECT_TRUE(engine.pylon().sections.empty());
}

/**
 * @brief Test that an unsupported parent component of a turbofan engine is rejected.
 */
TEST_F(PylonRules, UnsupportedParentRejected)
{
    /* Create the pylon designer */
    geometry::pylon::Default designer{config, aircraft, geometry.path()};
    designer.initialize();

    /* Setup an engine on top of the fuselage center */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Fuselage, Lateral::Mid, Longitudinal::Rear, Vertical::Over}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({1.0, 0.0, 1.0});
    engine.set_nacelle(nacelle);

    /* Design the pylon and check the error */
    try
    {
        designer(engine);
        FAIL() << "Expected std::runtime_error for an unsupported parent component";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The parent component is not supported!"), std::string::npos) << error.what();
    }
}

/**
 * @brief Test the current behaviour that the pylon rejects an open rotor on top of the fuselage, which the placement accepts.
 */
TEST_F(PylonRules, OpenRotorFuselageTopRejected)
{
    /* Create the pylon designer */
    geometry::pylon::Default designer{config, aircraft, geometry.path()};
    designer.initialize();

    /* Setup the open rotor on top of the rear fuselage, a location the placement accepts */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Over}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({1.8, 0.9, 1.1});
    engine.set_nacelle(nacelle);

    /* Design the pylon and check the error */
    try
    {
        designer(engine);
        FAIL() << "Expected std::runtime_error for an open rotor on top of the fuselage";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The parent component is not supported!"), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that every supported placement of a turbofan engine gets a pylon.
 */
TEST_F(PylonRules, SupportedPlacementsGetPylon)
{
    /* Create the pylon designer */
    geometry::pylon::Default designer{config, aircraft, geometry.path()};
    designer.initialize();

    /* Setup one engine for every supported placement */
    Turbofan<EnergyCarrierFamily::Kerosene> wing_under_right{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    wing_under_right.set_dimension({0.8, 0.8, 1.5});
    wing_under_right.set_fan({0.9});
    wing_under_right.set_position({2.0, 3.0, -1.0});
    wing_under_right.set_nacelle(nacelle);
    Turbofan<EnergyCarrierFamily::Kerosene> wing_under_left{1, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}};
    wing_under_left.set_dimension({0.8, 0.8, 1.5});
    wing_under_left.set_fan({0.9});
    wing_under_left.set_position({2.0, -3.0, -1.0});
    wing_under_left.set_nacelle(nacelle);
    Turbofan<EnergyCarrierFamily::Kerosene> wing_over_right{2, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Over}};
    wing_over_right.set_dimension({0.8, 0.8, 1.5});
    wing_over_right.set_fan({0.9});
    wing_over_right.set_position({2.0, 1.0, 3.0});
    wing_over_right.set_nacelle(nacelle);
    Turbofan<EnergyCarrierFamily::Kerosene> wing_over_left{3, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Over}};
    wing_over_left.set_dimension({0.8, 0.8, 1.5});
    wing_over_left.set_fan({0.9});
    wing_over_left.set_position({2.0, -1.0, 3.0});
    wing_over_left.set_nacelle(nacelle);
    Turbofan<EnergyCarrierFamily::Kerosene> fuselage_right{4, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Mid}};
    fuselage_right.set_dimension({0.8, 0.8, 1.5});
    fuselage_right.set_fan({0.9});
    fuselage_right.set_position({1.0, 2.0, 0.1});
    fuselage_right.set_nacelle(nacelle);
    Turbofan<EnergyCarrierFamily::Kerosene> fuselage_left{5, {Parent::Fuselage, Lateral::Left, Longitudinal::Rear, Vertical::Mid}};
    fuselage_left.set_dimension({0.8, 0.8, 1.5});
    fuselage_left.set_fan({0.9});
    fuselage_left.set_position({1.0, -2.0, 0.1});
    fuselage_left.set_nacelle(nacelle);
    Turbofan<EnergyCarrierFamily::Kerosene> wing_body_right{6, {Parent::WingBody, Lateral::Right, Longitudinal::Rear, Vertical::Over}};
    wing_body_right.set_dimension({0.8, 0.8, 1.5});
    wing_body_right.set_fan({0.9});
    wing_body_right.set_position({2.0, 1.0, 3.0});
    wing_body_right.set_nacelle(nacelle);
    Turbofan<EnergyCarrierFamily::Kerosene> wing_body_left{7, {Parent::WingBody, Lateral::Left, Longitudinal::Rear, Vertical::Over}};
    wing_body_left.set_dimension({0.8, 0.8, 1.5});
    wing_body_left.set_fan({0.9});
    wing_body_left.set_position({2.0, -1.0, 3.0});
    wing_body_left.set_nacelle(nacelle);

    /* Design all pylons */
    designer(wing_under_right);
    designer(wing_under_left);
    designer(wing_over_right);
    designer(wing_over_left);
    designer(fuselage_right);
    designer(fuselage_left);
    designer(wing_body_right);
    designer(wing_body_left);

    /* Check that every engine has a pylon with two sections */
    EXPECT_EQ(wing_under_right.pylon().sections.size(), 2U);
    EXPECT_EQ(wing_under_left.pylon().sections.size(), 2U);
    EXPECT_EQ(wing_over_right.pylon().sections.size(), 2U);
    EXPECT_EQ(wing_over_left.pylon().sections.size(), 2U);
    EXPECT_EQ(fuselage_right.pylon().sections.size(), 2U);
    EXPECT_EQ(fuselage_left.pylon().sections.size(), 2U);
    EXPECT_EQ(wing_body_right.pylon().sections.size(), 2U);
    EXPECT_EQ(wing_body_left.pylon().sections.size(), 2U);
}

/**
 * @brief Test that the pylon profile of an engine ID overrides the default profile.
 */
TEST_F(PylonRules, ProfilePerEngineIdOverridesDefault)
{
    /* Write a diamond profile and select it for the engine with ID 1 */
    std::ofstream diamond(geometry.path() / "diamond.dat");
    diamond << "#diamond\n0 0\n0.5 0.2\n1 0\n0.5 -0.2\n";
    diamond.close();
    ASSERT_FALSE(diamond.fail());
    node &propulsion = config->at("module_configuration_file/program_settings").appendChild("propulsion", true);
    propulsion.setAttrib("ID", "1");
    propulsion.appendChild("pylon", true).appendChild("profile", true).appendChild("value", true) = std::string{"diamond.dat"};

    /* Create the pylon designer */
    geometry::pylon::Default designer{config, aircraft, geometry.path()};
    designer.initialize();

    /* Setup the engines with ID 0 and 1 under the wing */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_0{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine_0.set_dimension({0.8, 0.8, 1.5});
    engine_0.set_fan({0.9});
    engine_0.set_position({2.0, 3.0, -1.0});
    engine_0.set_nacelle(nacelle);
    Turbofan<EnergyCarrierFamily::Kerosene> engine_1{1, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}};
    engine_1.set_dimension({0.8, 0.8, 1.5});
    engine_1.set_fan({0.9});
    engine_1.set_position({2.0, -3.0, -1.0});
    engine_1.set_nacelle(nacelle);

    /* Design both pylons */
    designer(engine_0);
    designer(engine_1);

    /* Check the profiles: ID 0 has the 202 points of pylon.dat, ID 1 the 4 points of the diamond */
    ASSERT_EQ(engine_0.pylon().sections.size(), 2U);
    ASSERT_EQ(engine_1.pylon().sections.size(), 2U);
    EXPECT_EQ(engine_0.pylon().sections.at(0).get_contour(false).size(), 202U);
    EXPECT_EQ(engine_1.pylon().sections.at(0).get_contour(false).size(), 4U);
}

/**
 * @brief Test that a pylon profile path that exists but cannot be opened throws.
 */
TEST_F(PylonRules, UnreadableProfileFileThrows)
{
    /* Select a profile whose path is a directory */
    std::filesystem::create_directories(geometry.path() / "blocked.dat");
    config->at("module_configuration_file/program_settings/propulsion@Default/pylon/profile/value") = std::string{"blocked.dat"};

    /* Create the pylon designer */
    geometry::pylon::Default designer{config, aircraft, geometry.path()};
    designer.initialize();

    /* Setup the engine under the wing */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({2.0, 3.0, -1.0});
    engine.set_nacelle(nacelle);

    /* Design the pylon and check the error */
    try
    {
        designer(engine);
        FAIL() << "Expected std::runtime_error for a profile file that cannot be opened";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("Could not open file:"), std::string::npos) << error.what();
    }
}

/**
 * @brief Test the current behaviour that a pylon profile file without coordinates gives empty sections.
 */
TEST_F(PylonRules, ProfileFileWithoutCoordinatesGivesEmptySections)
{
    /* Write a profile file without coordinates and select it */
    std::ofstream profile(geometry.path() / "empty.dat");
    profile << "# no coordinates\nabc def\n";
    profile.close();
    ASSERT_FALSE(profile.fail());
    config->at("module_configuration_file/program_settings/propulsion@Default/pylon/profile/value") = std::string{"empty.dat"};

    /* Create the pylon designer */
    geometry::pylon::Default designer{config, aircraft, geometry.path()};
    designer.initialize();

    /* Setup the engine under the wing */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({2.0, 3.0, -1.0});
    engine.set_nacelle(nacelle);

    /* Design the pylon */
    EXPECT_NO_THROW(designer(engine));

    /* Check that the two sections have no points */
    ASSERT_EQ(engine.pylon().sections.size(), 2U);
    EXPECT_EQ(engine.pylon().sections.at(0).get_contour(false).size(), 0U);
    EXPECT_EQ(engine.pylon().sections.at(1).get_contour(false).size(), 0U);
}

/**
 * @brief Test the name and the axis of the pylon of an engine under the wing.
 */
TEST_F(PylonRules, UnderWingPylonNameAndAxis)
{
    /* Create the pylon designer */
    geometry::pylon::Default designer{config, aircraft, geometry.path()};
    designer.initialize();

    /* Setup the engine with ID 3 under the wing */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{3, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({2.0, 3.0, -1.0});
    engine.set_nacelle(nacelle);

    /* Design the pylon */
    designer(engine);

    /* Check the name and the axis from the top of the nacelle to the engine */
    ASSERT_EQ(engine.pylon().sections.size(), 2U);
    EXPECT_EQ(engine.pylon().name, "pylon_3");
    EXPECT_EQ(engine.pylon().normal, geom2::Direction_3(0, 0, -1));
    EXPECT_EQ(engine.pylon().origin, geom2::Point_3(0, 0, 0));
}

/**
 * @brief Test the wing-side pylon chord limited by the mean aerodynamic chord of the wing.
 */
TEST_F(PylonRules, WingChordCappedByMeanAerodynamicChord)
{
    /* Use the wing with the airfoil contour and create the pylon designer */
    aircraft->wings.at(0) = airfoil_wing;
    geometry::pylon::Default designer{config, aircraft, geometry.path()};
    designer.initialize();

    /* Setup the engine under the wing at y = 1, where the local wing chord is 1.8 m */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({2.0, 1.0, -1.0});
    engine.set_nacelle(nacelle);

    /* Design the pylon */
    designer(engine);

    /* Check the chords: nacelle side 0.75 L = 1.125, wing side min(1.15 L, 0.9 MAC) = min(1.725, 1.4) = 1.4 */
    ASSERT_EQ(engine.pylon().sections.size(), 2U);
    EXPECT_NEAR(engine.pylon().sections.at(0).get_chord_length(), 1.125, 1e-9);
    EXPECT_NEAR(engine.pylon().sections.at(1).get_chord_length(), 1.4, 1e-9);
}

/**
 * @brief Test the wing-side pylon chord limited by the engine length.
 */
TEST_F(PylonRules, WingChordCappedByEngineLength)
{
    /* Create the pylon designer */
    geometry::pylon::Default designer{config, aircraft, geometry.path()};
    designer.initialize();

    /* Setup an engine of length 1 m under the wing at y = 1, where the local wing chord is 1.8 m */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.0});
    engine.set_fan({0.9});
    engine.set_position({2.0, 1.0, -1.0});
    engine.set_nacelle(nacelle);

    /* Design the pylon */
    designer(engine);

    /* Check the chords: nacelle side 0.75 L = 0.75, wing side min(1.15 L, 0.9 MAC) = min(1.15, 1.4) = 1.15 */
    ASSERT_EQ(engine.pylon().sections.size(), 2U);
    EXPECT_NEAR(engine.pylon().sections.at(0).get_chord_length(), 0.75, 1e-9);
    EXPECT_NEAR(engine.pylon().sections.at(1).get_chord_length(), 1.15, 1e-9);
}

/**
 * @brief Test the wing-side pylon chord limited by the local trailing edge of the wing.
 */
TEST_F(PylonRules, WingChordCappedAtTrailingEdge)
{
    /* Create the pylon designer */
    geometry::pylon::Default designer{config, aircraft, geometry.path()};
    designer.initialize();

    /* Setup the engine under the wing at y = 4, where the local wing chord is 1.2 m */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({2.0, 4.0, -1.0});
    engine.set_nacelle(nacelle);

    /* Design the pylon */
    designer(engine);

    /* Check the wing-side chord: the desired 1.4 m is shortened to the local chord 1.2 m (bisection, 20 steps) */
    ASSERT_EQ(engine.pylon().sections.size(), 2U);
    EXPECT_NEAR(engine.pylon().sections.at(1).get_chord_length(), 1.2, 1e-5);
}

/**
 * @brief Test the wing-side pylon chord limited by the twisted trailing edge of the wing.
 */
TEST_F(PylonRules, WingChordCappedAtTwistedTrailingEdge)
{
    /* Use the wing with the airfoil contour, twisted by 60 degrees: the trailing edge is at c cos(60 deg) = 0.5 c */
    aircraft->wings.at(0) = airfoil_wing;
    aircraft->wings.at(0).sections.at(0).set_twist_angle(std::acos(-1.0) / 3.0);
    aircraft->wings.at(0).sections.at(1).set_twist_angle(std::acos(-1.0) / 3.0);
    geometry::pylon::Default designer{config, aircraft, geometry.path()};
    designer.initialize();

    /* Setup the engine under the wing at y = 1, where the local wing chord is 1.8 m */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({2.0, 1.0, -1.0});
    engine.set_nacelle(nacelle);

    /* Design the pylon */
    designer(engine);

    /* Check the wing-side chord: shortened to the twisted trailing edge at 0.5 * 1.8 = 0.9 m (bisection, 20 steps) */
    ASSERT_EQ(engine.pylon().sections.size(), 2U);
    EXPECT_NEAR(engine.pylon().sections.at(1).get_chord_length(), 0.9, 1e-5);
}

/**
 * @brief Test the minimum wing-side pylon chord when no chord fits before the trailing edge.
 */
TEST_F(PylonRules, WingChordMinimum)
{
    /* Use the wing with the airfoil contour, twisted by 90 degrees: the trailing edge is at the leading edge */
    aircraft->wings.at(0) = airfoil_wing;
    aircraft->wings.at(0).sections.at(0).set_twist_angle(std::acos(-1.0) / 2.0);
    aircraft->wings.at(0).sections.at(1).set_twist_angle(std::acos(-1.0) / 2.0);
    geometry::pylon::Default designer{config, aircraft, geometry.path()};
    designer.initialize();

    /* Setup the engine under the wing at y = 1 */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({2.0, 1.0, -1.0});
    engine.set_nacelle(nacelle);

    /* Design the pylon */
    designer(engine);

    /* Check the wing-side chord: the minimum 0.001 m */
    ASSERT_EQ(engine.pylon().sections.size(), 2U);
    EXPECT_DOUBLE_EQ(engine.pylon().sections.at(1).get_chord_length(), 0.001);
}

/**
 * @brief Test the pylon of an engine over the wing.
 */
TEST_F(PylonRules, OverWingPylon)
{
    /* Use the wing with the airfoil contour and create the pylon designer */
    aircraft->wings.at(0) = airfoil_wing;
    geometry::pylon::Default designer{config, aircraft, geometry.path()};
    designer.initialize();

    /* Setup the engine 1 m over the wing at y = 1, where the local wing chord is 1.8 m */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Over}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({2.0, 1.0, 3.0});
    engine.set_nacelle(nacelle);

    /* Design the pylon */
    designer(engine);

    /* Check the axis from the bottom of the nacelle to the engine and the chords 0.5 L = 0.75 and 1.4 */
    ASSERT_EQ(engine.pylon().sections.size(), 2U);
    EXPECT_EQ(engine.pylon().normal, geom2::Direction_3(0, 0, 1));
    EXPECT_NEAR(engine.pylon().sections.at(0).get_chord_length(), 0.75, 1e-9);
    EXPECT_NEAR(engine.pylon().sections.at(1).get_chord_length(), 1.4, 1e-9);

    /* Check the sections in global coordinates: nacelle bottom (2, 1, 2.5) moved by (0.375, 0, -0.084),
     * wing leading edge (3, 1, 2) shifted aft by 1.8 - 1.4 = 0.4 to end on the trailing edge */
    const auto root = geom2::transform::to_parent(engine.pylon(), engine.pylon().sections.at(0).origin) + (engine.position() - CGAL::ORIGIN);
    EXPECT_NEAR(root.x(), 2.375, 1e-6);
    EXPECT_NEAR(root.y(), 1.0, 1e-6);
    EXPECT_NEAR(root.z(), 2.416, 1e-6);
    const auto tip = geom2::transform::to_parent(engine.pylon(), engine.pylon().sections.at(1).origin) + (engine.position() - CGAL::ORIGIN);
    EXPECT_NEAR(tip.x(), 3.4, 1e-6);
    EXPECT_NEAR(tip.y(), 1.0, 1e-6);
    EXPECT_NEAR(tip.z(), 2.0, 1e-6);
}

/**
 * @brief Test the pylon of a wing-body engine.
 */
TEST_F(PylonRules, WingBodyPylon)
{
    /* Use the wing with the airfoil contour and create the pylon designer */
    aircraft->wings.at(0) = airfoil_wing;
    geometry::pylon::Default designer{config, aircraft, geometry.path()};
    designer.initialize();

    /* Setup the wing-body engine with ID 2, 1 m over the wing at y = 1 */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{2, {Parent::WingBody, Lateral::Right, Longitudinal::Rear, Vertical::Over}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({2.0, 1.0, 3.0});
    engine.set_nacelle(nacelle);

    /* Design the pylon */
    designer(engine);

    /* Check the name, the axis and the chords as for an engine over the wing */
    ASSERT_EQ(engine.pylon().sections.size(), 2U);
    EXPECT_EQ(engine.pylon().name, "pylon_2");
    EXPECT_EQ(engine.pylon().normal, geom2::Direction_3(0, 0, 1));
    EXPECT_NEAR(engine.pylon().sections.at(0).get_chord_length(), 0.75, 1e-9);
    EXPECT_NEAR(engine.pylon().sections.at(1).get_chord_length(), 1.4, 1e-9);

    /* Check the sections in global coordinates as for an engine over the wing */
    const auto root = geom2::transform::to_parent(engine.pylon(), engine.pylon().sections.at(0).origin) + (engine.position() - CGAL::ORIGIN);
    EXPECT_NEAR(root.x(), 2.375, 1e-6);
    EXPECT_NEAR(root.y(), 1.0, 1e-6);
    EXPECT_NEAR(root.z(), 2.416, 1e-6);
    const auto tip = geom2::transform::to_parent(engine.pylon(), engine.pylon().sections.at(1).origin) + (engine.position() - CGAL::ORIGIN);
    EXPECT_NEAR(tip.x(), 3.4, 1e-6);
    EXPECT_NEAR(tip.y(), 1.0, 1e-6);
    EXPECT_NEAR(tip.z(), 2.0, 1e-6);
}

/**
 * @brief Test that the wing named in the configuration carries the pylon when there are several wings.
 */
TEST_F(PylonRules, NamedWingCarriesPylon)
{
    /* Name the wing "front_wing" (chord 2 m to 1 m) and insert a second wing "rear_wing" with half the chords 10 m further aft as the first wing */
    aircraft->wings.at(0).name = "front_wing";
    geom2::MultisectionSurface<geom2::AirfoilSection> rear_wing = aircraft->wings.at(0);
    rear_wing.name = "rear_wing";
    rear_wing.origin = geom2::Point_3(13, 0, 2);
    rear_wing.sections.at(0).set_chord_length(1.0);
    rear_wing.sections.at(1).set_chord_length(0.5);
    aircraft->wings.insert(aircraft->wings.begin(), rear_wing);

    /* Create the pylon designer */
    geometry::pylon::Default designer{config, aircraft, geometry.path()};
    designer.initialize();

    /* Setup the engine under the wing at y = 3 */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({2.0, 3.0, -1.0});
    engine.set_nacelle(nacelle);

    /* Design the pylon */
    designer(engine);

    /* Check the wing side of the pylon in global coordinates: leading edge of "front_wing" at (3, 3, 2) */
    ASSERT_EQ(engine.pylon().sections.size(), 2U);
    const auto tip = geom2::transform::to_parent(engine.pylon(), engine.pylon().sections.at(1).origin) + (engine.position() - CGAL::ORIGIN);
    EXPECT_NEAR(tip.x(), 3.0, 1e-6);
    EXPECT_NEAR(tip.y(), 3.0, 1e-6);
    EXPECT_NEAR(tip.z(), 2.0, 1e-6);

    /* Check the wing-side chord: the local chord of "front_wing" at y = 3, 2 - 0.2 * 3 = 1.4 (trailing-edge cap, bisection) */
    EXPECT_NEAR(engine.pylon().sections.at(1).get_chord_length(), 1.4, 1e-5);
}

/**
 * @brief Test that the first wing carries the pylon when the configured wing name is not found.
 */
TEST_F(PylonRules, FirstWingCarriesPylonWhenNameNotFound)
{
    /* Name the wing "front_wing" (chord 2 m to 1 m) and insert a second wing "rear_wing" with half the chords 10 m further aft as the first wing */
    aircraft->wings.at(0).name = "front_wing";
    geom2::MultisectionSurface<geom2::AirfoilSection> rear_wing = aircraft->wings.at(0);
    rear_wing.name = "rear_wing";
    rear_wing.origin = geom2::Point_3(13, 0, 2);
    rear_wing.sections.at(0).set_chord_length(1.0);
    rear_wing.sections.at(1).set_chord_length(0.5);
    aircraft->wings.insert(aircraft->wings.begin(), rear_wing);
    config->at("module_configuration_file/program_settings/name_wing_engines/value") = std::string{"missing_wing"};

    /* Create the pylon designer */
    geometry::pylon::Default designer{config, aircraft, geometry.path()};
    designer.initialize();

    /* Setup the engine under the wing at y = 3 */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({2.0, 3.0, -1.0});
    engine.set_nacelle(nacelle);

    /* Design the pylon */
    designer(engine);

    /* Check the wing side of the pylon in global coordinates: leading edge of the first wing "rear_wing" at (13, 3, 2) */
    ASSERT_EQ(engine.pylon().sections.size(), 2U);
    const auto tip = geom2::transform::to_parent(engine.pylon(), engine.pylon().sections.at(1).origin) + (engine.position() - CGAL::ORIGIN);
    EXPECT_NEAR(tip.x(), 13.0, 1e-6);
    EXPECT_NEAR(tip.y(), 3.0, 1e-6);
    EXPECT_NEAR(tip.z(), 2.0, 1e-6);

    /* Check the wing-side chord: the local chord of "rear_wing" at y = 3, 1 - 0.1 * 3 = 0.7 (trailing-edge cap, bisection) */
    EXPECT_NEAR(engine.pylon().sections.at(1).get_chord_length(), 0.7, 1e-5);
}

/**
 * @brief Test the attachment points of the pylons of two fuselage engines.
 */
TEST_F(PylonRules, FuselageAttachmentPoints)
{
    /* Create the pylon designer */
    geometry::pylon::Default designer{config, aircraft, geometry.path()};
    designer.initialize();

    /* Setup the right and the left engine at the side of the fuselage */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_right{0, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Mid}};
    engine_right.set_dimension({0.8, 0.8, 1.5});
    engine_right.set_fan({0.9});
    engine_right.set_position({1.0, 2.0, 0.1});
    engine_right.set_nacelle(nacelle);
    Turbofan<EnergyCarrierFamily::Kerosene> engine_left{1, {Parent::Fuselage, Lateral::Left, Longitudinal::Rear, Vertical::Mid}};
    engine_left.set_dimension({0.8, 0.8, 1.5});
    engine_left.set_fan({0.9});
    engine_left.set_position({1.0, -2.0, 0.1});
    engine_left.set_nacelle(nacelle);

    /* Design both pylons */
    designer(engine_right);
    designer(engine_left);

    /* Check the axes from the nacelle side facing the fuselage to the engine */
    ASSERT_EQ(engine_right.pylon().sections.size(), 2U);
    ASSERT_EQ(engine_left.pylon().sections.size(), 2U);
    EXPECT_EQ(engine_right.pylon().normal, geom2::Direction_3(0, 1, 0));
    EXPECT_EQ(engine_left.pylon().normal, geom2::Direction_3(0, -1, 0));

    /* Check the sections in global coordinates: nacelle side facing the fuselage (1, +-1.5, 0.1) moved by the
     * inset (0.375, 0, 0.084) of an engine under the wing (decided relative to the wing, O-17), fuselage side (1, +-0.5, 0) */
    const auto root_right = geom2::transform::to_parent(engine_right.pylon(), engine_right.pylon().sections.at(0).origin) + (engine_right.position() - CGAL::ORIGIN);
    const auto tip_right = geom2::transform::to_parent(engine_right.pylon(), engine_right.pylon().sections.at(1).origin) + (engine_right.position() - CGAL::ORIGIN);
    const auto root_left = geom2::transform::to_parent(engine_left.pylon(), engine_left.pylon().sections.at(0).origin) + (engine_left.position() - CGAL::ORIGIN);
    const auto tip_left = geom2::transform::to_parent(engine_left.pylon(), engine_left.pylon().sections.at(1).origin) + (engine_left.position() - CGAL::ORIGIN);
    EXPECT_NEAR(root_right.x(), 1.375, 1e-6);
    EXPECT_NEAR(root_right.y(), 1.5, 1e-6);
    EXPECT_NEAR(root_right.z(), 0.184, 1e-6);
    EXPECT_NEAR(tip_right.x(), 1.0, 1e-6);
    EXPECT_NEAR(tip_right.y(), 0.5, 1e-6);
    EXPECT_NEAR(tip_right.z(), 0.0, 1e-6);
    EXPECT_NEAR(root_left.x(), 1.375, 1e-6);
    EXPECT_NEAR(root_left.y(), -1.5, 1e-6);
    EXPECT_NEAR(root_left.z(), 0.184, 1e-6);
    EXPECT_NEAR(tip_left.x(), 1.0, 1e-6);
    EXPECT_NEAR(tip_left.y(), -0.5, 1e-6);
    EXPECT_NEAR(tip_left.z(), 0.0, 1e-6);
}

/**
 * @brief Test the pylon of a liquid hydrogen turbofan engine under the wing.
 */
TEST_F(PylonRules, LiquidHydrogenTurbofanPylon)
{
    /* Create the pylon designer */
    geometry::pylon::Default designer{config, aircraft, geometry.path()};
    designer.initialize();

    /* Setup the liquid hydrogen engine under the wing at y = 3 */
    Turbofan<EnergyCarrierFamily::Liquid_Hydrogen> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({2.0, 3.0, -1.0});
    engine.set_nacelle(nacelle);

    /* Design the pylon */
    designer(engine);

    /* Check the pylon as for the kerosene turbofan: chords 1.125 and the local wing chord 1.4 (bisection) */
    ASSERT_EQ(engine.pylon().sections.size(), 2U);
    EXPECT_EQ(engine.pylon().name, "pylon_0");
    EXPECT_EQ(engine.pylon().normal, geom2::Direction_3(0, 0, -1));
    EXPECT_NEAR(engine.pylon().sections.at(0).get_chord_length(), 1.125, 1e-9);
    EXPECT_NEAR(engine.pylon().sections.at(1).get_chord_length(), 1.4, 1e-5);
}

/**
 * @brief Test the pylon of an open-rotor engine under the wing.
 */
TEST_F(PylonRules, OpenRotorPylonUnderWing)
{
    /* Create the pylon designer */
    geometry::pylon::Default designer{config, aircraft, geometry.path()};
    designer.initialize();

    /* Setup the open rotor with ID 4 under the wing at y = 3 */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{4, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({2.0, 3.0, -1.0});
    engine.set_nacelle(nacelle);

    /* Design the pylon */
    designer(engine);

    /* Check the name, the axis and the chords L / 2 = 0.75 and 0.4 L = 0.6 */
    ASSERT_EQ(engine.pylon().sections.size(), 2U);
    EXPECT_EQ(engine.pylon().name, "pylon_4");
    EXPECT_EQ(engine.pylon().normal, geom2::Direction_3(0, 0, -1));
    EXPECT_NEAR(engine.pylon().sections.at(0).get_chord_length(), 0.75, 1e-9);
    EXPECT_NEAR(engine.pylon().sections.at(1).get_chord_length(), 0.6, 1e-9);

    /* Check the sections relative to the engine, in global coordinates: nacelle top minus (engine - (0.3 L, 0, -h / 6))
     * = (0.45, 0, 0.5 - 0.1333), wing leading edge (3, 3, 2) minus (engine + (-1, 0, 0)) = (2, 0, 3) */
    const auto root = geom2::transform::to_parent(engine.pylon(), engine.pylon().sections.at(0).origin) + (engine.position() - CGAL::ORIGIN);
    EXPECT_NEAR(root.x(), 2.45, 1e-6);
    EXPECT_NEAR(root.y(), 3.0, 1e-6);
    EXPECT_NEAR(root.z(), -0.633333, 1e-6);
    const auto tip = geom2::transform::to_parent(engine.pylon(), engine.pylon().sections.at(1).origin) + (engine.position() - CGAL::ORIGIN);
    EXPECT_NEAR(tip.x(), 4.0, 1e-6);
    EXPECT_NEAR(tip.y(), 3.0, 1e-6);
    EXPECT_NEAR(tip.z(), 2.0, 1e-6);
}

/**
 * @brief Test the pylon of an open-rotor engine over the wing.
 */
TEST_F(PylonRules, OpenRotorPylonOverWing)
{
    /* Create the pylon designer */
    geometry::pylon::Default designer{config, aircraft, geometry.path()};
    designer.initialize();

    /* Setup the open rotor 1 m over the wing at y = 1 */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Over}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({2.0, 1.0, 3.0});
    engine.set_nacelle(nacelle);

    /* Design the pylon */
    designer(engine);

    /* Check the axis from the bottom of the nacelle to the engine and the chords L / 2 = 0.75 and 0.4 L = 0.6 */
    ASSERT_EQ(engine.pylon().sections.size(), 2U);
    EXPECT_EQ(engine.pylon().normal, geom2::Direction_3(0, 0, 1));
    EXPECT_NEAR(engine.pylon().sections.at(0).get_chord_length(), 0.75, 1e-9);
    EXPECT_NEAR(engine.pylon().sections.at(1).get_chord_length(), 0.6, 1e-9);

    /* Check the sections relative to the engine, in global coordinates: nacelle bottom minus (engine - (0.3 L, 0, -h / 6))
     * = (0.45, 0, -0.5 - 0.1333), wing leading edge (3, 1, 2) minus (engine + (-1.5, 0, -0.8)) = (2.5, 0, -0.2) */
    const auto root = geom2::transform::to_parent(engine.pylon(), engine.pylon().sections.at(0).origin) + (engine.position() - CGAL::ORIGIN);
    EXPECT_NEAR(root.x(), 2.45, 1e-6);
    EXPECT_NEAR(root.y(), 1.0, 1e-6);
    EXPECT_NEAR(root.z(), 2.366667, 1e-6);
    const auto tip = geom2::transform::to_parent(engine.pylon(), engine.pylon().sections.at(1).origin) + (engine.position() - CGAL::ORIGIN);
    EXPECT_NEAR(tip.x(), 4.5, 1e-6);
    EXPECT_NEAR(tip.y(), 1.0, 1e-6);
    EXPECT_NEAR(tip.z(), 2.8, 1e-6);
}

/**
 * @brief Test the pylon of an open-rotor engine at the side of the fuselage.
 */
TEST_F(PylonRules, OpenRotorPylonFuselage)
{
    /* Create the pylon designer */
    geometry::pylon::Default designer{config, aircraft, geometry.path()};
    designer.initialize();

    /* Setup the open rotor at the right side of the fuselage */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Mid}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_position({1.0, 2.0, 0.1});
    engine.set_nacelle(nacelle);

    /* Design the pylon */
    designer(engine);

    /* Check the axis from the nacelle side facing the fuselage to the engine and the chords 0.75 and 0.6 */
    ASSERT_EQ(engine.pylon().sections.size(), 2U);
    EXPECT_EQ(engine.pylon().normal, geom2::Direction_3(0, 1, 0));
    EXPECT_NEAR(engine.pylon().sections.at(0).get_chord_length(), 0.75, 1e-9);
    EXPECT_NEAR(engine.pylon().sections.at(1).get_chord_length(), 0.6, 1e-9);

    /* Check the sections relative to the engine, in global coordinates: nacelle side (0, -0.5, 0) plus (0.45, 0, -0.1333),
     * fuselage side (1, 0.5, 0) minus (engine + (-1.5, 1, -0.7)) = (1.5, -2.5, 0.6) */
    const auto root = geom2::transform::to_parent(engine.pylon(), engine.pylon().sections.at(0).origin) + (engine.position() - CGAL::ORIGIN);
    EXPECT_NEAR(root.x(), 1.45, 1e-6);
    EXPECT_NEAR(root.y(), 1.5, 1e-6);
    EXPECT_NEAR(root.z(), -0.033333, 1e-6);
    const auto tip = geom2::transform::to_parent(engine.pylon(), engine.pylon().sections.at(1).origin) + (engine.position() - CGAL::ORIGIN);
    EXPECT_NEAR(tip.x(), 2.5, 1e-6);
    EXPECT_NEAR(tip.y(), -0.5, 1e-6);
    EXPECT_NEAR(tip.z(), 0.7, 1e-6);
}
