/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 *
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <filesystem>
#include <gtest/gtest.h>

/* Unit Under Test */
#include "mass/default/default_mass.h"
#include "mass/default/openrotorfan.cpp"

/* === Types ===*/
using Point_2 = geom2::Point_2;
using Polygon_2 = geom2::Polygon_2;
using PolygonSection = geom2::PolygonSection;
using AirfoilSection = geom2::AirfoilSection;

/* === Fixtures === */
class OpenrotorfanMassNacelle : public ::testing::Test
{
  protected:
    void SetUp() override
    {
        /* Create the shape */
        Polygon_2 shape{};
        shape.push_back(Point_2(-1, -1));
        shape.push_back(Point_2(1, -1));
        shape.push_back(Point_2(1, 1));
        shape.push_back(Point_2(-1, 1));

        /* Create the nacelle surface with its centroid at (0, 1, 2) */
        nacelle_surface.sections.emplace_back(shape);
        nacelle_surface.sections.emplace_back(shape);
        nacelle_surface.sections.emplace_back(shape);
        nacelle_surface.sections[0].origin = {0, 0, 0};
        nacelle_surface.sections[0].set_width(1.0);
        nacelle_surface.sections[1].origin = {0, 1, 2};
        nacelle_surface.sections[1].set_width(1.0);
        nacelle_surface.sections[2].origin = {0, 2, 4};
        nacelle_surface.sections[2].set_width(1.0);
    }

    geom2::MultisectionSurface<PolygonSection> nacelle_surface;
};

class OpenrotorfanMassPylon : public ::testing::Test
{
  protected:
    void SetUp() override
    {
        /* Create the shape */
        Polygon_2 shape{};
        shape.push_back(Point_2(0, 0));
        shape.push_back(Point_2(0.5, 0.2));
        shape.push_back(Point_2(1.0, 0.0));
        shape.push_back(Point_2(0.5, 0.0));

        /* Create the airfoil */
        AirfoilSection airfoil{shape};

        /* Create the pylon surface with its centroid at (0.75, 0, -2) */
        pylon_surface.sections.emplace_back(airfoil);
        pylon_surface.sections.emplace_back(airfoil);
        pylon_surface.sections.emplace_back(airfoil);
        pylon_surface.sections[0].origin = geom2::Point_3(0, 0, 0);
        pylon_surface.sections[0].set_chord_length(3.0);
        pylon_surface.sections[1].origin = geom2::Point_3(0, 0, -2);
        pylon_surface.sections[1].set_chord_length(1.0);
        pylon_surface.sections[2].origin = geom2::Point_3(0, 0, -4);
        pylon_surface.sections[2].set_chord_length(1.0);
    }

    geom2::MultisectionSurface<AirfoilSection> pylon_surface{};
};

class OpenrotorfanMassAnalyzer : public ::testing::Test
{
  protected:
    void SetUp() override
    {
        /* Create the nacelle shape */
        Polygon_2 nacelle_shape{};
        nacelle_shape.push_back(Point_2(-1, -1));
        nacelle_shape.push_back(Point_2(1, -1));
        nacelle_shape.push_back(Point_2(1, 1));
        nacelle_shape.push_back(Point_2(-1, 1));

        /* Create the nacelle surface with its centroid at (0, 1, 2) */
        nacelle_surface.sections.emplace_back(nacelle_shape);
        nacelle_surface.sections.emplace_back(nacelle_shape);
        nacelle_surface.sections.emplace_back(nacelle_shape);
        nacelle_surface.sections[0].origin = {0, 0, 0};
        nacelle_surface.sections[0].set_width(1.0);
        nacelle_surface.sections[1].origin = {0, 1, 2};
        nacelle_surface.sections[1].set_width(1.0);
        nacelle_surface.sections[2].origin = {0, 2, 4};
        nacelle_surface.sections[2].set_width(1.0);

        /* Create the pylon airfoil */
        Polygon_2 pylon_shape{};
        pylon_shape.push_back(Point_2(0, 0));
        pylon_shape.push_back(Point_2(0.5, 0.2));
        pylon_shape.push_back(Point_2(1.0, 0.0));
        pylon_shape.push_back(Point_2(0.5, 0.0));
        AirfoilSection airfoil{pylon_shape};

        /* Create the pylon surface with its centroid at (0.75, 0, -2) */
        pylon_surface.sections.emplace_back(airfoil);
        pylon_surface.sections.emplace_back(airfoil);
        pylon_surface.sections.emplace_back(airfoil);
        pylon_surface.sections[0].origin = geom2::Point_3(0, 0, 0);
        pylon_surface.sections[0].set_chord_length(3.0);
        pylon_surface.sections[1].origin = geom2::Point_3(0, 0, -2);
        pylon_surface.sections[1].set_chord_length(1.0);
        pylon_surface.sections[2].origin = geom2::Point_3(0, 0, -4);
        pylon_surface.sections[2].set_chord_length(1.0);

        /* Setup the engine with thrust 1000 N, h = w = 2 m and L = 4 m */
        engine.set_required_thrust(1000.0);
        engine.set_dimension({2.0, 2.0, 4.0});
        engine.set_nacelle(nacelle_surface);

        /* Read the configuration with neutral technology factors */
        config = aixml::openDocument(std::filesystem::path{CMAKE_TEST_CONFIG_FILE});
        set_technology_factors(1.0, 1.0, 1.0);
    }

    /* Set the mass technology factors in the configuration */
    void set_technology_factors(const double engine_mass, const double nacelle_mass, const double pylon_mass)
    {
        const std::string base = "module_configuration_file/program_settings/technology_factors/";
        config->at(base + "engine_mass/value") = engine_mass;
        config->at(base + "nacelle_mass/value") = nacelle_mass;
        config->at(base + "pylon_mass/value") = pylon_mass;
    }

    /* Create and initialize the analyzer with the current configuration, then analyze the engine */
    void analyze()
    {
        mass::Default analyzer{config};
        analyzer.initialize();
        analyzer(engine);
    }

    geom2::MultisectionSurface<PolygonSection> nacelle_surface;
    geom2::MultisectionSurface<AirfoilSection> pylon_surface{};
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{};
    std::shared_ptr<node> config;
};

/* === Tests === */
/**
 * @brief Test analysing the mass of an open-rotor engine.
 */
TEST(OpenrotorfanDefaultMass, EngineMass)
{
    EXPECT_NEAR(mass::calculate_engine_mass_openrotor(1.0, 1000.0), 386.964, 1e-9);
}

/**
 * @brief Test analysing the mass of an open-rotor engine with a technology factor.
 */
TEST(OpenrotorfanDefaultMass, EngineMassTechnologyFactor)
{
    EXPECT_NEAR(mass::calculate_engine_mass_openrotor(0.8, 1000.0), 309.5712, 1e-9);
}

/**
 * @brief Test analysing the mass of an open-rotor engine without thrust.
 */
TEST(OpenrotorfanDefaultMass, EngineMassZeroThrust)
{
    EXPECT_NEAR(mass::calculate_engine_mass_openrotor(1.0, 0.0), 367.884, 1e-9);
}

/**
 * @brief Test analysing the CG of an open-rotor engine.
 */
TEST(OpenrotorfanDefaultMass, EngineCG)
{
    EXPECT_EQ(mass::calculate_engine_CG_openrotor(4.0), Eigen::Vector3d(2.0, 0.0, 0.0));
    EXPECT_EQ(mass::calculate_engine_CG_openrotor(3.0), Eigen::Vector3d(1.5, 0.0, 0.0));
}

/**
 * @brief Test analysing the inertia of an open-rotor engine.
 */
TEST(OpenrotorfanDefaultMass, EngineInertia)
{
    Eigen::Matrix3d inertia = mass::calculate_engine_inertia_openrotor(2.0, 2.0, 4.0, 12.0);
    Eigen::Matrix3d inertia_expected;
    inertia_expected << 6.0, 0.0 , 0.0,
                        0.0, 19.0, 0.0,
                        0.0, 0.0 , 19.0;
    EXPECT_TRUE(inertia.isApprox(inertia_expected, 1e-9));
}

/**
 * @brief Test analysing the inertia of an open-rotor engine with a non-circular cross-section.
 */
TEST(OpenrotorfanDefaultMass, EngineInertiaNonCircular)
{
    Eigen::Matrix3d inertia = mass::calculate_engine_inertia_openrotor(2.0, 4.0, 3.0, 8.0);
    EXPECT_NEAR(inertia(0, 0), 9.0, 1e-9);
    EXPECT_NEAR(inertia(1, 1), 10.5, 1e-9);
    EXPECT_NEAR(inertia(2, 2), 10.5, 1e-9);
    EXPECT_NEAR(inertia(0, 1), 0.0, 1e-9);
    EXPECT_NEAR(inertia(0, 2), 0.0, 1e-9);
    EXPECT_NEAR(inertia(1, 2), 0.0, 1e-9);
}

/**
 * @brief Test analysing the nacelle mass of an open-rotor engine.
 */
TEST(OpenrotorfanDefaultMass, NacelleMass)
{
    EXPECT_NEAR(mass::calculate_nacelle_mass_openrotor(1.0, 1000.0), 599.32, 1e-9);
    EXPECT_NEAR(mass::calculate_nacelle_mass_openrotor(0.8, 1000.0), 479.456, 1e-9);
}

/**
 * @brief Test analysing the pylon mass of an open-rotor engine.
 */
TEST(OpenrotorfanDefaultMass, PylonMass)
{
    EXPECT_NEAR(mass::calculate_pylon_mass_openrotor(1.0, 1000.0), 353.535, 1e-9);
    EXPECT_NEAR(mass::calculate_pylon_mass_openrotor(0.8, 1000.0), 282.828, 1e-9);
}

/**
 * @brief Test analysing the nacelle CG of an open-rotor engine.
 */
TEST_F(OpenrotorfanMassNacelle, NacelleCGFollowsSurface)
{
    /* Analyse the default */
    Eigen::Vector3d nacelle_cg = mass::calculate_nacelle_CG_openrotor(nacelle_surface);
    EXPECT_TRUE(nacelle_cg.isApprox(Eigen::Vector3d(0.0, 1.0, 2.0), 1e-9));

    /* Move the origin of the nacelle */
    nacelle_surface.origin = geom2::Point_3(1.0, 2.0, 3.0);
    nacelle_cg = mass::calculate_nacelle_CG_openrotor(nacelle_surface);
    EXPECT_TRUE(nacelle_cg.isApprox(Eigen::Vector3d(1.0, 3.0, 5.0), 1e-9));
}

/**
 * @brief Test analysing the nacelle CG of an open-rotor engine with a rotated nacelle.
 */
TEST_F(OpenrotorfanMassNacelle, NacelleCGFollowsRotation)
{
    /* Change the normal of the nacelle */
    nacelle_surface.normal = {1, 0, 0};
    nacelle_surface.rotation_z = -1.5708; // Rotate 90 degrees
    Eigen::Vector3d nacelle_cg = mass::calculate_nacelle_CG_openrotor(nacelle_surface);
    EXPECT_TRUE(nacelle_cg.isApprox(Eigen::Vector3d(2.0, 1.0, 0.0), 1e-4));
}

/**
 * @brief Test analysing the pylon CG of an open-rotor engine.
 */
TEST_F(OpenrotorfanMassPylon, PylonCGFollowsSurface)
{
    /* Analyse the default */
    Eigen::Vector3d pylon_cg = mass::calculate_pylon_CG_openrotor(pylon_surface);
    EXPECT_TRUE(pylon_cg.isApprox(Eigen::Vector3d(0.75, 0.0, -2.0), 1e-9));

    /* Move the origin of the pylon */
    pylon_surface.origin = geom2::Point_3(1.0, 2.0, 3.0);
    pylon_cg = mass::calculate_pylon_CG_openrotor(pylon_surface);
    EXPECT_TRUE(pylon_cg.isApprox(Eigen::Vector3d(1.75, 2.0, 1.0), 1e-9));
}

/**
 * @brief Test analysing the masses of an open-rotor engine without a pylon.
 */
TEST_F(OpenrotorfanMassAnalyzer, WithoutPylon)
{
    /* Analyse the engine */
    analyze();

    /* Check the engine */
    PointMass engine_mass = engine.pointmass(Component::Engine);
    Eigen::Matrix3d inertia_expected;
    inertia_expected << 193.482, 0.0    , 0.0,
                        0.0    , 612.693, 0.0,
                        0.0    , 0.0    , 612.693;
    EXPECT_NEAR(engine_mass.mass, 386.964, 1e-9);
    EXPECT_TRUE(engine_mass.CG.isApprox(Eigen::Vector3d(2.0, 0.0, 0.0)));
    EXPECT_TRUE(engine_mass.inertia.isApprox(inertia_expected, 1e-9));

    /* Check the nacelle */
    PointMass nacelle_mass = engine.pointmass(Component::Nacelle);
    EXPECT_NEAR(nacelle_mass.mass, 599.32, 1e-9);
    EXPECT_TRUE(nacelle_mass.CG.isApprox(Eigen::Vector3d(0.0, 1.0, 2.0), 1e-9));

    /* Check the pylon */
    PointMass pylon_mass = engine.pointmass(Component::Pylon);
    EXPECT_EQ(pylon_mass.mass, 0.0);
    EXPECT_EQ(pylon_mass.CG, Eigen::Vector3d::Zero());
    EXPECT_EQ(pylon_mass.inertia, Eigen::Matrix3d::Zero());
}

/**
 * @brief Test analysing the masses of an open-rotor engine with a pylon.
 */
TEST_F(OpenrotorfanMassAnalyzer, WithPylon)
{
    /* Analyse the engine with a pylon */
    engine.set_pylon(pylon_surface);
    analyze();

    /* Check the pylon */
    PointMass pylon_mass = engine.pointmass(Component::Pylon);
    EXPECT_NEAR(pylon_mass.mass, 353.535, 1e-9);
    EXPECT_TRUE(pylon_mass.CG.isApprox(Eigen::Vector3d(0.75, 0.0, -2.0), 1e-9));
}

/**
 * @brief Test applying the technology factors from the configuration.
 */
TEST_F(OpenrotorfanMassAnalyzer, TechnologyFactorsFromConfiguration)
{
    /* Analyse the engine with a pylon and technology factors 0.8, 0.9 and 1.1 */
    engine.set_pylon(pylon_surface);
    set_technology_factors(0.8, 0.9, 1.1);
    analyze();

    /* Check the masses */
    EXPECT_NEAR(engine.pointmass(Component::Engine).mass, 309.5712, 1e-9);
    EXPECT_NEAR(engine.pointmass(Component::Nacelle).mass, 539.388, 1e-9);
    EXPECT_NEAR(engine.pointmass(Component::Pylon).mass, 388.8885, 1e-9);
}

/**
 * @brief Test combining the component masses into the total mass.
 */
TEST_F(OpenrotorfanMassAnalyzer, TotalMassCombinesComponents)
{
    /* Analyse the engine with a pylon */
    engine.set_pylon(pylon_surface);
    analyze();

    /* Check the total mass and the mass-weighted CG of engine, nacelle and pylon */
    PointMass total = engine.total_mass();
    EXPECT_NEAR(total.mass, 1339.819, 1e-9);
    EXPECT_TRUE(total.CG.isApprox(Eigen::Vector3d(0.775537031495, 0.447314152135, 0.366892841496), 1e-9));
}

/**
 * @brief Test that a pre-set engine mass is kept.
 */
TEST_F(OpenrotorfanMassAnalyzer, PresetEngineMassIsKept)
{
    /* Analyse the engine with a pre-set engine mass of 2000 kg */
    engine.set_pointmass(Component::Engine, {Eigen::Vector3d(9.0, 9.0, 9.0), Eigen::Matrix3d::Identity(), 2000.0});
    analyze();

    /* Check that the mass is kept and CG and inertia are recalculated */
    PointMass engine_mass = engine.pointmass(Component::Engine);
    Eigen::Matrix3d inertia_expected;
    inertia_expected << 1000.0, 0.0           , 0.0,
                        0.0   , 3166.666666667, 0.0,
                        0.0   , 0.0           , 3166.666666667;
    EXPECT_EQ(engine_mass.mass, 2000.0);
    EXPECT_TRUE(engine_mass.CG.isApprox(Eigen::Vector3d(2.0, 0.0, 0.0)));
    EXPECT_TRUE(engine_mass.inertia.isApprox(inertia_expected, 1e-9));
}

/**
 * @brief Test that the nacelle and pylon inertia are not scaled by the mass.
 */
TEST_F(OpenrotorfanMassAnalyzer, NacelleAndPylonInertiaNotScaledByMass)
{
    /* Analyse the engine with a pylon */
    engine.set_pylon(pylon_surface);
    analyze();
    Eigen::Matrix3d nacelle_inertia = engine.pointmass(Component::Nacelle).inertia;
    Eigen::Matrix3d pylon_inertia = engine.pointmass(Component::Pylon).inertia;

    /* Analyse again with nacelle and pylon technology factors of 0.5 */
    set_technology_factors(1.0, 0.5, 0.5);
    analyze();

    /* Check that the mass changes but the inertia does not */
    EXPECT_NEAR(engine.pointmass(Component::Nacelle).mass, 299.66, 1e-9);
    EXPECT_TRUE(engine.pointmass(Component::Nacelle).inertia.isApprox(nacelle_inertia));
    EXPECT_TRUE(engine.pointmass(Component::Pylon).inertia.isApprox(pylon_inertia));
    EXPECT_FALSE(nacelle_inertia.isZero());
}
