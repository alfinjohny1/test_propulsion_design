/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 *
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <cmath>
#include <filesystem>
#include <gtest/gtest.h>
#include <aircraftGeometry2/processing/measure.h>

/* Unit Under Test */
#include "mass/default/default_mass.h"
#include "mass/point_mass.h"

/* === Types ===*/
using Point_2 = geom2::Point_2;
using Polygon_2 = geom2::Polygon_2;
using PolygonSection = geom2::PolygonSection;
using AirfoilSection = geom2::AirfoilSection;

/* === Fixtures === */
class TurbofanMassAnalyzer : public ::testing::Test
{
  protected:
    void SetUp() override
    {
        /* Create the nacelle shape */
        Polygon_2 nacelle_shape{};
        nacelle_shape.push_back(Point_2(-1, -1));
        nacelle_shape.push_back(Point_2(1, -1));
        nacelle_shape.push_back(Point_2(1, 1));
        nacelle_shape.push_back(Point_2(-1, 1));

        /* Create the nacelle surface with its centroid at (0, 1, 2) */
        nacelle_surface.sections.emplace_back(nacelle_shape);
        nacelle_surface.sections.emplace_back(nacelle_shape);
        nacelle_surface.sections.emplace_back(nacelle_shape);
        nacelle_surface.sections[0].origin = {0, 0, 0};
        nacelle_surface.sections[0].set_width(1.0);
        nacelle_surface.sections[1].origin = {0, 1, 2};
        nacelle_surface.sections[1].set_width(1.0);
        nacelle_surface.sections[2].origin = {0, 2, 4};
        nacelle_surface.sections[2].set_width(1.0);

        /* Create the pylon airfoil */
        Polygon_2 pylon_shape{};
        pylon_shape.push_back(Point_2(0, 0));
        pylon_shape.push_back(Point_2(0.5, 0.2));
        pylon_shape.push_back(Point_2(1.0, 0.0));
        pylon_shape.push_back(Point_2(0.5, 0.0));
        AirfoilSection airfoil{pylon_shape};

        /* Create the pylon surface with its centroid at (0.75, 0, -2) */
        pylon_surface.sections.emplace_back(airfoil);
        pylon_surface.sections.emplace_back(airfoil);
        pylon_surface.sections.emplace_back(airfoil);
        pylon_surface.sections[0].origin = geom2::Point_3(0, 0, 0);
        pylon_surface.sections[0].set_chord_length(3.0);
        pylon_surface.sections[1].origin = geom2::Point_3(0, 0, -2);
        pylon_surface.sections[1].set_chord_length(1.0);
        pylon_surface.sections[2].origin = geom2::Point_3(0, 0, -4);
        pylon_surface.sections[2].set_chord_length(1.0);

        /* Setup the engine with thrust 1000 N, h = w = 2 m and L = 4 m */
        engine.set_required_thrust(1000.0);
        engine.set_dimension({2.0, 2.0, 4.0});
        engine.set_nacelle(nacelle_surface);

        /* Read the configuration with neutral technology factors */
        config = aixml::openDocument(std::filesystem::path{CMAKE_TEST_CONFIG_FILE});
        set_technology_factors(1.0, 1.0, 1.0);
    }

    /* Set the mass technology factors in the configuration */
    void set_technology_factors(const double engine_mass, const double nacelle_mass, const double pylon_mass)
    {
        const std::string base = "module_configuration_file/program_settings/technology_factors/";
        config->at(base + "engine_mass/value") = engine_mass;
        config->at(base + "nacelle_mass/value") = nacelle_mass;
        config->at(base + "pylon_mass/value") = pylon_mass;
    }

    /* Create and initialize the analyzer with the current configuration, then analyze the engine */
    void analyze()
    {
        mass::Default analyzer{config};
        analyzer.initialize();
        analyzer(engine);
    }

    geom2::MultisectionSurface<PolygonSection> nacelle_surface;
    geom2::MultisectionSurface<AirfoilSection> pylon_surface{};
    Turbofan<EnergyCarrierFamily::Kerosene> engine{};
    std::shared_ptr<node> config;
};

/* === Tests === */
/**
 * @brief Test analysing the engine of a turbofan without a pre-set engine mass.
 */
TEST_F(TurbofanMassAnalyzer, EngineMassFromRegression)
{
    /* Analyse the engine */
    analyze();

    /* Check the engine: m = 0.0159 * 1000 + 306.57, CG at L / 2, solid cylinder with r = 1 */
    PointMass engine_mass = engine.pointmass(Component::Engine);
    Eigen::Matrix3d inertia_expected;
    inertia_expected << 161.235, 0.0     , 0.0,
                        0.0    , 510.5775, 0.0,
                        0.0    , 0.0     , 510.5775;
    EXPECT_NEAR(engine_mass.mass, 322.47, 1e-9);
    EXPECT_TRUE(engine_mass.CG.isApprox(Eigen::Vector3d(2.0, 0.0, 0.0)));
    EXPECT_TRUE(engine_mass.inertia.isApprox(inertia_expected, 1e-9));
}

/**
 * @brief Test that a pre-set engine mass of a turbofan is kept.
 */
TEST_F(TurbofanMassAnalyzer, PresetEngineMassIsKept)
{
    /* Analyse the engine with a pre-set engine mass of 2000 kg */
    engine.set_pointmass(Component::Engine, {Eigen::Vector3d(9.0, 9.0, 9.0), Eigen::Matrix3d::Identity(), 2000.0});
    analyze();

    /* Check that the mass is kept and CG and inertia are recalculated with it */
    PointMass engine_mass = engine.pointmass(Component::Engine);
    Eigen::Matrix3d inertia_expected;
    inertia_expected << 1000.0, 0.0           , 0.0,
                        0.0   , 3166.666666667, 0.0,
                        0.0   , 0.0           , 3166.666666667;
    EXPECT_EQ(engine_mass.mass, 2000.0);
    EXPECT_TRUE(engine_mass.CG.isApprox(Eigen::Vector3d(2.0, 0.0, 0.0)));
    EXPECT_TRUE(engine_mass.inertia.isApprox(inertia_expected, 1e-9));
}

/**
 * @brief Test analysing the nacelle of a turbofan.
 */
TEST_F(TurbofanMassAnalyzer, NacelleMassAndCG)
{
    /* Analyse the engine */
    analyze();

    /* Check the nacelle: m = 0.0039 * 1000 + 595.42, CG at the centroid of the surface */
    PointMass nacelle_mass = engine.pointmass(Component::Nacelle);
    EXPECT_NEAR(nacelle_mass.mass, 599.32, 1e-9);
    EXPECT_TRUE(nacelle_mass.CG.isApprox(Eigen::Vector3d(0.0, 1.0, 2.0), 1e-9));
}

/**
 * @brief Test analysing the pylon of a turbofan.
 */
TEST_F(TurbofanMassAnalyzer, PylonMassAndCG)
{
    /* Analyse the engine with a pylon */
    engine.set_pylon(pylon_surface);
    analyze();

    /* Check the pylon: m = 0.0024 * 1000 + 233.29, CG at the centroid of the surface */
    PointMass pylon_mass = engine.pointmass(Component::Pylon);
    EXPECT_NEAR(pylon_mass.mass, 235.69, 1e-9);
    EXPECT_TRUE(pylon_mass.CG.isApprox(Eigen::Vector3d(0.75, 0.0, -2.0), 1e-9));
}

/**
 * @brief Test the current behaviour that the nacelle inertia is the unscaled thin-wall value of the geometry library (O-1).
 */
TEST_F(TurbofanMassAnalyzer, NacelleInertiaIsUnscaledGeometryValue)
{
    /* Thin-walled surface of unit density and thickness in m^4, not scaled by the nacelle mass */
    Eigen::Matrix3d geometry_inertia = geom2::measure::inertia(nacelle_surface).eigen_object();

    /* Analyse the engine with the nacelle technology factor 1 and again with 0.5 */
    analyze();
    Eigen::Matrix3d inertia_factor_1 = engine.pointmass(Component::Nacelle).inertia;
    set_technology_factors(1.0, 0.5, 1.0);
    analyze();

    /* Check that the inertia is the geometry library value in both cases while the mass is halved */
    EXPECT_FALSE(geometry_inertia.isZero());
    EXPECT_TRUE(inertia_factor_1.isApprox(geometry_inertia, 1e-12));
    EXPECT_TRUE(engine.pointmass(Component::Nacelle).inertia.isApprox(geometry_inertia, 1e-12));
    EXPECT_NEAR(engine.pointmass(Component::Nacelle).mass, 299.66, 1e-9);
}

/**
 * @brief Test the current behaviour that the pylon inertia is the unscaled thin-wall value of the geometry library (O-1).
 */
TEST_F(TurbofanMassAnalyzer, PylonInertiaIsUnscaledGeometryValue)
{
    /* Thin-walled surface of unit density and thickness in m^4, not scaled by the pylon mass */
    Eigen::Matrix3d geometry_inertia = geom2::measure::inertia(pylon_surface).eigen_object();

    /* Analyse the engine with a pylon, with the pylon technology factor 1 and again with 0.5 */
    engine.set_pylon(pylon_surface);
    analyze();
    Eigen::Matrix3d inertia_factor_1 = engine.pointmass(Component::Pylon).inertia;
    set_technology_factors(1.0, 1.0, 0.5);
    analyze();

    /* Check that the inertia is the geometry library value in both cases while the mass is halved */
    EXPECT_FALSE(geometry_inertia.isZero());
    EXPECT_TRUE(inertia_factor_1.isApprox(geometry_inertia, 1e-12));
    EXPECT_TRUE(engine.pointmass(Component::Pylon).inertia.isApprox(geometry_inertia, 1e-12));
    EXPECT_NEAR(engine.pointmass(Component::Pylon).mass, 117.845, 1e-9);
}

/**
 * @brief Test that a turbofan without a pylon has no pylon mass.
 */
TEST_F(TurbofanMassAnalyzer, WithoutPylonNoPylonMass)
{
    /* Analyse the engine without a pylon */
    analyze();

    /* Check that the pylon point mass is zero */
    PointMass pylon_mass = engine.pointmass(Component::Pylon);
    EXPECT_EQ(pylon_mass.mass, 0.0);
    EXPECT_EQ(pylon_mass.CG, Eigen::Vector3d::Zero());
    EXPECT_EQ(pylon_mass.inertia, Eigen::Matrix3d::Zero());
}

/**
 * @brief Test applying the technology factors from the configuration to a turbofan.
 */
TEST_F(TurbofanMassAnalyzer, TechnologyFactorsFromConfiguration)
{
    /* Analyse the engine with a pylon and technology factors 0.8, 0.9 and 1.1 */
    engine.set_pylon(pylon_surface);
    set_technology_factors(0.8, 0.9, 1.1);
    analyze();

    /* Check the masses: 0.8 * 322.47, 0.9 * 599.32 and 1.1 * 235.69 */
    EXPECT_NEAR(engine.pointmass(Component::Engine).mass, 257.976, 1e-9);
    EXPECT_NEAR(engine.pointmass(Component::Nacelle).mass, 539.388, 1e-9);
    EXPECT_NEAR(engine.pointmass(Component::Pylon).mass, 259.259, 1e-9);
}

/**
 * @brief Test analysing the masses of a liquid hydrogen turbofan.
 */
TEST_F(TurbofanMassAnalyzer, LiquidHydrogenTurbofan)
{
    /* Setup the liquid hydrogen engine as the kerosene engine, with a pylon */
    Turbofan<EnergyCarrierFamily::Liquid_Hydrogen> engine_lh2{};
    engine_lh2.set_required_thrust(1000.0);
    engine_lh2.set_dimension({2.0, 2.0, 4.0});
    engine_lh2.set_nacelle(nacelle_surface);
    engine_lh2.set_pylon(pylon_surface);

    /* Analyse the engine */
    mass::Default analyzer{config};
    analyzer.initialize();
    analyzer(engine_lh2);

    /* Check the masses and the CGs as for the kerosene engine */
    EXPECT_NEAR(engine_lh2.pointmass(Component::Engine).mass, 322.47, 1e-9);
    EXPECT_TRUE(engine_lh2.pointmass(Component::Engine).CG.isApprox(Eigen::Vector3d(2.0, 0.0, 0.0)));
    EXPECT_NEAR(engine_lh2.pointmass(Component::Nacelle).mass, 599.32, 1e-9);
    EXPECT_TRUE(engine_lh2.pointmass(Component::Nacelle).CG.isApprox(Eigen::Vector3d(0.0, 1.0, 2.0), 1e-9));
    EXPECT_NEAR(engine_lh2.pointmass(Component::Pylon).mass, 235.69, 1e-9);
    EXPECT_TRUE(engine_lh2.pointmass(Component::Pylon).CG.isApprox(Eigen::Vector3d(0.75, 0.0, -2.0), 1e-9));
}

/**
 * @brief Test adding two point masses on the x-axis with the Steiner theorem.
 */
TEST(PointMassAddition, SteinerOnDiagonal)
{
    /* Point mass a: 2 kg at (1, 0, 0) with inertia diag(1, 1, 1); point mass b: 2 kg at (-1, 0, 0) without inertia */
    PointMass a{Eigen::Vector3d(1.0, 0.0, 0.0), Eigen::Matrix3d::Identity(), 2.0};
    PointMass b{Eigen::Vector3d(-1.0, 0.0, 0.0), Eigen::Matrix3d::Zero(), 2.0};

    /* Add the point masses */
    PointMass sum = a + b;

    /* Check mass 4 kg at the origin, Ixx = 1, Iyy = Izz = 1 + 2 * 1^2 + 2 * 1^2 = 5 */
    Eigen::Matrix3d inertia_expected;
    inertia_expected << 1.0, 0.0, 0.0,
                        0.0, 5.0, 0.0,
                        0.0, 0.0, 5.0;
    EXPECT_DOUBLE_EQ(sum.mass, 4.0);
    EXPECT_TRUE(sum.CG.isApprox(Eigen::Vector3d(0.0, 0.0, 0.0)));
    EXPECT_TRUE(sum.inertia.isApprox(inertia_expected, 1e-12));
}

/**
 * @brief Test the current behaviour that the products of inertia get a positive Steiner term (Eq. 36, sign convention open, O-8).
 */
TEST(PointMassAddition, SteinerOffDiagonal)
{
    /* Point masses of 1 kg at (1, 1, 0) and (-1, -1, 0) without own inertia */
    PointMass a{Eigen::Vector3d(1.0, 1.0, 0.0), Eigen::Matrix3d::Zero(), 1.0};
    PointMass b{Eigen::Vector3d(-1.0, -1.0, 0.0), Eigen::Matrix3d::Zero(), 1.0};

    /* Add the point masses */
    PointMass sum = a + b;

    /* Check Ixx = Iyy = 2, Izz = 4 and Ixy = Iyx = 1 * 1 * 1 + 1 * (-1) * (-1) = 2 (Eq. 36) */
    Eigen::Matrix3d inertia_expected;
    inertia_expected << 2.0, 2.0, 0.0,
                        2.0, 2.0, 0.0,
                        0.0, 0.0, 4.0;
    EXPECT_DOUBLE_EQ(sum.mass, 2.0);
    EXPECT_TRUE(sum.CG.isApprox(Eigen::Vector3d(0.0, 0.0, 0.0)));
    EXPECT_TRUE(sum.inertia.isApprox(inertia_expected, 1e-12));
}

/**
 * @brief Test combining the engine, nacelle and pylon point masses of a propulsion.
 */
TEST(PointMassAddition, TotalMassOfThreeComponents)
{
    /* Engine 1 kg at the origin, nacelle 1 kg at (2, 0, 0) and pylon 2 kg at (1, 1, 0), without own inertia */
    Propulsion<EnergyCarrierFamily::Kerosene> engine;
    engine.set_pointmass(Component::Engine, {Eigen::Vector3d(0.0, 0.0, 0.0), Eigen::Matrix3d::Zero(), 1.0});
    engine.set_pointmass(Component::Nacelle, {Eigen::Vector3d(2.0, 0.0, 0.0), Eigen::Matrix3d::Zero(), 1.0});
    engine.set_pointmass(Component::Pylon, {Eigen::Vector3d(1.0, 1.0, 0.0), Eigen::Matrix3d::Zero(), 2.0});

    /* Get the total mass */
    PointMass total = engine.total_mass();

    /* Check mass 4 kg at (1, 0.5, 0); distances (-1, -0.5, 0), (1, -0.5, 0), (0, 0.5, 0):
     * Ixx = 0.25 + 0.25 + 2 * 0.25 = 1, Iyy = 1 + 1 = 2, Izz = 1.25 + 1.25 + 0.5 = 3, Ixy = 0.5 - 0.5 + 0 = 0 */
    Eigen::Matrix3d inertia_expected;
    inertia_expected << 1.0, 0.0, 0.0,
                        0.0, 2.0, 0.0,
                        0.0, 0.0, 3.0;
    EXPECT_DOUBLE_EQ(total.mass, 4.0);
    EXPECT_TRUE(total.CG.isApprox(Eigen::Vector3d(1.0, 0.5, 0.0), 1e-12));
    EXPECT_TRUE(total.inertia.isApprox(inertia_expected, 1e-12));
}

/**
 * @brief Test the current behaviour that adding two point masses without mass gives an undefined CG.
 */
TEST(PointMassAddition, ZeroMassesGiveUndefinedCG)
{
    /* Two point masses without mass */
    PointMass a{};
    PointMass b{};

    /* Add the point masses */
    PointMass sum = a + b;

    /* Check that the mass is zero and the CG is not a number (division by zero, O-14) */
    EXPECT_DOUBLE_EQ(sum.mass, 0.0);
    EXPECT_TRUE(std::isnan(sum.CG.x()));
}

/**
 * @brief Test converting the engine, nacelle and pylon point masses to the global reference frame and back.
 */
TEST(PropulsionFrameConversion, AllComponentsShiftedAndRestored)
{
    /* Engine at (2, 3, 4) with three point masses in the engine frame */
    Propulsion<EnergyCarrierFamily::Kerosene> engine;
    engine.set_position({2.0, 3.0, 4.0});
    Eigen::Matrix3d inertia_engine;
    inertia_engine << 1.0, 0.1, 0.0,
                      0.1, 2.0, 0.0,
                      0.0, 0.0, 3.0;
    Eigen::Matrix3d inertia_nacelle;
    inertia_nacelle << 4.0, 0.0, 0.2,
                       0.0, 5.0, 0.0,
                       0.2, 0.0, 6.0;
    Eigen::Matrix3d inertia_pylon;
    inertia_pylon << 7.0, 0.0, 0.0,
                     0.0, 8.0, 0.3,
                     0.0, 0.3, 9.0;
    engine.set_pointmass(Component::Engine, {Eigen::Vector3d(1.0, 0.0, 0.0), inertia_engine, 10.0});
    engine.set_pointmass(Component::Nacelle, {Eigen::Vector3d(0.0, 1.0, 2.0), inertia_nacelle, 20.0});
    engine.set_pointmass(Component::Pylon, {Eigen::Vector3d(0.75, 0.0, -2.0), inertia_pylon, 5.0});

    /* Change to the global reference frame with the reference point (1, 1, 1) */
    engine.change_to_global_reference_frame({1.0, 1.0, 1.0});

    /* Check the position (2, 3, 4) - (1, 1, 1) and every CG shifted by it, with unchanged inertia and mass */
    EXPECT_NEAR(engine.position().x(), 1.0, 1e-12);
    EXPECT_NEAR(engine.position().y(), 2.0, 1e-12);
    EXPECT_NEAR(engine.position().z(), 3.0, 1e-12);
    EXPECT_TRUE(engine.pointmass(Component::Engine).CG.isApprox(Eigen::Vector3d(2.0, 2.0, 3.0), 1e-12));
    EXPECT_TRUE(engine.pointmass(Component::Nacelle).CG.isApprox(Eigen::Vector3d(1.0, 3.0, 5.0), 1e-12));
    EXPECT_TRUE(engine.pointmass(Component::Pylon).CG.isApprox(Eigen::Vector3d(1.75, 2.0, 1.0), 1e-12));
    EXPECT_EQ(engine.pointmass(Component::Engine).inertia, inertia_engine);
    EXPECT_EQ(engine.pointmass(Component::Nacelle).inertia, inertia_nacelle);
    EXPECT_EQ(engine.pointmass(Component::Pylon).inertia, inertia_pylon);
    EXPECT_DOUBLE_EQ(engine.pointmass(Component::Nacelle).mass, 20.0);

    /* Revert to the local reference frame */
    engine.revert_to_local_reference_frame({1.0, 1.0, 1.0});

    /* Check that position and CGs are restored and the inertia is still unchanged */
    EXPECT_NEAR(engine.position().x(), 2.0, 1e-12);
    EXPECT_NEAR(engine.position().y(), 3.0, 1e-12);
    EXPECT_NEAR(engine.position().z(), 4.0, 1e-12);
    EXPECT_TRUE(engine.pointmass(Component::Engine).CG.isApprox(Eigen::Vector3d(1.0, 0.0, 0.0), 1e-12));
    EXPECT_TRUE(engine.pointmass(Component::Nacelle).CG.isApprox(Eigen::Vector3d(0.0, 1.0, 2.0), 1e-12));
    EXPECT_TRUE(engine.pointmass(Component::Pylon).CG.isApprox(Eigen::Vector3d(0.75, 0.0, -2.0), 1e-12));
    EXPECT_EQ(engine.pointmass(Component::Engine).inertia, inertia_engine);
    EXPECT_EQ(engine.pointmass(Component::Nacelle).inertia, inertia_nacelle);
    EXPECT_EQ(engine.pointmass(Component::Pylon).inertia, inertia_pylon);
}
