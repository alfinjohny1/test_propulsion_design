/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 *
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <cmath>
#include <filesystem>
#include <fstream>
#include <gtest/gtest.h>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "../../temp_directory.h"

/* Unit Under Test */
#include "nacelle/default/default_nacelle.h"

/* === Fixtures === */
/**
 * @brief Nacelle designer on an empty temporary geometry directory.
 * The engine is the one of NacelleDefaultTurbofanKerosene.LargeFanShortDuct.
 */
class NacelleProfileFile : public ::testing::Test
{
  protected:
    void SetUp() override
    {
        config = aixml::openDocument(std::filesystem::path{CMAKE_TEST_CONFIG_FILE});
    }

    void set_profile(const std::string &profile)
    {
        config->at("module_configuration_file/program_settings/propulsion@Default/nacelle/profile/value") = profile;
    }

    /* Design the nacelle with the given geometry directory and return the engine */
    auto design(const std::filesystem::path &geometry_directory) -> Turbofan<EnergyCarrierFamily::Kerosene>
    {
        geometry::nacelle::Default designer{config, geometry_directory};
        designer.initialize();
        Turbofan<EnergyCarrierFamily::Kerosene> engine{};
        engine.set_dimension({1.0, 2.0, 3.0});
        engine.set_fan({2.5});
        designer(engine);
        return engine;
    }

    static auto read_text(const std::filesystem::path &file) -> std::string
    {
        std::ifstream stream(file);
        std::stringstream content;
        content << stream.rdbuf();
        return content.str();
    }

    std::shared_ptr<node> config;
    const UniqueTempDirectory geometry{"test_nacelle_profile"};
};

/* === Tests === */
/**
 * @brief Test creating a missing nacelle profile file.
 */
TEST_F(NacelleProfileFile, CreatesMissingProfileFile)
{
    const std::filesystem::path profile_file = geometry.path() / "nacelle.dat";
    ASSERT_FALSE(std::filesystem::exists(profile_file));

    const auto engine = design(geometry.path());

    ASSERT_TRUE(std::filesystem::exists(profile_file));
    std::ifstream file(profile_file);
    std::vector<std::pair<double, double>> points;
    std::string line;
    while (std::getline(file, line))
    {
        std::istringstream row(line);
        double x = 0.0;
        double y = 0.0;
        if (row >> x >> y)
        {
            points.emplace_back(x, y);
        }
    }
    ASSERT_EQ(points.size(), 40U);
    const double pi = std::acos(-1.0);
    for (std::size_t k = 0; k < points.size(); ++k)
    {
        const double angle = pi * 9.0 * static_cast<double>(k) / 180.0;
        /* The file holds 5 decimals */
        EXPECT_NEAR(points[k].first, 0.5 * std::cos(angle), 1e-5);
        EXPECT_NEAR(points[k].second, 0.5 * std::sin(angle), 1e-5);
    }
    EXPECT_FALSE(engine.nacelle().sections.empty());
}

/**
 * @brief Test that the created nacelle profile gives the same nacelle as the stub profile.
 */
TEST_F(NacelleProfileFile, CreatedProfileGivesSameNacelleAsStub)
{
    const auto from_created = design(geometry.path());
    const auto from_stub = design(std::filesystem::path{CMAKE_TEST_STUBS_DIR});

    const auto &created = from_created.nacelle();
    const auto &stub = from_stub.nacelle();
    ASSERT_EQ(created.sections.size(), 4U);
    ASSERT_EQ(created.sections.size(), stub.sections.size());
    EXPECT_EQ(created.name, stub.name);
    EXPECT_EQ(created.origin, stub.origin);
    EXPECT_EQ(created.normal, stub.normal);
    /* Compare every section with the stub nacelle */
    EXPECT_EQ(created.sections[0].name, "nacelle");
    EXPECT_EQ(created.sections[0].origin, stub.sections[0].origin);
    EXPECT_NEAR(created.sections[0].get_contour(true).bbox().x_span(), stub.sections[0].get_contour(true).bbox().x_span(), 1e-9);
    EXPECT_NEAR(created.sections[0].get_contour(true).bbox().y_span(), stub.sections[0].get_contour(true).bbox().y_span(), 1e-9);
    EXPECT_EQ(created.sections[1].name, "nacelle");
    EXPECT_EQ(created.sections[1].origin, stub.sections[1].origin);
    EXPECT_NEAR(created.sections[1].get_contour(true).bbox().x_span(), stub.sections[1].get_contour(true).bbox().x_span(), 1e-9);
    EXPECT_NEAR(created.sections[1].get_contour(true).bbox().y_span(), stub.sections[1].get_contour(true).bbox().y_span(), 1e-9);
    EXPECT_EQ(created.sections[2].name, "nacelle");
    EXPECT_EQ(created.sections[2].origin, stub.sections[2].origin);
    EXPECT_NEAR(created.sections[2].get_contour(true).bbox().x_span(), stub.sections[2].get_contour(true).bbox().x_span(), 1e-9);
    EXPECT_NEAR(created.sections[2].get_contour(true).bbox().y_span(), stub.sections[2].get_contour(true).bbox().y_span(), 1e-9);
    EXPECT_EQ(created.sections[3].name, "nacelle");
    EXPECT_EQ(created.sections[3].origin, stub.sections[3].origin);
    EXPECT_NEAR(created.sections[3].get_contour(true).bbox().x_span(), stub.sections[3].get_contour(true).bbox().x_span(), 1e-9);
    EXPECT_NEAR(created.sections[3].get_contour(true).bbox().y_span(), stub.sections[3].get_contour(true).bbox().y_span(), 1e-9);
    /* The inlet section has the fan diameter */
    EXPECT_NEAR(created.sections[0].get_contour(true).bbox().x_span(), 2.5, 1e-3);
    EXPECT_NEAR(created.sections[0].get_contour(true).bbox().y_span(), 2.5, 1e-3);
}

/**
 * @brief Test that an existing nacelle profile file is read and not created again.
 */
TEST_F(NacelleProfileFile, SecondRunReadsExistingFile)
{
    const std::filesystem::path profile_file = geometry.path() / "nacelle.dat";
    const auto first = design(geometry.path());
    ASSERT_FALSE(first.nacelle().sections.empty());
    ASSERT_EQ(first.nacelle().sections[0].get_contour(false).size(), 40U);

    /* Replace the created circle by a square */
    std::ofstream square(profile_file, std::ios::trunc);
    square << "# square\n0.5 0.5\n-0.5 0.5\n-0.5 -0.5\n0.5 -0.5\n";
    square.close();
    ASSERT_FALSE(square.fail());
    const std::string square_content = read_text(profile_file);

    const auto second = design(geometry.path());

    EXPECT_EQ(read_text(profile_file), square_content);
    ASSERT_EQ(second.nacelle().sections.size(), 4U);
    /* Check that every section is a square: it fills its bounding box */
    EXPECT_EQ(second.nacelle().sections[0].get_contour(true).size(), 4U);
    EXPECT_NEAR(std::abs(CGAL::to_double(second.nacelle().sections[0].get_contour(true).area())) /
                    (second.nacelle().sections[0].get_contour(true).bbox().x_span() * second.nacelle().sections[0].get_contour(true).bbox().y_span()),
                1.0, 1e-9);
    EXPECT_EQ(second.nacelle().sections[1].get_contour(true).size(), 4U);
    EXPECT_NEAR(std::abs(CGAL::to_double(second.nacelle().sections[1].get_contour(true).area())) /
                    (second.nacelle().sections[1].get_contour(true).bbox().x_span() * second.nacelle().sections[1].get_contour(true).bbox().y_span()),
                1.0, 1e-9);
    EXPECT_EQ(second.nacelle().sections[2].get_contour(true).size(), 4U);
    EXPECT_NEAR(std::abs(CGAL::to_double(second.nacelle().sections[2].get_contour(true).area())) /
                    (second.nacelle().sections[2].get_contour(true).bbox().x_span() * second.nacelle().sections[2].get_contour(true).bbox().y_span()),
                1.0, 1e-9);
    EXPECT_EQ(second.nacelle().sections[3].get_contour(true).size(), 4U);
    EXPECT_NEAR(std::abs(CGAL::to_double(second.nacelle().sections[3].get_contour(true).area())) /
                    (second.nacelle().sections[3].get_contour(true).bbox().x_span() * second.nacelle().sections[3].get_contour(true).bbox().y_span()),
                1.0, 1e-9);
}

/**
 * @brief Test that a nacelle profile path which cannot be created throws.
 */
TEST_F(NacelleProfileFile, UncreatableProfilePathThrows)
{
    std::ofstream(geometry.path() / "blocker") << "not a directory";
    set_profile("blocker/nacelle.dat");

    try
    {
        design(geometry.path());
        FAIL() << "Expected std::runtime_error for an uncreatable profile path";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("Error while creating the file for nacelle."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that an unsupported nacelle profile throws.
 */
TEST_F(NacelleProfileFile, UnsupportedProfileThrows)
{
    set_profile("Triangle");

    try
    {
        design(geometry.path());
        FAIL() << "Expected std::invalid_argument for an unsupported nacelle profile";
    }
    catch (const std::invalid_argument &error)
    {
        /* The name is converted to lower case when the configuration is read */
        EXPECT_NE(std::string{error.what()}.find("The nacelle shape 'triangle' is not supported."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test creating a nacelle profile file in a missing subdirectory.
 */
TEST_F(NacelleProfileFile, CreatesMissingSubdirectory)
{
    set_profile("profiles/nacelle.dat");

    const auto engine = design(geometry.path());

    EXPECT_TRUE(std::filesystem::exists(geometry.path() / "profiles" / "nacelle.dat"));
    EXPECT_EQ(engine.nacelle().sections.size(), 4U);
}
