/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 *
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <cmath>
#include <filesystem>
#include <fstream>
#include <gtest/gtest.h>
#include <stdexcept>
#include <string>

#include "../../temp_directory.h"

/* Unit Under Test */
#include "nacelle/default/default_nacelle.h"

/* === Fixtures === */
class NacelleDefault : public ::testing::Test
{
  protected:
    void SetUp() override
    {
        /* Copy the stub profile nacelle.dat (circle of diameter 1) into the geometry directory */
        std::filesystem::copy_file(std::filesystem::path{CMAKE_TEST_STUBS_DIR} / "nacelle.dat", geometry.path() / "nacelle.dat");

        /* Read the configuration with the default profile nacelle.dat */
        config = aixml::openDocument(std::filesystem::path{CMAKE_TEST_CONFIG_FILE});
        config->at("module_configuration_file/program_settings/propulsion@Default/nacelle/profile/value") = std::string{"nacelle.dat"};
    }

    const UniqueTempDirectory geometry{"test_nacelle_default"};
    std::shared_ptr<node> config;
};

/* === Tests === */
/**
 * @brief Test that the nacelle profile of an engine ID overrides the default profile.
 */
TEST_F(NacelleDefault, ProfilePerEngineIdOverridesDefault)
{
    /* Write a square profile and select it for the engine with ID 1 */
    std::ofstream square(geometry.path() / "square.dat");
    square << "# square\n0.5 0.5\n-0.5 0.5\n-0.5 -0.5\n0.5 -0.5\n";
    square.close();
    ASSERT_FALSE(square.fail());
    node &propulsion = config->at("module_configuration_file/program_settings").appendChild("propulsion", true);
    propulsion.setAttrib("ID", "1");
    propulsion.appendChild("nacelle", true).appendChild("profile", true).appendChild("value", true) = std::string{"square.dat"};

    /* Create the nacelle designer and initialize */
    geometry::nacelle::Default designer{config, geometry.path()};
    designer.initialize();

    /* Design the nacelles of the engines with ID 0 and 1 */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_0{0};
    engine_0.set_dimension({1.0, 2.0, 4.0});
    engine_0.set_fan({2.5});
    designer(engine_0);
    Turbofan<EnergyCarrierFamily::Kerosene> engine_1{1};
    engine_1.set_dimension({1.0, 2.0, 4.0});
    engine_1.set_fan({2.5});
    designer(engine_1);

    /* Check the sections: ID 1 is a square (fills its bounding box), ID 0 the default circle (about pi/4 of it) */
    const auto contour_0 = engine_0.nacelle().sections[0].get_contour(true);
    const auto contour_1 = engine_1.nacelle().sections[0].get_contour(true);
    EXPECT_EQ(contour_1.size(), 4U);
    EXPECT_NEAR(std::abs(CGAL::to_double(contour_1.area())) / (contour_1.bbox().x_span() * contour_1.bbox().y_span()), 1.0, 1e-9);
    EXPECT_GT(contour_0.size(), 4U);
    EXPECT_NEAR(std::abs(CGAL::to_double(contour_0.area())) / (contour_0.bbox().x_span() * contour_0.bbox().y_span()), 0.782, 1e-3);
}

/**
 * @brief Test that the nacelle profile name is case-insensitive.
 */
TEST_F(NacelleDefault, ProfileNameIsCaseInsensitive)
{
    /* Select the profile in mixed case */
    config->at("module_configuration_file/program_settings/propulsion@Default/nacelle/profile/value") = std::string{"Circle"};

    /* Create the nacelle designer and initialize */
    geometry::nacelle::Default designer{config, geometry.path()};
    designer.initialize();

    /* Design the nacelle */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0};
    engine.set_dimension({1.0, 2.0, 4.0});
    engine.set_fan({2.5});
    EXPECT_NO_THROW(designer(engine));

    /* Check the inlet section of the circle */
    ASSERT_EQ(engine.nacelle().sections.size(), 4U);
    EXPECT_NEAR(engine.nacelle().sections[0].get_contour(true).bbox().x_span(), 2.5, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[0].get_contour(true).bbox().y_span(), 2.5, 1e-9);
}

/**
 * @brief Test the current behaviour that the ellipse profile gives the same section as the circle profile.
 */
TEST_F(NacelleDefault, EllipseGivesSameSectionAsCircle)
{
    /* Design the nacelle with the circle profile */
    config->at("module_configuration_file/program_settings/propulsion@Default/nacelle/profile/value") = std::string{"circle"};
    geometry::nacelle::Default designer_circle{config, geometry.path()};
    designer_circle.initialize();
    Turbofan<EnergyCarrierFamily::Kerosene> engine_circle{0};
    engine_circle.set_dimension({1.0, 2.0, 4.0});
    engine_circle.set_fan({2.5});
    designer_circle(engine_circle);

    /* Design the nacelle with the ellipse profile */
    config->at("module_configuration_file/program_settings/propulsion@Default/nacelle/profile/value") = std::string{"ellipse"};
    geometry::nacelle::Default designer_ellipse{config, geometry.path()};
    designer_ellipse.initialize();
    Turbofan<EnergyCarrierFamily::Kerosene> engine_ellipse{0};
    engine_ellipse.set_dimension({1.0, 2.0, 4.0});
    engine_ellipse.set_fan({2.5});
    designer_ellipse(engine_ellipse);

    /* Check that both inlet sections are equal */
    const auto circle = engine_circle.nacelle().sections[0].get_contour(true);
    const auto ellipse = engine_ellipse.nacelle().sections[0].get_contour(true);
    EXPECT_EQ(ellipse.size(), circle.size());
    EXPECT_NEAR(ellipse.bbox().x_span(), circle.bbox().x_span(), 1e-12);
    EXPECT_NEAR(ellipse.bbox().y_span(), circle.bbox().y_span(), 1e-12);
    EXPECT_NEAR(CGAL::to_double(ellipse.area()), CGAL::to_double(circle.area()), 1e-12);
    ASSERT_EQ(ellipse.size(), circle.size());
    for (std::size_t i = 0; i < circle.size(); ++i)
    {
        EXPECT_NEAR(CGAL::to_double(ellipse[i].x()), CGAL::to_double(circle[i].x()), 1e-12);
        EXPECT_NEAR(CGAL::to_double(ellipse[i].y()), CGAL::to_double(circle[i].y()), 1e-12);
    }
}

/**
 * @brief Test that a profile path that exists but cannot be opened throws.
 */
TEST_F(NacelleDefault, UnreadableProfileFileThrows)
{
    /* Select a profile whose path is a directory */
    std::filesystem::create_directories(geometry.path() / "blocked.dat");
    config->at("module_configuration_file/program_settings/propulsion@Default/nacelle/profile/value") = std::string{"blocked.dat"};

    /* Create the nacelle designer and initialize */
    geometry::nacelle::Default designer{config, geometry.path()};
    designer.initialize();

    /* Design the nacelle and check the error */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0};
    engine.set_dimension({1.0, 2.0, 4.0});
    engine.set_fan({2.5});
    try
    {
        designer(engine);
        FAIL() << "Expected std::runtime_error for a profile file that cannot be opened";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("Could not open file:"), std::string::npos) << error.what();
    }
}

/**
 * @brief Test the current behaviour that a nacelle profile file without coordinates gives empty sections.
 */
TEST_F(NacelleDefault, ProfileFileWithoutCoordinatesGivesEmptySections)
{
    /* Write a profile file without coordinates and select it */
    std::ofstream profile(geometry.path() / "empty.dat");
    profile << "# no coordinates\nabc def\n";
    profile.close();
    ASSERT_FALSE(profile.fail());
    config->at("module_configuration_file/program_settings/propulsion@Default/nacelle/profile/value") = std::string{"empty.dat"};

    /* Create the nacelle designer and initialize */
    geometry::nacelle::Default designer{config, geometry.path()};
    designer.initialize();

    /* Design the nacelle */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0};
    engine.set_dimension({1.0, 2.0, 4.0});
    engine.set_fan({2.5});
    EXPECT_NO_THROW(designer(engine));

    /* Check that the four sections have no points */
    ASSERT_EQ(engine.nacelle().sections.size(), 4U);
    EXPECT_EQ(engine.nacelle().sections[0].get_contour(true).size(), 0U);
    EXPECT_EQ(engine.nacelle().sections[3].get_contour(true).size(), 0U);
}

/**
 * @brief Test the inner nacelle diameter when the engine width is the largest dimension.
 */
TEST_F(NacelleDefault, InnerDiameterFromEngineWidth)
{
    /* Create the nacelle designer and initialize */
    geometry::nacelle::Default designer{config, geometry.path()};
    designer.initialize();

    /* Design the nacelle of an engine with height 1 m, width 3 m and fan diameter 2 m */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0};
    engine.set_dimension({1.0, 3.0, 4.0});
    engine.set_fan({2.0});
    designer(engine);

    /* Check the inlet section */
    EXPECT_NEAR(engine.nacelle().sections[0].get_contour(true).bbox().x_span(), 3.0, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[0].get_contour(true).bbox().y_span(), 3.0, 1e-9);
}

/**
 * @brief Test the inner nacelle diameter when the engine height is the largest dimension.
 */
TEST_F(NacelleDefault, InnerDiameterFromEngineHeight)
{
    /* Create the nacelle designer and initialize */
    geometry::nacelle::Default designer{config, geometry.path()};
    designer.initialize();

    /* Design the nacelle of an engine with height 3.5 m, width 1 m and fan diameter 2 m */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0};
    engine.set_dimension({3.5, 1.0, 4.0});
    engine.set_fan({2.0});
    designer(engine);

    /* Check the inlet section */
    EXPECT_NEAR(engine.nacelle().sections[0].get_contour(true).bbox().x_span(), 3.5, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[0].get_contour(true).bbox().y_span(), 3.5, 1e-9);
}

/**
 * @brief Test the four sections of the nacelle of a kerosene turbofan engine.
 */
TEST_F(NacelleDefault, TurbofanKeroseneNacelleSections)
{
    /* Create the nacelle designer and initialize */
    geometry::nacelle::Default designer{config, geometry.path()};
    designer.initialize();

    /* Design the nacelle of the engine with ID 3: length 4 m, fan diameter 2.5 m */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{3};
    engine.set_dimension({1.0, 2.0, 4.0});
    engine.set_fan({2.5});
    designer(engine);

    /* Check the surface */
    ASSERT_EQ(engine.nacelle().sections.size(), 4U);
    EXPECT_EQ(engine.nacelle().name, "nacelle_3");
    EXPECT_EQ(engine.nacelle().normal, geom2::Direction_3(1.0, 0.0, 0.0));
    EXPECT_EQ(engine.nacelle().origin, geom2::Point_3(0.0, 0.0, 0.0));

    /* Check the sections at 0, 0.25 L, 0.75 L and L with 1.0, 1.21, 1.21 and 1.0 times 2.5 m */
    EXPECT_NEAR(engine.nacelle().sections[0].origin.z(), 0.0, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[0].get_contour(true).bbox().x_span(), 2.5, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[1].origin.z(), 1.0, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[1].get_contour(true).bbox().x_span(), 3.025, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[2].origin.z(), 3.0, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[2].get_contour(true).bbox().x_span(), 3.025, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[3].origin.z(), 4.0, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[3].get_contour(true).bbox().x_span(), 2.5, 1e-9);

    /* Check the vertical spans */
    EXPECT_NEAR(engine.nacelle().sections[0].get_contour(true).bbox().y_span(), 2.5, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[1].get_contour(true).bbox().y_span(), 3.025, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[2].get_contour(true).bbox().y_span(), 3.025, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[3].get_contour(true).bbox().y_span(), 2.5, 1e-9);
}

/**
 * @brief Test the four sections of the nacelle of a liquid hydrogen turbofan engine.
 */
TEST_F(NacelleDefault, TurbofanLiquidHydrogenNacelleSections)
{
    /* Create the nacelle designer and initialize */
    geometry::nacelle::Default designer{config, geometry.path()};
    designer.initialize();

    /* Design the nacelle of the engine with ID 3: length 4 m, fan diameter 2.5 m */
    Turbofan<EnergyCarrierFamily::Liquid_Hydrogen> engine{3};
    engine.set_dimension({1.0, 2.0, 4.0});
    engine.set_fan({2.5});
    designer(engine);

    /* Check the surface */
    ASSERT_EQ(engine.nacelle().sections.size(), 4U);
    EXPECT_EQ(engine.nacelle().name, "nacelle_3");
    EXPECT_EQ(engine.nacelle().normal, geom2::Direction_3(1.0, 0.0, 0.0));

    /* Check the sections at 0, 0.25 L, 0.75 L and L with 1.0, 1.21, 1.21 and 1.0 times 2.5 m */
    EXPECT_NEAR(engine.nacelle().sections[0].origin.z(), 0.0, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[0].get_contour(true).bbox().x_span(), 2.5, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[1].origin.z(), 1.0, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[1].get_contour(true).bbox().x_span(), 3.025, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[2].origin.z(), 3.0, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[2].get_contour(true).bbox().x_span(), 3.025, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[3].origin.z(), 4.0, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[3].get_contour(true).bbox().x_span(), 2.5, 1e-9);

    /* Check the vertical spans */
    EXPECT_NEAR(engine.nacelle().sections[0].get_contour(true).bbox().y_span(), 2.5, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[1].get_contour(true).bbox().y_span(), 3.025, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[2].get_contour(true).bbox().y_span(), 3.025, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[3].get_contour(true).bbox().y_span(), 2.5, 1e-9);
}

/**
 * @brief Test the engine geometry of a turbofan engine.
 */
TEST_F(NacelleDefault, TurbofanEngineGeometry)
{
    /* Create the nacelle designer and initialize */
    geometry::nacelle::Default designer{config, geometry.path()};
    designer.initialize();

    /* Design the nacelle of the engine with ID 3: length 4 m, fan diameter 2.5 m */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{3};
    engine.set_dimension({1.0, 2.0, 4.0});
    engine.set_fan({2.5});
    designer(engine);

    /* Check the surface */
    ASSERT_EQ(engine.engine_geom().sections.size(), 2U);
    EXPECT_EQ(engine.engine_geom().name, "engine_3");
    EXPECT_EQ(engine.engine_geom().normal, geom2::Direction_3(1.0, 0.0, 0.0));

    /* Check the cone from scale 0 at -0.1 L to scale 0.15 (0.375 m) at 0 */
    EXPECT_NEAR(engine.engine_geom().sections[0].origin.z(), -0.4, 1e-9);
    EXPECT_NEAR(engine.engine_geom().sections[0].get_contour(true).bbox().x_span(), 0.0, 1e-9);
    EXPECT_NEAR(engine.engine_geom().sections[1].origin.z(), 0.0, 1e-9);
    EXPECT_NEAR(engine.engine_geom().sections[1].get_contour(true).bbox().x_span(), 0.375, 1e-9);
}

/**
 * @brief Test the engine geometry of a liquid hydrogen turbofan engine.
 */
TEST_F(NacelleDefault, TurbofanLiquidHydrogenEngineGeometry)
{
    /* Create the nacelle designer and initialize */
    geometry::nacelle::Default designer{config, geometry.path()};
    designer.initialize();

    /* Design the nacelle of the engine with ID 3: length 4 m, fan diameter 2.5 m */
    Turbofan<EnergyCarrierFamily::Liquid_Hydrogen> engine{3};
    engine.set_dimension({1.0, 2.0, 4.0});
    engine.set_fan({2.5});
    designer(engine);

    /* Check the surface */
    ASSERT_EQ(engine.engine_geom().sections.size(), 2U);
    EXPECT_EQ(engine.engine_geom().name, "engine_3");
    EXPECT_EQ(engine.engine_geom().normal, geom2::Direction_3(1.0, 0.0, 0.0));

    /* Check the cone from scale 0 at -0.1 L to scale 0.15 (0.375 m) at 0 */
    EXPECT_NEAR(engine.engine_geom().sections[0].origin.z(), -0.4, 1e-9);
    EXPECT_NEAR(engine.engine_geom().sections[0].get_contour(true).bbox().x_span(), 0.0, 1e-9);
    EXPECT_NEAR(engine.engine_geom().sections[1].origin.z(), 0.0, 1e-9);
    EXPECT_NEAR(engine.engine_geom().sections[1].get_contour(true).bbox().x_span(), 0.375, 1e-9);
}

/**
 * @brief Test the twelve sections of the nacelle of an open-rotor engine.
 */
TEST_F(NacelleDefault, OpenRotorNacelleSections)
{
    /* Create the nacelle designer and initialize */
    geometry::nacelle::Default designer{config, geometry.path()};
    designer.initialize();

    /* Design the nacelle of the engine with ID 2: length 5 m, diameter 3.25 m */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{2};
    engine.set_dimension({1.0, 1.0, 5.0});
    engine.set_fan({3.25});
    designer(engine);

    /* Check the surface */
    ASSERT_EQ(engine.nacelle().sections.size(), 12U);
    EXPECT_EQ(engine.nacelle().name, "nacelle_2");
    EXPECT_EQ(engine.nacelle().normal, geom2::Direction_3(1.0, 0.0, 0.0));

    /* Spinner tip, spinner and hub body: scales 0.001, 0.3, 0.4, 0.4 at 0, 0.01 L, 0.31 L, 0.61 L */
    EXPECT_NEAR(engine.nacelle().sections[0].origin.z(), 0.0, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[0].get_contour(true).bbox().x_span(), 0.00325, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[1].origin.z(), 0.05, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[1].get_contour(true).bbox().x_span(), 0.975, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[2].origin.z(), 1.55, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[2].get_contour(true).bbox().x_span(), 1.3, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[3].origin.z(), 3.05, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[3].get_contour(true).bbox().x_span(), 1.3, 1e-9);

    /* First rotor disc: scale 1.0 from 0.61 L to 0.62 L, then hub body 0.4 to 0.77 L */
    EXPECT_NEAR(engine.nacelle().sections[4].origin.z(), 3.05, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[4].get_contour(true).bbox().x_span(), 3.25, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[5].origin.z(), 3.1, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[5].get_contour(true).bbox().x_span(), 3.25, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[6].origin.z(), 3.1, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[6].get_contour(true).bbox().x_span(), 1.3, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[7].origin.z(), 3.85, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[7].get_contour(true).bbox().x_span(), 1.3, 1e-9);

    /* Second rotor disc: scale 1.0 from 0.77 L to 0.78 L, then aft body 0.3 and tail cone 0.2 at 0.88 L */
    EXPECT_NEAR(engine.nacelle().sections[8].origin.z(), 3.85, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[8].get_contour(true).bbox().x_span(), 3.25, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[9].origin.z(), 3.9, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[9].get_contour(true).bbox().x_span(), 3.25, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[10].origin.z(), 3.9, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[10].get_contour(true).bbox().x_span(), 0.975, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[11].origin.z(), 4.4, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[11].get_contour(true).bbox().x_span(), 0.65, 1e-9);

    /* Check the vertical spans */
    EXPECT_NEAR(engine.nacelle().sections[0].get_contour(true).bbox().y_span(), 0.00325, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[1].get_contour(true).bbox().y_span(), 0.975, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[2].get_contour(true).bbox().y_span(), 1.3, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[3].get_contour(true).bbox().y_span(), 1.3, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[4].get_contour(true).bbox().y_span(), 3.25, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[5].get_contour(true).bbox().y_span(), 3.25, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[6].get_contour(true).bbox().y_span(), 1.3, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[7].get_contour(true).bbox().y_span(), 1.3, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[8].get_contour(true).bbox().y_span(), 3.25, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[9].get_contour(true).bbox().y_span(), 3.25, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[10].get_contour(true).bbox().y_span(), 0.975, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[11].get_contour(true).bbox().y_span(), 0.65, 1e-9);
}

/**
 * @brief Test the engine geometry of an open-rotor engine.
 */
TEST_F(NacelleDefault, OpenRotorEngineGeometry)
{
    /* Create the nacelle designer and initialize */
    geometry::nacelle::Default designer{config, geometry.path()};
    designer.initialize();

    /* Design the nacelle of the engine with ID 2: length 5 m, diameter 3.25 m */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{2};
    engine.set_dimension({1.0, 1.0, 5.0});
    engine.set_fan({3.25});
    designer(engine);

    /* Check the single section with scale 0.3 (0.975 m) at the origin */
    ASSERT_EQ(engine.engine_geom().sections.size(), 1U);
    EXPECT_EQ(engine.engine_geom().name, "engine_2");
    EXPECT_EQ(engine.engine_geom().normal, geom2::Direction_3(1.0, 0.0, 0.0));
    EXPECT_NEAR(engine.engine_geom().sections[0].origin.z(), 0.0, 1e-9);
    EXPECT_NEAR(engine.engine_geom().sections[0].get_contour(true).bbox().x_span(), 0.975, 1e-9);
}

/**
 * @brief Test the inner nacelle diameter of an open-rotor engine when the engine width is the largest dimension.
 */
TEST_F(NacelleDefault, OpenRotorInnerDiameterFromEngineWidth)
{
    /* Create the nacelle designer and initialize */
    geometry::nacelle::Default designer{config, geometry.path()};
    designer.initialize();

    /* Design the nacelle of an open rotor with height 1 m, width 4 m and diameter 3.25 m */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{2};
    engine.set_dimension({1.0, 4.0, 5.0});
    engine.set_fan({3.25});
    designer(engine);

    /* Check the rotor disc with scale 1.0 */
    ASSERT_EQ(engine.nacelle().sections.size(), 12U);
    EXPECT_NEAR(engine.nacelle().sections[4].get_contour(true).bbox().x_span(), 4.0, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[4].get_contour(true).bbox().y_span(), 4.0, 1e-9);
}

/**
 * @brief Test the inner nacelle diameter of an open-rotor engine when the engine height is the largest dimension.
 */
TEST_F(NacelleDefault, OpenRotorInnerDiameterFromEngineHeight)
{
    /* Create the nacelle designer and initialize */
    geometry::nacelle::Default designer{config, geometry.path()};
    designer.initialize();

    /* Design the nacelle of an open rotor with height 4.5 m, width 1 m and diameter 3.25 m */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{2};
    engine.set_dimension({4.5, 1.0, 5.0});
    engine.set_fan({3.25});
    designer(engine);

    /* Check the rotor disc with scale 1.0 */
    ASSERT_EQ(engine.nacelle().sections.size(), 12U);
    EXPECT_NEAR(engine.nacelle().sections[4].get_contour(true).bbox().x_span(), 4.5, 1e-9);
    EXPECT_NEAR(engine.nacelle().sections[4].get_contour(true).bbox().y_span(), 4.5, 1e-9);
}
