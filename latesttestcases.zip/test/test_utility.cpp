/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <filesystem>
#include <gtest/gtest.h>
#include <stdexcept>
#include <string>

/* Unit Under Test */
#include "utility.h"
#include "utility.cpp"

/* === Fixtures === */
class UtilityEnergyCarrier : public ::testing::Test {
protected:
    void SetUp() override {
        // Setup the energy carriers structure
        node& energy_carrier1 = energy_carriers_node.appendChild("energy_carrier");
        energy_carrier1.setAttrib("ID", "0");
        energy_carrier1.appendChild("value") = "kerosene"; // Assuming direct assignment is possible

        node& energy_carrier2 = energy_carriers_node.appendChild("energy_carrier");
        energy_carrier2.setAttrib("ID", "1");
        energy_carrier2.appendChild("value") = "liquid_hydrogen"; // Assuming direct assignment is possible
    }
    node energy_carriers_node;
};

class UtilityPropulsor: public ::testing::Test
{
protected:
    void SetUp() override
    {
        /* Setup the propulsor structure */
        this->propulsor.setAttrib("ID", "0");
        this->propulsor.appendChild("powertrain").appendChild("value");
        this->propulsor.appendChild("type").appendChild("value");
        this->propulsor.appendChild("position").appendChild("parent_component").appendChild("value");
        this->propulsor.at("position").appendChild("x").appendChild("value");
        this->propulsor.at("position").appendChild("y").appendChild("value");
        this->propulsor.at("position").appendChild("z").appendChild("value");
        this->propulsor.appendChild("energy_carrier_ID").appendChild("value");
        this->propulsor.appendChild("thrust_share").appendChild("value");
        this->propulsor.at("thrust_share").appendChild("unit");
        this->propulsor.at("thrust_share").appendChild("lower_boundary");
        this->propulsor.at("thrust_share").appendChild("upper_boundary");

        /* Set the initial values */
        this->propulsor.at("powertrain/value") = "turbo";
        this->propulsor.at("type/value") = "fan";
        this->propulsor.at("position/parent_component/value") = "wing";
        this->propulsor.at("position/x/value") = "front";
        this->propulsor.at("position/y/value") = "left";
        this->propulsor.at("position/z/value") = "under";
        this->propulsor.at("energy_carrier_ID/value") = "0";
        this->propulsor.at("thrust_share/value") = "1.0";

        /* Set energy carrier */
        energyCarriersMap[0] = EnergyCarrierFamily::Kerosene;
        energyCarriersMap[1] = EnergyCarrierFamily::Liquid_Hydrogen;
    }
    node propulsor{"propulsor"};
    EnergyCarriersMap energyCarriersMap;
};

/**
 * @brief Propulsor node and energy-carrier map as in the aircraft file (structure as in test_utility.cpp).
 */
class UtilityInputs : public ::testing::Test
{
  protected:
    void SetUp() override
    {
        /* Setup the propulsor structure */
        propulsor.setAttrib("ID", "3");
        propulsor.appendChild("powertrain").appendChild("value");
        propulsor.appendChild("type").appendChild("value");
        propulsor.appendChild("position").appendChild("parent_component").appendChild("value");
        propulsor.at("position").appendChild("x").appendChild("value");
        propulsor.at("position").appendChild("y").appendChild("value");
        propulsor.at("position").appendChild("z").appendChild("value");
        propulsor.appendChild("energy_carrier_ID").appendChild("value");
        propulsor.appendChild("thrust_share").appendChild("value");

        /* Set the initial values: kerosene turbofan under the left wing */
        propulsor.at("powertrain/value") = "turbo";
        propulsor.at("type/value") = "fan";
        propulsor.at("position/parent_component/value") = "wing";
        propulsor.at("position/x/value") = "front";
        propulsor.at("position/y/value") = "left";
        propulsor.at("position/z/value") = "under";
        propulsor.at("energy_carrier_ID/value") = "0";
        propulsor.at("thrust_share/value") = "1.0";

        /* Set the energy carriers */
        energy_carriers[0] = EnergyCarrierFamily::Kerosene;
        energy_carriers[1] = EnergyCarrierFamily::Liquid_Hydrogen;
    }

    node propulsor{"propulsor"};
    EnergyCarriersMap energy_carriers;
};

/* === Tests === */
/**
 * @brief Test reading the energy carrier type from the aircraft xml file.
 */
TEST(Utility, ToEnergyCarrier)
{
    /* Categorize a valid energy carrier name */
    EnergyCarrierFamily result = utility::to_energy_carrier("Kerosene");
    EXPECT_EQ(result, EnergyCarrierFamily::Kerosene);
    result = utility::to_energy_carrier("Liquid_Hydrogen");
    EXPECT_EQ(result, EnergyCarrierFamily::Liquid_Hydrogen);

    /* Categorize a mixed case valid carrier name */
    result = utility::to_energy_carrier("kEroSenE");
    EXPECT_EQ(result, EnergyCarrierFamily::Kerosene);

    /* Categorize a hyphenated fine-grained fuel id (family before the first '-') */
    result = utility::to_energy_carrier("SAF-HEFA-SPK");
    EXPECT_EQ(result, EnergyCarrierFamily::Kerosene);

    /* Categorize an invalid carrier name */
    EXPECT_THROW(utility::to_energy_carrier("Steam"), std::runtime_error);
}

/**
 * @brief Test getting the parent component and position of the engine.
 */
TEST(Utility, GetParentComponent) {
    // Test valid inputs for each component
    node position;
    position.appendChild("parent_component").appendChild("value");
    position.appendChild("x").appendChild("value");
    position.appendChild("y").appendChild("value");
    position.appendChild("z").appendChild("value");
    // Test case 1: Wing, Left, Front, Over
    position.at("parent_component/value") = "wing";
    position.at("y/value") = "left";
    position.at("x/value") = "front";
    position.at("z/value") = "over";
    auto result = utility::get_parent_component(position);
    EXPECT_EQ(std::get<0>(result), Parent::Wing);
    EXPECT_EQ(std::get<1>(result), Lateral::Left);
    EXPECT_EQ(std::get<2>(result), Longitudinal::Front);
    EXPECT_EQ(std::get<3>(result), Vertical::Over);
}

/**
 * @brief Test creating a energy carrier map based on test nodes of aircraft xml file.
 */
TEST_F(UtilityEnergyCarrier, CreateEnergyCarrierMap) {
    EnergyCarriersMap result = utility::create_energy_carrier_map(energy_carriers_node);

    // Expect two entries in the map
    ASSERT_EQ(result.size(), 2);

    // Check if the map has the correct mapping for ID 0 and ID 1
    EXPECT_EQ(result.at(0), EnergyCarrierFamily::Kerosene);
    EXPECT_EQ(result.at(1), EnergyCarrierFamily::Liquid_Hydrogen);
}

/**
 * @brief Test creating a engine based on test nodes of aircraft xml file
 */
TEST_F(UtilityPropulsor, CreateEngineN)
{
    /* Test creating the first engine */
    auto engine = utility::create_engine(propulsor, energyCarriersMap);
    EXPECT_TRUE(std::holds_alternative<Turbofan<EnergyCarrierFamily::Kerosene>>(engine));

    /* Change the default propulsion type */
    propulsor.setAttrib("ID", "1");
    propulsor.at("powertrain/value") = "turbo";
    propulsor.at("type/value") = "prop";
    propulsor.at("thrust_share/value") = 0.5;
    const double total_thrust = 1.5;
    engine = utility::create_engine(propulsor, energyCarriersMap, total_thrust);
    EXPECT_TRUE(std::holds_alternative<Turboprop<EnergyCarrierFamily::Kerosene>>(engine));

    /* Test the properties of the engine */
    Turboprop<EnergyCarrierFamily::Kerosene> &turboprop = std::get<Turboprop<EnergyCarrierFamily::Kerosene>>(engine);
    EXPECT_EQ(turboprop.id(), 1);

    /* Test with offtakes */
    engine = utility::create_engine(propulsor, energyCarriersMap, total_thrust, {10, 20});
    auto& engine_with_offtakes = std::get<Turboprop<EnergyCarrierFamily::Kerosene>>(engine);
    EXPECT_NEAR(engine_with_offtakes.offtakes().bleed_air, 10 * 0.5, 1e-3);
    EXPECT_NEAR(engine_with_offtakes.offtakes().shaft_power, 20 * 0.5, 1e-3);

    /* Change the default energy carrier */
    propulsor.at("energy_carrier_ID/value") = "1";
    engine = utility::create_engine(propulsor, energyCarriersMap);
    EXPECT_TRUE(std::holds_alternative<Turboprop<EnergyCarrierFamily::Liquid_Hydrogen>>(engine));

    /* Change to a not supported type */
    propulsor.at("powertrain/value") = "impulse";
    EXPECT_THROW(utility::create_engine(propulsor, energyCarriersMap), std::runtime_error);
}

/**
 * @brief Test calculating the point mass of the overall propulsor.
 */
TEST(UtilityMass, CalculatePointMass)
{
    /* Create an array of PointMass structures for testing */
    std::array<PointMass, static_cast<std::size_t>(Component::Other) + 1> pointmasses;

    /* Set up values for pointmasses array */
    pointmasses[static_cast<std::size_t>(Component::Engine)].CG = Eigen::Vector3d(0.0, 2.5, 0.0);
    pointmasses[static_cast<std::size_t>(Component::Engine)].inertia   <<   1.42, 0.0   , 0.0,
                                                                            0.0  , 1.42 , 0.0,
                                                                            0.0  , 0.0   , 0.17;
    pointmasses[static_cast<std::size_t>(Component::Engine)].mass = 1.0;

    pointmasses[static_cast<std::size_t>(Component::Nacelle)].CG = Eigen::Vector3d(0.0, -2.5, 0.0);
    pointmasses[static_cast<std::size_t>(Component::Nacelle)].inertia   <<   1.42, 0.0   , 0.0,
                                                                            0.0  , 1.42 , 0.0,
                                                                            0.0  , 0.0   , 0.17;
    pointmasses[static_cast<std::size_t>(Component::Nacelle)].mass = 1.0;

    pointmasses[static_cast<std::size_t>(Component::Pylon)].CG = Eigen::Vector3d(0.0, 0.0, 2.5);
    pointmasses[static_cast<std::size_t>(Component::Pylon)].inertia    <<   1.42, 0.0   , 0.0,
                                                                            0.0  , 0.17 , 0.0,
                                                                            0.0  , 0.0   , 1.42;
    pointmasses[static_cast<std::size_t>(Component::Pylon)].mass = 1.0;

    pointmasses[static_cast<std::size_t>(Component::Other)].CG = Eigen::Vector3d(0.0, 0.0, -2.5);
    pointmasses[static_cast<std::size_t>(Component::Other)].inertia    <<   1.42, 0.0   , 0.0,
                                                                            0.0  , 0.17   , 0.0,
                                                                            0.0  , 0.0   , 1.42;
    pointmasses[static_cast<std::size_t>(Component::Other)].mass = 1.0;

    /* Call the function you want to test */
    PointMass totalPropulsion = std::accumulate(pointmasses.begin(), pointmasses.end(), PointMass{});

    /* Perform assertions to check the results */
    Eigen::Matrix3d inertia_expected;
    inertia_expected << 30.68  , 0.0   , 0.0,
                        0.0  , 15.68   , 0.0,
                        0.0  , 0.0   , 15.68;
    EXPECT_EQ(totalPropulsion.CG, Eigen::Vector3d(0.0, 0.0, 0.0));
    EXPECT_EQ(totalPropulsion.inertia, inertia_expected);
    EXPECT_EQ(totalPropulsion.mass, 4.0);
}

/**
 * @brief Test creating a turbofan engine with liquid hydrogen.
 */
TEST_F(UtilityInputs, CreateEngineTurbofanLiquidHydrogen)
{
    /* Use the liquid hydrogen energy carrier */
    propulsor.at("energy_carrier_ID/value") = "1";

    /* Create the engine */
    auto engine = utility::create_engine(propulsor, energy_carriers);

    /* Check the type */
    EXPECT_TRUE(std::holds_alternative<Turbofan<EnergyCarrierFamily::Liquid_Hydrogen>>(engine));
}

/**
 * @brief Test creating an open-rotor engine.
 */
TEST_F(UtilityInputs, CreateEngineOpenRotor)
{
    /* Create a kerosene open rotor */
    propulsor.at("powertrain/value") = "openrotor";
    propulsor.at("type/value") = "fan";
    auto engine = utility::create_engine(propulsor, energy_carriers);
    EXPECT_TRUE(std::holds_alternative<Openrotorfan<EnergyCarrierFamily::Kerosene>>(engine));

    /* Use liquid hydrogen and check the error */
    propulsor.at("energy_carrier_ID/value") = "1";
    try
    {
        utility::create_engine(propulsor, energy_carriers);
        FAIL() << "Expected std::runtime_error for a liquid hydrogen open rotor";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The energy carrier is not supported for a openrotor engine!"), std::string::npos) << error.what();
    }
}

/**
 * @brief Test reading the engine ID from the propulsor node.
 */
TEST_F(UtilityInputs, CreateEngineReadsId)
{
    /* Create the engine */
    auto engine = utility::create_engine(propulsor, energy_carriers);

    /* Check the ID */
    EXPECT_EQ(std::get<Turbofan<EnergyCarrierFamily::Kerosene>>(engine).id(), 3);
}

/**
 * @brief Test parsing every supported position tag.
 */
TEST_F(UtilityInputs, PositionTagsAllValidValues)
{
    node &position = propulsor.at("position");

    /* Parent components */
    position.at("parent_component/value") = "wing";
    EXPECT_EQ(std::get<Parent>(utility::get_parent_component(position)), Parent::Wing);
    position.at("parent_component/value") = "wing_body";
    EXPECT_EQ(std::get<Parent>(utility::get_parent_component(position)), Parent::WingBody);
    position.at("parent_component/value") = "fuselage";
    EXPECT_EQ(std::get<Parent>(utility::get_parent_component(position)), Parent::Fuselage);
    position.at("parent_component/value") = "empennage";
    EXPECT_EQ(std::get<Parent>(utility::get_parent_component(position)), Parent::Empennage);

    /* Lateral positions */
    position.at("y/value") = "left";
    EXPECT_EQ(std::get<Lateral>(utility::get_parent_component(position)), Lateral::Left);
    position.at("y/value") = "right";
    EXPECT_EQ(std::get<Lateral>(utility::get_parent_component(position)), Lateral::Right);
    position.at("y/value") = "mid";
    EXPECT_EQ(std::get<Lateral>(utility::get_parent_component(position)), Lateral::Mid);

    /* Longitudinal positions */
    position.at("x/value") = "front";
    EXPECT_EQ(std::get<Longitudinal>(utility::get_parent_component(position)), Longitudinal::Front);
    position.at("x/value") = "rear";
    EXPECT_EQ(std::get<Longitudinal>(utility::get_parent_component(position)), Longitudinal::Rear);

    /* Vertical positions */
    position.at("z/value") = "under";
    EXPECT_EQ(std::get<Vertical>(utility::get_parent_component(position)), Vertical::Under);
    position.at("z/value") = "mid";
    EXPECT_EQ(std::get<Vertical>(utility::get_parent_component(position)), Vertical::Mid);
    position.at("z/value") = "over";
    EXPECT_EQ(std::get<Vertical>(utility::get_parent_component(position)), Vertical::Over);
    position.at("z/value") = "in";
    EXPECT_EQ(std::get<Vertical>(utility::get_parent_component(position)), Vertical::In);
}

/**
 * @brief Test rejecting unsupported position tags.
 */
TEST_F(UtilityInputs, PositionTagsRejectInvalidValues)
{
    node &position = propulsor.at("position");

    /* Invalid parent component */
    position.at("parent_component/value") = "tail";
    try
    {
        utility::get_parent_component(position);
        FAIL() << "Expected std::runtime_error for the parent component 'tail'";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The parent component 'tail' is not supported."), std::string::npos) << error.what();
    }

    /* Invalid lateral position */
    position.at("parent_component/value") = "wing";
    position.at("y/value") = "centre";
    try
    {
        utility::get_parent_component(position);
        FAIL() << "Expected std::runtime_error for the lateral position 'centre'";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The lateral position 'centre' is not supported."), std::string::npos) << error.what();
    }

    /* Invalid longitudinal position */
    position.at("y/value") = "left";
    position.at("x/value") = "back";
    try
    {
        utility::get_parent_component(position);
        FAIL() << "Expected std::runtime_error for the longitudinal position 'back'";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The longitudinal position 'back' is not supported."), std::string::npos) << error.what();
    }

    /* Invalid vertical position */
    position.at("x/value") = "front";
    position.at("z/value") = "below";
    try
    {
        utility::get_parent_component(position);
        FAIL() << "Expected std::runtime_error for the vertical position 'below'";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The vertical position 'below' is not supported."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that the position tags are case-sensitive.
 */
TEST_F(UtilityInputs, PositionTagsAreCaseSensitive)
{
    /* Use a capitalised parent component */
    propulsor.at("position/parent_component/value") = "Wing";

    /* Check that it is rejected */
    EXPECT_THROW(utility::get_parent_component(propulsor.at("position")), std::runtime_error);
}

/**
 * @brief Test the energy carrier family of green liquid hydrogen.
 */
TEST_F(UtilityInputs, EnergyCarrierGreenHydrogen)
{
    /* Categorize the fuel identifier */
    EXPECT_EQ(utility::to_energy_carrier("liquid_hydrogen_green"), EnergyCarrierFamily::Liquid_Hydrogen);
}

/**
 * @brief Test rejecting an unknown energy carrier identifier.
 */
TEST_F(UtilityInputs, EnergyCarrierUnknownIdentifier)
{
    /* Categorize an unknown fuel identifier and check the error */
    try
    {
        utility::to_energy_carrier("Steam");
        FAIL() << "Expected std::runtime_error for the energy carrier 'Steam'";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The energy carrier 'steam' is not supported."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test rejecting an energy carrier map with an unknown fuel.
 */
TEST_F(UtilityInputs, EnergyCarrierMapRejectsUnknownFuel)
{
    /* Setup the energy carriers structure with an unknown fuel */
    node energy_carriers_node;
    node &carrier = energy_carriers_node.appendChild("energy_carrier");
    carrier.setAttrib("ID", "0");
    carrier.appendChild("value") = "steam";

    /* Create the map */
    EXPECT_THROW(utility::create_energy_carrier_map(energy_carriers_node), std::runtime_error);
}

/**
 * @brief Test distributing thrust and offtakes to an engine by its thrust share.
 */
TEST_F(UtilityInputs, CreateEngineDistributesThrustAndOfftakes)
{
    /* Create the engine with a thrust share of 0.3 */
    propulsor.at("thrust_share/value") = "0.3";
    auto engine = utility::create_engine(propulsor, energy_carriers, 1000.0, {10.0, 20000.0});

    /* Check thrust and offtakes */
    const auto &turbofan = std::get<Turbofan<EnergyCarrierFamily::Kerosene>>(engine);
    EXPECT_NEAR(turbofan.required_thrust(), 300.0, 1e-3);
    EXPECT_NEAR(turbofan.offtakes().bleed_air, 3.0, 1e-3);
    EXPECT_NEAR(turbofan.offtakes().shaft_power, 6000.0, 1e-3);
}

/**
 * @brief Test scaling and adding offtakes.
 */
TEST_F(UtilityInputs, OfftakesScaleAndAdd)
{
    /* Scale offtakes */
    const Offtakes scaled = 2.5 * Offtakes{4.0, 1000.0};
    EXPECT_NEAR(scaled.bleed_air, 10.0, 1e-3);
    EXPECT_NEAR(scaled.shaft_power, 2500.0, 1e-3);

    /* Add offtakes */
    const Offtakes sum = Offtakes{1.0, 2.0} + Offtakes{3.0, 4.0};
    EXPECT_NEAR(sum.bleed_air, 4.0, 1e-3);
    EXPECT_NEAR(sum.shaft_power, 6.0, 1e-3);
}

/**
 * @brief Test creating an engine with an empty energy carrier map.
 */
TEST_F(UtilityInputs, CreateEngineWithEmptyEnergyCarrierMap)
{
    /* Create the engine with an empty map */
    const EnergyCarriersMap empty_map;
    try
    {
        utility::create_engine(propulsor, empty_map);
        FAIL() << "Expected std::runtime_error for an empty energy-carrier map";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("Energy carrier with ID 0 is not found in the map."), std::string::npos) << error.what();
    }
}
