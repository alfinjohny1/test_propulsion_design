/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 *
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <filesystem>
#include <memory>
#include <gtest/gtest.h>
#include <stdexcept>
#include <string>
#include <aircraftGeometry2/geometry/builder.h>

#include "../../temp_directory.h"

/* Unit Under Test */
#include "integration/default/default_integration.h"

/* === Fixtures === */
class IntegrationRules : public ::testing::Test
{
  protected:
    void SetUp() override
    {
        /* Setup the aircraft geometry */
        geom2::Polygon_2 poly = geom2::build::ellipse(1.0, 1.0).get_contour(false);
        airfoil.push_back({0, 0});
        airfoil.push_back({0.5, 0.2});
        airfoil.push_back({1.0, 0});
        airfoil.push_back({0.0, 0.0});

        /* Nacelle (also used as fuselage): diameter 1 m, length 2 m along local z */
        nacelle.sections.emplace_back(poly);
        nacelle.sections.emplace_back(poly);
        nacelle.sections.back().origin = geom2::Point_3(0, 0, 2.0);
        nacelle.normal = geom2::Direction_3(1, 0, 0);

        /* Main wing: chord 2 m at the root and 1 m at local z = -5, origin (3, 0, 2) */
        wing.sections.emplace_back(airfoil);
        wing.sections.emplace_back(airfoil);
        wing.sections.at(0).set_chord_length(2.0);
        wing.sections.at(1).set_chord_length(1.0);
        wing.sections.at(1).origin = geom2::Point_3(0, 0, -5.0);
        wing.origin = geom2::Point_3(3, 0, 2);
        wing.normal = geom2::Direction_3(0, -1, 0);
        wing.name = "front_wing";

        /* Vertical tail */
        vtp.sections.emplace_back(airfoil);
        vtp.sections.emplace_back(airfoil);
        vtp.sections.at(0).set_chord_length(1.0);
        vtp.sections.at(1).set_chord_length(0.5);
        vtp.sections.at(1).origin = geom2::Point_3(1.0, 0, -3.0);
        vtp.origin = geom2::Point_3(1.0, 0, 0.5);
        vtp.normal = geom2::Direction_3(0, 0, -1);
        vtp.is_symmetric = false;

        /* Assemble the aircraft */
        aircraft->wings.emplace_back(wing);
        aircraft->fuselages.emplace_back(nacelle);
        aircraft->empennage.emplace_back(vtp);
    }

    std::shared_ptr<node> config = aixml::openDocument(std::filesystem::path{CMAKE_TEST_CONFIG_FILE});
    geom2::Polygon_2 airfoil;
    geom2::MultisectionSurface<geom2::PolygonSection> nacelle;
    geom2::MultisectionSurface<geom2::AirfoilSection> wing;
    geom2::MultisectionSurface<geom2::AirfoilSection> vtp;
    std::shared_ptr<geometry::Aircraft> aircraft = std::make_shared<geometry::Aircraft>();
};

/* === Tests === */
/**
 * @brief Test that an unsupported location of a turbofan engine is rejected.
 */
TEST_F(IntegrationRules, UnsupportedTurbofanLocationRejected)
{
    /* Create the integrator for two wing engines */
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup an engine at the rear of the wing */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Left, Longitudinal::Rear, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the error */
    try
    {
        integrator(engine);
        FAIL() << "Expected std::runtime_error for an unsupported location";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The parent component or location of the engine is not supported."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that an unsupported location of an open-rotor engine is rejected.
 */
TEST_F(IntegrationRules, UnsupportedOpenRotorLocationRejected)
{
    /* Create the integrator for two fuselage engines */
    design::integration::Default integrator{config, aircraft, {2, 0, 0}};

    /* Setup an open rotor at the front of the fuselage */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Fuselage, Lateral::Left, Longitudinal::Front, Vertical::Mid}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the error */
    try
    {
        integrator(engine);
        FAIL() << "Expected std::runtime_error for an unsupported location";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The parent component or location of the engine is not supported."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that an aircraft with two fuselages is rejected.
 */
TEST_F(IntegrationRules, TwoFuselagesRejected)
{
    /* Add a second fuselage and create the integrator for two wing engines */
    aircraft->fuselages.emplace_back(nacelle);
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right engine under the wing */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the error */
    try
    {
        integrator(engine);
        FAIL() << "Expected std::runtime_error for two fuselages";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The aircraft does not contain exactly one fuselage."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that an empennage engine without a vertical tail is rejected.
 */
TEST_F(IntegrationRules, MissingVerticalTailRejected)
{
    /* Remove the vertical tail and create the integrator for one empennage engine */
    aircraft->empennage.clear();
    design::integration::Default integrator{config, aircraft, {0, 0, 1}};

    /* Setup the engine in the empennage */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Empennage, Lateral::Mid, Longitudinal::Front, Vertical::In}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the error */
    try
    {
        integrator(engine);
        FAIL() << "Expected std::runtime_error for a missing vertical tail";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The aircraft does not contain a vertical tail."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that the wing named in the configuration carries the engines when there are several wings.
 */
TEST_F(IntegrationRules, NamedWingSelected)
{
    /* Insert a second wing 10 m further aft in front of the named wing "front_wing" */
    geom2::MultisectionSurface<geom2::AirfoilSection> rear_wing = wing;
    rear_wing.name = "rear_wing";
    rear_wing.origin = geom2::Point_3(13, 0, 2);
    aircraft->wings.insert(aircraft->wings.begin(), rear_wing);
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right engine under the wing */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check that it is placed at the named wing */
    integrator(engine);
    EXPECT_NEAR(engine.position().x(), 1.8032562, 1e-6);
    EXPECT_NEAR(engine.position().y(), 2.33719, 1e-6);
    EXPECT_NEAR(engine.position().z(), 1.3467438, 1e-6);
}

/**
 * @brief Test that the first wing carries the engines when the configured wing name is not found.
 */
TEST_F(IntegrationRules, FirstWingUsedWhenNameNotFound)
{
    /* Insert a second wing 10 m further aft as the first wing and configure a missing wing name */
    geom2::MultisectionSurface<geom2::AirfoilSection> rear_wing = wing;
    rear_wing.name = "rear_wing";
    rear_wing.origin = geom2::Point_3(13, 0, 2);
    aircraft->wings.insert(aircraft->wings.begin(), rear_wing);
    config->at("module_configuration_file/program_settings/name_wing_engines/value") = std::string{"missing_wing"};
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right engine under the wing */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check that it is placed at the first wing, 10 m further aft */
    integrator(engine);
    EXPECT_NEAR(engine.position().x(), 11.8032562, 1e-6);
    EXPECT_NEAR(engine.position().y(), 2.33719, 1e-6);
    EXPECT_NEAR(engine.position().z(), 1.3467438, 1e-6);
}

/**
 * @brief Test that a wing that is not extruded along the y-axis is rejected.
 */
TEST_F(IntegrationRules, WingNotAlongYRejected)
{
    /* Turn the wing normal to +y while the wing extends to negative local z, and create the integrator */
    aircraft->wings.at(0).normal = geom2::Direction_3(0, 1, 0);
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right engine under the wing */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the error */
    try
    {
        integrator(engine);
        FAIL() << "Expected std::runtime_error for a wing not along the y-axis";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The wing is not oriented in y-direction."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that a fuselage engine count other than two is rejected.
 */
TEST_F(IntegrationRules, FuselageEngineCountMustBeTwo)
{
    /* Create the integrator for three fuselage engines */
    design::integration::Default integrator{config, aircraft, {3, 0, 0}};

    /* Setup the right engine at the rear fuselage */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Mid}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the error */
    try
    {
        integrator(engine);
        FAIL() << "Expected std::runtime_error for three fuselage engines";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The number of engines on the fuselage is not supported."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that a second fuselage engine on the same side is rejected.
 */
TEST_F(IntegrationRules, FuselageRejectsSecondEngineOnSameSide)
{
    /* Create the integrator for two fuselage engines */
    design::integration::Default integrator{config, aircraft, {2, 0, 0}};

    /* Setup two right engines at the rear fuselage */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_0{0, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Mid}};
    engine_0.set_dimension({0.8, 0.8, 1.5});
    engine_0.set_fan({0.9});
    engine_0.set_nacelle(nacelle);
    Turbofan<EnergyCarrierFamily::Kerosene> engine_1{1, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Mid}};
    engine_1.set_dimension({0.8, 0.8, 1.5});
    engine_1.set_fan({0.9});
    engine_1.set_nacelle(nacelle);

    /* Integrate both engines and check the error for the second one */
    integrator(engine_0);
    try
    {
        integrator(engine_1);
        FAIL() << "Expected std::runtime_error for a second engine on the same side";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("No space left on the fuselage for the engine to be integrated."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that a fuselage that is not extruded along the x-axis is rejected.
 */
TEST_F(IntegrationRules, FuselageNotAlongXRejected)
{
    /* Turn the fuselage normal to the y-axis and create the integrator for two fuselage engines */
    aircraft->fuselages.at(0).normal = geom2::Direction_3(0, 1, 0);
    design::integration::Default integrator{config, aircraft, {2, 0, 0}};

    /* Setup the right engine at the rear fuselage */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Mid}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the error */
    try
    {
        integrator(engine);
        FAIL() << "Expected std::runtime_error for a fuselage not along the x-axis";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The fuselage is not oriented in x-direction."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test integrating the right turbofan engine at the rear fuselage.
 */
TEST_F(IntegrationRules, FuselageRightEnginePosition)
{
    /* Create the integrator for two fuselage engines */
    design::integration::Default integrator{config, aircraft, {2, 0, 0}};

    /* Setup the right engine at the rear fuselage */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Mid}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the position: 0.8 L = 1.6 along, 0.5 w + 0.625 w_nac = 1.125 to the side, 0.25 h = 0.25 up */
    integrator(engine);
    EXPECT_NEAR(engine.position().x(), 1.6, 1e-6);
    EXPECT_NEAR(engine.position().y(), 1.125, 1e-6);
    EXPECT_NEAR(engine.position().z(), 0.25, 1e-6);
}

/**
 * @brief Test applying the user shift to a fuselage engine in the fuselage frame.
 */
TEST_F(IntegrationRules, FuselageShiftAppliedInFuselageFrame)
{
    /* Set the shift of slot 0 to (0.1, 0.2, 0.3) and create the integrator for two fuselage engines */
    config->at("module_configuration_file/program_settings/repositioning/engine_shifts/engine/shift_x/value") = 0.1;
    config->at("module_configuration_file/program_settings/repositioning/engine_shifts/engine/shift_y/value") = 0.2;
    config->at("module_configuration_file/program_settings/repositioning/engine_shifts/engine/shift_z/value") = 0.3;
    design::integration::Default integrator{config, aircraft, {2, 0, 0}};

    /* Setup the right engine with ID 0 at the rear fuselage */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Mid}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the position: fuselage-local (1.125 + 0.1, 0.25 + 0.2, 1.6 - 0.3) */
    integrator(engine);
    EXPECT_NEAR(engine.position().x(), 1.3, 1e-6);
    EXPECT_NEAR(engine.position().y(), 1.225, 1e-6);
    EXPECT_NEAR(engine.position().z(), 0.45, 1e-6);
}

/**
 * @brief Test that the fuselage engine position is given in the global frame of the fuselage origin.
 */
TEST_F(IntegrationRules, FuselagePositionInGlobalFrame)
{
    /* Move the fuselage origin to (2, 0, 0) and create the integrator for two fuselage engines */
    aircraft->fuselages.at(0).origin = geom2::Point_3(2, 0, 0);
    design::integration::Default integrator{config, aircraft, {2, 0, 0}};

    /* Setup the right engine at the rear fuselage */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Mid}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check that it moved with the fuselage origin by 2 m */
    integrator(engine);
    EXPECT_NEAR(engine.position().x(), 3.6, 1e-6);
    EXPECT_NEAR(engine.position().y(), 1.125, 1e-6);
    EXPECT_NEAR(engine.position().z(), 0.25, 1e-6);
}

/**
 * @brief Test that a second empennage engine is rejected.
 */
TEST_F(IntegrationRules, EmpennageRejectsSecondEngine)
{
    /* Create the integrator for two empennage engines */
    design::integration::Default integrator{config, aircraft, {0, 0, 2}};

    /* Setup two engines in the empennage */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_0{0, {Parent::Empennage, Lateral::Mid, Longitudinal::Front, Vertical::In}};
    engine_0.set_dimension({0.8, 0.8, 1.5});
    engine_0.set_fan({0.9});
    engine_0.set_nacelle(nacelle);
    Turbofan<EnergyCarrierFamily::Kerosene> engine_1{1, {Parent::Empennage, Lateral::Mid, Longitudinal::Front, Vertical::In}};
    engine_1.set_dimension({0.8, 0.8, 1.5});
    engine_1.set_fan({0.9});
    engine_1.set_nacelle(nacelle);

    /* Integrate both engines and check the error for the second one */
    integrator(engine_0);
    try
    {
        integrator(engine_1);
        FAIL() << "Expected std::runtime_error for a second empennage engine";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("No space left on the empennage for the engine to be integrated."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that a vertical tail that is not in line with the fuselage center is rejected.
 */
TEST_F(IntegrationRules, EmpennageOffCentreRejected)
{
    /* Move the vertical tail 0.5 m to the side and create the integrator for one empennage engine */
    aircraft->empennage.at(0).origin = geom2::Point_3(1.0, 0.5, 0.5);
    design::integration::Default integrator{config, aircraft, {0, 0, 1}};

    /* Setup the engine in the empennage */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Empennage, Lateral::Mid, Longitudinal::Front, Vertical::In}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the error */
    try
    {
        integrator(engine);
        FAIL() << "Expected std::runtime_error for a vertical tail off the fuselage center";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The empennage is not in line with the fuselage center."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test applying the user shift to an empennage engine in the global frame.
 */
TEST_F(IntegrationRules, EmpennageShiftAppliedInGlobalFrame)
{
    /* Set the shift of slot 0 to (0.1, 0.2, 0.3) and create the integrator for one empennage engine */
    config->at("module_configuration_file/program_settings/repositioning/engine_shifts/engine/shift_x/value") = 0.1;
    config->at("module_configuration_file/program_settings/repositioning/engine_shifts/engine/shift_y/value") = 0.2;
    config->at("module_configuration_file/program_settings/repositioning/engine_shifts/engine/shift_z/value") = 0.3;
    design::integration::Default integrator{config, aircraft, {0, 0, 1}};

    /* Setup the engine with ID 0 in the empennage */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Empennage, Lateral::Mid, Longitudinal::Front, Vertical::In}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the position: (1.264 + 0.1, 0 + 0.2, 1.0 - 0.3) */
    integrator(engine);
    EXPECT_NEAR(engine.position().x(), 1.364, 1e-3);
    EXPECT_NEAR(engine.position().y(), 0.2, 1e-3);
    EXPECT_NEAR(engine.position().z(), 0.7, 1e-3);
}

/**
 * @brief Test integrating two wing-body engines, one on each side.
 */
TEST_F(IntegrationRules, WingBodyTwoEnginesOnBothSides)
{
    /* Create the integrator for two wing engines */
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right and the left wing-body engine */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_right{0, {Parent::WingBody, Lateral::Right, Longitudinal::Rear, Vertical::Over}};
    engine_right.set_dimension({0.8, 0.8, 1.5});
    engine_right.set_fan({0.9});
    engine_right.set_nacelle(nacelle);
    Turbofan<EnergyCarrierFamily::Kerosene> engine_left{1, {Parent::WingBody, Lateral::Left, Longitudinal::Rear, Vertical::Over}};
    engine_left.set_dimension({0.8, 0.8, 1.5});
    engine_left.set_fan({0.9});
    engine_left.set_nacelle(nacelle);

    /* Integrate both engines */
    integrator(engine_right);
    integrator(engine_left);

    /* Check the positions: s = 0.8 * 1.089 = 0.8712, c = 2 - s / 5 = 1.82576, x = 3 + 0.7 c, z = 2 + 0.8 */
    EXPECT_NEAR(engine_right.position().x(), 4.278032, 1e-6);
    EXPECT_NEAR(engine_right.position().y(), 0.8712, 1e-6);
    EXPECT_NEAR(engine_right.position().z(), 2.8, 1e-6);
    EXPECT_NEAR(engine_left.position().x(), 4.278032, 1e-6);
    EXPECT_NEAR(engine_left.position().y(), -0.8712, 1e-6);
    EXPECT_NEAR(engine_left.position().z(), 2.8, 1e-6);
}

/**
 * @brief Test integrating a single wing-body engine on the center line with a configuration without shift entries.
 */
TEST_F(IntegrationRules, WingBodySingleEngineWithoutShiftEntries)
{
    /* Replace the shift entries by the zero shifts repositioning/shift_x, _y, _z that the integrator still reads (O-27) */
    node &repositioning = config->at("module_configuration_file/program_settings/repositioning");
    repositioning.deleteChild("engine_shifts");
    repositioning.appendChild("shift_x", true).appendChild("value", true) = 0.0;
    repositioning.appendChild("shift_y", true).appendChild("value", true) = 0.0;
    repositioning.appendChild("shift_z", true).appendChild("value", true) = 0.0;
    design::integration::Default integrator{config, aircraft, {0, 1, 0}};

    /* Setup the wing-body engine */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::WingBody, Lateral::Right, Longitudinal::Rear, Vertical::Over}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the position: c = 2, x = 3 + 0.7 c, z = 2 + 0.8 */
    integrator(engine);
    EXPECT_NEAR(engine.position().x(), 4.4, 1e-6);
    EXPECT_NEAR(engine.position().y(), 0.0, 1e-6);
    EXPECT_NEAR(engine.position().z(), 2.8, 1e-6);
}

/**
 * @brief Test creating the integrator for a single wing-body engine with the shift entry of the configuration.
 */
TEST_F(IntegrationRules, WingBodySingleEngineWithConfiguredShiftEntry)
{
    /* Create the integrator for one wing engine with the shift entry for slot 0 */
    EXPECT_NO_THROW(design::integration::Default(config, aircraft, design::integration::Default::EngineCount{0, 1, 0}));
}

/**
 * @brief Test that a single wing-body engine colliding with the horizontal tail is rejected.
 */
TEST_F(IntegrationRules, WingBodySingleEngineEmpennageCollisionRejected)
{
    /* Add a horizontal tail whose sections are at y = 0.0 m and y = 2.0 m */
    geom2::MultisectionSurface<geom2::AirfoilSection> htp;
    htp.sections.emplace_back(airfoil);
    htp.sections.emplace_back(airfoil);
    htp.sections.at(0).origin = geom2::Point_3(0, 0, -0.0);
    htp.sections.at(1).origin = geom2::Point_3(0, 0, -2.0);
    htp.origin = geom2::Point_3(8, 0, 1);
    htp.normal = geom2::Direction_3(0, -1, 0);
    aircraft->empennage.emplace_back(htp);

    /* Replace the shift entries by the zero shifts repositioning/shift_x, _y, _z that the integrator still reads (O-27) */
    node &repositioning = config->at("module_configuration_file/program_settings/repositioning");
    repositioning.deleteChild("engine_shifts");
    repositioning.appendChild("shift_x", true).appendChild("value", true) = 0.0;
    repositioning.appendChild("shift_y", true).appendChild("value", true) = 0.0;
    repositioning.appendChild("shift_z", true).appendChild("value", true) = 0.0;
    design::integration::Default integrator{config, aircraft, {0, 1, 0}};

    /* Setup the wing-body engine */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::WingBody, Lateral::Right, Longitudinal::Rear, Vertical::Over}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the error: the tail blocks |y| < 2.5 m including the center line */
    try
    {
        integrator(engine);
        FAIL() << "Expected std::runtime_error for an empennage collision";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("Empennage-engine collision, engine cannot be placed over the wing."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that two wing-body engines without space next to the horizontal tail are rejected.
 */
TEST_F(IntegrationRules, WingBodyTwoEnginesWithoutSpaceRejected)
{
    /* Add a horizontal tail whose sections are at y = 1.0 m and y = 2.0 m */
    geom2::MultisectionSurface<geom2::AirfoilSection> htp;
    htp.sections.emplace_back(airfoil);
    htp.sections.emplace_back(airfoil);
    htp.sections.at(0).origin = geom2::Point_3(0, 0, -1.0);
    htp.sections.at(1).origin = geom2::Point_3(0, 0, -2.0);
    htp.origin = geom2::Point_3(8, 0, 1);
    htp.normal = geom2::Direction_3(0, -1, 0);
    aircraft->empennage.emplace_back(htp);

    /* Create the integrator for two wing engines */
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right and the left wing-body engine */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_right{0, {Parent::WingBody, Lateral::Right, Longitudinal::Rear, Vertical::Over}};
    engine_right.set_dimension({0.8, 0.8, 1.5});
    engine_right.set_fan({0.9});
    engine_right.set_nacelle(nacelle);
    Turbofan<EnergyCarrierFamily::Kerosene> engine_left{1, {Parent::WingBody, Lateral::Left, Longitudinal::Rear, Vertical::Over}};
    engine_left.set_dimension({0.8, 0.8, 1.5});
    engine_left.set_fan({0.9});
    engine_left.set_nacelle(nacelle);

    /* Integrate the first engine and check the error: the free spans 1.5 m and 0.25 m are too small for 1.089 m */
    try
    {
        integrator(engine_right);
        FAIL() << "Expected std::runtime_error for no available space";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("No available space, engine cannot be placed over the wing."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test placing two wing-body engines outboard of a horizontal tail close to the center line.
 */
TEST_F(IntegrationRules, WingBodyTwoEnginesOutboardOfHorizontalTail)
{
    /* Add a horizontal tail whose sections are at y = 0.1 m and y = 0.5 m */
    geom2::MultisectionSurface<geom2::AirfoilSection> htp;
    htp.sections.emplace_back(airfoil);
    htp.sections.emplace_back(airfoil);
    htp.sections.at(0).origin = geom2::Point_3(0, 0, -0.1);
    htp.sections.at(1).origin = geom2::Point_3(0, 0, -0.5);
    htp.origin = geom2::Point_3(8, 0, 1);
    htp.normal = geom2::Direction_3(0, -1, 0);
    aircraft->empennage.emplace_back(htp);

    /* Create the integrator for two wing engines */
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right and the left wing-body engine */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_right{0, {Parent::WingBody, Lateral::Right, Longitudinal::Rear, Vertical::Over}};
    engine_right.set_dimension({0.8, 0.8, 1.5});
    engine_right.set_fan({0.9});
    engine_right.set_nacelle(nacelle);
    Turbofan<EnergyCarrierFamily::Kerosene> engine_left{1, {Parent::WingBody, Lateral::Left, Longitudinal::Rear, Vertical::Over}};
    engine_left.set_dimension({0.8, 0.8, 1.5});
    engine_left.set_fan({0.9});
    engine_left.set_nacelle(nacelle);

    /* Integrate both engines */
    integrator(engine_right);
    integrator(engine_left);

    /* Check the positions outboard of the tail (blocked to 0.6 m): s = 0.75 * 1.089 + 0.6 = 1.41675, c = 1.71665 */
    EXPECT_NEAR(engine_right.position().x(), 4.201655, 1e-6);
    EXPECT_NEAR(engine_right.position().y(), 1.41675, 1e-6);
    EXPECT_NEAR(engine_right.position().z(), 2.8, 1e-6);
    EXPECT_NEAR(engine_left.position().x(), 4.201655, 1e-6);
    EXPECT_NEAR(engine_left.position().y(), -1.41675, 1e-6);
    EXPECT_NEAR(engine_left.position().z(), 2.8, 1e-6);
}

/**
 * @brief Test integrating a turbofan and an open-rotor engine without aircraft geometry.
 */
TEST_F(IntegrationRules, NoGeometryPlacesEnginesAtOrigin)
{
    /* Create the integrator for two wing engines without aircraft geometry */
    design::integration::Default integrator{config, nullptr, {0, 2, 0}};

    /* Setup a turbofan and an open rotor under the wing */
    Turbofan<EnergyCarrierFamily::Kerosene> turbofan{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    turbofan.set_dimension({0.8, 0.8, 1.5});
    turbofan.set_fan({0.9});
    turbofan.set_nacelle(nacelle);
    Openrotorfan<EnergyCarrierFamily::Kerosene> openrotor{1, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}};
    openrotor.set_dimension({0.8, 0.8, 1.5});
    openrotor.set_fan({0.9});
    openrotor.set_nacelle(nacelle);

    /* Integrate both engines and check that they are at the origin */
    integrator(turbofan);
    integrator(openrotor);
    EXPECT_EQ(turbofan.position(), geom2::Point_3(0.0, 0.0, 0.0));
    EXPECT_EQ(openrotor.position(), geom2::Point_3(0.0, 0.0, 0.0));
}

/**
 * @brief Test that an unsupported number of wing engines is rejected.
 */
TEST_F(IntegrationRules, UnsupportedWingEngineCountRejected)
{
    /* Create the integrator for three wing engines */
    design::integration::Default integrator{config, aircraft, {0, 3, 0}};

    /* Setup the right engine under the wing */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the error */
    try
    {
        integrator(engine);
        FAIL() << "Expected std::runtime_error for three wing engines";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("Unsupported number of wing-mounted engines."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test applying the user shift to both wing engines, mirrored for the left engine.
 */
TEST_F(IntegrationRules, UserShiftAppliedAndMirrored)
{
    /* Set the shift of slot 0 to (0.1, 0.2, 0.3) and create the integrator for two wing engines */
    config->at("module_configuration_file/program_settings/repositioning/engine_shifts/engine/shift_x/value") = 0.1;
    config->at("module_configuration_file/program_settings/repositioning/engine_shifts/engine/shift_y/value") = 0.2;
    config->at("module_configuration_file/program_settings/repositioning/engine_shifts/engine/shift_z/value") = 0.3;
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right and the left engine under the wing */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_right{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine_right.set_dimension({0.8, 0.8, 1.5});
    engine_right.set_fan({0.9});
    engine_right.set_nacelle(nacelle);
    Turbofan<EnergyCarrierFamily::Kerosene> engine_left{1, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}};
    engine_left.set_dimension({0.8, 0.8, 1.5});
    engine_left.set_fan({0.9});
    engine_left.set_nacelle(nacelle);

    /* Integrate both engines */
    integrator(engine_right);
    integrator(engine_left);

    /* Check the positions: 0.1 m aft, 0.2 m up and 0.3 m outboard of (1.8032562, +-2.33719, 1.3467438) */
    EXPECT_NEAR(engine_right.position().x(), 1.9032562, 1e-6);
    EXPECT_NEAR(engine_right.position().y(), 2.63719, 1e-6);
    EXPECT_NEAR(engine_right.position().z(), 1.5467438, 1e-6);
    EXPECT_NEAR(engine_left.position().x(), 1.9032562, 1e-6);
    EXPECT_NEAR(engine_left.position().y(), -2.63719, 1e-6);
    EXPECT_NEAR(engine_left.position().z(), 1.5467438, 1e-6);
}

/**
 * @brief Test applying different user shifts to the inner and the outer slot of four wing engines.
 */
TEST_F(IntegrationRules, UserShiftPerSlotForFourEngines)
{
    /* Set the shift of slot 0 to (0.1, 0.2, 0.3), add slot 1 with (-0.1, 0.0, 0.5) and create the integrator for four wing engines */
    config->at("module_configuration_file/program_settings/repositioning/engine_shifts/engine/shift_x/value") = 0.1;
    config->at("module_configuration_file/program_settings/repositioning/engine_shifts/engine/shift_y/value") = 0.2;
    config->at("module_configuration_file/program_settings/repositioning/engine_shifts/engine/shift_z/value") = 0.3;
    node &slot_1 = config->at("module_configuration_file/program_settings/repositioning/engine_shifts").appendChild("engine", true);
    slot_1.appendChild("id", true).appendChild("value", true) = std::string{"1"};
    slot_1.appendChild("shift_x", true).appendChild("value", true) = -0.1;
    slot_1.appendChild("shift_y", true).appendChild("value", true) = 0.0;
    slot_1.appendChild("shift_z", true).appendChild("value", true) = 0.5;
    design::integration::Default integrator{config, aircraft, {0, 4, 0}};

    /* Setup four engines, integrated in the order right inner, right outer, left inner, left outer */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_right_inner{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine_right_inner.set_dimension({0.8, 0.8, 1.5});
    engine_right_inner.set_fan({0.9});
    engine_right_inner.set_nacelle(nacelle);
    Turbofan<EnergyCarrierFamily::Kerosene> engine_right_outer{1, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine_right_outer.set_dimension({0.8, 0.8, 1.5});
    engine_right_outer.set_fan({0.9});
    engine_right_outer.set_nacelle(nacelle);
    Turbofan<EnergyCarrierFamily::Kerosene> engine_left_inner{2, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}};
    engine_left_inner.set_dimension({0.8, 0.8, 1.5});
    engine_left_inner.set_fan({0.9});
    engine_left_inner.set_nacelle(nacelle);
    Turbofan<EnergyCarrierFamily::Kerosene> engine_left_outer{3, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}};
    engine_left_outer.set_dimension({0.8, 0.8, 1.5});
    engine_left_outer.set_fan({0.9});
    engine_left_outer.set_nacelle(nacelle);

    /* Integrate the engines */
    integrator(engine_right_inner);
    integrator(engine_right_outer);
    integrator(engine_left_inner);
    integrator(engine_left_outer);

    /* Check the inner engines: slot 0 shift from (1.8360005, +-0.699975, 1.3139995) */
    EXPECT_NEAR(engine_right_inner.position().x(), 1.9360005, 1e-6);
    EXPECT_NEAR(engine_right_inner.position().y(), 0.999975, 1e-6);
    EXPECT_NEAR(engine_right_inner.position().z(), 1.5139995, 1e-6);
    EXPECT_NEAR(engine_left_inner.position().x(), 1.9360005, 1e-6);
    EXPECT_NEAR(engine_left_inner.position().y(), -0.999975, 1e-6);
    EXPECT_NEAR(engine_left_inner.position().z(), 1.5139995, 1e-6);

    /* Check the outer engines: slot 1 shift from (1.818, +-1.6, 1.332) */
    EXPECT_NEAR(engine_right_outer.position().x(), 1.718, 1e-6);
    EXPECT_NEAR(engine_right_outer.position().y(), 2.1, 1e-6);
    EXPECT_NEAR(engine_right_outer.position().z(), 1.332, 1e-6);
    EXPECT_NEAR(engine_left_outer.position().x(), 1.718, 1e-6);
    EXPECT_NEAR(engine_left_outer.position().y(), -2.1, 1e-6);
    EXPECT_NEAR(engine_left_outer.position().z(), 1.332, 1e-6);
}

/**
 * @brief Test that a shift entry with a slot ID out of range is rejected.
 */
TEST_F(IntegrationRules, ShiftIdOutOfRangeRejected)
{
    /* Set the slot ID 1, while two wing engines have only slot 0 */
    config->at("module_configuration_file/program_settings/repositioning/engine_shifts/engine/id/value") = std::string{"1"};

    /* Create the integrator and check the error */
    try
    {
        design::integration::Default integrator{config, aircraft, {0, 2, 0}};
        FAIL() << "Expected std::runtime_error for a slot ID out of range";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("engine slot ID '1' is out of range."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that two shift entries with the same slot ID are rejected.
 */
TEST_F(IntegrationRules, DuplicateShiftIdRejected)
{
    /* Add a second shift entry with the slot ID 0 */
    node &duplicate = config->at("module_configuration_file/program_settings/repositioning/engine_shifts").appendChild("engine", true);
    duplicate.appendChild("id", true).appendChild("value", true) = std::string{"0"};

    /* Create the integrator for four wing engines and check the error */
    try
    {
        design::integration::Default integrator{config, aircraft, {0, 4, 0}};
        FAIL() << "Expected std::runtime_error for a duplicate slot ID";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("Duplicate shift definition for propulsor ID '0'."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that a shift entry with a non-numeric slot ID is rejected.
 */
TEST_F(IntegrationRules, NonNumericShiftIdRejected)
{
    /* Set the slot ID to a text */
    config->at("module_configuration_file/program_settings/repositioning/engine_shifts/engine/id/value") = std::string{"abc"};

    /* Create the integrator and check the error */
    try
    {
        design::integration::Default integrator{config, aircraft, {0, 2, 0}};
        FAIL() << "Expected std::runtime_error for a non-numeric slot ID";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("Configured engine slot ID 'abc' is not a valid numeric ID."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that the engine position is given in the global frame of the wing origin.
 */
TEST_F(IntegrationRules, PositionInGlobalFrame)
{
    /* Move the wing origin from (3, 0, 2) to (13, 1, 4) and create the integrator for two wing engines */
    aircraft->wings.at(0).origin = geom2::Point_3(13, 1, 4);
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right engine under the wing */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check that it moved with the wing origin by (10, 1, 2) */
    integrator(engine);
    EXPECT_NEAR(engine.position().x(), 11.8032562, 1e-6);
    EXPECT_NEAR(engine.position().y(), 3.33719, 1e-6);
    EXPECT_NEAR(engine.position().z(), 3.3467438, 1e-6);
}

/**
 * @brief Test placing a wing engine at the wing kink when enabled.
 */
TEST_F(IntegrationRules, EngineAtKinkWhenEnabled)
{
    /* Kinked wing: chord 2 m at the root, 1.7 m at the kink at local z = -1.5 and 1 m at z = -5 with the leading edge 0.6 m aft */
    geom2::MultisectionSurface<geom2::AirfoilSection> kinked_wing;
    kinked_wing.sections.emplace_back(airfoil);
    kinked_wing.sections.emplace_back(airfoil);
    kinked_wing.sections.emplace_back(airfoil);
    kinked_wing.sections.at(0).set_chord_length(2.0);
    kinked_wing.sections.at(1).set_chord_length(1.7);
    kinked_wing.sections.at(1).origin = geom2::Point_3(0, 0, -1.5);
    kinked_wing.sections.at(2).set_chord_length(1.0);
    kinked_wing.sections.at(2).origin = geom2::Point_3(0.6, 0, -5.0);
    kinked_wing.origin = geom2::Point_3(3, 0, 2);
    kinked_wing.normal = geom2::Direction_3(0, -1, 0);
    aircraft->wings.at(0) = kinked_wing;

    /* Create the integrator for two wing engines with the kink placement of the configuration (enabled) */
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right engine under the wing */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the position at the kink: s = 1.5, c = 1.7, x = 3 + 0.17 - 1.35, z = 2 - 0.5 - 0.17 */
    integrator(engine);
    EXPECT_NEAR(engine.position().x(), 1.82, 1e-6);
    EXPECT_NEAR(engine.position().y(), 1.5, 1e-6);
    EXPECT_NEAR(engine.position().z(), 1.33, 1e-6);
}

/**
 * @brief Test placing a wing engine at the default span position when the kink placement is disabled.
 */
TEST_F(IntegrationRules, EngineAtDefaultSpanWhenKinkDisabled)
{
    /* Kinked wing: chord 2 m at the root, 1.7 m at the kink at local z = -1.5 and 1 m at z = -5 with the leading edge 0.6 m aft */
    geom2::MultisectionSurface<geom2::AirfoilSection> kinked_wing;
    kinked_wing.sections.emplace_back(airfoil);
    kinked_wing.sections.emplace_back(airfoil);
    kinked_wing.sections.emplace_back(airfoil);
    kinked_wing.sections.at(0).set_chord_length(2.0);
    kinked_wing.sections.at(1).set_chord_length(1.7);
    kinked_wing.sections.at(1).origin = geom2::Point_3(0, 0, -1.5);
    kinked_wing.sections.at(2).set_chord_length(1.0);
    kinked_wing.sections.at(2).origin = geom2::Point_3(0.6, 0, -5.0);
    kinked_wing.origin = geom2::Point_3(3, 0, 2);
    kinked_wing.normal = geom2::Direction_3(0, -1, 0);
    aircraft->wings.at(0) = kinked_wing;

    /* Disable the kink placement in a copy of the configuration file, which is read when the integrator is created */
    const UniqueTempDirectory temp{"test_integration_rules"};
    std::filesystem::copy_file(std::filesystem::path{CMAKE_TEST_CONFIG_FILE}, temp.path() / "propulsion_design_conf.xml");
    auto disabled = aixml::openDocument(temp.path() / "propulsion_design_conf.xml");
    disabled->at("module_configuration_file/program_settings/engine_at_kink/value") = std::string{"false"};
    ASSERT_TRUE(aixml::saveDocument(*disabled));
    config = aixml::openDocument(temp.path() / "propulsion_design_conf.xml");

    /* Create the integrator for two wing engines */
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right engine under the wing */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the default position: s = 2.33719, x_LE = 0.143518, c = 1.532562 */
    integrator(engine);
    EXPECT_NEAR(engine.position().x(), 1.9467742, 1e-6);
    EXPECT_NEAR(engine.position().y(), 2.33719, 1e-6);
    EXPECT_NEAR(engine.position().z(), 1.3467438, 1e-6);
}

/**
 * @brief Test that the kink placement is not used for four wing engines.
 */
TEST_F(IntegrationRules, KinkIgnoredForFourEngines)
{
    /* Kinked wing: chord 2 m at the root, 1.7 m at the kink at local z = -1.5 and 1 m at z = -5 with the leading edge 0.6 m aft */
    geom2::MultisectionSurface<geom2::AirfoilSection> kinked_wing;
    kinked_wing.sections.emplace_back(airfoil);
    kinked_wing.sections.emplace_back(airfoil);
    kinked_wing.sections.emplace_back(airfoil);
    kinked_wing.sections.at(0).set_chord_length(2.0);
    kinked_wing.sections.at(1).set_chord_length(1.7);
    kinked_wing.sections.at(1).origin = geom2::Point_3(0, 0, -1.5);
    kinked_wing.sections.at(2).set_chord_length(1.0);
    kinked_wing.sections.at(2).origin = geom2::Point_3(0.6, 0, -5.0);
    kinked_wing.origin = geom2::Point_3(3, 0, 2);
    kinked_wing.normal = geom2::Direction_3(0, -1, 0);
    aircraft->wings.at(0) = kinked_wing;

    /* Create the integrator for four wing engines with the kink placement of the configuration (enabled) */
    design::integration::Default integrator{config, aircraft, {0, 4, 0}};

    /* Setup the right inner engine under the wing */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the default inner position: s = 0.699975, c = 1.860005 */
    integrator(engine);
    EXPECT_NEAR(engine.position().x(), 1.8360005, 1e-6);
    EXPECT_NEAR(engine.position().y(), 0.699975, 1e-6);
    EXPECT_NEAR(engine.position().z(), 1.3139995, 1e-6);
}

/**
 * @brief Test placing a wing engine at the default span position when it does not fit at the wing kink.
 */
TEST_F(IntegrationRules, KinkWithoutClearanceFallsBackToDefaultSpan)
{
    /* Kinked wing: chord 2 m at the root, 1.54 m at the kink at local z = -2.3 and 1 m at z = -5 with the leading edge 0.6 m aft */
    geom2::MultisectionSurface<geom2::AirfoilSection> kinked_wing;
    kinked_wing.sections.emplace_back(airfoil);
    kinked_wing.sections.emplace_back(airfoil);
    kinked_wing.sections.emplace_back(airfoil);
    kinked_wing.sections.at(0).set_chord_length(2.0);
    kinked_wing.sections.at(1).set_chord_length(1.54);
    kinked_wing.sections.at(1).origin = geom2::Point_3(0, 0, -2.3);
    kinked_wing.sections.at(2).set_chord_length(1.0);
    kinked_wing.sections.at(2).origin = geom2::Point_3(0.6, 0, -5.0);
    kinked_wing.origin = geom2::Point_3(3, 0, 2);
    kinked_wing.normal = geom2::Direction_3(0, -1, 0);
    aircraft->wings.at(0) = kinked_wing;

    /* Create the integrator for two wing engines with the kink placement of the configuration (enabled) */
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right engine under the wing */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine: 2.3 + 1.089 / 2 = 2.8445 exceeds the tip limit span / 2 = 2.5, so the default s = 2.33719 is used */
    integrator(engine);

    /* Check the default position: x_LE = 0.00826444, c = 1.532562 */
    EXPECT_NEAR(engine.position().x(), 1.81152064, 1e-6);
    EXPECT_NEAR(engine.position().y(), 2.33719, 1e-6);
    EXPECT_NEAR(engine.position().z(), 1.3467438, 1e-6);
}

/**
 * @brief Test placing a wing-body engine at the wing kink when enabled.
 */
TEST_F(IntegrationRules, WingBodyEngineAtKink)
{
    /* Kinked wing: chord 2 m at the root, 1.7 m at the kink at local z = -1.5 and 1 m at z = -5 with the leading edge 0.6 m aft */
    geom2::MultisectionSurface<geom2::AirfoilSection> kinked_wing;
    kinked_wing.sections.emplace_back(airfoil);
    kinked_wing.sections.emplace_back(airfoil);
    kinked_wing.sections.emplace_back(airfoil);
    kinked_wing.sections.at(0).set_chord_length(2.0);
    kinked_wing.sections.at(1).set_chord_length(1.7);
    kinked_wing.sections.at(1).origin = geom2::Point_3(0, 0, -1.5);
    kinked_wing.sections.at(2).set_chord_length(1.0);
    kinked_wing.sections.at(2).origin = geom2::Point_3(0.6, 0, -5.0);
    kinked_wing.origin = geom2::Point_3(3, 0, 2);
    kinked_wing.normal = geom2::Direction_3(0, -1, 0);
    aircraft->wings.at(0) = kinked_wing;

    /* Create the integrator for two wing engines with the kink placement of the configuration (enabled) */
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right and the left wing-body engine */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_right{0, {Parent::WingBody, Lateral::Right, Longitudinal::Rear, Vertical::Over}};
    engine_right.set_dimension({0.8, 0.8, 1.5});
    engine_right.set_fan({0.9});
    engine_right.set_nacelle(nacelle);
    Turbofan<EnergyCarrierFamily::Kerosene> engine_left{1, {Parent::WingBody, Lateral::Left, Longitudinal::Rear, Vertical::Over}};
    engine_left.set_dimension({0.8, 0.8, 1.5});
    engine_left.set_fan({0.9});
    engine_left.set_nacelle(nacelle);

    /* Integrate both engines */
    integrator(engine_right);
    integrator(engine_left);

    /* Check both engines at the kink on their own side: s = 1.5 instead of 0.8712, c = 1.7, x = 3 + 0.7 c, z = 2 + 0.8 */
    EXPECT_NEAR(engine_right.position().x(), 4.19, 1e-6);
    EXPECT_NEAR(engine_right.position().y(), 1.5, 1e-6);
    EXPECT_NEAR(engine_right.position().z(), 2.8, 1e-6);
    EXPECT_NEAR(engine_left.position().x(), 4.19, 1e-6);
    EXPECT_NEAR(engine_left.position().y(), -1.5, 1e-6);
    EXPECT_NEAR(engine_left.position().z(), 2.8, 1e-6);
}

/**
 * @brief Test integrating two open-rotor engines under the wing.
 */
TEST_F(IntegrationRules, OpenRotorUnderWing)
{
    /* Create the integrator for two wing engines */
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right and the left open rotor under the wing */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine_right{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine_right.set_dimension({0.8, 0.8, 1.5});
    engine_right.set_fan({0.9});
    engine_right.set_nacelle(nacelle);
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine_left{1, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}};
    engine_left.set_dimension({0.8, 0.8, 1.5});
    engine_left.set_fan({0.9});
    engine_left.set_nacelle(nacelle);

    /* Integrate both engines */
    integrator(engine_right);
    integrator(engine_left);

    /* Check the positions: s = 1.3 (0.5 + 0.5 * 1.089) = 1.35785, c = 1.72843, x = 3 + 0.5 c, z = 2 - 0.3 */
    EXPECT_NEAR(engine_right.position().x(), 3.864215, 1e-6);
    EXPECT_NEAR(engine_right.position().y(), 1.35785, 1e-6);
    EXPECT_NEAR(engine_right.position().z(), 1.7, 1e-6);
    EXPECT_NEAR(engine_left.position().x(), 3.864215, 1e-6);
    EXPECT_NEAR(engine_left.position().y(), -1.35785, 1e-6);
    EXPECT_NEAR(engine_left.position().z(), 1.7, 1e-6);
}

/**
 * @brief Test applying the user shift to both open-rotor wing engines, mirrored for the left engine.
 */
TEST_F(IntegrationRules, OpenRotorShiftAppliedAndMirrored)
{
    /* Set the shift of slot 0 to (0.1, 0.2, 0.3) and create the integrator for two wing engines */
    config->at("module_configuration_file/program_settings/repositioning/engine_shifts/engine/shift_x/value") = 0.1;
    config->at("module_configuration_file/program_settings/repositioning/engine_shifts/engine/shift_y/value") = 0.2;
    config->at("module_configuration_file/program_settings/repositioning/engine_shifts/engine/shift_z/value") = 0.3;
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right and the left open rotor under the wing */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine_right{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine_right.set_dimension({0.8, 0.8, 1.5});
    engine_right.set_fan({0.9});
    engine_right.set_nacelle(nacelle);
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine_left{1, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}};
    engine_left.set_dimension({0.8, 0.8, 1.5});
    engine_left.set_fan({0.9});
    engine_left.set_nacelle(nacelle);

    /* Integrate both engines */
    integrator(engine_right);
    integrator(engine_left);

    /* Check the positions: 0.1 m aft, 0.2 m up and 0.3 m outboard of (3.864215, +-1.35785, 1.7) */
    EXPECT_NEAR(engine_right.position().x(), 3.964215, 1e-6);
    EXPECT_NEAR(engine_right.position().y(), 1.65785, 1e-6);
    EXPECT_NEAR(engine_right.position().z(), 1.9, 1e-6);
    EXPECT_NEAR(engine_left.position().x(), 3.964215, 1e-6);
    EXPECT_NEAR(engine_left.position().y(), -1.65785, 1e-6);
    EXPECT_NEAR(engine_left.position().z(), 1.9, 1e-6);
}

/**
 * @brief Test integrating an open-rotor engine over the wing.
 */
TEST_F(IntegrationRules, OpenRotorOverWing)
{
    /* Create the integrator for two wing engines */
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right open rotor over the wing */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Over}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the position: s = 0.5 + 0.5 * 0.9 = 0.95, c = 1.81, x = 3 + 0.3 c, z = 2 + 0.65 * 0.9 */
    integrator(engine);
    EXPECT_NEAR(engine.position().x(), 3.543, 1e-6);
    EXPECT_NEAR(engine.position().y(), 0.95, 1e-6);
    EXPECT_NEAR(engine.position().z(), 2.585, 1e-6);
}

/**
 * @brief Test integrating an open-rotor engine in the wing.
 */
TEST_F(IntegrationRules, OpenRotorInWing)
{
    /* Create the integrator for two wing engines */
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right open rotor in the wing */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::In}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the position at the trailing edge: s = 0.5 + 0.5 * 1.089 = 1.0445, c = 1.7911 */
    integrator(engine);
    EXPECT_NEAR(engine.position().x(), 4.7911, 1e-6);
    EXPECT_NEAR(engine.position().y(), 1.0445, 1e-6);
    EXPECT_NEAR(engine.position().z(), 2.0, 1e-6);
}

/**
 * @brief Test integrating two open-rotor engines at the rear fuselage.
 */
TEST_F(IntegrationRules, OpenRotorFuselageMid)
{
    /* Create the integrator for two fuselage engines */
    design::integration::Default integrator{config, aircraft, {2, 0, 0}};

    /* Setup the right and the left open rotor at the rear fuselage */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine_right{0, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Mid}};
    engine_right.set_dimension({0.8, 0.8, 1.5});
    engine_right.set_fan({0.9});
    engine_right.set_nacelle(nacelle);
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine_left{1, {Parent::Fuselage, Lateral::Left, Longitudinal::Rear, Vertical::Mid}};
    engine_left.set_dimension({0.8, 0.8, 1.5});
    engine_left.set_fan({0.9});
    engine_left.set_nacelle(nacelle);

    /* Integrate both engines */
    integrator(engine_right);
    integrator(engine_left);

    /* Check the positions: 0.9 L = 1.8 along the fuselage, 0.2 w + w_nac = 1.2 to the side, 0.65 h = 0.65 up */
    EXPECT_NEAR(engine_right.position().x(), 1.8, 1e-6);
    EXPECT_NEAR(engine_right.position().y(), 1.2, 1e-6);
    EXPECT_NEAR(engine_right.position().z(), 0.65, 1e-6);
    EXPECT_NEAR(engine_left.position().x(), 1.8, 1e-6);
    EXPECT_NEAR(engine_left.position().y(), -1.2, 1e-6);
    EXPECT_NEAR(engine_left.position().z(), 0.65, 1e-6);
}

/**
 * @brief Test integrating an open-rotor engine on top of the fuselage.
 */
TEST_F(IntegrationRules, OpenRotorFuselageTop)
{
    /* Create the integrator for two fuselage engines */
    design::integration::Default integrator{config, aircraft, {2, 0, 0}};

    /* Setup the right open rotor on top of the rear fuselage */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Over}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the position: 0.9 L = 1.8 along the fuselage, 0.9 w_nac = 0.9 to the side, 1.1 h = 1.1 up */
    integrator(engine);
    EXPECT_NEAR(engine.position().x(), 1.8, 1e-6);
    EXPECT_NEAR(engine.position().y(), 0.9, 1e-6);
    EXPECT_NEAR(engine.position().z(), 1.1, 1e-6);
}

/**
 * @brief Test integrating an open-rotor engine in the vertical tail.
 */
TEST_F(IntegrationRules, OpenRotorEmpennage)
{
    /* Create the integrator for one empennage engine */
    design::integration::Default integrator{config, aircraft, {0, 0, 1}};

    /* Setup the open rotor in the empennage */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Empennage, Lateral::Mid, Longitudinal::Front, Vertical::In}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the position, the same as for the turbofan in the vertical tail */
    integrator(engine);
    EXPECT_NEAR(engine.position().x(), 1.264, 1e-3);
    EXPECT_NEAR(engine.position().y(), 0.0, 1e-3);
    EXPECT_NEAR(engine.position().z(), 1.0, 1e-3);
}

/**
 * @brief Test that an open-rotor engine over a wing that is not extruded along the y-axis is rejected.
 */
TEST_F(IntegrationRules, OpenRotorOverWingNotAlongYRejected)
{
    /* Turn the wing normal to +y while the wing extends to negative local z, and create the integrator for two wing engines */
    aircraft->wings.at(0).normal = geom2::Direction_3(0, 1, 0);
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right open rotor over the wing */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Over}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the error */
    try
    {
        integrator(engine);
        FAIL() << "Expected std::runtime_error for a wing not along the y-axis";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The wing is not oriented in y-direction."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that an open-rotor engine under a wing that is not extruded along the y-axis is rejected.
 */
TEST_F(IntegrationRules, OpenRotorUnderWingNotAlongYRejected)
{
    /* Turn the wing normal to +y while the wing extends to negative local z, and create the integrator for two wing engines */
    aircraft->wings.at(0).normal = geom2::Direction_3(0, 1, 0);
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right open rotor under the wing */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the error */
    try
    {
        integrator(engine);
        FAIL() << "Expected std::runtime_error for a wing not along the y-axis";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The wing is not oriented in y-direction."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that an open-rotor engine in a wing that is not extruded along the y-axis is rejected.
 */
TEST_F(IntegrationRules, OpenRotorInWingNotAlongYRejected)
{
    /* Turn the wing normal to +y while the wing extends to negative local z, and create the integrator for two wing engines */
    aircraft->wings.at(0).normal = geom2::Direction_3(0, 1, 0);
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right open rotor in the wing */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::In}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the error */
    try
    {
        integrator(engine);
        FAIL() << "Expected std::runtime_error for a wing not along the y-axis";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The wing is not oriented in y-direction."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that a second open-rotor engine over the wing on the same side is rejected for two wing engines.
 */
TEST_F(IntegrationRules, OpenRotorOverWingRejectsSecondEngineOnSameSide)
{
    /* Create the integrator for two wing engines */
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup two right open rotors over the wing */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine_0{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Over}};
    engine_0.set_dimension({0.8, 0.8, 1.5});
    engine_0.set_fan({0.9});
    engine_0.set_nacelle(nacelle);
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine_1{1, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Over}};
    engine_1.set_dimension({0.8, 0.8, 1.5});
    engine_1.set_fan({0.9});
    engine_1.set_nacelle(nacelle);

    /* Integrate both engines and check the error for the second one */
    integrator(engine_0);
    try
    {
        integrator(engine_1);
        FAIL() << "Expected std::runtime_error for a second engine on the same side";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("No space on the wing for the engine to be integrated."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that a second open-rotor engine under the wing on the same side is rejected for two wing engines.
 */
TEST_F(IntegrationRules, OpenRotorUnderWingRejectsSecondEngineOnSameSide)
{
    /* Create the integrator for two wing engines */
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup two right open rotors under the wing */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine_0{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine_0.set_dimension({0.8, 0.8, 1.5});
    engine_0.set_fan({0.9});
    engine_0.set_nacelle(nacelle);
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine_1{1, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine_1.set_dimension({0.8, 0.8, 1.5});
    engine_1.set_fan({0.9});
    engine_1.set_nacelle(nacelle);

    /* Integrate both engines and check the error for the second one */
    integrator(engine_0);
    try
    {
        integrator(engine_1);
        FAIL() << "Expected std::runtime_error for a second engine on the same side";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("No space on the wing for the engine to be integrated."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that an unsupported number of open-rotor engines over the wing is rejected.
 */
TEST_F(IntegrationRules, OpenRotorOverWingUnsupportedEngineCountRejected)
{
    /* Create the integrator for three wing engines */
    design::integration::Default integrator{config, aircraft, {0, 3, 0}};

    /* Setup the right open rotor over the wing */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Over}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the error */
    try
    {
        integrator(engine);
        FAIL() << "Expected std::runtime_error for three wing engines";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The number of engines on the wing is not supported."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that an unsupported number of open-rotor engines under the wing is rejected.
 */
TEST_F(IntegrationRules, OpenRotorUnderWingUnsupportedEngineCountRejected)
{
    /* Create the integrator for three wing engines */
    design::integration::Default integrator{config, aircraft, {0, 3, 0}};

    /* Setup the right open rotor under the wing */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the error */
    try
    {
        integrator(engine);
        FAIL() << "Expected std::runtime_error for three wing engines";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The number of engines on the wing is not supported."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that an open-rotor engine at the rear fuselage is rejected when the fuselage is not extruded along the x-axis.
 */
TEST_F(IntegrationRules, OpenRotorFuselageNotAlongXRejected)
{
    /* Turn the fuselage normal to the y-axis and create the integrator for two fuselage engines */
    aircraft->fuselages.at(0).normal = geom2::Direction_3(0, 1, 0);
    design::integration::Default integrator{config, aircraft, {2, 0, 0}};

    /* Setup the right open rotor at the rear fuselage */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Mid}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the error */
    try
    {
        integrator(engine);
        FAIL() << "Expected std::runtime_error for a fuselage not along the x-axis";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The fuselage is not oriented in x-direction."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that an open-rotor fuselage engine count other than two is rejected at the rear fuselage.
 */
TEST_F(IntegrationRules, OpenRotorFuselageEngineCountMustBeTwo)
{
    /* Create the integrator for three fuselage engines */
    design::integration::Default integrator{config, aircraft, {3, 0, 0}};

    /* Setup the right open rotor at the rear fuselage */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Mid}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the error */
    try
    {
        integrator(engine);
        FAIL() << "Expected std::runtime_error for three fuselage engines";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The number of engines on the fuselage is not supported."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that a second open-rotor engine on the same side is rejected at the rear fuselage.
 */
TEST_F(IntegrationRules, OpenRotorFuselageRejectsSecondEngineOnSameSide)
{
    /* Create the integrator for two fuselage engines */
    design::integration::Default integrator{config, aircraft, {2, 0, 0}};

    /* Setup two right open rotors at the rear fuselage */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine_0{0, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Mid}};
    engine_0.set_dimension({0.8, 0.8, 1.5});
    engine_0.set_fan({0.9});
    engine_0.set_nacelle(nacelle);
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine_1{1, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Mid}};
    engine_1.set_dimension({0.8, 0.8, 1.5});
    engine_1.set_fan({0.9});
    engine_1.set_nacelle(nacelle);

    /* Integrate both engines and check the error for the second one */
    integrator(engine_0);
    try
    {
        integrator(engine_1);
        FAIL() << "Expected std::runtime_error for a second engine on the same side";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("No space left on the fuselage for the engine to be integrated."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that an open-rotor engine on top of the rear fuselage is rejected when the fuselage is not extruded along the x-axis.
 */
TEST_F(IntegrationRules, OpenRotorFuselageTopNotAlongXRejected)
{
    /* Turn the fuselage normal to the y-axis and create the integrator for two fuselage engines */
    aircraft->fuselages.at(0).normal = geom2::Direction_3(0, 1, 0);
    design::integration::Default integrator{config, aircraft, {2, 0, 0}};

    /* Setup the right open rotor on top of the rear fuselage */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Over}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the error */
    try
    {
        integrator(engine);
        FAIL() << "Expected std::runtime_error for a fuselage not along the x-axis";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The fuselage is not oriented in x-direction."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that an open-rotor fuselage engine count other than two is rejected on top of the rear fuselage.
 */
TEST_F(IntegrationRules, OpenRotorFuselageTopEngineCountMustBeTwo)
{
    /* Create the integrator for three fuselage engines */
    design::integration::Default integrator{config, aircraft, {3, 0, 0}};

    /* Setup the right open rotor on top of the rear fuselage */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Over}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the error */
    try
    {
        integrator(engine);
        FAIL() << "Expected std::runtime_error for three fuselage engines";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The number of engines on the fuselage is not supported."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that a second open-rotor engine on the same side is rejected on top of the rear fuselage.
 */
TEST_F(IntegrationRules, OpenRotorFuselageTopRejectsSecondEngineOnSameSide)
{
    /* Create the integrator for two fuselage engines */
    design::integration::Default integrator{config, aircraft, {2, 0, 0}};

    /* Setup two right open rotors on top of the rear fuselage */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine_0{0, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Over}};
    engine_0.set_dimension({0.8, 0.8, 1.5});
    engine_0.set_fan({0.9});
    engine_0.set_nacelle(nacelle);
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine_1{1, {Parent::Fuselage, Lateral::Right, Longitudinal::Rear, Vertical::Over}};
    engine_1.set_dimension({0.8, 0.8, 1.5});
    engine_1.set_fan({0.9});
    engine_1.set_nacelle(nacelle);

    /* Integrate both engines and check the error for the second one */
    integrator(engine_0);
    try
    {
        integrator(engine_1);
        FAIL() << "Expected std::runtime_error for a second engine on the same side";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("No space left on the fuselage for the engine to be integrated."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that a second open-rotor engine in the empennage is rejected.
 */
TEST_F(IntegrationRules, OpenRotorEmpennageRejectsSecondEngine)
{
    /* Create the integrator for two empennage engines */
    design::integration::Default integrator{config, aircraft, {0, 0, 2}};

    /* Setup two open rotors in the empennage */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine_0{0, {Parent::Empennage, Lateral::Mid, Longitudinal::Front, Vertical::In}};
    engine_0.set_dimension({0.8, 0.8, 1.5});
    engine_0.set_fan({0.9});
    engine_0.set_nacelle(nacelle);
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine_1{1, {Parent::Empennage, Lateral::Mid, Longitudinal::Front, Vertical::In}};
    engine_1.set_dimension({0.8, 0.8, 1.5});
    engine_1.set_fan({0.9});
    engine_1.set_nacelle(nacelle);

    /* Integrate both engines and check the error for the second one */
    integrator(engine_0);
    try
    {
        integrator(engine_1);
        FAIL() << "Expected std::runtime_error for a second empennage engine";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("No space left on the empennage for the engine to be integrated."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that an open-rotor engine in a vertical tail that is not in line with the fuselage center is rejected.
 */
TEST_F(IntegrationRules, OpenRotorEmpennageOffCentreRejected)
{
    /* Move the vertical tail 0.5 m to the side and create the integrator for one empennage engine */
    aircraft->empennage.at(0).origin = geom2::Point_3(1.0, 0.5, 0.5);
    design::integration::Default integrator{config, aircraft, {0, 0, 1}};

    /* Setup the open rotor in the empennage */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Empennage, Lateral::Mid, Longitudinal::Front, Vertical::In}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the error */
    try
    {
        integrator(engine);
        FAIL() << "Expected std::runtime_error for a vertical tail off the fuselage center";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The empennage is not in line with the fuselage center."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test integrating the left open-rotor engine over the wing, mirrored to the left wing.
 */
TEST_F(IntegrationRules, OpenRotorOverWingLeftEngineMirrored)
{
    /* Create the integrator for two wing engines */
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the left open rotor over the wing */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{1, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Over}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the mirrored position of the right engine (3.543, 0.95, 2.585) */
    integrator(engine);
    EXPECT_NEAR(engine.position().x(), 3.543, 1e-6);
    EXPECT_NEAR(engine.position().y(), -0.95, 1e-6);
    EXPECT_NEAR(engine.position().z(), 2.585, 1e-6);
}

/**
 * @brief Test integrating the left open-rotor engine in the wing, mirrored to the left wing.
 */
TEST_F(IntegrationRules, OpenRotorInWingLeftEngineMirrored)
{
    /* Create the integrator for two wing engines */
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the left open rotor in the wing */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{1, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::In}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the mirrored position of the right engine (4.7911, 1.0445, 2.0) */
    integrator(engine);
    EXPECT_NEAR(engine.position().x(), 4.7911, 1e-6);
    EXPECT_NEAR(engine.position().y(), -1.0445, 1e-6);
    EXPECT_NEAR(engine.position().z(), 2.0, 1e-6);
}

/**
 * @brief Test integrating the left open-rotor engine on top of the fuselage, mirrored to the left side (candidate defect, O-28).
 */
TEST_F(IntegrationRules, OpenRotorFuselageTopLeftEngineMirrored)
{
    /* Create the integrator for two fuselage engines */
    design::integration::Default integrator{config, aircraft, {2, 0, 0}};

    /* Setup the left open rotor on top of the rear fuselage */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{1, {Parent::Fuselage, Lateral::Left, Longitudinal::Rear, Vertical::Over}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the mirrored position of the right engine (1.8, 0.9, 1.1) */
    integrator(engine);
    EXPECT_NEAR(engine.position().x(), 1.8, 1e-6);
    EXPECT_NEAR(engine.position().y(), -0.9, 1e-6);
    EXPECT_NEAR(engine.position().z(), 1.1, 1e-6);
}

/**
 * @brief Test integrating the inner and the outer right open-rotor engine of four engines under the wing.
 */
TEST_F(IntegrationRules, OpenRotorFourEnginesUnderWing)
{
    /* Create the integrator for four wing engines */
    design::integration::Default integrator{config, aircraft, {0, 4, 0}};

    /* Setup the right inner and the right outer open rotor under the wing */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine_inner{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine_inner.set_dimension({0.8, 0.8, 1.5});
    engine_inner.set_fan({0.9});
    engine_inner.set_nacelle(nacelle);
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine_outer{1, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine_outer.set_dimension({0.8, 0.8, 1.5});
    engine_outer.set_fan({0.9});
    engine_outer.set_nacelle(nacelle);

    /* Integrate both engines */
    integrator(engine_inner);
    integrator(engine_outer);

    /* Check the positions: inner s = 1.3 * 0.225 (0.64 * 5 + 1 - 1.089) = 0.9099675, outer s = 1.3 * 0.64 * 5 / 2 = 2.08, c = 2 - s / 5, x = 3 + 0.5 c, z = 2 - 0.3 */
    EXPECT_NEAR(engine_inner.position().x(), 3.90900325, 1e-6);
    EXPECT_NEAR(engine_inner.position().y(), 0.9099675, 1e-6);
    EXPECT_NEAR(engine_inner.position().z(), 1.7, 1e-6);
    EXPECT_NEAR(engine_outer.position().x(), 3.792, 1e-6);
    EXPECT_NEAR(engine_outer.position().y(), 2.08, 1e-6);
    EXPECT_NEAR(engine_outer.position().z(), 1.7, 1e-6);
}

/**
 * @brief Test integrating the inner and the outer right open-rotor engine of four engines over the wing.
 */
TEST_F(IntegrationRules, OpenRotorFourEnginesOverWing)
{
    /* Create the integrator for four wing engines */
    design::integration::Default integrator{config, aircraft, {0, 4, 0}};

    /* Setup the right inner and the right outer open rotor over the wing */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine_inner{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Over}};
    engine_inner.set_dimension({0.8, 0.8, 1.5});
    engine_inner.set_fan({0.9});
    engine_inner.set_nacelle(nacelle);
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine_outer{1, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Over}};
    engine_outer.set_dimension({0.8, 0.8, 1.5});
    engine_outer.set_fan({0.9});
    engine_outer.set_nacelle(nacelle);

    /* Integrate both engines */
    integrator(engine_inner);
    integrator(engine_outer);

    /* Check the positions: inner s = 0.225 (0.64 * 5 + 1 - 0.9) = 0.7425, outer s = 0.64 * 5 / 2 = 1.6, c = 2 - s / 5, x = 3 + 0.3 c, z = 2 + 0.65 * 0.9 */
    EXPECT_NEAR(engine_inner.position().x(), 3.55545, 1e-6);
    EXPECT_NEAR(engine_inner.position().y(), 0.7425, 1e-6);
    EXPECT_NEAR(engine_inner.position().z(), 2.585, 1e-6);
    EXPECT_NEAR(engine_outer.position().x(), 3.504, 1e-6);
    EXPECT_NEAR(engine_outer.position().y(), 1.6, 1e-6);
    EXPECT_NEAR(engine_outer.position().z(), 2.585, 1e-6);
}

/**
 * @brief Test integrating the inner and the outer right open-rotor engine of four engines in the wing.
 */
TEST_F(IntegrationRules, OpenRotorFourEnginesInWing)
{
    /* Create the integrator for four wing engines */
    design::integration::Default integrator{config, aircraft, {0, 4, 0}};

    /* Setup the right inner and the right outer open rotor in the wing */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine_inner{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::In}};
    engine_inner.set_dimension({0.8, 0.8, 1.5});
    engine_inner.set_fan({0.9});
    engine_inner.set_nacelle(nacelle);
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine_outer{1, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::In}};
    engine_outer.set_dimension({0.8, 0.8, 1.5});
    engine_outer.set_fan({0.9});
    engine_outer.set_nacelle(nacelle);

    /* Integrate both engines */
    integrator(engine_inner);
    integrator(engine_outer);

    /* Check the positions: inner s = 0.225 (0.64 * 5 + 1 - 1.089) = 0.699975, outer s = 0.64 * 5 / 2 = 1.6, c = 2 - s / 5, x = 3 + c, z = 2 */
    EXPECT_NEAR(engine_inner.position().x(), 4.860005, 1e-6);
    EXPECT_NEAR(engine_inner.position().y(), 0.699975, 1e-6);
    EXPECT_NEAR(engine_inner.position().z(), 2.0, 1e-6);
    EXPECT_NEAR(engine_outer.position().x(), 4.68, 1e-6);
    EXPECT_NEAR(engine_outer.position().y(), 1.6, 1e-6);
    EXPECT_NEAR(engine_outer.position().z(), 2.0, 1e-6);
}

/**
 * @brief Test integrating a liquid hydrogen turbofan engine under the wing like a kerosene turbofan engine.
 */
TEST_F(IntegrationRules, LiquidHydrogenTurbofanUnderWing)
{
    /* Create the integrator for two wing engines */
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right liquid hydrogen turbofan under the wing */
    Turbofan<EnergyCarrierFamily::Liquid_Hydrogen> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the position of the kerosene turbofan */
    integrator(engine);
    EXPECT_NEAR(engine.position().x(), 1.8032562, 1e-6);
    EXPECT_NEAR(engine.position().y(), 2.33719, 1e-6);
    EXPECT_NEAR(engine.position().z(), 1.3467438, 1e-6);
}

/**
 * @brief Test that a wing-body engine is rejected when the wing is not extruded along the y-axis.
 */
TEST_F(IntegrationRules, WingBodyWingNotAlongYRejected)
{
    /* Turn the wing normal to +y while the wing extends to negative local z, and create the integrator for two wing engines */
    aircraft->wings.at(0).normal = geom2::Direction_3(0, 1, 0);
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right wing-body engine */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::WingBody, Lateral::Right, Longitudinal::Rear, Vertical::Over}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the error */
    try
    {
        integrator(engine);
        FAIL() << "Expected std::runtime_error for a wing not along the y-axis";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("The wing is not oriented in y-direction."), std::string::npos) << error.what();
    }
}

/**
 * @brief Test integrating a single wing-body engine with the lateral position left on the center line.
 */
TEST_F(IntegrationRules, WingBodySingleLeftEngineOnCenterLine)
{
    /* Replace the shift entries by the zero shifts repositioning/shift_x, _y, _z that the integrator still reads (O-27) */
    node &repositioning = config->at("module_configuration_file/program_settings/repositioning");
    repositioning.deleteChild("engine_shifts");
    repositioning.appendChild("shift_x", true).appendChild("value", true) = 0.0;
    repositioning.appendChild("shift_y", true).appendChild("value", true) = 0.0;
    repositioning.appendChild("shift_z", true).appendChild("value", true) = 0.0;
    design::integration::Default integrator{config, aircraft, {0, 1, 0}};

    /* Setup the wing-body engine on the left */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::WingBody, Lateral::Left, Longitudinal::Rear, Vertical::Over}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the position of the right engine: c = 2, x = 3 + 0.7 c, z = 2 + 0.8 */
    integrator(engine);
    EXPECT_NEAR(engine.position().x(), 4.4, 1e-6);
    EXPECT_NEAR(engine.position().y(), 0.0, 1e-6);
    EXPECT_NEAR(engine.position().z(), 2.8, 1e-6);
}

/**
 * @brief Test placing two wing-body engines at the default span position when they do not fit at the wing kink.
 */
TEST_F(IntegrationRules, WingBodyKinkWithoutClearanceFallsBackToDefaultSpan)
{
    /* Kinked wing: chord 2 m at the root, 1.54 m at the kink at local z = -2.3 and 1 m at z = -5 with the leading edge 0.6 m aft */
    geom2::MultisectionSurface<geom2::AirfoilSection> kinked_wing;
    kinked_wing.sections.emplace_back(airfoil);
    kinked_wing.sections.emplace_back(airfoil);
    kinked_wing.sections.emplace_back(airfoil);
    kinked_wing.sections.at(0).set_chord_length(2.0);
    kinked_wing.sections.at(1).set_chord_length(1.54);
    kinked_wing.sections.at(1).origin = geom2::Point_3(0, 0, -2.3);
    kinked_wing.sections.at(2).set_chord_length(1.0);
    kinked_wing.sections.at(2).origin = geom2::Point_3(0.6, 0, -5.0);
    kinked_wing.origin = geom2::Point_3(3, 0, 2);
    kinked_wing.normal = geom2::Direction_3(0, -1, 0);
    aircraft->wings.at(0) = kinked_wing;

    /* Create the integrator for two wing engines with the kink placement of the configuration (enabled) */
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right and the left wing-body engine */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_right{0, {Parent::WingBody, Lateral::Right, Longitudinal::Rear, Vertical::Over}};
    engine_right.set_dimension({0.8, 0.8, 1.5});
    engine_right.set_fan({0.9});
    engine_right.set_nacelle(nacelle);
    Turbofan<EnergyCarrierFamily::Kerosene> engine_left{1, {Parent::WingBody, Lateral::Left, Longitudinal::Rear, Vertical::Over}};
    engine_left.set_dimension({0.8, 0.8, 1.5});
    engine_left.set_fan({0.9});
    engine_left.set_nacelle(nacelle);

    /* Integrate both engines: 2.3 + 1.089 / 2 = 2.8445 exceeds the window limit span / 2 = 2.5, so the default s = 0.8 * 1.089 = 0.8712 is used */
    integrator(engine_right);
    integrator(engine_left);

    /* Check both engines at the default span on their own side: x_LE = 0, c = 2 - 0.2 s = 1.82576, x = 3 + 0.7 c, z = 2 + 0.8 */
    EXPECT_NEAR(engine_right.position().x(), 4.278032, 1e-6);
    EXPECT_NEAR(engine_right.position().y(), 0.8712, 1e-6);
    EXPECT_NEAR(engine_right.position().z(), 2.8, 1e-6);
    EXPECT_NEAR(engine_left.position().x(), 4.278032, 1e-6);
    EXPECT_NEAR(engine_left.position().y(), -0.8712, 1e-6);
    EXPECT_NEAR(engine_left.position().z(), 2.8, 1e-6);
}

/**
 * @brief Test placing a wing engine at the default span position when the wing has three sections but no kink.
 */
TEST_F(IntegrationRules, WingWithoutKinkUsesDefaultSpan)
{
    /* Straight wing with three sections: chord 2 m at the root, 1.7 m at local z = -1.5 and 1 m at z = -5, leading edge along local z */
    geom2::MultisectionSurface<geom2::AirfoilSection> straight_wing;
    straight_wing.sections.emplace_back(airfoil);
    straight_wing.sections.emplace_back(airfoil);
    straight_wing.sections.emplace_back(airfoil);
    straight_wing.sections.at(0).set_chord_length(2.0);
    straight_wing.sections.at(1).set_chord_length(1.7);
    straight_wing.sections.at(1).origin = geom2::Point_3(0, 0, -1.5);
    straight_wing.sections.at(2).set_chord_length(1.0);
    straight_wing.sections.at(2).origin = geom2::Point_3(0, 0, -5.0);
    straight_wing.origin = geom2::Point_3(3, 0, 2);
    straight_wing.normal = geom2::Direction_3(0, -1, 0);
    straight_wing.name = "front_wing";
    aircraft->wings.at(0) = straight_wing;

    /* Create the integrator for two wing engines with the kink placement of the configuration (enabled) */
    design::integration::Default integrator{config, aircraft, {0, 2, 0}};

    /* Setup the right engine under the wing */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}};
    engine.set_dimension({0.8, 0.8, 1.5});
    engine.set_fan({0.9});
    engine.set_nacelle(nacelle);

    /* Integrate the engine and check the default position of the two-section wing: s = 2.33719, c = 1.532562 */
    integrator(engine);
    EXPECT_NEAR(engine.position().x(), 1.8032562, 1e-6);
    EXPECT_NEAR(engine.position().y(), 2.33719, 1e-6);
    EXPECT_NEAR(engine.position().z(), 1.3467438, 1e-6);
}

/**
 * @brief Test that a shift entry without a slot ID is rejected.
 */
TEST_F(IntegrationRules, ShiftEntryWithoutIdRejected)
{
    /* Remove the slot ID of the shift entry */
    config->at("module_configuration_file/program_settings/repositioning/engine_shifts/engine").deleteChild("id");

    /* Create the integrator and check the error */
    try
    {
        design::integration::Default integrator{config, aircraft, {0, 2, 0}};
        FAIL() << "Expected std::runtime_error for a shift entry without slot ID";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("Failed to read id/value from engine shift entry"), std::string::npos) << error.what();
    }
}

/**
 * @brief Test the current behaviour that the integrator without engines rejects the shift entry of slot 0.
 */
TEST_F(IntegrationRules, NoEnginesRejectShiftEntry)
{
    /* Create the integrator without engines and check the error */
    try
    {
        design::integration::Default integrator{config, aircraft, {0, 0, 0}};
        FAIL() << "Expected std::runtime_error for the shift entry of slot 0 without engines";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("engine slot ID '0' is out of range."), std::string::npos) << error.what();
    }
}
