/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 *
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <aixml/node.h>
#include <algorithm>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <gtest/gtest.h>
#include <iomanip>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include "../temp_directory.h"

/* Unit Under Test */
#include "engine_design/engine_design.h"
#include "engine_design/rubber/rubber_design.h"

/* === Fixtures === */
/**
 * @brief Provides an engine designer and a small 2 x 2 x 2 deck.
 * The designer only stores its constructor arguments, so no configuration or files are needed.
 */
class ScaleDeckDataValues : public ::testing::Test
{
  protected:
    void SetUp() override
    {
        deck.name = "test_deck";
        deck.N = {0.8, 1.0};
        deck.FL = {0.0, 10000.0};
        deck.Mach = {0.0, 0.8};
        deck.values.resize(boost::extents[2][2][2]);
        deck.values[0][0][0] = 100.0;
        deck.values[0][0][1] = 200.0;
        deck.values[0][1][0] = -9999.0;
        deck.values[0][1][1] = 50.0;
        deck.values[1][0][0] = 0.0;
        deck.values[1][0][1] = -9999.0;
        deck.values[1][1][0] = 1.5;
        deck.values[1][1][1] = 400.0;
    }

    design::EngineDesigner designer{nullptr, {}, {}};
    DeckData deck;
};

/**
 * @brief Temporary project engine directory and engine database with consistent copies of the test engine.
 *
 * Every engine copy is a "previously adjusted" dataset: its XML stores a factor f_old and its
 * WF deck is the base deck of the stub engine times (2 - f_old). For a configured factor f the
 * requirement is that the adjusted deck equals base * (2 - f), whatever f_old was, and the
 * engine XML stores f.
 *
 * Rubber implements this as a ratio on the current deck (current * (2 - f) / (2 - f_old)) and,
 * in both initialize() and save(), takes the deck file name from the first engine_model entry
 * of the configuration (the Default one).
 */
class RubberEfficiencyFactor : public ::testing::Test
{
  protected:
    void SetUp() override
    {
        base_deck.emplace(DeckData::from_csv(STUB_ENGINE / "test-engine_WF.csv"));
        project = temp.path() / "project";
        database = temp.path() / "database";
        std::filesystem::create_directories(project);
        std::filesystem::create_directories(database);

        config = aixml::openDocument(std::filesystem::path{CMAKE_TEST_CONFIG_FILE});
        config->at("module_configuration_file/program_settings/propulsion@Default/Rubber/engine_model/value") = std::string{MODEL_A};
        config->at("module_configuration_file/program_settings/path_engine_database/value") = database.string();
    }

    /*
     * Create <directory>/<model> with the stub XML storing f_old and the deck base * (2 - f_old).
     * Contains fatal assertions: call it as ASSERT_NO_FATAL_FAILURE(make_engine(...)).
     */
    void make_engine(const std::filesystem::path &directory, const std::string &model, const double f_old) const
    {
        const std::filesystem::path engine_dir = directory / model;
        std::filesystem::create_directories(engine_dir);
        std::filesystem::copy_file(STUB_ENGINE / "test-engine.xml", engine_dir / (model + ".xml"));
        auto engine_xml = aixml::openDocument(engine_dir / (model + ".xml"));
        engine_xml->at("EngineDataFile").appendChild("EngineTechnologyFactor", true) = f_old;
        ASSERT_TRUE(aixml::saveDocument(*engine_xml));
        ASSERT_NO_FATAL_FAILURE(write_deck(engine_dir / (model + "_WF.csv"), 2.0 - f_old));
    }

    /* Add a marker node to the engine XML; it disappears if the engine is copied over again */
    static void add_marker(const std::filesystem::path &directory, const std::string &model)
    {
        auto engine_xml = aixml::openDocument(directory / model / (model + ".xml"));
        engine_xml->at("EngineDataFile").appendChild("TestMarker", true) = std::string{"project copy"};
        ASSERT_TRUE(aixml::saveDocument(*engine_xml));
    }

    [[nodiscard]] static auto has_marker(const std::filesystem::path &directory, const std::string &model) -> bool
    {
        auto engine_xml = aixml::openDocument(directory / model / (model + ".xml"));
        return engine_xml->find("EngineDataFile/TestMarker") != nullptr;
    }

    [[nodiscard]] static auto read_text(const std::filesystem::path &file) -> std::string
    {
        std::ifstream stream(file);
        std::stringstream content;
        content << stream.rdbuf();
        return content.str();
    }

    /* Write base deck * factor (-9999 kept) in the deck CSV format, with full precision */
    void write_deck(const std::filesystem::path &file_name, const double factor) const
    {
        std::ofstream file(file_name, std::ios::out | std::ios::trunc);
        ASSERT_TRUE(file.is_open());
        file << std::setprecision(17);
        const DeckData &deck = *base_deck;
        for (std::size_t n = 0; n < deck.N.size(); ++n)
        {
            file << deck.N[n] << ';';
            for (const double mach : deck.Mach)
                file << mach << ';';
            file << '\n';
            for (std::size_t fl = 0; fl < deck.FL.size(); ++fl)
            {
                file << deck.FL[fl] << ';';
                for (std::size_t m = 0; m < deck.Mach.size(); ++m)
                {
                    const double value = deck.values[n][fl][m];
                    file << (value == -9999.0 ? -9999.0 : factor * value) << ';';
                }
                file << '\n';
            }
        }
        file.close();
        ASSERT_FALSE(file.fail());
    }

    void set_configured_factor(const double factor)
    {
        config->at("module_configuration_file/program_settings/technology_factors/engine_efficiency/value") = factor;
    }

    /* Add a propulsion entry with its own engine model for the given propulsor ID */
    void add_model_override(const std::string &id, const std::string &model)
    {
        node &propulsion = config->at("module_configuration_file/program_settings").appendChild("propulsion", true);
        propulsion.setAttrib("ID", id);
        propulsion.appendChild("engine", true).appendChild("Rubber", true).appendChild("engine_model", true).appendChild("value", true) = model;
    }

    [[nodiscard]] static auto stored_factor(const std::filesystem::path &directory, const std::string &model) -> double
    {
        auto engine_xml = aixml::openDocument(directory / model / (model + ".xml"));
        return engine_xml->at("EngineDataFile/EngineTechnologyFactor");
    }

    /*
     * Expect <directory>/<model>/<model>_WF.csv to be base deck * factor, -9999 unchanged.
     * Contains a fatal assertion: call it as ASSERT_NO_FATAL_FAILURE(expect_deck(...)).
     */
    void expect_deck(const std::filesystem::path &directory, const std::string &model, const double factor) const
    {
        const DeckData written = DeckData::from_csv(directory / model / (model + "_WF.csv"));
        const DeckData &base = *base_deck;
        ASSERT_EQ(written.values.num_elements(), base.values.num_elements());
        EXPECT_EQ(written.N, base.N);
        EXPECT_EQ(written.FL, base.FL);
        EXPECT_EQ(written.Mach, base.Mach);
        const auto *in = base.values.data();
        const auto *out = written.values.data();
        std::size_t mismatches = 0;
        for (std::size_t i = 0; i < base.values.num_elements(); ++i)
        {
            const double expected = in[i] == -9999.0 ? -9999.0 : factor * in[i];
            /* Rubber writes 6 significant digits and reads the configured factor as float */
            if (std::abs(out[i] - expected) > 1e-5 * std::max(1.0, std::abs(expected)))
            {
                ++mismatches;
            }
        }
        EXPECT_EQ(mismatches, 0U);
    }

    static constexpr const char *MODEL_A = "test-engine";   /**< Default engine model of the configuration. */
    static constexpr const char *MODEL_B = "test-engine-b"; /**< Engine model of a per-engine override. */
    const std::filesystem::path STUB_ENGINE = std::filesystem::path{CMAKE_TEST_STUBS_DIR} / "engines" / "test-engine";
    const UniqueTempDirectory temp{"test_rubber_efficiency_factor"};
    std::filesystem::path project;
    std::filesystem::path database;
    std::optional<DeckData> base_deck; /* Constructed in place: multi_array copy-assignment requires equal shapes */
    std::shared_ptr<node> config;
};

/* === Tests === */
/**
 * @brief Test scaling the deck values with an efficiency factor above one.
 */
TEST_F(ScaleDeckDataValues, FactorAboveOneReducesValues)
{
    const DeckData result = designer.scale_deck_data_values(deck, 1.1);

    EXPECT_NEAR(result.values[0][0][0], 90.0, 1e-9);
    EXPECT_NEAR(result.values[0][0][1], 180.0, 1e-9);
    EXPECT_EQ(result.values[0][1][0], -9999.0);
    EXPECT_NEAR(result.values[0][1][1], 45.0, 1e-9);
    EXPECT_NEAR(result.values[1][0][0], 0.0, 1e-9);
    EXPECT_EQ(result.values[1][0][1], -9999.0);
    EXPECT_NEAR(result.values[1][1][0], 1.35, 1e-9);
    EXPECT_NEAR(result.values[1][1][1], 360.0, 1e-9);
}

/**
 * @brief Test scaling the deck values with an efficiency factor of one.
 */
TEST_F(ScaleDeckDataValues, FactorOneLeavesValuesUnchanged)
{
    const DeckData result = designer.scale_deck_data_values(deck, 1.0);

    EXPECT_NEAR(result.values[0][0][0], 100.0, 1e-9);
    EXPECT_NEAR(result.values[0][0][1], 200.0, 1e-9);
    EXPECT_EQ(result.values[0][1][0], -9999.0);
    EXPECT_NEAR(result.values[0][1][1], 50.0, 1e-9);
    EXPECT_NEAR(result.values[1][0][0], 0.0, 1e-9);
    EXPECT_EQ(result.values[1][0][1], -9999.0);
    EXPECT_NEAR(result.values[1][1][0], 1.5, 1e-9);
    EXPECT_NEAR(result.values[1][1][1], 400.0, 1e-9);
}

/**
 * @brief Test scaling the deck values with an efficiency factor below one.
 */
TEST_F(ScaleDeckDataValues, FactorBelowOneIncreasesValues)
{
    const DeckData result = designer.scale_deck_data_values(deck, 0.9);

    EXPECT_NEAR(result.values[0][0][0], 110.0, 1e-9);
    EXPECT_NEAR(result.values[0][0][1], 220.0, 1e-9);
    EXPECT_EQ(result.values[0][1][0], -9999.0);
    EXPECT_NEAR(result.values[0][1][1], 55.0, 1e-9);
    EXPECT_NEAR(result.values[1][0][0], 0.0, 1e-9);
    EXPECT_EQ(result.values[1][0][1], -9999.0);
    EXPECT_NEAR(result.values[1][1][0], 1.65, 1e-9);
    EXPECT_NEAR(result.values[1][1][1], 440.0, 1e-9);
}

/**
 * @brief Test that the -9999 placeholders are never scaled.
 */
TEST_F(ScaleDeckDataValues, PlaceholderNeverScaled)
{
    /* Efficiency factor 0.5 */
    DeckData deck_a = deck;
    const DeckData result_a = designer.scale_deck_data_values(deck_a, 0.5);
    EXPECT_EQ(result_a.values[0][1][0], -9999.0);
    EXPECT_EQ(result_a.values[1][0][1], -9999.0);

    /* Efficiency factor 0.9 */
    DeckData deck_b = deck;
    const DeckData result_b = designer.scale_deck_data_values(deck_b, 0.9);
    EXPECT_EQ(result_b.values[0][1][0], -9999.0);
    EXPECT_EQ(result_b.values[1][0][1], -9999.0);

    /* Efficiency factor 1.0 */
    DeckData deck_c = deck;
    const DeckData result_c = designer.scale_deck_data_values(deck_c, 1.0);
    EXPECT_EQ(result_c.values[0][1][0], -9999.0);
    EXPECT_EQ(result_c.values[1][0][1], -9999.0);

    /* Efficiency factor 1.1 */
    DeckData deck_d = deck;
    const DeckData result_d = designer.scale_deck_data_values(deck_d, 1.1);
    EXPECT_EQ(result_d.values[0][1][0], -9999.0);
    EXPECT_EQ(result_d.values[1][0][1], -9999.0);

    /* Efficiency factor 1.5 */
    DeckData deck_e = deck;
    const DeckData result_e = designer.scale_deck_data_values(deck_e, 1.5);
    EXPECT_EQ(result_e.values[0][1][0], -9999.0);
    EXPECT_EQ(result_e.values[1][0][1], -9999.0);
}

/**
 * @brief Test that scaling modifies the input deck in place.
 */
TEST_F(ScaleDeckDataValues, ModifiesInputInPlace)
{
    const DeckData result = designer.scale_deck_data_values(deck, 1.1);

    EXPECT_NEAR(deck.values[0][0][0], 90.0, 1e-9);
    EXPECT_NEAR(deck.values[0][0][1], 180.0, 1e-9);
    EXPECT_EQ(deck.values[0][1][0], -9999.0);
    EXPECT_NEAR(deck.values[0][1][1], 45.0, 1e-9);
    EXPECT_NEAR(deck.values[1][0][0], 0.0, 1e-9);
    EXPECT_EQ(deck.values[1][0][1], -9999.0);
    EXPECT_NEAR(deck.values[1][1][0], 1.35, 1e-9);
    EXPECT_NEAR(deck.values[1][1][1], 360.0, 1e-9);
    EXPECT_TRUE(deck.values == result.values);
}

/**
 * @brief Test that scaling keeps the name and the breakpoints of the deck.
 */
TEST_F(ScaleDeckDataValues, MetadataUnchanged)
{
    const DeckData result = designer.scale_deck_data_values(deck, 1.1);

    EXPECT_EQ(result.name, "test_deck");
    EXPECT_EQ(result.N, (std::vector<double>{0.8, 1.0}));
    EXPECT_EQ(result.FL, (std::vector<double>{0.0, 10000.0}));
    EXPECT_EQ(result.Mach, (std::vector<double>{0.0, 0.8}));
    ASSERT_EQ(result.values.shape()[0], 2U);
    ASSERT_EQ(result.values.shape()[1], 2U);
    ASSERT_EQ(result.values.shape()[2], 2U);
}

/**
 * @brief Test scaling an empty deck.
 */
TEST_F(ScaleDeckDataValues, EmptyDeck)
{
    DeckData empty{};

    const DeckData result = designer.scale_deck_data_values(empty, 1.1);

    EXPECT_EQ(result.values.num_elements(), 0U);
}

/**
 * @brief Test scaling a deck read from a deck file.
 */
TEST(ScaleDeckDataValuesDeckFile, ScalesEveryValueOfDeckFile)
{
    /* Read the fuel-flow deck of the test engine */
    std::filesystem::path deck_file{std::filesystem::path{CMAKE_TEST_STUBS_DIR} / "engines" / "test-engine" / "test-engine_WF.csv"};
    const DeckData original = DeckData::from_csv(deck_file);
    DeckData deck = DeckData::from_csv(deck_file);
    design::EngineDesigner designer{nullptr, {}, {}};

    const DeckData result = designer.scale_deck_data_values(deck, 1.1);

    ASSERT_GT(original.values.num_elements(), 0U);
    std::size_t placeholders = 0;
    std::size_t scaled = 0;
    const auto *in = original.values.data();
    const auto *out = result.values.data();
    for (std::size_t i = 0; i < original.values.num_elements(); ++i)
    {
        if (in[i] == -9999.0)
        {
            EXPECT_EQ(out[i], -9999.0);
            ++placeholders;
        }
        else
        {
            EXPECT_NEAR(out[i], 0.9 * in[i], 1e-12 * std::max(1.0, std::abs(in[i])));
            ++scaled;
        }
    }
    /* The file contains both real values and placeholders, so both branches were exercised */
    EXPECT_GT(placeholders, 0U);
    EXPECT_GT(scaled, 0U);
}

/**
 * @brief Test writing a scaled deck and reading it back.
 */
TEST(ScaleDeckDataValuesDeckFile, WriteAndReadBackScaledDeck)
{
    const UniqueTempDirectory temp{"test_scale_deck_round_trip"};
    const std::filesystem::path &engine_directory = temp.path();
    std::filesystem::create_directories(engine_directory / "test-engine");

    std::filesystem::path deck_file{std::filesystem::path{CMAKE_TEST_STUBS_DIR} / "engines" / "test-engine" / "test-engine_WF.csv"};
    DeckData deck = DeckData::from_csv(deck_file);
    design::EngineDesigner designer{nullptr, engine_directory, {}};
    const DeckData scaled = designer.scale_deck_data_values(deck, 1.1);
    designer.write_deck_value(scaled, "test-engine");

    /* The deck keeps the name of the file it was read from, so the original WF file is overwritten */
    EXPECT_EQ(scaled.name, "test-engine_WF");
    const std::filesystem::path written = engine_directory / "test-engine" / "test-engine_WF.csv";
    ASSERT_TRUE(std::filesystem::exists(written));
    const DeckData read_back = DeckData::from_csv(written);

    EXPECT_EQ(read_back.N, scaled.N);
    EXPECT_EQ(read_back.FL, scaled.FL);
    EXPECT_EQ(read_back.Mach, scaled.Mach);
    ASSERT_EQ(read_back.values.num_elements(), scaled.values.num_elements());
    const auto *expected = scaled.values.data();
    const auto *actual = read_back.values.data();
    for (std::size_t i = 0; i < scaled.values.num_elements(); ++i)
    {
        /* The file is written with the default stream precision (6 significant digits) */
        EXPECT_NEAR(actual[i], expected[i], 1e-5 * std::max(1.0, std::abs(expected[i])));
    }
}

/**
 * @brief Test re-adjusting a previously adjusted engine during initialization.
 */
TEST_F(RubberEfficiencyFactor, InitializeReadjustsPreviouslyAdjustedEngine)
{
    ASSERT_NO_FATAL_FAILURE(make_engine(project, MODEL_A, 1.05));
    set_configured_factor(1.1);
    design::Rubber designer{config, project, {}};

    designer.initialize();

    ASSERT_NO_FATAL_FAILURE(expect_deck(project, MODEL_A, 2.0 - 1.1));
    EXPECT_NEAR(stored_factor(project, MODEL_A), 1.1, 1e-6);
    /* The designer keeps the ratio factor 2 - (2 - f) / (2 - f_old) */
    EXPECT_NEAR(designer.technology_factor("engine_efficiency"), 2.0 - 0.9 / 0.95, 1e-6);
}

/**
 * @brief Test initializing with the factor already stored in the engine.
 */
TEST_F(RubberEfficiencyFactor, InitializeSameFactorLeavesEngineUnchanged)
{
    ASSERT_NO_FATAL_FAILURE(make_engine(project, MODEL_A, 1.05));
    set_configured_factor(1.05);
    design::Rubber designer{config, project, {}};

    designer.initialize();

    ASSERT_NO_FATAL_FAILURE(expect_deck(project, MODEL_A, 2.0 - 1.05));
    EXPECT_NEAR(stored_factor(project, MODEL_A), 1.05, 1e-6);
}

/**
 * @brief Test that initializing twice scales the deck once.
 */
TEST_F(RubberEfficiencyFactor, InitializeTwiceScalesOnce)
{
    ASSERT_NO_FATAL_FAILURE(make_engine(project, MODEL_A, 1.05));
    set_configured_factor(1.1);
    design::Rubber{config, project, {}}.initialize();

    design::Rubber{config, project, {}}.initialize();

    ASSERT_NO_FATAL_FAILURE(expect_deck(project, MODEL_A, 2.0 - 1.1));
    EXPECT_NEAR(stored_factor(project, MODEL_A), 1.1, 1e-6);
}

/**
 * @brief Test that initializing does not change the engine database.
 */
TEST_F(RubberEfficiencyFactor, InitializeDoesNotTouchDatabase)
{
    ASSERT_NO_FATAL_FAILURE(make_engine(database, MODEL_A, 1.0));
    set_configured_factor(1.1);
    design::Rubber designer{config, project, {}};

    designer.initialize();

    ASSERT_NO_FATAL_FAILURE(expect_deck(database, MODEL_A, 1.0));
    EXPECT_NEAR(stored_factor(database, MODEL_A), 1.0, 1e-6);
    EXPECT_FALSE(std::filesystem::exists(project / MODEL_A));
}

/**
 * @brief Test that saving copies a new engine into the project and adjusts the copy.
 */
TEST_F(RubberEfficiencyFactor, SaveCopiesAndAdjustsNewEngine)
{
    ASSERT_NO_FATAL_FAILURE(make_engine(database, MODEL_A, 1.0));
    set_configured_factor(1.1);
    design::Rubber designer{config, project, {}};
    designer.initialize();
    designer.add_designed_engine(MODEL_A);

    designer.save();

    ASSERT_TRUE(std::filesystem::exists(project / MODEL_A / (std::string{MODEL_A} + ".xml")));
    ASSERT_NO_FATAL_FAILURE(expect_deck(project, MODEL_A, 2.0 - 1.1));
    EXPECT_NEAR(stored_factor(project, MODEL_A), 1.1, 1e-6);
    ASSERT_NO_FATAL_FAILURE(expect_deck(database, MODEL_A, 1.0));
    EXPECT_NEAR(stored_factor(database, MODEL_A), 1.0, 1e-6);
}

/**
 * @brief Test saving with the neutral efficiency factor.
 */
TEST_F(RubberEfficiencyFactor, SaveWithNeutralFactorCopiesUnchanged)
{
    ASSERT_NO_FATAL_FAILURE(make_engine(database, MODEL_A, 1.0));
    set_configured_factor(1.0);
    design::Rubber designer{config, project, {}};
    designer.initialize();
    designer.add_designed_engine(MODEL_A);

    designer.save();

    ASSERT_NO_FATAL_FAILURE(expect_deck(project, MODEL_A, 1.0));
    EXPECT_NEAR(stored_factor(project, MODEL_A), 1.0, 1e-6);
}

/**
 * @brief Test that saving keeps an engine that is already in the project.
 */
TEST_F(RubberEfficiencyFactor, SaveSkipsEngineAlreadyInProject)
{
    ASSERT_NO_FATAL_FAILURE(make_engine(database, MODEL_A, 1.0));
    ASSERT_NO_FATAL_FAILURE(make_engine(project, MODEL_A, 1.1));
    ASSERT_NO_FATAL_FAILURE(add_marker(project, MODEL_A));
    set_configured_factor(1.1);
    design::Rubber designer{config, project, {}};
    designer.initialize();
    designer.add_designed_engine(MODEL_A);

    designer.save();

    EXPECT_TRUE(has_marker(project, MODEL_A));
    ASSERT_NO_FATAL_FAILURE(expect_deck(project, MODEL_A, 2.0 - 1.1));
    EXPECT_NEAR(stored_factor(project, MODEL_A), 1.1, 1e-6);
}

/**
 * @brief Test initializing with a factor within the adjustment threshold.
 */
TEST_F(RubberEfficiencyFactor, InitializeFactorWithinThresholdNotAdjusted)
{
    ASSERT_NO_FATAL_FAILURE(make_engine(project, MODEL_A, 1.05));
    const std::filesystem::path deck_file = project / MODEL_A / (std::string{MODEL_A} + "_WF.csv");
    const std::string deck_before = read_text(deck_file);
    set_configured_factor(1.05 + 4e-7);
    design::Rubber designer{config, project, {}};

    designer.initialize();

    EXPECT_EQ(read_text(deck_file), deck_before);
    EXPECT_EQ(stored_factor(project, MODEL_A), 1.05);
}

/**
 * @brief Test initializing with a factor outside the adjustment threshold.
 */
TEST_F(RubberEfficiencyFactor, InitializeFactorOutsideThresholdAdjusted)
{
    ASSERT_NO_FATAL_FAILURE(make_engine(project, MODEL_A, 1.05));
    const std::filesystem::path deck_file = project / MODEL_A / (std::string{MODEL_A} + "_WF.csv");
    const std::string deck_before = read_text(deck_file);
    constexpr double f = 1.05 + 4e-6;
    set_configured_factor(f);
    design::Rubber designer{config, project, {}};

    designer.initialize();

    /* The deck values change by only 4e-6 relative, but Rubber rewrites the file in its own format */
    EXPECT_NE(read_text(deck_file), deck_before);
    ASSERT_NO_FATAL_FAILURE(expect_deck(project, MODEL_A, 2.0 - f));
    EXPECT_NEAR(stored_factor(project, MODEL_A), f, 2e-7); /* float resolution near 1.05 is 1.2e-7 */
    EXPECT_GT(std::abs(stored_factor(project, MODEL_A) - 1.05), 2e-6);
}

/**
 * @brief Test that initializing adjusts the default and the overridden engine model once.
 */
TEST_F(RubberEfficiencyFactor, InitializeAdjustsEachOverriddenModelOnce)
{
    ASSERT_NO_FATAL_FAILURE(make_engine(project, MODEL_A, 1.05));
    ASSERT_NO_FATAL_FAILURE(make_engine(project, MODEL_B, 1.05));
    add_model_override("1", MODEL_B);
    set_configured_factor(1.1);
    design::Rubber designer{config, project, {}};

    designer.initialize();

    ASSERT_NO_FATAL_FAILURE(expect_deck(project, MODEL_A, 2.0 - 1.1));
    ASSERT_NO_FATAL_FAILURE(expect_deck(project, MODEL_B, 2.0 - 1.1));
    EXPECT_NEAR(stored_factor(project, MODEL_A), 1.1, 1e-6);
    EXPECT_NEAR(stored_factor(project, MODEL_B), 1.1, 1e-6);
}

/**
 * @brief Test that saving adjusts the copied overridden engine model.
 */
TEST_F(RubberEfficiencyFactor, SaveAdjustsCopiedOverrideModel)
{
    ASSERT_NO_FATAL_FAILURE(make_engine(database, MODEL_A, 1.0));
    ASSERT_NO_FATAL_FAILURE(make_engine(database, MODEL_B, 1.0));
    add_model_override("1", MODEL_B);
    set_configured_factor(1.1);
    design::Rubber designer{config, project, {}};
    designer.initialize();
    designer.add_designed_engine(MODEL_B);

    ASSERT_NO_THROW(designer.save());

    ASSERT_TRUE(std::filesystem::exists(project / MODEL_B / (std::string{MODEL_B} + ".xml")));
    ASSERT_NO_FATAL_FAILURE(expect_deck(project, MODEL_B, 2.0 - 1.1));
    EXPECT_NEAR(stored_factor(project, MODEL_B), 1.1, 1e-6);
}

/**
 * @brief Test generating an empty deck with the given grids, filled with the placeholder -9999.
 */
TEST(GenerateEmptyDeckData, GridsFilledWithPlaceholder)
{
    design::EngineDesigner designer{nullptr, {}, {}};

    const DeckData deck = designer.generate_empty_deck_data("empty_deck", {0.0, 5000.0}, {0.0, 0.4, 0.8}, {0.6, 0.8, 1.0, 1.1});

    EXPECT_EQ(deck.name, "empty_deck");
    EXPECT_EQ(deck.FL, (std::vector<double>{0.0, 5000.0}));
    EXPECT_EQ(deck.Mach, (std::vector<double>{0.0, 0.4, 0.8}));
    EXPECT_EQ(deck.N, (std::vector<double>{0.6, 0.8, 1.0, 1.1}));
    ASSERT_EQ(deck.values.shape()[0], 4U);
    ASSERT_EQ(deck.values.shape()[1], 2U);
    ASSERT_EQ(deck.values.shape()[2], 3U);
    const auto *values = deck.values.data();
    for (std::size_t i = 0; i < deck.values.num_elements(); ++i)
    {
        EXPECT_EQ(values[i], -9999.0);
    }
}

/**
 * @brief Test generating an empty deck without grid points.
 */
TEST(GenerateEmptyDeckData, EmptyGridsGiveNoValues)
{
    design::EngineDesigner designer{nullptr, {}, {}};

    const DeckData deck = designer.generate_empty_deck_data("empty_deck", {}, {}, {});

    EXPECT_EQ(deck.name, "empty_deck");
    EXPECT_TRUE(deck.FL.empty());
    EXPECT_TRUE(deck.Mach.empty());
    EXPECT_TRUE(deck.N.empty());
    EXPECT_EQ(deck.values.num_elements(), 0U);
}
