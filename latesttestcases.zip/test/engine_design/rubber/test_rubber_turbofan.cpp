/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 * 
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <filesystem>
#include <fstream>
#include <gtest/gtest.h>
#include <string>

#include "../../temp_directory.h"

/* Unit Under Test */
#include "engine_design/rubber/rubber_design.h"

/* === Fixtures === */
class TemporaryEngineDesign : public ::testing::Test
{
  protected:
    void SetUp() override
    {
        /* Create a temporary directory */
        temp_dir_ = std::filesystem::temp_directory_path() / "test_rubber_turbofan";
        std::filesystem::create_directory(temp_dir_);
    }

    void TearDown() override
    {
        /* Remove the temporary directory */
        std::filesystem::remove_all(temp_dir_);
    }

    std::filesystem::path temp_dir_;
};

/* === Tests === */
/**
 * @brief Test designing a turbofan engine with kerosene as fuel.
 */
TEST(EngineDesignRubber, DesignTurbofanKeroseneManuallySelected)
{
    /* Set the manual selection to the test engine */
    std::filesystem::path config_path{CMAKE_TEST_CONFIG_FILE};
    auto config = aixml::openDocument(config_path);
    config->at("module_configuration_file/program_settings/propulsion@Default/Rubber/engine_model/value") = "test-engine";

    /* Set the engine database path */
    config->at("module_configuration_file/program_settings/path_engine_database/value") = std::string{CMAKE_TEST_STUBS_DIR} + "/engines";

    /* Create the engine designer and initialize */
    design::Rubber designer{config, {""}, {}}; // No engine directory -> Use database entry
    designer.initialize();

    /* Design the engine which needs no scaling */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{};
    engine.set_required_thrust(110.31e3);
    designer(engine);

    /* Check the result */
    EXPECT_EQ(engine.model(), "test-engine");
    EXPECT_NEAR(engine.scale(), 1.0, 1e-6);
    EXPECT_NEAR(engine.dimension().height, 2.118, 1e-3);
    EXPECT_NEAR(engine.dimension().width, 1.829, 1e-3);
    EXPECT_NEAR(engine.dimension().length, 2.508, 1e-3);
    EXPECT_NEAR(engine.fan().diameter, 1.613, 1e-3);
    EXPECT_NEAR(engine.pointmass(Component::Engine).mass, 2404.0, 1e-3);
    /*
     * NOTE: this test currently cannot reach these checks. Since engine-library commit 2ac1f62
     * ("Changes reference from core to overall massflow") the library reads the deck
     * <name>_St2_W (total mass flow at station 2) instead of <name>_W25 (core mass flow), and the
     * test-engine stub has no test-engine_St2_W.csv. Substituting the stub's W25 deck would be
     * unjustified (core flow is not total flow). The stub shares dimensions and SLST with the
     * database engine V2527-A5, but its dry mass (2404 vs 2858 kg) and its thrust and fuel-flow
     * decks differ, so the V2527-A5 St2_W deck cannot simply be copied in either.
     * Options: (a) obtain the matching St2_W deck for this stub; (b) replace the stub by a clearly
     * labelled synthetic, internally consistent engine fixture with derived expectations;
     * (c) use a complete reference engine such as V2527-A5 and derive new expectations.
     * The former check EXPECT_NEAR(tsfc, 0.0, 1e-3) accepted any TSFC of a real engine
     * (about 1e-5 kg/Ns), so it checked nothing. EXPECT_GT below only removes that ineffective
     * assertion; it does not check TSFC accuracy, and the test still fails before reaching it.
     */
    EXPECT_NEAR(engine.bucket_point().thrust, 35090.0, 1e-3);
    EXPECT_GT(engine.bucket_point().tsfc, 0.0);

    /* Reduce the design thrust so a scale of 2 is necessary */
    engine.set_required_thrust(110.31e3 * 2);
    designer(engine);
    EXPECT_NEAR(engine.scale(), 2.0, 1e-6);
    EXPECT_NEAR(engine.dimension().height, 2.995, 1e-3);
    EXPECT_NEAR(engine.dimension().width, 2.586, 1e-3);
    EXPECT_NEAR(engine.dimension().length, 3.309, 1e-3);
    EXPECT_NEAR(engine.fan().diameter, 2.281, 1e-3);

}

/**
 * @brief Test designing a turbofan engine with kerosene as fuel.
 */
TEST(EngineDesignRubber, DesignTurbofanKeroseneAutomaticallySelected)
{
    /* Set the manual selection to the test engine */
    std::filesystem::path config_path{CMAKE_TEST_CONFIG_FILE};
    auto config = aixml::openDocument(config_path);
    config->at("module_configuration_file/program_settings/propulsion@Default/Rubber").deleteChild("engine_model");

    /* Set the engine database path */
    config->at("module_configuration_file/program_settings/path_engine_database/value") = std::string{CMAKE_TEST_STUBS_DIR} + "engines";

    /* Create the engine designer and initialize */
    design::Rubber designer{config, {""}, {}}; // No engine directory -> Use database entry
    designer.initialize();

    /* Design the engine which needs no scaling */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{};
    engine.set_required_thrust(110.31e3);
    designer(engine);

    /* Check the result */
    EXPECT_EQ(engine.model(), "test-engine");
}

/**
 * @brief Test that the automatic engine selection fails with a clear error if the engine database is empty.
 */
TEST(EngineDesignRubber, DesignTurbofanKeroseneEmptyDatabase)
{
    /* No manual selection -> the engine is selected automatically from the database */
    std::filesystem::path config_path{CMAKE_TEST_CONFIG_FILE};
    auto config = aixml::openDocument(config_path);
    config->at("module_configuration_file/program_settings/propulsion@Default/Rubber").deleteChild("engine_model");

    /* Set the engine database path to an existing, empty directory */
    const UniqueTempDirectory empty_database{"test_rubber_empty_database"};
    config->at("module_configuration_file/program_settings/path_engine_database/value") = empty_database.path().string();

    /* Create the engine designer and initialize */
    design::Rubber designer{config, {""}, {}}; // No engine directory -> Use database entry
    designer.initialize();

    /* Design an engine with a positive required thrust */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{};
    engine.set_required_thrust(110.31e3);
    try
    {
        designer(engine);
        FAIL() << "Expected std::runtime_error for an empty engine database";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("No engine found in the database"), std::string::npos) << error.what();
    }
}

/**
 * @brief Test designing a turbofan engine with a database that contains no engine folders.
 */
TEST(EngineDesignRubber, DesignTurbofanKeroseneDatabaseWithoutEngineFolders)
{
    /* No manual selection -> the engine is selected automatically from the database */
    std::filesystem::path config_path{CMAKE_TEST_CONFIG_FILE};
    auto config = aixml::openDocument(config_path);
    config->at("module_configuration_file/program_settings/propulsion@Default/Rubber").deleteChild("engine_model");

    /* Database with files only, among them an engine XML that is not inside an engine folder */
    const UniqueTempDirectory database{"test_rubber_files_only_database"};
    std::filesystem::copy_file(std::filesystem::path{CMAKE_TEST_STUBS_DIR} / "engines" / "test-engine" / "test-engine.xml",
                               database.path() / "test-engine.xml");
    std::ofstream(database.path() / "README.txt") << "not an engine";
    config->at("module_configuration_file/program_settings/path_engine_database/value") = database.path().string();

    /* Create the engine designer and initialize */
    design::Rubber designer{config, {""}, {}};
    designer.initialize();

    /* Design an engine with a positive required thrust */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{};
    engine.set_required_thrust(110.31e3);
    try
    {
        designer(engine);
        FAIL() << "Expected std::runtime_error for a database without engine folders";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("No engine found in the database"), std::string::npos) << error.what();
    }
}

/**
 * @brief Test that the save method copies non existing engines from the database.
 */
TEST_F(TemporaryEngineDesign, SaveTurbofanKerosene)
{
    /* Set the manual selection to the test engine */
    std::filesystem::path config_path{CMAKE_TEST_CONFIG_FILE};
    auto config = aixml::openDocument(config_path);
    config->at("module_configuration_file/program_settings/propulsion@Default/Rubber/engine_model/value") = "test-engine";

    /* Set the engine database path */
    config->at("module_configuration_file/program_settings/path_engine_database/value") = std::string{CMAKE_TEST_STUBS_DIR} + "/engines";

    /* Create the engine designer and initialize */
    design::Rubber designer{config, {temp_dir_}, {}}; // No engine directory -> Use database entry
    designer.initialize();
    Turbofan<EnergyCarrierFamily::Kerosene> engine{};
    engine.set_required_thrust(110.31e3);
    designer(engine);
    designer.save();

    /* Check whether the engine directory is copied */
    auto result = temp_dir_ / "test-engine";
    ASSERT_TRUE(std::filesystem::exists(result));

    /* Calling save again should not add another folder */
    designer.save();
    auto n_folers = std::count_if(
        std::filesystem::directory_iterator(temp_dir_),
        std::filesystem::directory_iterator(),
        [](const auto &entry) { return entry.is_directory(); });
    EXPECT_EQ(n_folers, 1);
}

/**
 * @brief Test changing the technology factor of the engine efficiency.
 */
TEST(EngineDesignRubber, ChangeTechnologyFactor)
{
    /* Set the manual selection to the test engine */
    std::filesystem::path config_path{CMAKE_TEST_CONFIG_FILE};
    auto config = aixml::openDocument(config_path);
    config->at("module_configuration_file/program_settings/propulsion@Default/Rubber/engine_model/value") = "test-engine";

    /* Set the engine database path */
    config->at("module_configuration_file/program_settings/path_engine_database/value") = std::string{CMAKE_TEST_STUBS_DIR} + "/engines";

    /* Modify the technology factor */
    config->at("module_configuration_file/program_settings/technology_factors/engine_efficiency/value") = 0.9;

    /* Create the engine designer and initialize */
    design::Rubber designer{config, {""}, {}}; // No engine directory -> Use database entry
    EXPECT_THROW(designer.initialize(), std::runtime_error);
}
