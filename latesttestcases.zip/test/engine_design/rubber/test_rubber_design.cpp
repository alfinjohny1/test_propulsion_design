/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 *
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <cmath>
#include <filesystem>
#include <gtest/gtest.h>
#include <iostream>
#include <runtimeInfo/runtimeInfo.h>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

#include "../../temp_directory.h"

/* Unit Under Test */
#include "engine_design/rubber/rubber_design.h"
#include "io/engine_xml.h"

/* === Fixtures === */
/* Sets a runtime-info object at console mode 1 and captures std::cout and std::cerr; everything is restored on destruction */
class OutputCapture
{
  public:
    explicit OutputCapture(const std::filesystem::path &log_file)
        : previous_runtime_info(myRuntimeInfo),
          old_cout(std::cout.rdbuf(captured_cout.rdbuf())),
          old_cerr(std::cerr.rdbuf(captured_cerr.rdbuf()))
    {
        myRuntimeInfo = new runtimeInfo(1, 0, log_file.string(), "rubber_design_test");
    }

    ~OutputCapture()
    {
        std::cout.rdbuf(old_cout);
        std::cerr.rdbuf(old_cerr);
        delete myRuntimeInfo;
        myRuntimeInfo = previous_runtime_info;
    }

    OutputCapture(const OutputCapture &) = delete;
    OutputCapture &operator=(const OutputCapture &) = delete;

    std::stringstream captured_cout;
    std::stringstream captured_cerr;

  private:
    runtimeInfo *previous_runtime_info;
    std::streambuf *old_cout;
    std::streambuf *old_cerr;
};

class RubberDesign : public ::testing::Test
{
  protected:
    void SetUp() override
    {
        /* Create the project engine directory and the engine database */
        project = temp.path() / "project";
        database = temp.path() / "database";
        std::filesystem::create_directories(project);
        std::filesystem::create_directories(database);

        /* Copy the default engine of the repository's engine database; tests that need other engines copy them */
        std::filesystem::copy(engines / "PW1127G-JM", database / "PW1127G-JM", std::filesystem::copy_options::recursive);

        /* Read the configuration with the default engine PW1127G-JM and neutral technology factors */
        config = aixml::openDocument(std::filesystem::path{CMAKE_TEST_CONFIG_FILE});
        config->at("module_configuration_file/program_settings/path_engine_database/value") = database.string();
        config->at("module_configuration_file/program_settings/propulsion@Default/Rubber/engine_model/value") = std::string{"PW1127G-JM"};
        config->at("module_configuration_file/program_settings/technology_factors/engine_mass/value") = 1.0;
        config->at("module_configuration_file/program_settings/technology_factors/engine_efficiency/value") = 1.0;

        /* Design condition: Mach 0.78 at 10668 m, ISA */
        condition.altitude = 10668.0;
        condition.mach = 0.78;
    }

    const std::filesystem::path engines = std::filesystem::path{CMAKE_TEST_STUBS_DIR} / ".." / ".." / ".." / ".." / "engines";
    const UniqueTempDirectory temp{"test_rubber_design"};
    std::filesystem::path project;
    std::filesystem::path database;
    std::shared_ptr<node> config;
    FlightCondition condition;
};

/* === Tests === */
/**
 * @brief Test selecting the preselected engine model of each engine ID.
 */
TEST_F(RubberDesign, PreselectedModelPerEngineId)
{
    /* Copy V2527-A5 into the database */
    std::filesystem::copy(engines / "V2527-A5", database / "V2527-A5", std::filesystem::copy_options::recursive);

    /* Preselect the model V2527-A5 for the engine with ID 1 */
    node &propulsion = config->at("module_configuration_file/program_settings").appendChild("propulsion", true);
    propulsion.setAttrib("ID", "1");
    propulsion.appendChild("engine", true).appendChild("Rubber", true).appendChild("engine_model", true).appendChild("value", true) = std::string{"V2527-A5"};

    /* Create the engine designer and initialize */
    design::Rubber designer{config, project, condition};
    designer.initialize();

    /* Design the engines with ID 0 and 1 */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_0{0, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}, 100000.0};
    Turbofan<EnergyCarrierFamily::Kerosene> engine_1{1, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}, 100000.0};
    designer(engine_0);
    designer(engine_1);

    /* Check the models: ID 0 has the default, ID 1 its own model */
    EXPECT_EQ(engine_0.model(), "PW1127G-JM");
    EXPECT_EQ(engine_1.model(), "V2527-A5");
}

/**
 * @brief Test selecting the engine model with the closest SLST when no model is preselected.
 */
TEST_F(RubberDesign, ModelSelectedByClosestSlst)
{
    /* Copy V2527-A5 and Trent XWB-84 into the database */
    std::filesystem::copy(engines / "V2527-A5", database / "V2527-A5", std::filesystem::copy_options::recursive);
    std::filesystem::copy(engines / "Trent XWB-84", database / "Trent XWB-84", std::filesystem::copy_options::recursive);

    /* Remove the default preselection */
    config->at("module_configuration_file/program_settings/propulsion@Default/Rubber").deleteChild("engine_model");

    /* Create the engine designer and initialize */
    design::Rubber designer{config, project, condition};
    designer.initialize();

    /* Design engines close to the SLST of V2527-A5 (110.31 kN), PW1127G-JM (120.43 kN) and Trent XWB-84 (374.5 kN) */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_a{0, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}, 115000.0};
    Turbofan<EnergyCarrierFamily::Kerosene> engine_b{1, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}, 116000.0};
    Turbofan<EnergyCarrierFamily::Kerosene> engine_c{2, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}, 300000.0};
    designer(engine_a);
    designer(engine_b);
    designer(engine_c);

    /* Check the models: 115 kN is 4.69 kN from V2527-A5, 116 kN is 4.43 kN from PW1127G-JM */
    EXPECT_EQ(engine_a.model(), "V2527-A5");
    EXPECT_EQ(engine_b.model(), "PW1127G-JM");
    EXPECT_EQ(engine_c.model(), "Trent XWB-84");
}

/**
 * @brief Test that an engine in the project engine directory is used before the database engine.
 */
TEST_F(RubberDesign, ProjectEngineUsedBeforeDatabase)
{
    /* Copy PW1127G-JM into the project and change its dry mass to 3000 kg */
    std::filesystem::copy(database / "PW1127G-JM", project / "PW1127G-JM", std::filesystem::copy_options::recursive);
    auto engine_xml = aixml::openDocument(project / "PW1127G-JM" / "PW1127G-JM.xml");
    engine_xml->at("EngineDataFile/MassProperties/Dry_mass") = 3000.0;
    ASSERT_TRUE(aixml::saveDocument(*engine_xml));

    /* Create the engine designer and initialize */
    design::Rubber designer{config, project, condition};
    designer.initialize();

    /* Design the engine without required thrust, so it is not scaled */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}, 0.0};
    designer(engine);

    /* Check the mass of the project engine (database: 2858 kg) */
    EXPECT_NEAR(engine.pointmass(Component::Engine).mass, 3000.0, 1e-9);
}

/**
 * @brief Test the error for an engine model that is neither in the project nor in the database.
 */
TEST_F(RubberDesign, MissingEngineListsSearchedFolders)
{
    /* Preselect a model that does not exist */
    config->at("module_configuration_file/program_settings/propulsion@Default/Rubber/engine_model/value") = std::string{"NoSuchEngine"};

    /* Create the engine designer and initialize */
    design::Rubber designer{config, project, condition};
    designer.initialize();

    /* Design the engine and check the error */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}, 100000.0};
    try
    {
        designer(engine);
        FAIL() << "Expected std::runtime_error for a missing engine model";
    }
    catch (const std::runtime_error &error)
    {
        EXPECT_NE(std::string{error.what()}.find("NoSuchEngine.xml could not be found in the following folders:"), std::string::npos) << error.what();
        EXPECT_NE(std::string{error.what()}.find(project.string()), std::string::npos) << error.what();
        EXPECT_NE(std::string{error.what()}.find(database.string()), std::string::npos) << error.what();
    }
}

/**
 * @brief Test designing an engine without required thrust.
 */
TEST_F(RubberDesign, ZeroThrustGivesUnscaledEngine)
{
    /* Create the engine designer and initialize */
    design::Rubber designer{config, project, condition};
    designer.initialize();

    /* Design the engine without required thrust */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}, 0.0};
    designer(engine);

    /* Check the scale, dimensions and mass of PW1127G-JM */
    EXPECT_DOUBLE_EQ(engine.scale(), 1.0);
    EXPECT_NEAR(engine.dimension().height, 2.224, 1e-9);
    EXPECT_NEAR(engine.dimension().width, 2.224, 1e-9);
    EXPECT_NEAR(engine.dimension().length, 3.401, 1e-9);
    EXPECT_NEAR(engine.fan().diameter, 2.05, 1e-9);
    EXPECT_NEAR(engine.pointmass(Component::Engine).mass, 2858.0, 1e-9);
}

/**
 * @brief Test that the scale factor is proportional to the required thrust.
 */
TEST_F(RubberDesign, ScaleProportionalToRequiredThrust)
{
    /* Create the engine designer and initialize */
    design::Rubber designer{config, project, condition};
    designer.initialize();

    /* Design the engine for 100 kN and for 200 kN */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_100{0, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}, 100000.0};
    Turbofan<EnergyCarrierFamily::Kerosene> engine_200{1, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}, 200000.0};
    designer(engine_100);
    designer(engine_200);

    /* Check that twice the thrust gives twice the scale */
    EXPECT_GT(engine_100.scale(), 0.0);
    EXPECT_NEAR(engine_200.scale(), 2.0 * engine_100.scale(), 1e-12);
}

/**
 * @brief Test the scale factor against the published sea level static thrust of the engine.
 */
TEST_F(RubberDesign, ScaleFromPublishedSlst)
{
    /* Create the engine designer and initialize */
    design::Rubber designer{config, project, condition};
    designer.initialize();

    /* Design the engine for 100 kN */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}, 100000.0};
    designer(engine);

    /* Check k = 100 kN / 120.43 kN (SLST in PW1127G-JM.xml); the deck thrust at sea level differs from it by less than 0.1 % */
    EXPECT_NEAR(engine.scale(), 100.0 / 120.43, 1e-3);
}

/**
 * @brief Test scaling the engine dimensions with the scale factor.
 */
TEST_F(RubberDesign, DimensionsScaledWithScaleFactor)
{
    /* Create the engine designer and initialize */
    design::Rubber designer{config, project, condition};
    designer.initialize();

    /* Design the engine for 200 kN */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}, 200000.0};
    designer(engine);

    /* Check height, width and fan diameter with k^0.5 and the length with k^0.4 */
    const double k = engine.scale();
    EXPECT_NEAR(engine.dimension().height, 2.224 * std::pow(k, 0.5), 1e-9);
    EXPECT_NEAR(engine.dimension().width, 2.224 * std::pow(k, 0.5), 1e-9);
    EXPECT_NEAR(engine.dimension().length, 3.401 * std::pow(k, 0.4), 1e-9);
    EXPECT_NEAR(engine.fan().diameter, 2.05 * std::pow(k, 0.5), 1e-9);
}

/**
 * @brief Test scaling the engine mass with the scale factor and the technology factor.
 */
TEST_F(RubberDesign, MassScaledWithScaleAndTechnologyFactor)
{
    /* Set the engine mass technology factor to 0.9 */
    config->at("module_configuration_file/program_settings/technology_factors/engine_mass/value") = 0.9;

    /* Create the engine designer and initialize */
    design::Rubber designer{config, project, condition};
    designer.initialize();

    /* Design the engine for 200 kN */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}, 200000.0};
    designer(engine);

    /* Check the mass 0.9 * 2858 kg * k^1.1 */
    EXPECT_NEAR(engine.pointmass(Component::Engine).mass, 2572.2 * std::pow(engine.scale(), 1.1), 1e-6);
}

/**
 * @brief Test that the diameter of an open-rotor engine is its propeller diameter.
 */
TEST_F(RubberDesign, OpenRotorDiameterIsPropellerDiameter)
{
    /* Copy the open-rotor engine CROR into the database and preselect it */
    std::filesystem::copy(engines / "CROR", database / "CROR", std::filesystem::copy_options::recursive);
    config->at("module_configuration_file/program_settings/propulsion@Default/Rubber/engine_model/value") = std::string{"CROR"};

    /* Create the engine designer and initialize */
    design::Rubber designer{config, project, condition};
    designer.initialize();

    /* Design the engine without required thrust */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}, 0.0};
    designer(engine);

    /* Check the diameter (fan 1.2 m, propeller 3.25 m) and the mass */
    EXPECT_DOUBLE_EQ(engine.scale(), 1.0);
    EXPECT_NEAR(engine.fan().diameter, 3.25, 1e-9);
    EXPECT_NEAR(engine.pointmass(Component::Engine).mass, 4252.0, 1e-9);
}

/**
 * @brief Test that the shaft power offtake raises the fuel flow by the offtake correction.
 */
TEST_F(RubberDesign, ShaftPowerOfftakeRaisesFuelFlow)
{
    /* Evaluate the unscaled engine at the take-off rating at Mach 0.78 and 10668 m without offtakes */
    auto engine = io::load_engine_scaled("PW1127G-JM", 1.0, {database});
    engine.calculate_N1_with_penalties(10668.0, 0.78, condition.ambiance, 1.0, "takeoff", 0.0, 0.0);
    const double thrust = engine.get_thrust();
    const double fuel_flow = engine.get_fuelflow();

    /* Evaluate again with a shaft power offtake of 100 */
    engine.calculate_N1_with_penalties(10668.0, 0.78, condition.ambiance, 1.0, "takeoff", 0.0, 100.0);

    /* Check the thrust and the fuel flow * (1 + 100 * c_sh / thrust) with c_sh = 0.00228022488 at Mach 0.78 and 10668 m */
    EXPECT_DOUBLE_EQ(engine.get_thrust(), thrust);
    EXPECT_NEAR(engine.get_fuelflow(), fuel_flow * (1.0 + 100.0 * 0.00228022488 / thrust), 1e-12 * fuel_flow);
}

/**
 * @brief Test that the bleed air offtake lowers the thrust by the offtake correction.
 */
TEST_F(RubberDesign, BleedAirOfftakeLowersThrust)
{
    /* Evaluate the unscaled engine at the take-off rating with 0, 0.5 and 1 kg/s bleed air */
    auto engine = io::load_engine_scaled("PW1127G-JM", 1.0, {database});
    engine.calculate_N1_with_penalties(10668.0, 0.78, condition.ambiance, 1.0, "takeoff", 0.0, 0.0);
    const double thrust_0 = engine.get_thrust();
    const double fuel_flow_0 = engine.get_fuelflow();
    engine.calculate_N1_with_penalties(10668.0, 0.78, condition.ambiance, 1.0, "takeoff", 0.5, 0.0);
    const double thrust_05 = engine.get_thrust();
    const double fuel_flow_05 = engine.get_fuelflow();
    engine.calculate_N1_with_penalties(10668.0, 0.78, condition.ambiance, 1.0, "takeoff", 1.0, 0.0);
    const double thrust_10 = engine.get_thrust();

    /* Check that the thrust is reduced linearly with the bleed air and the fuel flow is unchanged */
    EXPECT_LT(thrust_05, thrust_0);
    EXPECT_NEAR(thrust_0 - thrust_10, 2.0 * (thrust_0 - thrust_05), 1e-9 * thrust_0);
    EXPECT_DOUBLE_EQ(fuel_flow_05, fuel_flow_0);
}

/**
 * @brief Test that the shaft power offtake of the engine is passed in W to the bucket point calculation (candidate defect: the engine design passes kW, while the engine library expects W).
 */
TEST_F(RubberDesign, BucketPointWithShaftPowerOfftake)
{
    /* Create the engine designer and initialize */
    design::Rubber designer{config, project, condition};
    designer.initialize();

    /* Design the engine for 100 kN without offtakes and with a shaft power offtake of 100000 W */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_0{0, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}, 100000.0};
    Turbofan<EnergyCarrierFamily::Kerosene> engine_shaft{1, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}, 100000.0, {0.0, 100000.0}};
    designer(engine_0);
    designer(engine_shaft);

    /* Evaluate the scaled engine at take-off at the design condition, where the offtake correction is set */
    auto scaled = io::load_engine_scaled("PW1127G-JM", engine_0.scale(), {database});
    scaled.calculate_N1_with_penalties(10668.0, 0.78, condition.ambiance, 1.0, "takeoff", 0.0, 0.0);
    const double thrust_takeoff = scaled.get_thrust();

    /* Check the bucket point: same thrust, TSFC * (1 + 100000 W * c_sh / thrust) with c_sh = 0.00228022488 */
    EXPECT_DOUBLE_EQ(engine_shaft.bucket_point().thrust, engine_0.bucket_point().thrust);
    EXPECT_NEAR(engine_shaft.bucket_point().tsfc, engine_0.bucket_point().tsfc * (1.0 + 100000.0 * 0.00228022488 / thrust_takeoff),
                1e-12 * engine_0.bucket_point().tsfc);
}

/**
 * @brief Test that the bleed air offtake of the engine is passed to the bucket point calculation.
 */
TEST_F(RubberDesign, BucketPointWithBleedAirOfftake)
{
    /* Create the engine designer and initialize */
    design::Rubber designer{config, project, condition};
    designer.initialize();

    /* Design the engine for 100 kN without offtakes and with a bleed air offtake of 0.5 kg/s */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_0{0, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}, 100000.0};
    Turbofan<EnergyCarrierFamily::Kerosene> engine_bleed{1, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}, 100000.0, {0.5, 0.0}};
    designer(engine_0);
    designer(engine_bleed);

    /* Evaluate the thrust ratio of the scaled engine with and without 0.5 kg/s bleed air at take-off */
    auto scaled = io::load_engine_scaled("PW1127G-JM", engine_0.scale(), {database});
    scaled.calculate_N1_with_penalties(10668.0, 0.78, condition.ambiance, 1.0, "takeoff", 0.0, 0.0);
    const double thrust_0 = scaled.get_thrust();
    scaled.calculate_N1_with_penalties(10668.0, 0.78, condition.ambiance, 1.0, "takeoff", 0.5, 0.0);
    const double ratio = scaled.get_thrust() / thrust_0;

    /* Check the bucket point: thrust * ratio and TSFC / ratio at the same N1 */
    EXPECT_LT(ratio, 1.0);
    EXPECT_NEAR(engine_bleed.bucket_point().thrust, engine_0.bucket_point().thrust * ratio, 1e-9 * engine_0.bucket_point().thrust);
    EXPECT_NEAR(engine_bleed.bucket_point().tsfc, engine_0.bucket_point().tsfc / ratio, 1e-9 * engine_0.bucket_point().tsfc);
}

/**
 * @brief Test that the bucket point is the first local TSFC minimum on the N1 grid from idle.
 */
TEST_F(RubberDesign, BucketPointIsFirstLocalTsfcMinimum)
{
    /* Create the engine designer and initialize */
    design::Rubber designer{config, project, condition};
    designer.initialize();

    /* Design the engine for 100 kN */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}, 100000.0};
    designer(engine);

    /* Evaluate the scaled engine at idle and at take-off at the design condition */
    auto scaled = io::load_engine_scaled("PW1127G-JM", engine.scale(), {database});
    scaled.calculate_N1_with_penalties(10668.0, 0.78, condition.ambiance, 1.0, "idle", 0.0, 0.0);
    const double n1_idle = scaled.get_operating_point().N;
    scaled.calculate_N1_with_penalties(10668.0, 0.78, condition.ambiance, 1.0, "takeoff", 0.0, 0.0);
    const double n1_takeoff = scaled.get_operating_point().N;

    /* Evaluate thrust and TSFC on the N1 grid with step 0.01 from idle to one step above take-off */
    auto op = scaled.get_operating_point();
    std::vector<double> thrust;
    std::vector<double> tsfc;
    for (double n1 = n1_idle; n1 <= n1_takeoff + 0.01; n1 += 0.01)
    {
        op.N = n1;
        scaled.set_operating_point(op);
        thrust.push_back(scaled.get_thrust());
        tsfc.push_back(scaled.get_fuelflow() / scaled.get_thrust());
    }

    /* Find the grid point of the bucket point */
    std::size_t bucket = 0;
    while (bucket < thrust.size() && std::abs(thrust[bucket] - engine.bucket_point().thrust) > 1e-9 * thrust[bucket])
    {
        ++bucket;
    }
    ASSERT_LT(bucket + 1, thrust.size());

    /* Check that the TSFC does not rise up to the bucket point and rises at the next grid point */
    EXPECT_NEAR(engine.bucket_point().tsfc, tsfc[bucket], 1e-9 * tsfc[bucket]);
    for (std::size_t i = 1; i <= bucket; ++i)
    {
        EXPECT_LE(tsfc[i], tsfc[i - 1]);
    }
    EXPECT_GT(tsfc[bucket + 1], tsfc[bucket]);
}

/**
 * @brief Test the bucket point of an engine whose first local TSFC minimum lies an odd number of 0.01 steps above idle.
 */
TEST_F(RubberDesign, BucketPointAtOddStepOfN1Grid)
{
    /* Copy V2527-A5 into the database and preselect it */
    std::filesystem::copy(engines / "V2527-A5", database / "V2527-A5", std::filesystem::copy_options::recursive);
    config->at("module_configuration_file/program_settings/propulsion@Default/Rubber/engine_model/value") = std::string{"V2527-A5"};

    /* Create the engine designer and initialize */
    design::Rubber designer{config, project, condition};
    designer.initialize();

    /* Design the engine for 100 kN */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}, 100000.0};
    designer(engine);

    /* Evaluate the scaled engine at idle and at take-off at the design condition */
    auto scaled = io::load_engine_scaled("V2527-A5", engine.scale(), {database});
    scaled.calculate_N1_with_penalties(10668.0, 0.78, condition.ambiance, 1.0, "idle", 0.0, 0.0);
    const double n1_idle = scaled.get_operating_point().N;
    scaled.calculate_N1_with_penalties(10668.0, 0.78, condition.ambiance, 1.0, "takeoff", 0.0, 0.0);
    const double n1_takeoff = scaled.get_operating_point().N;

    /* Evaluate thrust and TSFC on the N1 grid with step 0.01 from idle to one step above take-off */
    auto op = scaled.get_operating_point();
    std::vector<double> thrust;
    std::vector<double> tsfc;
    for (double n1 = n1_idle; n1 <= n1_takeoff + 0.01; n1 += 0.01)
    {
        op.N = n1;
        scaled.set_operating_point(op);
        thrust.push_back(scaled.get_thrust());
        tsfc.push_back(scaled.get_fuelflow() / scaled.get_thrust());
    }

    /* Find the first local TSFC minimum on the grid */
    std::size_t minimum = 0;
    while (minimum + 1 < tsfc.size() && tsfc[minimum + 1] <= tsfc[minimum])
    {
        ++minimum;
    }
    ASSERT_LT(minimum + 1, tsfc.size());

    /* Check that the minimum is at an odd step, which a coarser step of 0.02 would miss, and that it is the bucket point */
    EXPECT_EQ(minimum % 2, 1U);
    EXPECT_NEAR(engine.bucket_point().thrust, thrust[minimum], 1e-9 * thrust[minimum]);
    EXPECT_NEAR(engine.bucket_point().tsfc, tsfc[minimum], 1e-9 * tsfc[minimum]);
}

/**
 * @brief Test the bucket point when the idle N1 cannot be calculated at the design condition.
 */
TEST_F(RubberDesign, BucketPointZeroWhenIdleN1Fails)
{
    /* Design condition at 20000 m, outside the engine deck */
    condition.altitude = 20000.0;

    /* Create the engine designer and initialize */
    design::Rubber designer{config, project, condition};
    designer.initialize();

    /* Design the engine for 100 kN at console mode 1 and capture the output */
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}, 100000.0};
    std::string output;
    {
        OutputCapture capture{temp.path() / "rubber.log"};
        designer(engine);
        output = capture.captured_cout.str();
    }

    /* Check the warning and the bucket point {0, 0}; the engine is still sized */
    EXPECT_NE(output.find("Calculating the N1 failed:"), std::string::npos);
    EXPECT_DOUBLE_EQ(engine.bucket_point().thrust, 0.0);
    EXPECT_DOUBLE_EQ(engine.bucket_point().tsfc, 0.0);
    EXPECT_GT(engine.scale(), 0.0);
}

/**
 * @brief Test recording every designed engine model once.
 */
TEST_F(RubberDesign, DesignedEnginesRecordedOnce)
{
    /* Copy V2527-A5 into the database */
    std::filesystem::copy(engines / "V2527-A5", database / "V2527-A5", std::filesystem::copy_options::recursive);

    /* Preselect the model V2527-A5 for the engine with ID 1 */
    node &propulsion = config->at("module_configuration_file/program_settings").appendChild("propulsion", true);
    propulsion.setAttrib("ID", "1");
    propulsion.appendChild("engine", true).appendChild("Rubber", true).appendChild("engine_model", true).appendChild("value", true) = std::string{"V2527-A5"};

    /* Create the engine designer and initialize */
    design::Rubber designer{config, project, condition};
    designer.initialize();

    /* Design two PW1127G-JM engines and one V2527-A5 engine */
    Turbofan<EnergyCarrierFamily::Kerosene> engine_0{0, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}, 100000.0};
    Turbofan<EnergyCarrierFamily::Kerosene> engine_1{1, {Parent::Wing, Lateral::Right, Longitudinal::Front, Vertical::Under}, 100000.0};
    Turbofan<EnergyCarrierFamily::Kerosene> engine_2{2, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}, 100000.0};
    designer(engine_0);
    designer(engine_1);
    designer(engine_2);

    /* Check the designed models */
    EXPECT_EQ(designer.designed_engines().size(), 2U);
    EXPECT_TRUE(designer.designed_engines().contains("PW1127G-JM"));
    EXPECT_TRUE(designer.designed_engines().contains("V2527-A5"));
}

/**
 * @brief Test designing a liquid hydrogen turbofan engine with a turbofan model.
 */
TEST_F(RubberDesign, LiquidHydrogenTurbofanWithTurbofanModel)
{
    /* Copy PW1127G-JM-H2 into the database and preselect it */
    std::filesystem::copy(engines / "PW1127G-JM-H2", database / "PW1127G-JM-H2", std::filesystem::copy_options::recursive);
    config->at("module_configuration_file/program_settings/propulsion@Default/Rubber/engine_model/value") = std::string{"PW1127G-JM-H2"};

    /* Create the engine designer and initialize */
    design::Rubber designer{config, project, condition};
    designer.initialize();

    /* Design the engine at console mode 1 and capture the output */
    Turbofan<EnergyCarrierFamily::Liquid_Hydrogen> engine{0, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}, 100000.0};
    std::string output;
    {
        OutputCapture capture{temp.path() / "rubber.log"};
        designer(engine);
        output = capture.captured_cerr.str();
    }

    /* Check the model, the scale and that no error was printed */
    EXPECT_EQ(engine.model(), "PW1127G-JM-H2");
    EXPECT_GT(engine.scale(), 0.0);
    EXPECT_EQ(output.find("not the correct type"), std::string::npos);
}

/**
 * @brief Test designing a liquid hydrogen turbofan engine with a model that is not a turbofan.
 */
TEST_F(RubberDesign, LiquidHydrogenTurbofanWithWrongTypePrintsError)
{
    /* Copy the open-rotor engine CROR into the database and preselect it */
    std::filesystem::copy(engines / "CROR", database / "CROR", std::filesystem::copy_options::recursive);
    config->at("module_configuration_file/program_settings/propulsion@Default/Rubber/engine_model/value") = std::string{"CROR"};

    /* Create the engine designer and initialize */
    design::Rubber designer{config, project, condition};
    designer.initialize();

    /* Design the engine at console mode 1 and capture the output */
    Turbofan<EnergyCarrierFamily::Liquid_Hydrogen> engine{0, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}, 100000.0};
    std::string output;
    {
        OutputCapture capture{temp.path() / "rubber.log"};
        designer(engine);
        output = capture.captured_cerr.str();
    }

    /* Check that the error was printed and the engine was still sized */
    EXPECT_NE(output.find("The engine chosen in the config file is not the correct type (turbofan)"), std::string::npos);
    EXPECT_EQ(engine.model(), "CROR");
}

/**
 * @brief Test that the gearbox ratio of the open-rotor engine CROR of the engine database is used for the tip Mach number.
 */
TEST_F(RubberDesign, OpenRotorGearboxRatioOfDatabaseEngineIsUsed)
{
    /* Copy the open-rotor engine CROR into the database */
    std::filesystem::copy(engines / "CROR", database / "CROR", std::filesystem::copy_options::recursive);

    /* Evaluate the unscaled engine at the cruise rating at the design condition */
    auto engine = io::load_engine_scaled("CROR", 1.0, {database});
    engine.calculate_N1_with_penalties(10668.0, 0.78, condition.ambiance, 1.0, "cruise", 0.0, 0.0);

    /* Check the gearbox ratio 8 of CROR.xml and a tip Mach number above the flight Mach number 0.78 */
    EXPECT_DOUBLE_EQ(io::load_engine_data("CROR", {database}).gearbox_ratio(), 8.0);
    EXPECT_GT(engine.get_tip_mach(condition.ambiance), 0.78);
}

/**
 * @brief Test the tip speed message with a copy of CROR that has the gearbox ratio at the path read by the engine library.
 */
TEST_F(RubberDesign, OpenRotorTipSpeedMessageWithGearboxRatioAtLibraryPath)
{
    /* Copy CROR into the database with the gearbox ratio 8 at the path read by the engine library, and preselect it */
    std::filesystem::copy(engines / "CROR", database / "CROR", std::filesystem::copy_options::recursive);
    auto engine_xml = aixml::openDocument(database / "CROR" / "CROR.xml");
    engine_xml->at("EngineDataFile/Deck").appendChild("Gearbox_Ratio", true) = 8.0;
    ASSERT_TRUE(aixml::saveDocument(*engine_xml));
    config->at("module_configuration_file/program_settings/propulsion@Default/Rubber/engine_model/value") = std::string{"CROR"};

    /* Create the engine designer and initialize */
    design::Rubber designer{config, project, condition};
    designer.initialize();

    /* Design the engine at console mode 1 and capture the output */
    Openrotorfan<EnergyCarrierFamily::Kerosene> engine{0, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}, 100000.0};
    std::string output;
    {
        OutputCapture capture{temp.path() / "rubber.log"};
        designer(engine);
        output = capture.captured_cout.str();
    }

    /* Check the tip Mach number and the message, printed twice with the flight Mach number in between */
    auto unscaled = io::load_engine_scaled("CROR", 1.0, {database});
    unscaled.calculate_N1_with_penalties(10668.0, 0.78, condition.ambiance, 1.0, "cruise", 0.0, 0.0);
    EXPECT_GT(unscaled.get_tip_mach(condition.ambiance), 1.2);
    const auto first = output.find("Tip Speed to high. Consider using more engines or reduce T/W");
    ASSERT_NE(first, std::string::npos);
    EXPECT_NE(output.find("Mach: 0.78", first), std::string::npos);
    EXPECT_NE(output.find("Tip Speed to high. Consider using more engines or reduce T/W", first + 1), std::string::npos);
}
