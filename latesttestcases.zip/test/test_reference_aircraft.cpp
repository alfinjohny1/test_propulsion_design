/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 *
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <algorithm>
#include <cmath>
#include <filesystem>
#include <gtest/gtest.h>
#include <map>
#include <memory>
#include <string>
#include <unitConversion/constants.h>
#include <vector>

#include "temp_directory.h"

/* Unit Under Test */
#include "io/engine_xml.h"
#include "propulsion_design.h"
#include "toolinfo.h"

/* === Fixtures === */
/**
 * @brief Runs the module once for each reference aircraft of the repository with the aircraft's geometry data, engine data and
 * the program settings of its configuration on top of the current module configuration (the shipped reference configurations
 * lack settings the current module requires). All expected values are computed from the files of the aircraft under test,
 * so the tests apply to every reference aircraft and follow updates of the reference data.
 */
class ReferenceAircraftDesign : public ::testing::TestWithParam<std::string>
{
  public:
    /* Find every reference aircraft "<group>/<aircraft>" with a clean sheet design and a propulsion design configuration */
    static auto find_reference_aircraft() -> std::vector<std::string>
    {
        std::vector<std::string> names;
        if (!std::filesystem::exists(references))
        {
            return names;
        }
        for (const auto &group : std::filesystem::directory_iterator(references))
        {
            if (!group.is_directory())
            {
                continue;
            }
            for (const auto &aircraft : std::filesystem::directory_iterator(group.path()))
            {
                const auto design = aircraft.path() / "clean_sheet_design";
                if (std::filesystem::exists(design / (aircraft.path().filename().string() + ".xml")) && !find_configuration(design).empty())
                {
                    names.push_back(group.path().filename().string() + "/" + aircraft.path().filename().string());
                }
            }
        }
        std::sort(names.begin(), names.end());
        return names;
    }

  protected:
    /* Find the propulsion design configuration of a design: first in the workflow phase folders read by the blackbox tests,
     * then anywhere in the configuration folders */
    static auto find_configuration(const std::filesystem::path &design) -> std::filesystem::path
    {
        if (!std::filesystem::exists(design / "config_files"))
        {
            return {};
        }
        for (const std::string phase : {"setup", "sizingLoop", "postProcessing", "studyLoop"})
        {
            if (std::filesystem::exists(design / "config_files" / phase / "propulsion_design_conf.xml"))
            {
                return design / "config_files" / phase / "propulsion_design_conf.xml";
            }
        }
        for (const auto &entry : std::filesystem::recursive_directory_iterator(design / "config_files"))
        {
            if (entry.path().filename() == "propulsion_design_conf.xml")
            {
                return entry.path();
            }
        }
        return {};
    }

    /* Copy the settings of a reference configuration into the matching nodes of a configuration; missing nodes are added,
     * child nodes with the name skipped are left out */
    static void merge_settings(node &target, node &source, const std::string &skipped = "")
    {
        for (node *child : source.getChildren())
        {
            if (child->getName() == skipped)
            {
                continue;
            }
            const std::string id = child->hasAttrib("ID") ? child->getStringAttrib("ID") : "";
            node *match = nullptr;
            for (node *candidate : target.getChildren())
            {
                if (candidate->getName() == child->getName() && (candidate->hasAttrib("ID") ? candidate->getStringAttrib("ID") : "") == id)
                {
                    match = candidate;
                    break;
                }
            }
            if (match == nullptr)
            {
                match = &target.appendChild(child->getName(), true);
                if (!id.empty())
                {
                    match->setAttrib("ID", id);
                }
            }
            if (child->getChildren().empty())
            {
                *match = static_cast<std::string>(*child);
            }
            else
            {
                merge_settings(*match, *child);
            }
        }
    }

    /* Copy the reference aircraft, run the module once and keep the result for all tests of this aircraft */
    static auto provide_design(const std::string &name) -> bool
    {
        if (designs.contains(name))
        {
            return designs.at(name).designed;
        }
        if (!temp)
        {
            temp = std::make_unique<UniqueTempDirectory>("test_reference_aircraft");
        }

        /* Copy the aircraft file, the geometry data, the engine data and the configuration of the aircraft */
        Design design;
        const std::filesystem::path source = references / name / "clean_sheet_design";
        const std::string aircraft_name = std::filesystem::path{name}.filename().string();
        design.directory = temp->path() / aircraft_name;
        design.aircraft = design.directory / (aircraft_name + ".xml");
        design.configuration = design.directory / "propulsion_design_conf.xml";
        std::filesystem::create_directories(design.directory);
        std::filesystem::copy_file(source / (aircraft_name + ".xml"), design.aircraft);
        std::filesystem::copy(source / "geometry_data", design.directory / "geometry_data", std::filesystem::copy_options::recursive);
        if (std::filesystem::exists(source / "engine_data"))
        {
            std::filesystem::copy(source / "engine_data", design.directory / "engine_data", std::filesystem::copy_options::recursive);
        }

        /* Configuration: the current module configuration with the program settings of the reference aircraft;
         * the outdated shift entries of the reference configurations are not taken over */
        std::filesystem::copy_file(std::filesystem::path{CMAKE_TEST_CONFIG_FILE}, design.configuration);
        auto configuration = aixml::openDocument(design.configuration);
        auto reference_configuration = aixml::openDocument(find_configuration(source));
        merge_settings(configuration->at("module_configuration_file/program_settings"),
                       reference_configuration->at("module_configuration_file/program_settings"), "repositioning");

        /* Point the configuration to the copy and the repository's engine database and switch off all outputs */
        const std::string control = "module_configuration_file/control_settings/";
        configuration->at(control + "aircraft_exchange_file_directory/value") = std::string{design.directory.string() + "/"};
        configuration->at(control + "aircraft_exchange_file_name/value") = std::string{aircraft_name + ".xml"};
        configuration->at(control + "console_output/value") = std::string{"mode_0"};
        configuration->at(control + "log_file_output/value") = std::string{"mode_0"};
        configuration->at(control + "log_file/value") = std::string{(design.directory / "propulsion_design.log").string()};
        configuration->at(control + "plot_output/enable/value") = std::string{"false"};
        configuration->at(control + "plot_output/copy_plotting_files/value") = std::string{"false"};
        configuration->at(control + "plot_output/delete_plotting_files_from_tool_folder/value") = std::string{"false"};
        configuration->at(control + "report_output/value") = std::string{"false"};
        configuration->at(control + "xml_output/value") = std::string{"false"};
        configuration->at(control + "tex_report/value") = std::string{"false"};
        configuration->at(control + "write_info_files/value") = std::string{"false"};
        configuration->at("module_configuration_file/program_settings/path_engine_database/value") = std::string{engines.string() + "/"};
        aixml::saveDocument(*configuration);

        /* Stop before the module when an engine data set in the project has no engine technology factor:
         * Rubber::initialize() reads it as 0, fails to correct it and ends the whole program with exit() (O-42) */
        for (const node *propulsion : configuration->getVector("module_configuration_file/program_settings/propulsion"))
        {
            const node *model = propulsion->find("engine/Rubber/engine_model/value");
            const std::filesystem::path deck = model != nullptr ? design.directory / "engine_data" / std::string(*const_cast<node *>(model)) : std::filesystem::path{};
            if (!deck.empty() && std::filesystem::exists(deck / (deck.filename().string() + ".xml")) &&
                aixml::openDocument(deck / (deck.filename().string() + ".xml"))->find("EngineDataFile/EngineTechnologyFactor") == nullptr)
            {
                design.error = "The engine data " + deck.filename().string() + " of the project has no EngineTechnologyFactor (O-42)";
                designs[name] = design;
                return false;
            }
        }

        /* Design, update and save */
        try
        {
            auto module = std::make_unique<PropulsionDesign>(TOOL_NAME, TOOL_VERSION, design.configuration);
            module->initialize();
            module->run();
            module->update();
            module->save();
            design.designed = true;
        }
        catch (const std::exception &error)
        {
            design.error = error.what();
        }
        catch (const std::string &error)
        {
            design.error = error;
        }
        catch (...)
        {
            design.error = "unknown exception";
        }
        designs[name] = design;
        return design.designed;
    }

    static void TearDownTestSuite()
    {
        /* Remove the copies of all reference aircraft */
        designs.clear();
        temp.reset();
    }

    /* The design of the aircraft of the current test */
    static auto design() -> const auto & { return designs.at(GetParam()); }

    /* The engine model configured for a propulsor: its own entry or the Default entry of the configuration */
    static auto configured_model(const std::shared_ptr<node> &configuration, const std::string &id) -> std::string
    {
        const std::string settings = "module_configuration_file/program_settings/";
        node *own = configuration->find(settings + "propulsion@" + id + "/engine/Rubber/engine_model/value");
        return own != nullptr ? std::string(*own) : std::string(configuration->at(settings + "propulsion@Default/engine/Rubber/engine_model/value"));
    }

    /* The engine data used by the module: the project's engine data before the engine database */
    static auto engine_data(const std::string &model) -> EngineData
    {
        return io::load_engine_data(model, {design().directory / "engine_data", engines});
    }

    struct Design
    {
        std::filesystem::path directory;
        std::filesystem::path aircraft;
        std::filesystem::path configuration;
        bool designed{false};
        std::string error;
    };

    inline static const std::filesystem::path references =
        std::filesystem::path{CMAKE_TEST_STUBS_DIR} / ".." / ".." / ".." / ".." / "aircraft_references";
    inline static const std::filesystem::path engines = std::filesystem::path{CMAKE_TEST_STUBS_DIR} / ".." / ".." / ".." / ".." / "engines";
    inline static std::unique_ptr<UniqueTempDirectory> temp;
    inline static std::map<std::string, Design> designs;
    const std::string propulsors = "aircraft_exchange_file/requirements_and_specifications/design_specification/propulsion/propulsor";
    const std::string results = "aircraft_exchange_file/component_design/propulsion/";
};

/* === Tests === */
/**
 * @brief Test that the required thrust of every propulsor is g * MTOM * T/W times its thrust share.
 */
TEST_P(ReferenceAircraftDesign, ThrustDistributedByThrustShare)
{
    /* Design the reference aircraft */
    ASSERT_TRUE(provide_design(GetParam())) << design().error;
    auto document = aixml::openDocument(design().aircraft);

    /* Read the total required thrust g * MTOM * T/W from the aircraft file */
    const double mtom = document->at("aircraft_exchange_file/analysis/masses_cg_inertia/maximum_takeoff_mass/mass_properties/mass/value");
    const double thrust_to_weight = document->at("aircraft_exchange_file/sizing_point/thrust_to_weight/value");
    const double total_thrust = G_FORCE * mtom * thrust_to_weight;

    /* Check the SLST of every propulsor */
    const auto specified = document->getVector(propulsors);
    ASSERT_FALSE(specified.empty());
    for (const node *propulsor : specified)
    {
        const std::string id = propulsor->getStringAttrib("ID");
        const double share = propulsor->at("thrust_share/value");
        EXPECT_NEAR(static_cast<double>(document->at(results + "specific/propulsion@" + id + "/engine/SLST/value")), total_thrust * share,
                    1e-6 * total_thrust);
    }
}

/**
 * @brief Test that every propulsor gets the engine model configured for it.
 */
TEST_P(ReferenceAircraftDesign, EngineModelFromConfiguration)
{
    /* Design the reference aircraft */
    ASSERT_TRUE(provide_design(GetParam())) << design().error;
    auto document = aixml::openDocument(design().aircraft);
    auto configuration = aixml::openDocument(design().configuration);

    /* Check the model of every propulsor against its own or the default entry of the configuration */
    for (const node *propulsor : document->getVector(propulsors))
    {
        const std::string id = propulsor->getStringAttrib("ID");
        EXPECT_EQ(static_cast<std::string>(document->at(results + "specific/propulsion@" + id + "/engine/model/value")),
                  configured_model(configuration, id));
    }
}

/**
 * @brief Test that the engine mass is the dry mass of the engine data scaled with k^1.1 and the technology factor.
 */
TEST_P(ReferenceAircraftDesign, EngineMassScaledFromEngineData)
{
    /* Design the reference aircraft */
    ASSERT_TRUE(provide_design(GetParam())) << design().error;
    auto document = aixml::openDocument(design().aircraft);
    auto configuration = aixml::openDocument(design().configuration);
    const double factor = configuration->at("module_configuration_file/program_settings/technology_factors/engine_mass/value");

    /* Check m = f_m * m_dry * k^1.1 with the dry mass of the engine data used by the module */
    for (const node *propulsor : document->getVector(propulsors))
    {
        const std::string engine = results + "specific/propulsion@" + propulsor->getStringAttrib("ID") + "/engine/";
        const double k = document->at(engine + "scale_factor/value");
        const double dry_mass = engine_data(document->at(engine + "model/value")).dry_mass();
        EXPECT_NEAR(static_cast<double>(document->at(engine + "mass_properties/mass/value")), factor * dry_mass * std::pow(k, 1.1),
                    1e-6 * dry_mass);
    }
}

/**
 * @brief Test that the engine center of gravity is at half the scaled engine length behind the engine position.
 */
TEST_P(ReferenceAircraftDesign, EngineCentreOfGravityAtHalfScaledLength)
{
    /* Design the reference aircraft */
    ASSERT_TRUE(provide_design(GetParam())) << design().error;
    auto document = aixml::openDocument(design().aircraft);

    /* Check CG = engine position + (L0 * k^0.4 / 2, 0, 0) with the length L0 of the engine data used by the module */
    for (const node *propulsor : document->getVector(propulsors))
    {
        const std::string engine = results + "specific/propulsion@" + propulsor->getStringAttrib("ID") + "/engine/";
        const double k = document->at(engine + "scale_factor/value");
        const double length = engine_data(document->at(engine + "model/value")).dimensions().length * std::pow(k, 0.4);
        EXPECT_NEAR(static_cast<double>(document->at(engine + "mass_properties/center_of_gravity/x/value")),
                    static_cast<double>(document->at(engine + "position/x/value")) + 0.5 * length, 1e-6);
        EXPECT_NEAR(static_cast<double>(document->at(engine + "mass_properties/center_of_gravity/y/value")),
                    static_cast<double>(document->at(engine + "position/y/value")), 1e-6);
        EXPECT_NEAR(static_cast<double>(document->at(engine + "mass_properties/center_of_gravity/z/value")),
                    static_cast<double>(document->at(engine + "position/z/value")), 1e-6);
    }
}

/**
 * @brief Test that the nacelle sections are the scaled inner diameter at the ends and 1.21 times of it in the middle.
 */
TEST_P(ReferenceAircraftDesign, NacelleSectionsFromScaledEngineDiameter)
{
    /* Design the reference aircraft */
    ASSERT_TRUE(provide_design(GetParam())) << design().error;
    auto document = aixml::openDocument(design().aircraft);

    /* Check the four sections with the inner diameter D = max(width, height, fan diameter) * k^0.5 of the engine data */
    for (const node *propulsor : document->getVector(propulsors))
    {
        const std::string specific = results + "specific/propulsion@" + propulsor->getStringAttrib("ID") + "/";
        const double k = document->at(specific + "engine/scale_factor/value");
        const Dimensions dimensions = engine_data(document->at(specific + "engine/model/value")).dimensions();
        const double diameter = std::max({dimensions.width, dimensions.height, dimensions.diameter}) * std::sqrt(k);
        const std::string sections = specific + "nacelle@0/sections/section@";
        ASSERT_EQ(document->at(specific + "nacelle@0/sections").getVector("section").size(), 4U);
        EXPECT_NEAR(static_cast<double>(document->at(sections + "0/width/value")), diameter, 1e-6);
        EXPECT_NEAR(static_cast<double>(document->at(sections + "1/width/value")), 1.21 * diameter, 1e-6);
        EXPECT_NEAR(static_cast<double>(document->at(sections + "2/width/value")), 1.21 * diameter, 1e-6);
        EXPECT_NEAR(static_cast<double>(document->at(sections + "3/width/value")), diameter, 1e-6);
    }
}

/**
 * @brief Test that the engine of a left propulsor is the mirror image of the matching right propulsor.
 */
TEST_P(ReferenceAircraftDesign, LeftEngineMirrorsRightEngine)
{
    /* Design the reference aircraft */
    ASSERT_TRUE(provide_design(GetParam())) << design().error;
    auto document = aixml::openDocument(design().aircraft);

    /* Find for every left propulsor the right propulsor with the same parent, position tags and thrust share */
    const auto specified = document->getVector(propulsors);
    std::size_t pairs = 0;
    for (const node *left : specified)
    {
        if (static_cast<std::string>(left->at("position/y/value")) != "left")
        {
            continue;
        }
        for (const node *right : specified)
        {
            if (static_cast<std::string>(right->at("position/y/value")) != "right" ||
                static_cast<std::string>(right->at("position/parent_component/value")) != static_cast<std::string>(left->at("position/parent_component/value")) ||
                static_cast<std::string>(right->at("position/x/value")) != static_cast<std::string>(left->at("position/x/value")) ||
                static_cast<std::string>(right->at("position/z/value")) != static_cast<std::string>(left->at("position/z/value")) ||
                static_cast<double>(right->at("thrust_share/value")) != static_cast<double>(left->at("thrust_share/value")))
            {
                continue;
            }

            /* Check the mirrored engine position: same x and z, opposite y */
            const std::string position_left = results + "specific/propulsion@" + left->getStringAttrib("ID") + "/engine/position/";
            const std::string position_right = results + "specific/propulsion@" + right->getStringAttrib("ID") + "/engine/position/";
            EXPECT_NEAR(static_cast<double>(document->at(position_left + "x/value")), static_cast<double>(document->at(position_right + "x/value")), 1e-6);
            EXPECT_NEAR(static_cast<double>(document->at(position_left + "y/value")), -static_cast<double>(document->at(position_right + "y/value")), 1e-6);
            EXPECT_NEAR(static_cast<double>(document->at(position_left + "z/value")), static_cast<double>(document->at(position_right + "z/value")), 1e-6);
            EXPECT_LT(static_cast<double>(document->at(position_left + "y/value")), 0.0);
            ++pairs;
        }
    }

    /* Check that every left propulsor had a matching right propulsor */
    EXPECT_EQ(pairs, static_cast<std::size_t>(std::count_if(specified.begin(), specified.end(), [](const node *propulsor)
                                                             { return static_cast<std::string>(propulsor->at("position/y/value")) == "left"; })));
}

/**
 * @brief Test that the mass and the center of gravity of the propulsion assembly combine all exported components.
 */
TEST_P(ReferenceAircraftDesign, AggregateMassPropertiesFromComponents)
{
    /* Design the reference aircraft */
    ASSERT_TRUE(provide_design(GetParam())) << design().error;
    auto document = aixml::openDocument(design().aircraft);

    /* Sum the mass and the mass moments of the engine, nacelle and pylon of every propulsor */
    double mass = 0.0;
    double moment_x = 0.0;
    double moment_y = 0.0;
    double moment_z = 0.0;
    for (const node *propulsor : document->getVector(propulsors))
    {
        for (const std::string component : {"engine", "nacelle", "pylon"})
        {
            const std::string properties = results + "specific/propulsion@" + propulsor->getStringAttrib("ID") + "/" + component + "/mass_properties/";
            const double m = document->at(properties + "mass/value");
            mass += m;
            moment_x += m * static_cast<double>(document->at(properties + "center_of_gravity/x/value"));
            moment_y += m * static_cast<double>(document->at(properties + "center_of_gravity/y/value"));
            moment_z += m * static_cast<double>(document->at(properties + "center_of_gravity/z/value"));
        }
    }

    /* Check the total mass and the mass-weighted center of gravity */
    ASSERT_GT(mass, 0.0);
    EXPECT_NEAR(static_cast<double>(document->at(results + "mass_properties/mass/value")), mass, 1e-6 * mass);
    EXPECT_NEAR(static_cast<double>(document->at(results + "mass_properties/center_of_gravity/x/value")), moment_x / mass, 1e-5);
    EXPECT_NEAR(static_cast<double>(document->at(results + "mass_properties/center_of_gravity/y/value")), moment_y / mass, 1e-5);
    EXPECT_NEAR(static_cast<double>(document->at(results + "mass_properties/center_of_gravity/z/value")), moment_z / mass, 1e-5);
}

/* Run every test for every reference aircraft of the repository; the test name is the aircraft name */
INSTANTIATE_TEST_SUITE_P(AllReferenceAircraft, ReferenceAircraftDesign, ::testing::ValuesIn(ReferenceAircraftDesign::find_reference_aircraft()),
                         [](const ::testing::TestParamInfo<std::string> &info)
                         {
                             std::string name = info.param.substr(info.param.find('/') + 1);
                             std::replace(name.begin(), name.end(), '-', '_');
                             return name;
                         });
