/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 *
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <filesystem>
#include <gtest/gtest.h>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include "../temp_directory.h"

/* Unit Under Test */
#include "io/engine_xml.h"
#include "report/report_data.h"

/* === Fixtures === */
/**
 * @brief Temporary engine database with a copy of PW1127G-JM, an empty project engine directory
 * and the design condition Mach 0.78 at 10668 m (ISA).
 */
class ReportData : public ::testing::Test
{
  protected:
    void SetUp() override
    {
        /* Create the project engine directory and the engine database */
        project = temp.path() / "project";
        database = temp.path() / "database";
        std::filesystem::create_directories(project);
        std::filesystem::create_directories(database);

        /* Copy the engine PW1127G-JM of the repository's engine database */
        std::filesystem::copy(engines / "PW1127G-JM", database / "PW1127G-JM", std::filesystem::copy_options::recursive);

        /* Design condition: Mach 0.78 at 10668 m, ISA */
        condition.altitude = 10668.0;
        condition.mach = 0.78;
    }

    void TearDown() override
    {
        /* Restore std::cout */
        stop_capture();
    }

    /* Create an unscaled PW1127G-JM under the wing with the given ID, required thrust and offtakes */
    static auto make_engine(const int id, const double required_thrust, const Offtakes &offtakes) -> Turbofan<EnergyCarrierFamily::Kerosene>
    {
        Turbofan<EnergyCarrierFamily::Kerosene> engine{id, {Parent::Wing, Lateral::Left, Longitudinal::Front, Vertical::Under}, required_thrust, offtakes};
        engine.set_model("PW1127G-JM");
        engine.set_scale(1.0);
        return engine;
    }

    /* Redirect std::cout into a string stream */
    void start_capture()
    {
        captured_cout.str("");
        old_cout = std::cout.rdbuf(captured_cout.rdbuf());
    }

    /* Restore std::cout */
    void stop_capture()
    {
        if (old_cout != nullptr)
        {
            std::cout.rdbuf(old_cout);
            old_cout = nullptr;
        }
    }

    const std::filesystem::path engines = std::filesystem::path{CMAKE_TEST_STUBS_DIR} / ".." / ".." / ".." / ".." / "engines";
    const UniqueTempDirectory temp{"test_report_data"};
    std::filesystem::path project;
    std::filesystem::path database;
    FlightCondition condition;
    std::stringstream captured_cout;
    std::streambuf *old_cout{nullptr};
};

/* The FR-12 tests of the bucket curve calculation use the same fixture under their own suite name */
using BucketCurveFromEngineData = ReportData;

/* === Tests === */
/**
 * @brief Test that the total SLST and the take-off values are the sums over all installed engines.
 */
TEST_F(ReportData, TotalsSumInstalledEngines)
{
    /* Two unscaled engines with 100 kN and 50 kN required thrust */
    std::vector<PropulsionType> propulsions;
    propulsions.emplace_back(make_engine(0, 100000.0, {}));
    propulsions.emplace_back(make_engine(1, 50000.0, {}));

    /* Generate the report data */
    const report::Data data = report::generate_data(propulsions, condition, project, database);

    /* Evaluate the unscaled engine at the take-off rating at sea level */
    auto engine = io::load_engine_scaled("PW1127G-JM", 1.0, {database});
    engine.calculate_N1_with_penalties(0.0, 0.0, condition.ambiance, 1.0, "takeoff", 0.0, 0.0);

    /* Check the sum of the required thrusts and twice the take-off thrust and fuel flow of one engine */
    EXPECT_NEAR(data.SLST_total, 150000.0, 1e-9);
    EXPECT_GT(data.thrust_takeoff, 0.0);
    EXPECT_NEAR(data.thrust_takeoff, 2.0 * engine.get_thrust(), 1e-9 * data.thrust_takeoff);
    EXPECT_GT(data.fuel_flow_takeoff, 0.0);
    EXPECT_NEAR(data.fuel_flow_takeoff, 2.0 * engine.get_fuelflow(), 1e-9 * data.fuel_flow_takeoff);
}

/**
 * @brief Test that the bucket curve of an engine runs from idle to take-off at the design condition.
 */
TEST_F(ReportData, BucketCurveFromIdleToTakeoff)
{
    /* One unscaled engine without offtakes */
    std::vector<PropulsionType> propulsions;
    propulsions.emplace_back(make_engine(0, 100000.0, {}));

    /* Generate the report data */
    const report::Data data = report::generate_data(propulsions, condition, project, database);

    /* Evaluate the unscaled engine at idle and at take-off at the design condition */
    auto engine = io::load_engine_scaled("PW1127G-JM", 1.0, {database});
    engine.calculate_N1_with_penalties(10668.0, 0.78, condition.ambiance, 1.0, "idle", 0.0, 0.0);
    const double thrust_idle = engine.get_thrust();
    const double fuel_flow_idle = engine.get_fuelflow();
    engine.calculate_N1_with_penalties(10668.0, 0.78, condition.ambiance, 1.0, "takeoff", 0.0, 0.0);
    const double thrust_takeoff = engine.get_thrust();
    const double fuel_flow_takeoff = engine.get_fuelflow();

    /* Check the number of points and the first and the last point of the curve */
    const report::BucketCurve &curve = data.bucket_curves.at("without offtakes");
    ASSERT_EQ(curve.thrust().size(), report::bucket_points);
    EXPECT_NEAR(curve.thrust()[0], thrust_idle, 1e-9 * thrust_takeoff);
    EXPECT_NEAR(curve.fuel_flow()[0], fuel_flow_idle, 1e-9 * fuel_flow_takeoff);
    EXPECT_NEAR(curve.thrust()[report::bucket_points - 1], thrust_takeoff, 1e-9 * thrust_takeoff);
    EXPECT_NEAR(curve.fuel_flow()[report::bucket_points - 1], fuel_flow_takeoff, 1e-9 * fuel_flow_takeoff);
}

/**
 * @brief Test that the bucket curves of the aircraft are the sums of the curves of the installed engines.
 */
TEST_F(ReportData, BucketCurvesSumInstalledEngines)
{
    /* One and two identical unscaled engines without offtakes */
    std::vector<PropulsionType> one_engine;
    one_engine.emplace_back(make_engine(0, 100000.0, {}));
    std::vector<PropulsionType> two_engines;
    two_engines.emplace_back(make_engine(0, 100000.0, {}));
    two_engines.emplace_back(make_engine(1, 100000.0, {}));

    /* Generate the report data */
    const report::Data single = report::generate_data(one_engine, condition, project, database);
    const report::Data twin = report::generate_data(two_engines, condition, project, database);

    /* Check that both curves of two engines are twice the curves of one engine and that without offtakes both curves are equal */
    const report::BucketCurve &single_with = single.bucket_curves.at("with offtakes");
    const report::BucketCurve &twin_with = twin.bucket_curves.at("with offtakes");
    const report::BucketCurve &twin_without = twin.bucket_curves.at("without offtakes");
    EXPECT_GT(single_with.thrust()[0], 0.0);
    for (std::size_t i = 0; i < report::bucket_points; ++i)
    {
        EXPECT_NEAR(twin_with.thrust()[i], 2.0 * single_with.thrust()[i], 1e-9 * twin_with.thrust()[i]);
        EXPECT_NEAR(twin_with.fuel_flow()[i], 2.0 * single_with.fuel_flow()[i], 1e-9 * twin_with.fuel_flow()[i]);
        EXPECT_DOUBLE_EQ(twin_without.thrust()[i], twin_with.thrust()[i]);
        EXPECT_DOUBLE_EQ(twin_without.fuel_flow()[i], twin_with.fuel_flow()[i]);
    }
}

/**
 * @brief Test that the bleed air offtake lowers the thrust of the bucket curve with offtakes only.
 */
TEST_F(ReportData, BleedAirOfftakeAppliedToCurveWithOfftakes)
{
    /* One unscaled engine with a bleed air offtake of 0.5 kg/s */
    std::vector<PropulsionType> propulsions;
    propulsions.emplace_back(make_engine(0, 100000.0, {0.5, 0.0}));

    /* Generate the report data */
    const report::Data data = report::generate_data(propulsions, condition, project, database);

    /* Check the thrust at take-off: lower with offtakes than without */
    const report::BucketCurve &with = data.bucket_curves.at("with offtakes");
    const report::BucketCurve &without = data.bucket_curves.at("without offtakes");
    EXPECT_LT(with.thrust()[report::bucket_points - 1], without.thrust()[report::bucket_points - 1]);
    EXPECT_GT(with.thrust()[report::bucket_points - 1], 0.0);
}

/**
 * @brief Test that the report passes the shaft power offtake in W to the engine library.
 */
TEST_F(ReportData, ShaftPowerOfftakePassedInWatt)
{
    /* One unscaled engine with a shaft power offtake of 100000 W, below the deck maximum ShaftPowerExtractionMax = 150 kW of PW1127G-JM */
    std::vector<PropulsionType> propulsions;
    propulsions.emplace_back(make_engine(0, 100000.0, {0.0, 100000.0}));

    /* Generate the report data and capture the output */
    start_capture();
    const report::Data data = report::generate_data(propulsions, condition, project, database);
    stop_capture();

    /* Check that the engine library does not warn about an offtake above the deck maximum, which it converts to W */
    EXPECT_EQ(captured_cout.str().find("Shaft power extraction too high"), std::string::npos);

    /* Evaluate the unscaled engine at take-off at the design condition, where the offtake correction is set */
    auto engine = io::load_engine_scaled("PW1127G-JM", 1.0, {database});
    engine.calculate_N1_with_penalties(10668.0, 0.78, condition.ambiance, 1.0, "takeoff", 0.0, 0.0);
    const double thrust_takeoff = engine.get_thrust();

    /* Check the fuel flow ratio of the curves 1 + 100000 W * c_sh / thrust with c_sh = 0.00228022488 at Mach 0.78 and 10668 m */
    const report::BucketCurve &with = data.bucket_curves.at("with offtakes");
    const report::BucketCurve &without = data.bucket_curves.at("without offtakes");
    EXPECT_DOUBLE_EQ(with.thrust()[0], without.thrust()[0]);
    EXPECT_NEAR(with.fuel_flow()[0] / without.fuel_flow()[0], 1.0 + 100000.0 * 0.00228022488 / thrust_takeoff, 1e-12);
}

/**
 * @brief Test that a failed bucket curve is reported and does not stop the report data.
 */
TEST_F(ReportData, FailedBucketCurveKeepsTotals)
{
    /* Design condition at 20000 m, outside the engine deck */
    condition.altitude = 20000.0;
    std::vector<PropulsionType> propulsions;
    propulsions.emplace_back(make_engine(0, 100000.0, {}));

    /* Generate the report data and capture the output */
    start_capture();
    report::Data data;
    ASSERT_NO_THROW(data = report::generate_data(propulsions, condition, project, database));
    stop_capture();
    const std::string output = captured_cout.str();

    /* Check the messages, the empty curves and the totals at sea level */
    EXPECT_NE(output.find("Bucket curve plot could not be created! Reason:"), std::string::npos);
    EXPECT_NE(output.find("Plot for bucket curve without offtakes could not be created! Reason:"), std::string::npos);
    EXPECT_DOUBLE_EQ(data.bucket_curves.at("with offtakes").thrust()[0], 0.0);
    EXPECT_DOUBLE_EQ(data.bucket_curves.at("without offtakes").thrust()[0], 0.0);
    EXPECT_NEAR(data.SLST_total, 100000.0, 1e-9);
    EXPECT_GT(data.thrust_takeoff, 0.0);
}

/**
 * @brief Test that the bucket curve is evaluated on an even N1 grid from idle to take-off.
 */
TEST_F(BucketCurveFromEngineData, EvenN1GridFromIdleToTakeoff)
{
    /* Calculate the bucket curve of the unscaled engine without offtakes */
    auto engine = io::load_engine_scaled("PW1127G-JM", 1.0, {database});
    const report::BucketCurve curve = report::BucketCurve::from_engine_data(&engine, {}, condition);

    /* Get the idle and the take-off N1 of a second engine at the design condition */
    auto reference = io::load_engine_scaled("PW1127G-JM", 1.0, {database});
    reference.calculate_N1_with_penalties(10668.0, 0.78, condition.ambiance, 1.0, "idle", 0.0, 0.0);
    const double n1_idle = reference.get_operating_point().N;
    reference.calculate_N1_with_penalties(10668.0, 0.78, condition.ambiance, 1.0, "takeoff", 0.0, 0.0);
    const double n1_takeoff = reference.get_operating_point().N;

    /* Evaluate the second engine at the grid points 1 and 50 of N1 = idle + i * (take-off - idle) / 99 */
    auto op = reference.get_operating_point();
    op.N = n1_idle + 1.0 * (n1_takeoff - n1_idle) / 99.0;
    reference.set_operating_point(op);
    const double thrust_1 = reference.get_thrust();
    const double fuel_flow_1 = reference.get_fuelflow();
    op.N = n1_idle + 50.0 * (n1_takeoff - n1_idle) / 99.0;
    reference.set_operating_point(op);
    const double thrust_50 = reference.get_thrust();
    const double fuel_flow_50 = reference.get_fuelflow();

    /* Check the curve at both grid points */
    EXPECT_LT(n1_idle, n1_takeoff);
    EXPECT_NEAR(curve.thrust()[1], thrust_1, 1e-9 * thrust_1);
    EXPECT_NEAR(curve.fuel_flow()[1], fuel_flow_1, 1e-9 * fuel_flow_1);
    EXPECT_NEAR(curve.thrust()[50], thrust_50, 1e-9 * thrust_50);
    EXPECT_NEAR(curve.fuel_flow()[50], fuel_flow_50, 1e-9 * fuel_flow_50);
}

/**
 * @brief Test that the bucket curve calculation leaves the engine at the take-off N1 of the design condition.
 */
TEST_F(BucketCurveFromEngineData, EngineLeftAtTakeoffN1OfDesignCondition)
{
    /* Calculate the bucket curve of the unscaled engine without offtakes */
    auto engine = io::load_engine_scaled("PW1127G-JM", 1.0, {database});
    const report::BucketCurve curve = report::BucketCurve::from_engine_data(&engine, {}, condition);

    /* Get the take-off N1 of a second engine at the design condition */
    auto reference = io::load_engine_scaled("PW1127G-JM", 1.0, {database});
    reference.calculate_N1_with_penalties(10668.0, 0.78, condition.ambiance, 1.0, "takeoff", 0.0, 0.0);

    /* Check the operating point of the engine after the last grid point at take-off: Mach 0.78 and 10668 m */
    EXPECT_GT(curve.thrust()[report::bucket_points - 1], 0.0);
    EXPECT_NEAR(engine.get_operating_point().N, reference.get_operating_point().N, 1e-12);
    EXPECT_NEAR(engine.get_operating_point().Mach, 0.78, 1e-12);
    EXPECT_NEAR(engine.get_operating_point().altitude, 10668.0, 1e-9);
}

/**
 * @brief Test that the bleed air offtake lowers every thrust of the bucket curve by the correction of the take-off point.
 */
TEST_F(BucketCurveFromEngineData, BleedAirCorrectionOfTakeoffApplied)
{
    /* Calculate the bucket curves of the unscaled engine without and with 0.5 kg/s bleed air */
    auto engine = io::load_engine_scaled("PW1127G-JM", 1.0, {database});
    const report::BucketCurve without = report::BucketCurve::from_engine_data(&engine, {}, condition);
    const report::BucketCurve with = report::BucketCurve::from_engine_data(&engine, {0.5, 0.0}, condition);

    /* Get the thrust ratio with and without 0.5 kg/s bleed air at take-off at the design condition */
    auto reference = io::load_engine_scaled("PW1127G-JM", 1.0, {database});
    reference.calculate_N1_with_penalties(10668.0, 0.78, condition.ambiance, 1.0, "takeoff", 0.0, 0.0);
    const double thrust_0 = reference.get_thrust();
    reference.calculate_N1_with_penalties(10668.0, 0.78, condition.ambiance, 1.0, "takeoff", 0.5, 0.0);
    const double ratio = reference.get_thrust() / thrust_0;

    /* Check every point: thrust * ratio and unchanged fuel flow */
    EXPECT_LT(ratio, 1.0);
    for (std::size_t i = 0; i < report::bucket_points; ++i)
    {
        EXPECT_NEAR(with.thrust()[i], without.thrust()[i] * ratio, 1e-9 * without.thrust()[i]);
        EXPECT_NEAR(with.fuel_flow()[i], without.fuel_flow()[i], 1e-12 * without.fuel_flow()[i]);
    }
}
