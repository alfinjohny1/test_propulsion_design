/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 *
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <gtest/gtest.h>
#include <valarray>

/* Unit Under Test */
#include "report/report_data.h"

/* === Tests === */
/**
 * @brief Test the size of a default bucket curve.
 */
TEST(BucketCurve, DefaultSize)
{
    const report::BucketCurve curve{};

    EXPECT_EQ(curve.thrust().size(), report::bucket_points);
    EXPECT_EQ(curve.fuel_flow().size(), report::bucket_points);
}

/**
 * @brief Test constructing a bucket curve and setting its values.
 */
TEST(BucketCurve, ConstructorAndSetters)
{
    report::BucketCurve curve{{100.0, 200.0}, {1.0, 3.0}};
    ASSERT_EQ(curve.thrust().size(), 2U);
    EXPECT_NEAR(curve.thrust()[0], 100.0, 1e-12);
    EXPECT_NEAR(curve.thrust()[1], 200.0, 1e-12);
    ASSERT_EQ(curve.fuel_flow().size(), 2U);
    EXPECT_NEAR(curve.fuel_flow()[0], 1.0, 1e-12);
    EXPECT_NEAR(curve.fuel_flow()[1], 3.0, 1e-12);

    curve.set_thrust({10.0, 20.0, 30.0});
    curve.set_fuel_flow({0.1, 0.2, 0.3});
    ASSERT_EQ(curve.thrust().size(), 3U);
    EXPECT_NEAR(curve.thrust()[0], 10.0, 1e-12);
    EXPECT_NEAR(curve.thrust()[1], 20.0, 1e-12);
    EXPECT_NEAR(curve.thrust()[2], 30.0, 1e-12);
    ASSERT_EQ(curve.fuel_flow().size(), 3U);
    EXPECT_NEAR(curve.fuel_flow()[0], 0.1, 1e-12);
    EXPECT_NEAR(curve.fuel_flow()[1], 0.2, 1e-12);
    EXPECT_NEAR(curve.fuel_flow()[2], 0.3, 1e-12);
}

/**
 * @brief Test calculating the TSFC of a bucket curve.
 */
TEST(BucketCurve, TsfcIsFuelFlowOverThrust)
{
    const report::BucketCurve curve{{100.0, 200.0, 400.0}, {1.0, 1.0, 2.0}};

    ASSERT_EQ(curve.tsfc().size(), 3U);
    EXPECT_NEAR(curve.tsfc()[0], 0.01, 1e-12);
    EXPECT_NEAR(curve.tsfc()[1], 0.005, 1e-12);
    EXPECT_NEAR(curve.tsfc()[2], 0.005, 1e-12);
}

/**
 * @brief Test finding the bucket point at the minimum TSFC.
 */
TEST(BucketCurve, BucketPointAtMinimumTsfc)
{
    report::BucketCurve curve{{100.0, 200.0, 300.0}, {2.0, 1.0, 3.0}}; // TSFC: 0.02, 0.005, 0.01

    const BucketPoint point = curve.bucket_point();

    EXPECT_NEAR(point.thrust, 200.0, 1e-12);
    EXPECT_NEAR(point.tsfc, 0.005, 1e-12);
}

/**
 * @brief Test finding the bucket point at the ends of the curve.
 */
TEST(BucketCurve, BucketPointAtCurveEnds)
{
    report::BucketCurve first{{100.0, 200.0, 300.0}, {0.5, 2.0, 3.0}}; // TSFC: 0.005, 0.01, 0.01
    EXPECT_NEAR(first.bucket_point().thrust, 100.0, 1e-12);

    report::BucketCurve last{{100.0, 200.0, 300.0}, {2.0, 3.0, 0.3}}; // TSFC: 0.02, 0.015, 0.001
    EXPECT_NEAR(last.bucket_point().thrust, 300.0, 1e-12);
}

/**
 * @brief Test finding the bucket point with equal minima.
 */
TEST(BucketCurve, BucketPointTieTakesFirst)
{
    report::BucketCurve curve{{100.0, 200.0, 400.0}, {1.0, 1.0, 2.0}}; // TSFC: 0.01, 0.005, 0.005

    EXPECT_NEAR(curve.bucket_point().thrust, 200.0, 1e-12);
}

/**
 * @brief Test the const bucket point of a bucket curve.
 */
TEST(BucketCurve, ConstBucketPointMatches)
{
    report::BucketCurve curve{{100.0, 200.0, 300.0}, {2.0, 1.0, 3.0}};
    const report::BucketCurve &const_curve = curve;

    const BucketPoint from_const = const_curve.bucket_point(); // not cached yet -> computed
    const BucketPoint from_non_const = curve.bucket_point();   // computes and caches
    const BucketPoint from_const_cached = const_curve.bucket_point();

    EXPECT_NEAR(from_const.thrust, from_non_const.thrust, 1e-12);
    EXPECT_NEAR(from_const.tsfc, from_non_const.tsfc, 1e-12);
    EXPECT_NEAR(from_const_cached.thrust, from_non_const.thrust, 1e-12);
    EXPECT_NEAR(from_const_cached.tsfc, from_non_const.tsfc, 1e-12);
}

/**
 * @brief Test updating the cached bucket point.
 */
TEST(BucketCurve, UpdateBucketPoint)
{
    report::BucketCurve curve{{100.0, 200.0, 300.0}, {2.0, 1.0, 3.0}};
    curve.update_bucket_point();
    const report::BucketCurve &const_curve = curve;

    EXPECT_NEAR(const_curve.bucket_point().thrust, 200.0, 1e-12);
    EXPECT_NEAR(const_curve.bucket_point().tsfc, 0.005, 1e-12);
}

/**
 * @brief Test adding two bucket curves.
 */
TEST(BucketCurve, AdditionIsElementWise)
{
    const report::BucketCurve lhs{{100.0, 200.0, 300.0}, {2.0, 1.0, 3.0}};
    const report::BucketCurve rhs{{50.0, 100.0, 150.0}, {0.5, 1.5, 0.5}};

    const report::BucketCurve sum = lhs + rhs;

    ASSERT_EQ(sum.thrust().size(), 3U);
    EXPECT_NEAR(sum.thrust()[0], 150.0, 1e-12);
    EXPECT_NEAR(sum.thrust()[1], 300.0, 1e-12);
    EXPECT_NEAR(sum.thrust()[2], 450.0, 1e-12);
    ASSERT_EQ(sum.fuel_flow().size(), 3U);
    EXPECT_NEAR(sum.fuel_flow()[0], 2.5, 1e-12);
    EXPECT_NEAR(sum.fuel_flow()[1], 2.5, 1e-12);
    EXPECT_NEAR(sum.fuel_flow()[2], 3.5, 1e-12);
    ASSERT_EQ(lhs.thrust().size(), 3U);
    EXPECT_NEAR(lhs.thrust()[0], 100.0, 1e-12);
    EXPECT_NEAR(lhs.thrust()[1], 200.0, 1e-12);
    EXPECT_NEAR(lhs.thrust()[2], 300.0, 1e-12);
    ASSERT_EQ(rhs.fuel_flow().size(), 3U);
    EXPECT_NEAR(rhs.fuel_flow()[0], 0.5, 1e-12);
    EXPECT_NEAR(rhs.fuel_flow()[1], 1.5, 1e-12);
    EXPECT_NEAR(rhs.fuel_flow()[2], 0.5, 1e-12);
}

/**
 * @brief Test the bucket point of the sum of two bucket curves.
 */
TEST(BucketCurve, BucketPointOfSumUsesSummedCurve)
{
    const report::BucketCurve lhs{{100.0, 200.0, 300.0}, {2.0, 1.0, 3.0}};  // bucket at index 1
    const report::BucketCurve rhs{{100.0, 100.0, 100.0}, {0.5, 2.0, 0.1}}; // bucket at index 2

    report::BucketCurve sum = lhs + rhs; // thrust 200, 300, 400; fuel flow 2.5, 3.0, 3.1
                                         // TSFC   0.0125, 0.01, 0.00775 -> index 2
    const BucketPoint point = sum.bucket_point();

    EXPECT_NEAR(point.thrust, 400.0, 1e-12);
    EXPECT_NEAR(point.tsfc, 3.1 / 400.0, 1e-12);
}

/**
 * @brief Test adding a bucket curve in place.
 */
TEST(BucketCurve, PlusAssignMatchesPlus)
{
    const report::BucketCurve lhs{{100.0, 200.0, 300.0}, {2.0, 1.0, 3.0}};
    const report::BucketCurve rhs{{50.0, 100.0, 150.0}, {0.5, 1.5, 0.5}};

    report::BucketCurve accumulated = lhs;
    accumulated += rhs;
    const report::BucketCurve sum = lhs + rhs;

    ASSERT_EQ(accumulated.thrust().size(), 3U);
    EXPECT_NEAR(accumulated.thrust()[0], sum.thrust()[0], 1e-12);
    EXPECT_NEAR(accumulated.thrust()[1], sum.thrust()[1], 1e-12);
    EXPECT_NEAR(accumulated.thrust()[2], sum.thrust()[2], 1e-12);
    EXPECT_NEAR(accumulated.fuel_flow()[0], sum.fuel_flow()[0], 1e-12);
    EXPECT_NEAR(accumulated.fuel_flow()[1], sum.fuel_flow()[1], 1e-12);
    EXPECT_NEAR(accumulated.fuel_flow()[2], sum.fuel_flow()[2], 1e-12);
}

/**
 * @brief Test that adding in place invalidates the cached bucket point.
 */
TEST(BucketCurve, PlusAssignInvalidatesCachedBucketPoint)
{
    report::BucketCurve curve{{100.0, 200.0, 300.0}, {2.0, 1.0, 3.0}};
    ASSERT_NEAR(curve.bucket_point().thrust, 200.0, 1e-12); // cached at index 1

    curve += report::BucketCurve{{100.0, 100.0, 100.0}, {0.5, 2.0, 0.1}};

    EXPECT_NEAR(curve.bucket_point().thrust, 400.0, 1e-12); // now index 2
    const report::BucketCurve &const_curve = curve;
    EXPECT_NEAR(const_curve.bucket_point().thrust, 400.0, 1e-12);
}

/**
 * @brief Test accumulating bucket curves from a default curve.
 */
TEST(BucketCurve, AccumulateFromDefaultCurve)
{
    /* Create an engine curve with full size */
    report::BucketCurve total{};
    const std::valarray<double> thrust(1000.0, report::bucket_points);
    const std::valarray<double> fuel_flow(0.02, report::bucket_points);
    const report::BucketCurve engine{thrust, fuel_flow};

    /* Add the engine curve twice to the default curve */
    total += engine;
    total += engine;

    /* Check the summed curve; doubling is exact, so the values are compared exactly */
    ASSERT_EQ(total.thrust().size(), report::bucket_points);
    EXPECT_TRUE((total.thrust() == 2.0 * thrust).min());
    EXPECT_TRUE((total.fuel_flow() == 2.0 * fuel_flow).min());
    EXPECT_TRUE((total.tsfc() == engine.tsfc()).min());
}
