/*
 * UNICADO - UNIversity Conceptual Aircraft Design and Optimization
 *
 * Copyright (C) 2025 UNICADO consortium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Description:
 * This file is part of UNICADO.
 */

/* === Includes === */
#include <gtest/gtest.h>
#include <aircraftGeometry2/geometry/builder.h>
#include <string>

/* Unit Under Test */
#include "io/aircraft_xml.h"

/* === Fixtures === */

/* === Tests === */
/**
 * @brief Test creating the propulsion node with its children in an aircraft xml without propulsion data.
 */
TEST(AircraftXMLData, CreatesPropulsionNode)
{
    /* Create an empty aircraft xml and the file interface */
    std::shared_ptr<node> aircraft = std::make_shared<node>("file.xml");
    io::AircraftXML xml{aircraft};

    /* Check the propulsion node and its children */
    EXPECT_NE(aircraft->find("aircraft_exchange_file/component_design/propulsion"), nullptr);
    EXPECT_NE(aircraft->find("aircraft_exchange_file/component_design/propulsion/position"), nullptr);
    EXPECT_NE(aircraft->find("aircraft_exchange_file/component_design/propulsion/mass_properties"), nullptr);
    EXPECT_NE(aircraft->find("aircraft_exchange_file/component_design/propulsion/specific"), nullptr);
}

/**
 * @brief Test that an existing propulsion node is kept.
 */
TEST(AircraftXMLData, KeepsExistingPropulsionNode)
{
    /* Create an aircraft xml with an existing propulsion node and the file interface */
    std::shared_ptr<node> aircraft = std::make_shared<node>("file.xml");
    (*aircraft)[std::string{"aircraft_exchange_file/component_design/propulsion/note/value"}] = std::string{"existing"};
    io::AircraftXML xml{aircraft};

    /* Check that the existing data is kept and no children are added */
    EXPECT_EQ(std::string(aircraft->at("aircraft_exchange_file/component_design/propulsion/note/value")), "existing");
    EXPECT_EQ(aircraft->find("aircraft_exchange_file/component_design/propulsion/position"), nullptr);
    EXPECT_EQ(aircraft->find("aircraft_exchange_file/component_design/propulsion/specific"), nullptr);
}

/**
 * @brief Test inserting the mass properties of the propulsion assembly with every inertia entry.
 */
TEST(AircraftXMLData, MassPropertiesWithAllInertiaEntries)
{
    /* Create the mass properties: 500 kg at (1, 2, 3) with a different value in every inertia entry */
    std::shared_ptr<node> aircraft = std::make_shared<node>("file.xml");
    PointMass mass_properties;
    mass_properties.mass = 500.0;
    mass_properties.CG = Eigen::Vector3d(1.0, 2.0, 3.0);
    mass_properties.inertia << 11.0, 12.0, 13.0,
                               21.0, 22.0, 23.0,
                               31.0, 32.0, 33.0;

    /* Insert the mass properties */
    io::AircraftXML{aircraft}.insert(mass_properties);

    /* Check mass, CG and every inertia entry with its row and column, and the units */
    const std::string base = "aircraft_exchange_file/component_design/propulsion/mass_properties/";
    EXPECT_DOUBLE_EQ(aircraft->at(base + "mass/value"), 500.0);
    EXPECT_EQ(std::string(aircraft->at(base + "mass/unit")), "kg");
    EXPECT_DOUBLE_EQ(aircraft->at(base + "center_of_gravity/x/value"), 1.0);
    EXPECT_DOUBLE_EQ(aircraft->at(base + "center_of_gravity/y/value"), 2.0);
    EXPECT_DOUBLE_EQ(aircraft->at(base + "center_of_gravity/z/value"), 3.0);
    EXPECT_EQ(std::string(aircraft->at(base + "center_of_gravity/x/unit")), "m");
    EXPECT_DOUBLE_EQ(aircraft->at(base + "inertia/j_xx/value"), 11.0);
    EXPECT_DOUBLE_EQ(aircraft->at(base + "inertia/j_xy/value"), 12.0);
    EXPECT_DOUBLE_EQ(aircraft->at(base + "inertia/j_xz/value"), 13.0);
    EXPECT_DOUBLE_EQ(aircraft->at(base + "inertia/j_yx/value"), 21.0);
    EXPECT_DOUBLE_EQ(aircraft->at(base + "inertia/j_yy/value"), 22.0);
    EXPECT_DOUBLE_EQ(aircraft->at(base + "inertia/j_yz/value"), 23.0);
    EXPECT_DOUBLE_EQ(aircraft->at(base + "inertia/j_zx/value"), 31.0);
    EXPECT_DOUBLE_EQ(aircraft->at(base + "inertia/j_zy/value"), 32.0);
    EXPECT_DOUBLE_EQ(aircraft->at(base + "inertia/j_zz/value"), 33.0);
    EXPECT_EQ(std::string(aircraft->at(base + "inertia/j_xx/unit")), "kgm^2");
}

/**
 * @brief Test inserting the thrust, scale and bucket point of a kerosene turbofan engine.
 */
TEST(AircraftXMLData, EngineThrustScaleAndBucketPoint)
{
    /* Create the engine with thrust 120 kN, scale 1.5 and bucket point (30 kN, 1.6e-5 kg/Ns) */
    std::shared_ptr<node> aircraft = std::make_shared<node>("file.xml");
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0};
    engine.set_required_thrust(120000.0);
    engine.set_scale(1.5);
    engine.set_bucket_point({30000.0, 1.6e-5});
    engine.set_position({1.0, 2.0, 3.0});

    /* Insert the engine */
    io::AircraftXML{aircraft}.insert(engine);

    /* Check the values and the units */
    const std::string base = "aircraft_exchange_file/component_design/propulsion/specific/propulsion@0/engine/";
    EXPECT_DOUBLE_EQ(aircraft->at(base + "SLST/value"), 120000.0);
    EXPECT_EQ(std::string(aircraft->at(base + "SLST/unit")), "N");
    EXPECT_DOUBLE_EQ(aircraft->at(base + "scale_factor/value"), 1.5);
    EXPECT_EQ(std::string(aircraft->at(base + "scale_factor/unit")), "1");
    EXPECT_DOUBLE_EQ(aircraft->at(base + "bucket_point/thrust/value"), 30000.0);
    EXPECT_EQ(std::string(aircraft->at(base + "bucket_point/thrust/unit")), "N");
    EXPECT_DOUBLE_EQ(aircraft->at(base + "bucket_point/tsfc/value"), 1.6e-5);
    EXPECT_EQ(std::string(aircraft->at(base + "bucket_point/tsfc/unit")), "kg/Ns");
    EXPECT_EQ(std::string(aircraft->at(base + "position/x/unit")), "m");
}

/**
 * @brief Test inserting the mass properties of the engine, nacelle and pylon of a kerosene turbofan engine.
 */
TEST(AircraftXMLData, EngineNacelleAndPylonMassProperties)
{
    /* Create the engine with three different point masses */
    std::shared_ptr<node> aircraft = std::make_shared<node>("file.xml");
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0};
    engine.set_pointmass(Component::Engine, {Eigen::Vector3d(1.0, 0.0, 0.0), Eigen::Matrix3d::Identity(), 2000.0});
    engine.set_pointmass(Component::Nacelle, {Eigen::Vector3d(0.5, 0.1, 0.2), 2.0 * Eigen::Matrix3d::Identity(), 600.0});
    engine.set_pointmass(Component::Pylon, {Eigen::Vector3d(0.7, 0.0, -0.8), 3.0 * Eigen::Matrix3d::Identity(), 240.0});

    /* Insert the engine */
    io::AircraftXML{aircraft}.insert(engine);

    /* Check the point masses of the three components */
    const std::string base = "aircraft_exchange_file/component_design/propulsion/specific/propulsion@0/";
    EXPECT_DOUBLE_EQ(aircraft->at(base + "engine/mass_properties/mass/value"), 2000.0);
    EXPECT_DOUBLE_EQ(aircraft->at(base + "engine/mass_properties/center_of_gravity/x/value"), 1.0);
    EXPECT_DOUBLE_EQ(aircraft->at(base + "engine/mass_properties/inertia/j_yy/value"), 1.0);
    EXPECT_DOUBLE_EQ(aircraft->at(base + "nacelle/mass_properties/mass/value"), 600.0);
    EXPECT_DOUBLE_EQ(aircraft->at(base + "nacelle/mass_properties/center_of_gravity/y/value"), 0.1);
    EXPECT_DOUBLE_EQ(aircraft->at(base + "nacelle/mass_properties/inertia/j_yy/value"), 2.0);
    EXPECT_DOUBLE_EQ(aircraft->at(base + "pylon/mass_properties/mass/value"), 240.0);
    EXPECT_DOUBLE_EQ(aircraft->at(base + "pylon/mass_properties/center_of_gravity/z/value"), -0.8);
    EXPECT_DOUBLE_EQ(aircraft->at(base + "pylon/mass_properties/inertia/j_yy/value"), 3.0);
}

/**
 * @brief Test inserting a liquid hydrogen turbofan and an open-rotor engine.
 */
TEST(AircraftXMLData, LiquidHydrogenAndOpenRotorEngines)
{
    /* Create a liquid hydrogen turbofan with ID 0 and an open rotor with ID 1 */
    std::shared_ptr<node> aircraft = std::make_shared<node>("file.xml");
    Turbofan<EnergyCarrierFamily::Liquid_Hydrogen> turbofan{0};
    turbofan.set_model("PW1127G-JM-H2");
    Openrotorfan<EnergyCarrierFamily::Kerosene> openrotor{1};
    openrotor.set_model("CROR");

    /* Insert both engines */
    io::AircraftXML{aircraft}.insert(turbofan);
    io::AircraftXML{aircraft}.insert(openrotor);

    /* Check the models under the IDs of the engines */
    const std::string base = "aircraft_exchange_file/component_design/propulsion/specific/";
    EXPECT_EQ(std::string(aircraft->at(base + "propulsion@0/engine/model/value")), "PW1127G-JM-H2");
    EXPECT_EQ(std::string(aircraft->at(base + "propulsion@1/engine/model/value")), "CROR");
}

/**
 * @brief Test inserting two engines in descending order of their IDs (open question: not required by FR-9 as written).
 */
TEST(AircraftXMLData, EnginesWrittenInAnyIdOrder)
{
    /* Create the engines with ID 1 and ID 0 */
    std::shared_ptr<node> aircraft = std::make_shared<node>("file.xml");
    Turbofan<EnergyCarrierFamily::Kerosene> engine_1{1};
    engine_1.set_model("second");
    Turbofan<EnergyCarrierFamily::Kerosene> engine_0{0};
    engine_0.set_model("first");

    /* Insert the engine with ID 1 first */
    ASSERT_NO_THROW(io::AircraftXML{aircraft}.insert(engine_1));
    ASSERT_NO_THROW(io::AircraftXML{aircraft}.insert(engine_0));

    /* Check the models under the IDs of the engines */
    const std::string base = "aircraft_exchange_file/component_design/propulsion/specific/";
    EXPECT_EQ(std::string(aircraft->at(base + "propulsion@0/engine/model/value")), "first");
    EXPECT_EQ(std::string(aircraft->at(base + "propulsion@1/engine/model/value")), "second");
}

/**
 * @brief Test inserting the nacelle and pylon geometry of a kerosene turbofan engine.
 */
TEST(AircraftXMLData, NacelleAndPylonGeometry)
{
    /* Nacelle with sections of 1 m at z = 0 and 2 m x 1.5 m at z = 2; pylon with chords 1.125 m and 1.4 m */
    std::shared_ptr<node> aircraft = std::make_shared<node>("file.xml");
    geom2::PolygonSection circle = geom2::build::ellipse(1.0, 1.0);
    geom2::MultisectionSurface<geom2::PolygonSection> nacelle;
    nacelle.sections.emplace_back(circle);
    nacelle.sections.emplace_back(circle);
    nacelle.sections.at(1).origin = geom2::Point_3(0, 0, 2.0);
    nacelle.sections.at(1).set_width(2.0);
    nacelle.sections.at(1).set_height(1.5);
    geom2::Polygon_2 airfoil;
    airfoil.push_back({0.0, 0.0});
    airfoil.push_back({0.5, -0.1});
    airfoil.push_back({1.0, 0.0});
    airfoil.push_back({0.5, 0.1});
    geom2::MultisectionSurface<geom2::AirfoilSection> pylon;
    pylon.sections.emplace_back(airfoil);
    pylon.sections.emplace_back(airfoil);
    pylon.sections.at(0).set_chord_length(1.125);
    pylon.sections.at(1).set_chord_length(1.4);
    pylon.sections.at(1).origin = geom2::Point_3(1.0, 0.0, -3.0);
    Turbofan<EnergyCarrierFamily::Kerosene> engine{0};
    engine.set_nacelle(nacelle);
    engine.set_pylon(pylon);

    /* Insert the engine */
    io::AircraftXML{aircraft}.insert(engine);

    /* Check the nacelle sections */
    const std::string base = "aircraft_exchange_file/component_design/propulsion/specific/propulsion@0/";
    ASSERT_NE(aircraft->find(base + "nacelle@0/sections"), nullptr);
    EXPECT_EQ(aircraft->find(base + "nacelle@0/sections")->getVector("section").size(), 2U);
    EXPECT_DOUBLE_EQ(aircraft->at(base + "nacelle@0/sections/section@1/origin/z/value"), 2.0);
    EXPECT_NEAR(static_cast<double>(aircraft->at(base + "nacelle@0/sections/section@1/width/value")), 2.0, 1e-9);
    EXPECT_NEAR(static_cast<double>(aircraft->at(base + "nacelle@0/sections/section@1/height/value")), 1.5, 1e-9);

    /* Check the pylon sections */
    ASSERT_NE(aircraft->find(base + "pylon@0/sections"), nullptr);
    EXPECT_EQ(aircraft->find(base + "pylon@0/sections")->getVector("section").size(), 2U);
    EXPECT_NEAR(static_cast<double>(aircraft->at(base + "pylon@0/sections/section@0/chord_length/value")), 1.125, 1e-9);
    EXPECT_NEAR(static_cast<double>(aircraft->at(base + "pylon@0/sections/section@1/chord_length/value")), 1.4, 1e-9);
    EXPECT_DOUBLE_EQ(aircraft->at(base + "pylon@0/sections/section@1/origin/x/value"), 1.0);
    EXPECT_DOUBLE_EQ(aircraft->at(base + "pylon@0/sections/section@1/origin/z/value"), -3.0);
}
